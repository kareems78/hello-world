DROP TABLE IF EXISTS "ecategory";
CREATE TABLE "ecategory" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "emaincategory" integer NOT NULL,
  "description" text DEFAULT NULL,
    CONSTRAINT "FKECATEGORY_EMCAT" FOREIGN KEY ("emaincategory") REFERENCES "emaincategory" ("id")
);
INSERT INTO "ecategory" VALUES(1,'Bath/Misc',1,'');
INSERT INTO "ecategory" VALUES(2,'Bath/Necessities',1,'');
INSERT INTO "ecategory" VALUES(3,'Bills/Electricity',2,'');
INSERT INTO "ecategory" VALUES(4,'Bills/Rent',2,'');
INSERT INTO "ecategory" VALUES(5,'Bills/Utilities',2,'');
INSERT INTO "ecategory" VALUES(6,'Bills/Vonage',2,'');
INSERT INTO "ecategory" VALUES(7,'Bills/Wireless',2,'');
INSERT INTO "ecategory" VALUES(8,'Car/Gas',3,'');
INSERT INTO "ecategory" VALUES(9,'Car/Misc',3,'');
INSERT INTO "ecategory" VALUES(10,'Car/Oil Change',3,'');
INSERT INTO "ecategory" VALUES(11,'Car/Repairs',3,'');
INSERT INTO "ecategory" VALUES(12,'Clothes/Aalia',4,'');
INSERT INTO "ecategory" VALUES(13,'Clothes/Hafsa',4,'');
INSERT INTO "ecategory" VALUES(14,'Clothes/Kareem',4,'');
INSERT INTO "ecategory" VALUES(15,'Clothes/Shahana',4,'');
INSERT INTO "ecategory" VALUES(16,'Food/Fruits',5,'');
INSERT INTO "ecategory" VALUES(17,'Food/Grocery',5,'');
INSERT INTO "ecategory" VALUES(18,'Food/Meat',5,'');
INSERT INTO "ecategory" VALUES(19,'Food/Misc',5,'');
INSERT INTO "ecategory" VALUES(20,'Food/Restaurants',5,'');
INSERT INTO "ecategory" VALUES(21,'Food/Snacks',5,'');
INSERT INTO "ecategory" VALUES(22,'Home/Decor',7,'');
INSERT INTO "ecategory" VALUES(23,'Home/Electronics',7,'');
INSERT INTO "ecategory" VALUES(24,'Home/Misc',7,'');
INSERT INTO "ecategory" VALUES(25,'Home/Necessities',7,'');
INSERT INTO "ecategory" VALUES(26,'KitchenWare',8,'');
INSERT INTO "ecategory" VALUES(27,'Medical/Aalia',9,'');
INSERT INTO "ecategory" VALUES(28,'Medical/Hafsa',9,'');
INSERT INTO "ecategory" VALUES(29,'Medical/Kareem',9,'');
INSERT INTO "ecategory" VALUES(30,'Medical/Shahana',9,'');
INSERT INTO "ecategory" VALUES(31,'Misc',11,'');
INSERT INTO "ecategory" VALUES(32,'Personal Care',12,'');
INSERT INTO "ecategory" VALUES(33,'School/Misc',13,'');
INSERT INTO "ecategory" VALUES(34,'School/Tution',13,'');
INSERT INTO "ecategory" VALUES(35,'Transport',14,'');
INSERT INTO "ecategory" VALUES(36,'Food/Fish',5,'');
INSERT INTO "ecategory" VALUES(37,'Baby Expenses',11,'Food, Diapers etc');
INSERT INTO "ecategory" VALUES(38,'Gift',6,'');
INSERT INTO "ecategory" VALUES(39,'Medicines',10,'');
INSERT INTO "ecategory" VALUES(40,'Car/Service',3,'');
INSERT INTO "ecategory" VALUES(41,'Food/Milk',5,'');
INSERT INTO "ecategory" VALUES(42,'Trip Expenses',15,'');
INSERT INTO "ecategory" VALUES(43,'Clothes/Misc',4,'');
INSERT INTO "ecategory" VALUES(44,'Medical/General',9,'');
INSERT INTO "ecategory" VALUES(45,'Medical/Misc',9,'');
INSERT INTO "ecategory" VALUES(46,'Home/Laundry',7,'');
