<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>Chrome version</title>
<h1>Chrome version</h1>

<script>document.write(navigator.userAgent);</script>
