<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>


<h1>SQLite</h1>

<?php

error_reporting(-1);
include "./_pdo.php";
$db_file = "./tstdb.db";
PDO_Connect("sqlite:$db_file");
echo("PDO_Connect(): success!<br> $db_file file created");

$query = "select id, name, description from module";

$result = PDO_FetchAll($query);

//print_r($result);
echo "<br>";

echo "<table>";

foreach ($result as $rows => $row) {
	
	
  echo  '<tr><td>'.  $row['id'].'</td><td>'. $row['name']. '</td></tr>';
  }
  
  echo "</table>";

?>