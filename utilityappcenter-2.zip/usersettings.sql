DROP TABLE IF EXISTS "usersettings";
CREATE TABLE "usersettings" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "user" integer NOT NULL,
  "identifier" text NOT NULL,
  "value" text NOT NULL,
  "visible" text DEFAULT NULL,
  "description" blob DEFAULT NULL
 );
INSERT INTO "usersettings" VALUES(1,2,'homepage','123123',NULL,NULL);
INSERT INTO "usersettings" VALUES(2,2,'module','6','yes','Admin Apps');
INSERT INTO "usersettings" VALUES(3,2,'module','2','yes','Personal Apps');
INSERT INTO "usersettings" VALUES(4,2,'module','3','yes','Islamic Apps');
INSERT INTO "usersettings" VALUES(5,2,'module','4','yes','Misc Apps');
INSERT INTO "usersettings" VALUES(6,2,'module','8','yes','Work Apps');
INSERT INTO "usersettings" VALUES(7,2,'submodule','2','yes','Tasks');
INSERT INTO "usersettings" VALUES(8,2,'submodule','3','yes','Expenses');
INSERT INTO "usersettings" VALUES(9,2,'submodule','4','yes','Credentials');
INSERT INTO "usersettings" VALUES(10,2,'submodule','26','yes','Misc');
INSERT INTO "usersettings" VALUES(11,2,'submodule','6','yes','Weight Recorder');
INSERT INTO "usersettings" VALUES(12,2,'submodule','7','yes','Credit Payment');
INSERT INTO "usersettings" VALUES(13,2,'submodule','8','yes','Funds Transfer');
INSERT INTO "usersettings" VALUES(14,2,'submodule','9','yes','URL Store');
INSERT INTO "usersettings" VALUES(15,2,'submodule','11','yes','Salah Timings');
INSERT INTO "usersettings" VALUES(16,2,'submodule','13','yes','Salah Tracker');
INSERT INTO "usersettings" VALUES(17,2,'submodule','14','yes','Remainders');
INSERT INTO "usersettings" VALUES(18,2,'submodule','15','yes','Biometrics');
INSERT INTO "usersettings" VALUES(19,2,'submodule','20','yes','Online Orders');
INSERT INTO "usersettings" VALUES(20,2,'submodule','21','yes','Users');
INSERT INTO "usersettings" VALUES(21,2,'submodule','23','yes','Modules');
INSERT INTO "usersettings" VALUES(22,2,'submodule','24','yes','Categories');
INSERT INTO "usersettings" VALUES(23,2,'submodule','25','yes','ATT');
INSERT INTO "usersettings" VALUES(24,2,'monthlyexpensesyear','2016','','Monthly Expenses Report Year');
INSERT INTO "usersettings" VALUES(25,2,'categorizedexpensesmonth','01',NULL,'Expense Category Month');
INSERT INTO "usersettings" VALUES(26,2,'categorizedexpensesyear','2016',NULL,'Expense Category Year');
