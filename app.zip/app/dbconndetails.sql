BEGIN TRANSACTION;
CREATE TABLE "dbconndetails" (
"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE , 
"envname" TEXT NOT NULL , 
"username" INTEGER NOT NULL , 
"password" INTEGER NOT NULL , 
"dbhost" INTEGER NOT NULL, 
"dbport" INTEGER NOT NULL, 
"sid" INTEGER NOT NULL
);
INSERT INTO `dbconndetails` VALUES (1,'ST9_AMD','Cramer','att4t2015','139.76.213.209',11200,'lci9t1');
INSERT INTO `dbconndetails` VALUES (2,'ST9_ATT','Cramer','att4t2015','nmsis9d1.snt.bst.bls.com',1521,'lci9t1');
INSERT INTO `dbconndetails` VALUES (3,'IT7_AMD','Cramer','att4i2015','139.76.213.210',10181,'lci7i1');
INSERT INTO `dbconndetails` VALUES (4,'IT7_ATT','Cramer','att4i2015','nmsii7d1.snt.bst.bls.com',1521,'lci7i1');
INSERT INTO `dbconndetails` VALUES (5,'IT9_AMD','Cramer','att4i2015','139.76.213.210',11166,'lci9i1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (6,'PGG_AMD','Cramer','att4g2015','139.76.213.209',12054,'ipag2pdb.db.att.com');
INSERT INTO `dbconndetails` VALUES (7,'PGG_AMD(G)','GCP_USER','m1rr0rdb','139.76.213.209',12054,'ipag2pdb.db.att.com');
INSERT INTO `dbconndetails` VALUES (8,'PGG_ATT(G)','GCP_USER','m1rr0rdb','mlpd367db.sfdc.sbc.com',1524,'ipag2pdb.db.att.com');
INSERT INTO `dbconndetails` VALUES (9,'GG2_AMD(G)','GCP_USER','gcp_password','139.76.213.210',12122,'ipagg2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (10,'GG2_ATT(G)','GCP_USER','gcp_password','ipagg2d1.snt.bst.bls.com',1521,'ipagg2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (11,'GG2_ATT','Cramer','att4t2015','ipagg2d1.snt.bst.bls.com',1521,'ipagg2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (12,'GG2_AMD','Cramer','att4t2015','139.76.213.210',12122,'ipagg2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (13,'SIT3GG_AMD','Cramer','att4f2015','139.76.213.209',12098,'t1can1d3');
INSERT INTO `dbconndetails` VALUES (14,'SIT3GG_AMD(G)','GCP_USER','gcp_password','139.76.213.209',12098,'t1can1d3');
INSERT INTO `dbconndetails` VALUES (15,'ST8GG_AMD','Cramer','att4t2015','139.76.215.102',1521,'ipagt8g_1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (16,'ST8GG_AMD(G)','GCP_USER','gcp_password','139.76.215.102',1521,'ipagt8g_1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (17,'ST9GG_AMD','Cramer','att4t2015','139.76.213.29',1521,'ipagt9g1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (18,'ST9GG_AMD(G)','GCP_USER','gcp_password','139.76.213.29',1521,'ipagt9g1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (19,'SIT4GG_ATT','Cramer','att4f2015','zlt07954.vci.att.com',1524,'t1c4d76');
INSERT INTO `dbconndetails` VALUES (20,'SIT4GG_ATT(G)','GCP_USER','gcp_password','zlt07954.vci.att.com',1524,'t1c4d76');
INSERT INTO `dbconndetails` VALUES (21,'SIT3GG_ATT','Cramer','att4f2015','t1can1d3.vci.att.com',1524,'t1can1d3');
INSERT INTO `dbconndetails` VALUES (22,'SIT3GG_ATT(G)','GCP_USER','gcp_password','t1can1d3.vci.att.com',1524,'t1can1d3');
INSERT INTO `dbconndetails` VALUES (23,'GG3_AMD','Cramer','att4t2015','139.76.213.210',12132,'ipagg3d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (24,'GG3_AMD(G)','GCP_USER','gcp_password','139.76.213.210',12132,'ipagg3d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (25,'SIT4GG_AMD(G)','GCP_USER','gcp_password','139.76.213.210',10078,'t1c4d76');
INSERT INTO `dbconndetails` VALUES (26,'SIT4GG_AMD','Cramer','att4f2015','139.76.213.210',10078,'t1c4d76');
INSERT INTO `dbconndetails` VALUES (27,'SIT7GG_AMD','Cramer','att4f2015','139.76.213.210',10001,'t1c3d829');
INSERT INTO `dbconndetails` VALUES (28,'SIT7GG_AMD(G)','GCP_USER','gcp_password','139.76.213.210',10001,'t1c3d829');
INSERT INTO `dbconndetails` VALUES (29,'SIT7GG_ATT(G)','GCP_USER','gcp_password','zlt06459.vci.att.com',1524,'t1c3d829');
INSERT INTO `dbconndetails` VALUES (30,'SIT7GG_ATT','Cramer','att4f2015','zlt06459.vci.att.com',1524,'t1c3d829');
INSERT INTO `dbconndetails` VALUES (31,'ST9GG_ATT(G)','GCP_USER','gcp_password','ipagt9g1.snt.bst.bls.com',1521,'ipagt9g1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (32,'ST9GG_ATT','Cramer','att4t2015','ipagt9g1.snt.bst.bls.com',1521,'ipagt9g1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (33,'PGG_ATT','Cramer','att4g2015','mlpd367db.sfdc.sbc.com',1524,'ipag2pdb.db.att.com');
INSERT INTO `dbconndetails` VALUES (34,'ST5GG_AMD','Cramer','att4t2015','139.76.213.209',10150,'t5cnp1bdb.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (35,'ST5GG_AMD(G)','GCP_USER','gcp_password','139.76.213.209',10150,'t5cnp1bdb.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (36,'ST5GG_ATT','Cramer','att4t2015','ipagt5g11.snt.bst.bls.com',1521,'t5cnp1bdb.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (37,'ST5GG_ATT(G)','GCP_USER','gcp_password','ipagt5g11.snt.bst.bls.com',1521,'t5cnp1bdb.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (38,'GG3_ATT','Cramer','att4t2015','ipagg3d1.snt.bst.bls.com',1521,'ipagg3d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (39,'GG3_ATT(G)','GCP_USER','gcp_password','ipagg3d1.snt.bst.bls.com',1521,'ipagg3d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (40,'DEV2GG_AMD','Cramer','att4d2015','139.76.213.209',11140,'lci2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (41,'DEV2GG_AMD(G)','GCP_USER','gcp_password','139.76.213.209',11140,'lci2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (42,'DEV2GG_ATT','Cramer','att4d2015','nmsid1d1.snt.bst.bls.com',1521,'lci2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (43,'DEV2GG_ATT(G)','GCP_USER','gcp_password','nmsid1d1.snt.bst.bls.com',1521,'lci2d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (44,'SIT6GG_AMD','Cramer','att4f2015','10.26.48.146',15212,'t1can1d1.db.att.com');
INSERT INTO `dbconndetails` VALUES (45,'SIT6GG_AMD(G)','GCP_USER','gcp_password','10.26.48.146',15212,'t1can1d1.db.att.com');
INSERT INTO `dbconndetails` VALUES (46,'DEV6_AMD','Cramer','att4d2015','139.76.213.209',11158,'lci6d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (47,'GG1_AMD','Cramer','att4t2015','139.76.213.209',12130,'ipagg1d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (48,'GG1_AMD(G)','GCP_USER','gcp_password','139.76.213.209',12130,'ipagg1d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (49,'GG1_ATT','Cramer','att4t2015','ipagg1d1.snt.bst.bls.com',1521,'ipagg1d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (50,'GG1_ATT(G)','GCP_USER','gcp_password','ipagg1d1.snt.bst.bls.com',1521,'ipagg1d1.snt.bst.bls.com');
INSERT INTO `dbconndetails` VALUES (51,'PGG_ATT_New','Cramer','att4g2015','mlph636-vip.sfdc.sbc.com',1521,'p2can1d7.db.att.com');
INSERT INTO `dbconndetails` VALUES (52,'PGG_ATT_New(G)','GCP_USER','m1rr0rdb','mlph636-vip.sfdc.sbc.com',1521,'p2can1d7.db.att.com');
INSERT INTO `dbconndetails` VALUES (53,'PGG_AMD_New','Cramer','att4g2015','139.76.213.209',12124,'p2can1d7.db.att.com');
INSERT INTO `dbconndetails` VALUES (54,'PGG_AMD_New(G)','GCP_USER','m1rr0rdb','139.76.213.209',12124,'p2can1d7.db.att.com');
COMMIT;
