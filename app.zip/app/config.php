<?php
class AppConfig {
	
	//Common for all modules
	public $search = 'search.php';
	
	//home urls
	public $homepage = 'home.php';
	public $index = 'index.php';
	
	//All Categories related php files
	public $viewallcategories = 'allcategories.php';
	public $addallcategories = 'addallcategories.php';
	public $editallcategories = 'editallcategories.php';
	public $searchallcategories = 'searchallcategories.php';	
	
	//Dbopers related php files
	public $updateIds_dbopers = 'updateids.php';
	
	public $generatecsv = 'generatecsv.php';
	
	//Module related php files
	public $viewmodule = 'modules.php';
	
	//SubModule related php files
	public $viewsubmodule = 'submodules.php';	
	public $addsubmodule = 'addsubmodule.php';	
	public $editsubmodule = 'editsubmodule.php';	
	public $searchsubmodule = 'searchsubmodule.php';	
	
	//Users related php files
	public $viewusers = 'users.php';	
	public $addusers = 'adduser.php';	
	public $editusers = 'edituser.php';	
	public $searchusers = 'searchuser.php';	
	
	//Stimings related php files
	public $viewstimings = 'salahtimings.php';	
	public $viewmstimings = 'mstimings.php';	

	//Stracker related php files
	public $viewstracker = 'salahtracker.php';	
	public $addstracker = 'addstracker.php';	
	public $addmultiplestracker = 'addmultiplestracker.php';	
	public $editstracker = 'editstracker.php';	
	public $searchstracker = 'searchstracker.php';		
	public $stsettings = 'stsettings.php';	

	//Dtracker related php files
	public $viewdatracker = 'datracker.php';	
	public $adddatracker = 'adddatracker.php';	
	public $editdatracker = 'editdatracker.php';	
	public $searchdatracker = 'searchdatracker.php';	

	//Dailyfikr related php files
	public $viewdailyfikr = 'dailyfikr.php';	
	
	//Task related php files
	public $viewtask = 'tasks.php';
	public $addtask = 'addtask.php';
	public $addtasks = 'addtasks.php';
	public $edittask = 'edittask.php';
	public $comptasks = 'ctasks.php';
	public $searchtask = 'searchtask.php';
	
	//TaskList related php files
	public $viewtasklist = 'tasklist.php';
	public $addtasklist = 'addtasklist.php';
	public $edittasklist = 'edittasklist.php';
	public $searchtasklist = 'searchtasklist.php';	
	
	//Credential related php files
	public $viewcredential = 'credentials.php';
	public $addcredential = 'addcredential.php';
	public $editcredential = 'editcredential.php';
	public $searchcredential = 'searchcredential.php';
	
	//Expense related php files
	public $viewexpense = 'expenses.php';
	public $addexpense = 'addexpense.php';
	public $addexpenses = 'addexpenses.php';
	public $editexpense = 'editexpense.php';
	public $searchexpense = 'searchexpense.php';	
	public $searchbymonth = 'searchbymonth.php';
	
	//Expense Reports related php files
	public $monthlyexpensereports = 'monthlyexpenses.php';
	public $weeklyexpensereports = 'weeklyexpenses.php';
	public $categorizedexpensereports = 'categorizedexpenses.php';
	public $categorizedchartexpensereports = 'categorizedchartexpenses.php';
	
	//Urlstore related php files
	public $viewurlstore = 'urls.php';
	public $addurlstore = 'addurl.php';
	public $editurlstore = 'editurl.php';
	public $searchurlstore = 'searchurlstore.php';		
	
	//Biometrics related php files
	public $viewbiometrics = 'biometrics.php';
	public $addbiometrics = 'addbiometrics.php';
	public $editbiometrics = 'editbiometrics.php';
	public $searchbiometrics = 'searchbiometrics.php';		

	//Creditpayment related php files
	public $viewcreditpayment = 'creditpayment.php';
	public $addcreditpayment = 'addcreditpayment.php';
	public $editcreditpayment = 'editcreditpayment.php';
	public $searchcreditpayment = 'searchcreditpayment.php';
	
	//Fundstransfer related php files
	public $viewfundstransfer = 'fundstransfer.php';
	public $addfundstransfer = 'addfundstransfer.php';
	public $editfundstransfer = 'editfundstransfer.php';
	public $searchfundstransfer = 'searchfundstransfer.php';	
	
	//Onlineorders related php files
	public $viewonlineorders = 'onlineorders.php';
	public $addonlineorders = 'addonlineorders.php';
	public $editonlineorders = 'editonlineorders.php';
	public $searchonlineorders = 'searchonlineorders.php';	

	//Remainder related php files
	public $viewreminder = 'reminders.php';
	public $addreminder = 'addreminder.php';
	public $editreminder = 'editreminder.php';
	public $searchreminder = 'searchreminder.php';	
	
	//Weightrecorder related php files
	public $viewweightrecorder = 'weightrecorder.php';
	public $addweightrecorder = 'addweightrecorder.php';
	public $editweightrecorder = 'editweightrecorder.php';
	public $searchweightrecorder = 'searchweightrecorder.php';		
	
	//Taxreturns related php files
	public $viewtaxreturns = 'taxreturns.php';
	public $addtaxreturns = 'addtaxreturns.php';
	public $edittaxreturns = 'edittaxreturns.php';
	public $searchtaxreturns = 'searchtaxreturns.php';		
	
	// Dietplan related php files
	public $viewdplan = 'dietplan.php';
	public $adddplan = 'adddplan.php';
	public $editdplan = 'editdplan.php';
	public $searchdplan = 'searchdplan.php';		
	
	// Dtasks related php files
	public $viewdtasks = 'dtasks.php';
	public $adddtasks = 'adddtask.php';
	public $editdtasks = 'editdtask.php';
	public $searchdtasks = 'searchdtasks.php';		
	
	// Plotdetails related php files
	public $viewplotdetails = 'plotdetails.php';
	public $addplotdetailss = 'addplotdetails.php';
	public $editplotdetails = 'editplotdetails.php';
	public $searchplotdetails = 'searchplotdetails.php';	
	
	// Shopping list related php files
	public $viewshoppinglist = 'shoppinglist.php';
	
	// Scribble related php files
	public $viewscribble = 'scribble.php';	
	
	//Dbenvdetails related php files
	public $viewdbenvdetails = 'dbenvdetails.php';
	public $adddbenvdetails = 'adddbenvdetails.php';
	public $editdbenvdetails = 'editdbenvdetails.php';
	public $searchdbenvdetails = 'searchdbenvdetails.php';	
	
	//Dbconndetails related php files
	public $viewdbconndetails = 'dbconndetails.php';
	public $adddbconndetails = 'adddbconndetails.php';
	public $editdbconndetails = 'editdbconndetails.php';
	public $searchdbconndetails = 'search.php';	
	
	//Over Time Work Hours related php files
	public $viewotwhours = 'otwhours.php';
	public $addotwhours = 'addotwhours.php';
	public $editotwhours = 'editotwhours.php';
	public $searchotwhours = 'searchotwhours.php';		

	//MV Reqmnts related php files
	public $viewreqmnts = 'reqmnts.php';
	public $addreqmnts = 'addreqmnts.php';
	public $editreqmnts = 'editreqmnts.php';
	public $searchreqmnts = 'searchreqmnts.php';		
	
	// Circuit related php files
	public $viewcircuitsbytype = 'circuitsbytype.php';
	public $viewcircuitsbynode = 'circuitsbynode.php';
	public $viewcktportnodeinfo = 'cktportnodeinfo.php';
	public $viewunderlyingcircuits = 'underlyingcircuits.php';
	public $viewoverlyingcircuits = 'overlyingcircuits.php';
	
	// Node related php files
	public $viewnodesbytype = 'nodesbytype.php';	
	
	// Port related php files
	public $viewportsbytype = 'portsbytype.php';		
	public $viewphyportfrmcktnode = 'phyportfrmcktnode.php';
	
	// Service related php files
	public $viewservicesbytype = 'servicesbytype.php';		
	
	// Number related php files
	public $viewnumbersbytype = 'numbersbytype.php';		
	
	// Sttaus related php files
	public $viewstatusbyid = 'statusbyid.php';		
	
	// Dim Object related php files
	public $viewdimobjectsbytype = 'dimobjectsbytype.php';		
	
	// GCP-MV related php files
	public $viewmvconfigsbytype = 'mvconfigsbytype.php';		
	public $viewmvconfiginfo = 'mvconfiginfo.php';		
	public $viewmvflags = 'mvflags.php';		
	public $viewgcpmvactions = 'gcpmvactions.php';		
	public $viewcramermvactions = 'cramermvactions.php';		
	public $viewmvsessionsinfo = 'mvsessionsinfo.php';	
	public $viewmvrefreshinfo = 'mvrefreshinfo.php';	
	public $viewmvgcpextractinfo = 'mvgcpextractinfo.php';	
	public $viewremovemvjob = 'removemvjob.php';	
	public $viewremovemvlog = 'removemvlog.php';	
	public $viewexeccommand = 'execcommand.php';
	public $viewstuckjobcleanup = 'stuckjobcleanup.php';
	public $viewcreategcpmvjob = 'creategcpmvjob.php';
	public $viewcreatecramermvjob = 'createcramermvjob.php';
	public $viewexecgcpmvjob = 'execgcpmvjob.php';
	public $viewexeccramermvjob = 'execcramermvjob.php';	
	
	// Enumeration related php files
	public $viewenumdefs = 'enumdefs.php';		
	public $viewenumvalues = 'enumvalues.php';		
	
	// Network Setting related files
	public $viewnetworksettings = 'networksettings.php';		
}