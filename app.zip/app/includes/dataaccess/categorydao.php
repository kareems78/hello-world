<?php
 /**
  *	Data Access for Priority
  *
  */
 class CategoryDAO extends BaseDAO
 {
 
 
  	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = null;
	
	/**
	 * Contructor for CategoryDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($tableName)
	{
		$this->tableName = $tableName;
		parent::__construct($tableName, 0);
				
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		$addQuery = "insert into ".$this->tableName." (name, description) values (:name, :description)";		
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':description', $_formValues['desc']);
		
		$result = $stmt->execute();	
		
		return $result;
	}

     /**
      * Delete categories
      *
      * @param $_formValues
      */
     public function deleteCategories($_formValues)
	{
		$this->_log->info("deleteCategories() - start");
		$this->setFormInputs($_formValues);
		return $this->delete();
		$this->_log->info("deleteCategories() - end");
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$updateQuery = "update ".$this->tableName." set name=:name, description=:description where id=:id";
		
		$this->_log->info("updateQuery ==> ".$updateQuery);
		
		//$this->_log->info("name ==> ".$_formValues['name']." description ==> ".$_formValues['desc']." id ==> ".$_formValues['id']);
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':description', $_formValues['desc']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();	
		
		$this->_log->info("update() - end");
		
		return $result;		
	}

 }