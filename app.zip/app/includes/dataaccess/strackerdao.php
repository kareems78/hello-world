<?php
/**
 * Data Access for Salah Tracker
 *
 */ 
 class STrackerDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'salahtracker';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Object to hold salah tracker values
	 * @var salah tracker dto
	 */
	protected $stracker = null;	
	
	/**
	 * Contructor for STrackerDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from salahtracker where user = " . $this->_userid . " order by sdate desc",
		);
		
		return $queriesArray;
	}

     /**
      * Retrieves all records for current month and year
      *
      * @return list
      */
     public function getSTracker($records_per_page)
     {
         $dateRange = CommonUtil::dateRangeForCurrent();
         $startDate = $dateRange['start'];
         $endDate = $dateRange['end'];

         $getSTQuery = "select * from salahtracker where (sdate between '" . $startDate . "' and '" . $endDate . "') ".
                       "and user = " . $this->_userid . " order by sdate";

         return $this->getViewDataResultSets($getSTQuery, $records_per_page);
     }

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert()
	{
		$this->_log->info("insert() - start");
		
		$id = $this->generateID();
		
		//echo "id : ".$id;		
		
		$addQuery = "insert into salahtracker (id, sdate, createddate, updateddate, user, fazr, dhuhr, asr, maghrib, isha, notes) values ".
						"(:id, :sdate, :createddate, :updateddate, :user, :fazr, :dhuhr, :asr, :maghrib, :isha, :notes)";
		try
		{
			$stmt = $this->_conn->prepare($addQuery);
			$stmt->bindValue(':id', $id);
			$stmt->bindValue(':sdate', $this->stracker->_sdate);
			$stmt->bindValue(':createddate', $this->stracker->_createddate);
			$stmt->bindValue(':updateddate', $this->stracker->_updateddate);
			$stmt->bindValue(':user', $this->stracker->_user);
			$stmt->bindValue(':fazr', $this->stracker->_fazr);
			$stmt->bindValue(':dhuhr', $this->stracker->_dhuhr);		
			$stmt->bindValue(':asr', $this->stracker->_asr);
			$stmt->bindValue(':maghrib', $this->stracker->_maghrib);
			$stmt->bindValue(':isha', $this->stracker->_isha);
			$stmt->bindValue(':notes', $this->stracker->_notes);
			
			$result = $stmt->execute();
		
		}
		catch(PDOException $Exception)
		{
			$this->_log->info("in exception block");
			return $Exception->getCode();
			throw new DatabaseException($Exception->getMessage() , $Exception->getCode());
		} 
		
		$this->_log->info("insert() - end");
		
		//echo "result : ".$result."<br>";
		return $result;
	
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
 	public function addSalahTracker($_formValues)
	{
		$this->_log->info("addSalahTracker() - start");
		
		$this->stracker = new stracker($_formValues['sdate'], $_formValues['userid'], 
			$_formValues['fazr'], $_formValues['dhuhr'], $_formValues['asr'], 
			$_formValues['maghrib'], $_formValues['isha'], $_formValues['notes']);
			
		$result = $this->insert();
		
		$this->_log->info("addSalahTracker() - end");
		
		return $result;
	}		
	
 	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function addMultipleValues($_formValues)
	{
		$this->_log->info("addMultipleValues() - start");
		
		$fazrIds = $_formValues['fazr'];
		
		$row = 0;
		
		foreach ($fazrIds as $fazrId) 
		{
			
			if ($_formValues['sdate'.$row] != '')
			{
				//echo "<br> Expense : " . $row . " will be inserted";
				
				try
				{
				
					$this->stracker = new stracker($_formValues['sdate'.$row], $_formValues['userid'], 
						$_formValues['fazr'][$row], $_formValues['dhuhr'][$row], 
						$_formValues['asr'][$row], $_formValues['maghrib'][$row], 
						$_formValues['isha'][$row], $_formValues['notes'][$row]);
						
					$result = $this->insert();	
				}
				catch(PDOException $Exception)
				{
					$this->_log->info("in exception block");
					return $Exception->getCode();
					throw new DatabaseException($Exception->getMessage() , $Exception->getCode());
				} 				
								
			}
			
			$row = $row + 1;
		}
		
		$this->_log->info("addMultipleValues() - end");
		
		return $result;
	}	

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$updatedDate = CommonUtil::getCurrentSqliteFormatDate();
		$sDate = CommonUtil::convertToSQLiteDateFormat($_formValues['sdate']);
		
		$updateQuery = "update salahtracker set sdate=:sdate, updateddate=:updateddate, fazr=:fazr, dhuhr=:dhuhr, ".
		               "asr=:asr, maghrib=:maghrib, isha=:isha, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':sdate', $sDate);
		$stmt->bindValue(':updateddate', $updatedDate);
		$stmt->bindValue(':fazr', $_formValues['fazr']);
		$stmt->bindValue(':dhuhr', $_formValues['dhuhr']);		
		$stmt->bindValue(':asr', $_formValues['asr']);
		$stmt->bindValue(':maghrib', $_formValues['maghrib']);
		$stmt->bindValue(':isha', $_formValues['isha']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     public function search($records_per_page)
     {
     	$this->_log->info("search() - start");
     	
     	$this->_log->info("Records per page in search() - " . $records_per_page);
     	
     	$searchStr = $this->getSubModuleSearchString();
     	
         if ($searchStr != '')
         {
             $searchQuery = "select * from salahtracker s where ". $searchStr ." and s.user = " . $this->_userid . " order by s.sdate";
         }
         else
         {
             $searchQuery = "select * from salahtracker where user = " . $this->_userid . " order by sdate";
         }

         //echo "search query -> ".$getSTQuery."<br>";
         
         $this->_log->info("search() - end");

         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
     {

         if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '')
         {
             echo "no value is sent<br>";
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['fromdate'] != '')
             {
                 $fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
             }

             if ($_formValues['todate'] != '')
             {
                 $toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
             }

             if ($_formValues['fromdate'] != '')
             {
                 // only if fromdate is selected
                 if ($_formValues['todate'] == '')
                 {
                     $searchQuery = "(s.sdate between '". $fromDate . "' and '" . $fromDate . "') ";
                 }

                 // both fromdate & todate is selected
                 if ($_formValues['todate'] != '')
                 {
                     $searchQuery = "(s.sdate between '". $fromDate . "' and '" . $toDate . "') ";
                 }
             }
         }
         
         $this->updateSubModuleSearchString($searchQuery);

         return 	$searchQuery;

     }
     
     /**
      * created to update dates when added after designing the table.
      * gets sdate and updates them in createddate and updateddate.
      * Used only once
      * 
      */
     public function updateDates()
     {
     	
     	$query = 'select id, sdate from salahtracker';
     	
     	$result = $this->executeQuery($query);
     	
     	while($row = mysqli_fetch_array($result))
    	{
    		$updateQ = "update salahtracker set createddate=:createddate, updateddate=:updateddate where id=:id"; 
			
			$stmtUp = $this->_conn->prepare($updateQ);
			$stmtUp->bindValue(':updateddate', $row['sdate']);
			$stmtUp->bindValue(':createddate', $row['sdate']);
			$stmtUp->bindValue(':id', $row['id']);
			
			$result2 = $stmtUp->execute();    		
		}
     }
	
 }