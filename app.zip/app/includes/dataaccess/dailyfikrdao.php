<?php
 /**
 * Data Access for Daily Fikr
 *
 */ 
 class DailyFikrDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'dailyfikr';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for DailyfikrDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from dailyfikr d ".
	      		              " where d.user = ". $this->_userid . 
	      		              " order by d.id",
		);
		
		return $queriesArray;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into dailyfikr (id, name, user, createddate, display) values ".
						"(:id, :name, :user, :createddate, :display)";
	
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', 'Set Name');
		$stmt->bindValue(':user', $this->_userid);	
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':display', 'no');
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$objectIds = $_formValues['objectIds'];
		$this->_log->info("in dao : count : ".count($objectIds));
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			$this->_log->info("id : ".$id);
			$this->_log->info("display value : ".$_formValues['display'][$row]);
			//echo "query : ".$query;
			
			$updateQuery = "update dailyfikr set name=:name, display=:display ".
						   "where id=:id";
		
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':name', $_formValues['name'][$row]);
			$stmt->bindValue(':display', $_formValues['display'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;		
	}
	
 }