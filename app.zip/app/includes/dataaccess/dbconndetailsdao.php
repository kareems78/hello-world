<?php

/**
 * Data Access for DB Conn Details
 *
 */
class DBConnDetailsDAO extends BaseDAO
{
    /**
     * Object to hold table associated with
     * this DAO
     *
     */
    protected $tableName = 'dbconndetails';

    /**
     * Object to hold get all records query
     *
     */
    public $_getAllRecords = null;

    /**
     *
     */
    public static $_formValues = null;

    /**
     * Contructor for DBConnDetailsDAO
     * Calls BaseDAO construction and sets the table name.
     *
     *
     */
    public function __construct($userid)
    {
    	//echo "in dao constructor .. " . $userid;
    	parent::__construct($this->tableName, $userid);

        $queries = $this->getQueries();

        // sets the query to get all records
        $this->_getAllRecords = $queries['getAllRecordsQuery'];
        
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);        

    }

    /**
     * All the queries required
     *
     * return of array of all queries
     */
    protected function getQueries()
    {
        $queriesArray = array(
            "getAllRecordsQuery" => "select * from dbconndetails order by id desc",
        );

        return $queriesArray;
    }
    
       /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	{
		return $this->getEnvConnectionDropDownValues();
	}	    
    
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	   

    /**
     * Inserts a row into the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function insert($_formValues)
    {
        $addQuery = "insert into dbconndetails (envname, username, password, dbhost, dbport, sid) values ".
            		"(:envname, :username, :password, :dbhost, :dbport, :sid)";

		$stmt = $this->_conn->prepare($addQuery);
        $stmt->bindValue(':envname', 'Set Env Name');
		$stmt->bindValue(':username', 'Cramer');
		$stmt->bindValue(':password', 'att4t2015');
		$stmt->bindValue(':dbhost', 'Set DB Host');
		$stmt->bindValue(':dbport', '1521');
		$stmt->bindValue(':sid', 'Set SID');

        $result = $stmt->execute();

        //echo "result : ".$result."<br>";

        return $result;
    }

    /**
     * Updates a row in the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function update($_formValues)
    {
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update dbconndetails set envname=:envname, username=:username, password=:password, ".
							"dbhost=:dbhost, dbport=:dbport, sid=:sid " .
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':envname', $_formValues['envname'][$row]);
			$stmt->bindValue(':username', $_formValues['username'][$row]);
			$stmt->bindValue(':password', $_formValues['password'][$row]);
			$stmt->bindValue(':dbhost', $_formValues['dbhost'][$row]);
			$stmt->bindValue(':dbport', $_formValues['dbport'][$row]);
			$stmt->bindValue(':sid', $_formValues['sid'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;
    }
    
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
    public function generateSearchQuery($_formValues)
    {
    	$this->_log->info("generateSearchQuery() - start");
    	
    	$searchString = "envname like '" . $_formValues['envname'] ."%'";
    	
    	$this->updateSubModuleSearchString($searchString);
    	
    	$this->_log->info("generateSearchQuery() - end");
    }
    
     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($records_per_page)
	{
		$this->_log->info("search() - start");
		
		$result = null;
		
		$searchStr = $this->getSubModuleSearchString();
		
	    if ($searchStr != "")
    	{
			$dbConnDetailsQuery = "select * from dbconndetails where " . $searchStr . " order by envname";
			$dbConnDetailsQuery_rs = $this->executeQuery($dbConnDetailsQuery);
			
			$db_conn_result =  $dbConnDetailsQuery_rs;    

	    	$srchStrArray1 = explode("envname like '", $searchStr);
	    	
	    	$srchStrArray2 = explode("%", $srchStrArray1['1']);
	
	    	// push result set to array
			$rsArray["DB_CONN_DETAILS"] = $db_conn_result;
			$rsArray["SEARCH_STRING"] = $srchStrArray2['0'];

			$result = $rsArray;

    	}
    	else 
    	{
    		$result = null;
    	}
		
		$this->flushSubModuleSearchString();
		
		$this->_log->info("search() - end");
		
		return $rsArray;
	}    

}