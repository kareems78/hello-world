<?php
/**
 * Data Access for Port
 *
 */ 
 class PortDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'circuittypes';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_orastmt = null;	
	
	/**
	 * Contructor for PortDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
		
		$this->getOraConnection();	
	
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getPhysicalPortInfo($_formValues)
	{
		$this->_log->info("getPhysicalPortInfo() - start");
		
		$nodeId = $_formValues['nodeid'];
		
		if ($_formValues['cktname'] != "")
		{		
			$circuitName = $_formValues['cktname'];
		}	
		
		if ($_formValues['cktid'] != "")
		{
			$circuitId = $_formValues['cktid'];	
		}
		
		// Query to get logical port from circuit and node
		$logicalPortQuery = "SELECT p.portid FROM circuit c, port p " .
 							"WHERE (c.circuit2startport = p.portid OR c.circuit2endport = p.portid) " .
   							"AND p.port2node = :nodeid ";
   							
		if (isset($circuitName))
		{
			$logicalPortQuery = $logicalPortQuery . "AND c.name = :circuitname";
		}	
		else if (isset($circuitId))	
		{
			$logicalPortQuery = $logicalPortQuery . "AND c.circuitid = :circuitid";
		}		
		
		//$this->_log->info ("Query ==> " . $logicalPortQuery);
		
		if ($this->_oraconn != null)
		{
		
			if (isset($circuitName) or isset($circuitId))
			{
				$this->_orastmt = oci_parse($this->_oraconn, $logicalPortQuery);
				
				if (isset($circuitName))
				{
					oci_bind_by_name($this->_orastmt,":nodeid", $nodeId);
					oci_bind_by_name($this->_orastmt,":circuitname", $circuitName);
				}

				if (isset($circuitId))
				{
					oci_bind_by_name($this->_orastmt,":nodeid", $nodeId);
					oci_bind_by_name($this->_orastmt,":circuitid", $circuitId);
				}				
		
				oci_execute($this->_orastmt);	
				
				$lp_nrows = oci_fetch_all($this->_orastmt, $logicalport_resultset);
				
				oci_free_statement($this->_orastmt);
				
				//$this->_log->info($resultset);
				//$this->_log->info($resultset['CKT_STATUS'][0]);
				
				$logicalPortId = $logicalport_resultset[PORTID][0];
				
				if (isset($logicalPortId))
				{
					
					// Query 
					$query = "SELECT p.portid, p.name, p.createddate " .
	      					 "FROM port p CONNECT BY PRIOR parentport2port = portid ".
							 "START WITH portid = :logicalport ORDER BY LEVEL DESC";
					
					$this->_orastmt = oci_parse($this->_oraconn, $query);	

					oci_bind_by_name($this->_orastmt,":logicalport", $logicalPortId);
					
					oci_execute($this->_orastmt);	
					
					$nrows = oci_fetch_all($this->_orastmt, $resultset);
					
					oci_free_statement($this->_orastmt);					
					
					$this->closeOracleConnection();				
					
					// push to array
					$outputArray["query_output"] = $resultset;
					$outputArray["num_rows"] = $nrows;
					$outputArray["env_name"] = $this->_environment->_envname;
					
					if (isset($circuitName))
					{
						$outputArray["ckt_name"] = $circuitName;
					}
	
					if (isset($circuitId))
					{
						$outputArray["ckt_id"] = $circuitId;
					}				
					
					$outputArray["nodeid"] = $nodeId;
						
					$this->_log->info("getPhysicalPortInfo() - end");
					
					return $outputArray;					
				}
				else
				{
					$this->_log->info("No logical port returned.");
					$outputArray["error"] = "No logical port returned";
					$this->_log->info("getPhysicalPortInfo() - end");
					return $outputArray;
				}
				
				
			
			}
			else
			{
				$this->_log->info("No input received.");
				$outputArray["error"] = "Please enter either Circuit Id or Circuit Name";
				$this->_log->info("getPhysicalPortInfo() - end");
				return $outputArray;
			}
		}
		else
		{
			$this->_log->error("No Oracle Connection available");
			$this->_log->info("getPhysicalPortInfo() - end");
		}
	
	}
 }
