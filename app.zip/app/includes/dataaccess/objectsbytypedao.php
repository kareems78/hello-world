<?php

/**
 * Data Access for ObjectByType
 *
 */
class ObjectsByTypeDAO extends BaseDAO
{
    /**
     * Object to hold table associated with
     * this DAO
     *
     */
    protected $tableName = 'objecttypes';
    
    
    public $_objecttype = null;

    /**
     * Object to hold get all records query
     *
     */
    public $_getAllRecords = null;

    /**
     *
     */
    public static $_formValues = null;

    /**
     * Contructor for ObjectsByTypeDAO
     * Calls BaseDAO construction and sets the table name.
     *
     *
     */
    public function __construct($userid)
    {
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);     	
    	
    	$this->_objecttype = isset($_POST['objecttype']) ? $_POST['objecttype'] : $_GET['objecttype'];
    	
    	//echo "in dao constructor .. " . $userid;
    	parent::__construct($this->tableName, $userid);

    }

    /**
     * All the queries required
     *
     * return of array of all queries
     */
    protected function getQueries()
    {
        $queriesArray = array(
            "getAllRecordsQuery" => "select * from circuittypes ".
        							"where user = " . $this->_userid . " order by id desc",
        );

        return $queriesArray;
    }
    
    protected function setObjectTypeTable($objectType)
    {
    	if (isset($objectType))
    	{
	    	//get stored operation
			switch (strtolower($objectType))
			{
				// get circuits by node
				case strtolower('circuit'):
					$this->tableName = 'circuittypes';
					break;
	
				// get dropdown values
				case strtolower('node'):
					$this->tableName = 'nodetypes';	
					break;	
	
				default:
					die("Error occurred : <font color='red'>Object Type : ".$objectType." not found.</font>");
					
			}    	

			$this->_log->info("Object type table name set to ==> " . $this->tableName);
    	}
    	else
    	{
    		$this->_log->info("Object type is not set");
    		//die;
    	}
    }
    
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page, $objectType)
	{
		$query = "select * from " . $this->tableName .
        		 " where user = " . $this->_userid . 
        		 " and objecttype = '" . $objectType . 
        		 "' order by id desc";
		
		return $this->getViewDataResultSets($query, $records_per_page);
	}	   

    /**
     * Inserts a row into the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function insert($_formValues)
    {
    	$this->_log->info("insert() - start");
    	
        //$this->_log->info("user id : " . $this->_userid);
        
        $id = $this->generateIDWithTable($this->tableName);
        
        //$this->_log->info("id generated : " . $id);

        $addQuery = "insert into " . $this->tableName . " (id, typeid, name, objecttype, user, tablename) values ".
            		"(:id, :typeid, :name, :objecttype, :user, :tablename)";

		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
        $stmt->bindValue(':typeid', 'Set Type Id');
        $stmt->bindValue(':name', 'Set Name');
        $stmt->bindValue(':objecttype', $this->_objecttype);
        $stmt->bindValue(':user', $this->_userid);	
		$stmt->bindValue(':tablename', 'Set Extension Table');

        $result = $stmt->execute();

        //echo "result : ".$result."<br>";

        return $result;
    }

    /**
     * Updates a row in the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function update($_formValues)
    {
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update " . $this->tableName . " set typeid=:typeid, name=:name, tablename=:tablename ".
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':typeid', $_formValues['typeid'][$row]);
			$stmt->bindValue(':name', $_formValues['name'][$row]);
			$stmt->bindValue(':tablename', $_formValues['tablename'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;
    }

}