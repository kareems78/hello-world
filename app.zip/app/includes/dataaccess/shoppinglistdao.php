<?php
/**
 * Data Access for Shopping List
 *
 */ 
 class ShoppinglistDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'shoppinglist';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for ShoppinglistDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from shoppinglist s ".
	      		              " where s.user = ". $this->_userid . 
	      		              " order by s.createddate",
		);
		
		return $queriesArray;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into " .  $this->tableName ." (id, itemdesc, createddate, updateddate, user, notes) values ".
						"(:id, :itemdesc, :createddate, :updateddate, :user, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':itemdesc', 'Enter Item');
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':user', $this->_userid);		
		$stmt->bindValue(':notes', '');
		
		$result = $stmt->execute();
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$updatedDate = CommonUtil::getCurrentDate();
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) 
		{
			$updateQuery = "update " .  $this->tableName ." set itemdesc=:itemdesc, updateddate=:updateddate, ".
						   "notes=:notes where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':itemdesc', $_formValues['itemdesc'][$row]);
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':notes', $_formValues['notes'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1; 
		}		
		
		return $result;		
	}
	
 }