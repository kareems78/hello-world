<?php
/**
 * Data Access for TaskList
 *
 */ 
 class TaskListDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'tasklist';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 * Object to hold get all completed tasks query
	 *
	 */
	public $_getAllCompletedTasks = null;	
	
	/**
     *
     */	 
	public static $_formValues = null;
	
	/**
	 * 
	 * Object to hold task values
	 * @var tasklist dto
	 */
	protected $tasklist = null;	
	
 	/**
	 * Contructor for TaskListDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		// sets the query to get all tasks
		$this->_getAllCompletedTasks = $queries['getAllCompletedTasksQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}	

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		
		"getAllRecordsQuery" => "SELECT T.ID, T.TASK, T.CREATEDDATE, T.TASKDATE, T.STATUS ".
	      		 " FROM TASKLIST T WHERE T.USER = ".$this->_userid.
	      		 " ORDER BY T.TASKDATE DESC",
							  
		"getAllCompletedTasksQuery" => "SELECT T.ID, T.NAME, P.NAME AS pname, TT.NAME AS tname, T.CREATEDDATE, ".
							  "T.DUEDATE, T.COMPLETEDDATE, S.NAME AS sname, T.NOTES FROM TASK T, PRIORITY P, TASKTYPE TT, STATUS S ".
	      		              " WHERE T.PRIORITY=P.ID AND T.TYPE = TT.ID AND T.STATUS = S.ID AND T.STATUS = 4",							  
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	 {
	 }
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		$getTaskDateQuery = "select distinct taskdate, createddate from tasklist where user = " .$this->_userid . " order by taskdate desc";
		
		$getTaskDateQueryResult = $this->executeQuery($getTaskDateQuery);
		
		$i = 0;
		
		foreach($getTaskDateQueryResult as $rows => $row)
		{
			$getTaskListQuery = "select id, task, taskdate, createddate, status from tasklist where taskdate = '" . $row['taskdate'] . "'";
			$this->_log->info("query ===> " . $getTaskListQuery);
			$getTaskListQueryResult = $this->executeQuery($getTaskListQuery);

			$taskListArray[$i] = $getTaskListQueryResult;
			
			$i++;
		}
		
		$resultArray['taskDateArray'] = $getTaskDateQueryResult;
		$resultArray['taskListArray'] = $taskListArray;
		
		return $resultArray;
	}	

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insertTask()
	 {
		
	 	$getCreatedDateQuery = "select distinct createddate from tasklist where taskdate = '" . $this->tasklist->_taskdate . "' and user = " . $this->tasklist->_user;
	 	$getCreatedDateQueryResult = $this->executeQuery($getCreatedDateQuery);
	 	
	 	$row = $getCreatedDateQueryResult[0];
	 	
	 	if ($row['createddate'] != null)
	 	{
	 		$createdDate = $row['createddate'];
	 	}
	 	else
	 	{
	 		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
	 	}
		
		
		$id = $this->generateID();
		
		//echo "id : ".$id;
		
		$addQuery = "insert into tasklist (id, task, user, createddate, taskdate, status) values ".
						"(:id, :task, :user, :createddate, :taskdate, :status)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':task', $this->tasklist->_task);
		$stmt->bindValue(':user', $this->tasklist->_user);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':taskdate', $this->tasklist->_taskdate);
		$stmt->bindValue(':status', $this->tasklist->_status);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		//$this->_log->info("task list ==> " . $_formValues['tasklist']);
		
		$tasksArray = explode(PHP_EOL, $_formValues['tasklist']);
		
		for ($i = 0; $i < count($tasksArray); $i++) 
		{
			//$this->_log->info("task ==> " . $tasksArray[$i]);
			
			$this->tasklist = new tasklist($tasksArray[$i], $_formValues['taskdate'], 
			$_formValues['userid'], 'Not Done');
				
			$result = $this->insertTask();			
		}
		
		$this->_log->info("insert() - end");
		
		return $result;
	}	

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		
		$taskdate = CommonUtil::convertToSQLiteDateFormat($_formValues['taskdate']);
		
		$updateQuery = "update tasklist set task=:task, taskdate=:taskdate, status=:status ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':task', $_formValues['tasklist']);
		$stmt->bindValue(':taskdate', $taskdate);
		$stmt->bindValue(':status', $_formValues['status']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
     /**
      * Handles all buttons -> Delete, Done, Not Done and Cancel 
      *
      * @param $_formValues
      *
      */
	public function delete($_formValues)
	{
		$this->_log->info("delete() - start in tasklist dao");

		if(array_key_exists('Delete' , $_formValues))
        {
        	parent::delete();		
        }
        else
        {
        	$this->updateStatus($_formValues);
        }
		
	}
	
    public function updateStatus($_formValues)
	{
		
		if(array_key_exists('statusdone' , $_formValues))
        {
			$status = "Done";
        }		
        
		if(array_key_exists('statusnotdone' , $_formValues))
        {
			$status = "Not Done";		
        } 		
		
		if(array_key_exists('statuscancel' , $_formValues))
        {
			$status = "Cancel";		
        } 				
		
		$taskListIDs = $_formValues['deleteObject'];
		
		foreach ($taskListIDs as &$id) 
		{
			$updateQuery = "update tasklist set status = :status where id = :id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':status', $status);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
		}		
		
		return $result;	
	}	

     /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
     {
         // if task type is not selected setting it to default
         /*if(array_key_exists('type' , $_formValues))
         {
             //echo "type exists<br>";
         }*/
         if(!array_key_exists('type' , $_formValues))
         {
             //echo "type does not exist<br>";
             $_formValues['type'] = "";
         }
         
         // if status is not selected setting it to default
         /*if(array_key_exists('status' , $_formValues))
         {
             //echo "status exists<br>";
         }*/
         if(!array_key_exists('status' , $_formValues))
         {
             //echo "status does not exist<br>";
             $_formValues['status'] = "";
         }         

         if ($_formValues['createddate'] == '' and $_formValues['name'] == '' and $_formValues['type'] == '' and $_formValues['status'] == '')
         {
             //echo "no value is sent<br>";
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['createddate'] != '')
             {
                 $createdDate = CommonUtil::convertToSQLiteDateFormat($_formValues['createddate']);
             }

             if ($_formValues['name'] != '')
             {
                 $name = strtolower($_formValues['name']);
             }

             if ($_formValues['type'] != '')
             {
                 $typeIDs = CommonUtil::generateStringWithCommas($_formValues['type']);
             }
             
             if ($_formValues['status'] != '')
             {
                 $statusIDs = CommonUtil::generateStringWithCommas($_formValues['status']);
             }             


             if ($_formValues['name'] != '')
             {
                 // only if name is selected
                 if ($_formValues['createddate'] == '' and $_formValues['type'] == '' and $_formValues['status'] == '')
                 {
                     //$searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ";
                     $searchQuery = "and lower(t.name) like '%". $name ."%'";
                 }

                 // both name & createddate is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] == '' and $_formValues['status'] == '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%'";
                 }

                 // name and type is selected
                 if ($_formValues['type'] != '' and $_formValues['createddate'] == '' and $_formValues['status'] == '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.")";
                 }
                 
                 // name, type and status is selected
                 if ($_formValues['createddate'] == '' and $_formValues['type'] != '' and $_formValues['status'] != '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.") ".
                     	 "and t.status in (".$statusIDs.")";
                 }

                 // name and status is selected
                 if ($_formValues['status'] != '' and $_formValues['createddate'] == '' and $_formValues['type'] == '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.status in (".$statusIDs.")";
                 }                 

                 // name, createddate and type is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.")";
                 }
                 
                 // name, createddate, type and status is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] != '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.") ".
                         "and t.status in (".$statusIDs.")";
                 }                 
             }
             // if name and createddate is not selected, only type is selected
             elseif ($_formValues['type'] != '' and $_formValues['createddate'] == '' and $_formValues['status'] == '')
             {
                 $searchQuery = "and t.type in (".$typeIDs.")";
             }
             // if name and createddate is not selected, only type and status is selected
             elseif ($_formValues['createddate'] == '' and $_formValues['type'] != '' and $_formValues['status'] != '')
             {
                 $searchQuery = "and t.type in (".$typeIDs.") ".
                                "and t.status in (".$statusIDs.")";
             }             
             // only createddate is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] == '' and $_formValues['status'] == '')
             {
             	$searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ";
             }
             // createddate and type is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.type in (".$typeIDs.")";
             }
             // createddate and status is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['status'] != '' and $_formValues['type'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.status in (".$statusIDs.")";
             } 
             // createddate, type and status is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.type in (".$typeIDs.") ".
                         "and t.status in (".$statusIDs.")";
             }    
             // only status is selected                     
             elseif ($_formValues['createddate'] == '' and $_formValues['type'] == '' and $_formValues['status'] != '')
             {
                 $searchQuery = "and t.status in (".$statusIDs.")";
             }  
         }
         
         $this->updateSubModuleSearchString($searchQuery);

         return $searchQuery;

     }

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($records_per_page)
     {
     	$searchStr = $this->getSubModuleSearchString();
     	
         $searchQuery = "select t.id, t.name, p.name as pname, tt.name as tname, t.createddate, ".
             "t.completeddate, t.duedate, s.name as sname, t.notes from Task t, Priority p, TaskType tt, Status s ".
             " where t.priority=p.id and t.type = tt.id and t.status = s.id " . $searchStr . 
             " and t.user = " . $this->_userid ." order by t.id desc";

         //echo "Search Query -> ".$searchQuery."<br>";
		
         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

 }