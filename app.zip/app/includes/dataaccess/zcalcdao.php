<?php
/**
 * Data Access for Zcalc
 *
 */ 
 class ZcalcDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'zakat';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 * Object to hold get all completed tasks query
	 *
	 */
	public $_getAllCompletedTasks = null;	
	
	/**
     *
     */	 
	public static $_formValues = null;
	
 	/**
	 * Contructor for ZcalcDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		// sets the query to get all tasks
		$this->_getAllCompletedTasks = $queries['getAllCompletedTasksQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}	

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsOldQuery" => "SELECT T.ID, T.NAME, P.NAME AS pname, TT.NAME AS tname, T.CREATEDDATE, ".
							  "T.DUEDATE, S.NAME AS sname, T.NOTES FROM TASK T, PRIORITY P, TASKTYPE TT, STATUS S ".
	      		              " WHERE T.PRIORITY=P.ID AND T.TYPE = TT.ID AND T.STATUS = S.ID AND T.STATUS NOT IN (4,5) ORDER BY T.ID DESC",
		
		"getAllRecordsQuery" => "SELECT T.ID, T.NAME, P.NAME AS pname, TT.NAME AS tname, T.CREATEDDATE, ".
				 "T.DUEDATE, S.NAME AS sname, T.NOTES FROM TASK T, PRIORITY P, TASKTYPE TT, STATUS S ".
	      		 " WHERE T.PRIORITY=P.ID AND T.TYPE = TT.ID AND T.STATUS = S.ID AND T.STATUS NOT IN (4,5) AND T.USER = ".$this->_userid.
	      		 " ORDER BY T.ID DESC",
							  
		"getAllCompletedTasksQuery" => "SELECT T.ID, T.NAME, P.NAME AS pname, TT.NAME AS tname, T.CREATEDDATE, ".
							  "T.DUEDATE, T.COMPLETEDDATE, S.NAME AS sname, T.NOTES FROM TASK T, PRIORITY P, TASKTYPE TT, STATUS S ".
	      		              " WHERE T.PRIORITY=P.ID AND T.TYPE = TT.ID AND T.STATUS = S.ID AND T.STATUS = 4",							  
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	{
		$priorityDAO = new CategoryDAO('priority');
		$taskTypeDAO = new CategoryDAO('tasktype');
		$statusDAO = new CategoryDAO('status');
		
		// get info from priority, tasktype & status
		$priority_rs = $priorityDAO->getAll();
		$tasktype_rs = $taskTypeDAO->getAll();
		$status_rs = $statusDAO->getAll();
		
		// push result set to array
		$taskDropDownArray["priority"] = $priority_rs;
		$taskDropDownArray["tasktype"] = $tasktype_rs;
		$taskDropDownArray["status"] = $status_rs;
		
		return $taskDropDownArray;
	}
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		
		$dueDate = CommonUtil::convertToSQLiteDateFormat($_formValues['duedate']);
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();
		
		//echo "id : ".$id;
		
		$addQuery = "insert into task (id, name, priority, type, user, createddate, duedate, status, notes) values ".
						"(:id, :name, :priority, :type, :user, :createddate, :duedate, :status, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':priority', $_formValues['priority']);
		$stmt->bindValue(':type', $_formValues['type']);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':duedate', $dueDate);
		$stmt->bindValue(':status', $_formValues['status']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		
		$dueDate = CommonUtil::convertToSQLiteDateFormat($_formValues['duedate']);
		
		// set completeddate only if it is set in form		
		if ($_formValues['completeddate'] != '')
		{
			$completedDate = CommonUtil::convertToSQLiteDateFormat($_formValues['completeddate']);
		}
		else
		{
			if ($_formValues['status'] != '' and $_formValues['status'] == 4)
			{
				$completedDate = CommonUtil::getCurrentSqliteFormatDate();
			}
			else
			{
				$completedDate = null;
			}
			
		}
		
		$updateQuery = "update task set name=:name, priority=:priority, type=:type, duedate=:duedate, ".
					   "completeddate=:completeddate, status=:status, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':priority', $_formValues['priority']);
		$stmt->bindValue(':type', $_formValues['type']);
		$stmt->bindValue(':duedate', $dueDate);
		$stmt->bindValue(':completeddate', $completedDate);
		$stmt->bindValue(':status', $_formValues['status']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
     {
         // if task type is not selected setting it to default
         /*if(array_key_exists('type' , $_formValues))
         {
             //echo "type exists<br>";
         }*/
         if(!array_key_exists('type' , $_formValues))
         {
             //echo "type does not exist<br>";
             $_formValues['type'] = "";
         }
         
         // if status is not selected setting it to default
         /*if(array_key_exists('status' , $_formValues))
         {
             //echo "status exists<br>";
         }*/
         if(!array_key_exists('status' , $_formValues))
         {
             //echo "status does not exist<br>";
             $_formValues['status'] = "";
         }         

         if ($_formValues['createddate'] == '' and $_formValues['name'] == '' and $_formValues['type'] == '' and $_formValues['status'] == '')
         {
             //echo "no value is sent<br>";
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['createddate'] != '')
             {
                 $createdDate = CommonUtil::convertToSQLiteDateFormat($_formValues['createddate']);
             }

             if ($_formValues['name'] != '')
             {
                 $name = strtolower($_formValues['name']);
             }

             if ($_formValues['type'] != '')
             {
                 $typeIDs = CommonUtil::generateStringWithCommas($_formValues['type']);
             }
             
             if ($_formValues['status'] != '')
             {
                 $statusIDs = CommonUtil::generateStringWithCommas($_formValues['status']);
             }             


             if ($_formValues['name'] != '')
             {
                 // only if name is selected
                 if ($_formValues['createddate'] == '' and $_formValues['type'] == '' and $_formValues['status'] == '')
                 {
                     //$searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ";
                     $searchQuery = "and lower(t.name) like '%". $name ."%'";
                 }

                 // both name & createddate is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] == '' and $_formValues['status'] == '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%'";
                 }

                 // name and type is selected
                 if ($_formValues['type'] != '' and $_formValues['createddate'] == '' and $_formValues['status'] == '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.")";
                 }
                 
                 // name, type and status is selected
                 if ($_formValues['createddate'] == '' and $_formValues['type'] != '' and $_formValues['status'] != '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.") ".
                     	 "and t.status in (".$statusIDs.")";
                 }

                 // name and status is selected
                 if ($_formValues['status'] != '' and $_formValues['createddate'] == '' and $_formValues['type'] == '')
                 {
                     //$searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                     $searchQuery = "and lower(t.name) like '%". $name ."%' ".
                         "and t.status in (".$statusIDs.")";
                 }                 

                 // name, createddate and type is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.")";
                 }
                 
                 // name, createddate, type and status is selected
                 if ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] != '')
                 {
                     $searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and lower(t.name) like '%". $name ."%' ".
                         "and t.type in (".$typeIDs.") ".
                         "and t.status in (".$statusIDs.")";
                 }                 
             }
             // if name and createddate is not selected, only type is selected
             elseif ($_formValues['type'] != '' and $_formValues['createddate'] == '' and $_formValues['status'] == '')
             {
                 $searchQuery = "and t.type in (".$typeIDs.")";
             }
             // if name and createddate is not selected, only type and status is selected
             elseif ($_formValues['createddate'] == '' and $_formValues['type'] != '' and $_formValues['status'] != '')
             {
                 $searchQuery = "and t.type in (".$typeIDs.") ".
                                "and t.status in (".$statusIDs.")";
             }             
             // only createddate is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] == '' and $_formValues['status'] == '')
             {
             	$searchQuery = "and (t.createddate between '". $createdDate . "' and '" . $createdDate . "') ";
             }
             // createddate and type is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.type in (".$typeIDs.")";
             }
             // createddate and status is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['status'] != '' and $_formValues['type'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.status in (".$statusIDs.")";
             } 
             // createddate, type and status is selected
             elseif ($_formValues['createddate'] != '' and $_formValues['type'] != '' and $_formValues['status'] == '')
             {
                $searchQuery = "and (t.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
                         "and t.type in (".$typeIDs.") ".
                         "and t.status in (".$statusIDs.")";
             }    
             // only status is selected                     
             elseif ($_formValues['createddate'] == '' and $_formValues['type'] == '' and $_formValues['status'] != '')
             {
                 $searchQuery = "and t.status in (".$statusIDs.")";
             }  
         }

         return $searchQuery;

     }

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($searchStr, $records_per_page)
     {
         $searchQuery = "select t.id, t.name, p.name as pname, tt.name as tname, t.createddate, ".
             "t.completeddate, t.duedate, s.name as sname, t.notes from Task t, Priority p, TaskType tt, Status s ".
             " where t.priority=p.id and t.type = tt.id and t.status = s.id " . $searchStr . 
             " and t.user = " . $this->_userid ." order by t.id desc";

         //echo "Search Query -> ".$searchQuery."<br>";
		
         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

 }