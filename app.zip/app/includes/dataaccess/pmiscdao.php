<?php
/**
 * Data Access for Papps Misc
 *
 */ 
 class PMiscDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'content';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for PMiscDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName,  null);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select text from content where element_id='1'",
		);
		
		return $queriesArray;
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->executeQuery($this->_getAllRecords);
	}	

     /**
      * Updates a row in the database
      *
      * @param $content
      * @return bool
      *
      */
     public function update($content)
	{
		$updateQuery = "update content set text=:content where element_id='1'";
		
		$updateStmt = $this->_conn->prepare($updateQuery);
		$updateStmt->bindValue(':content', $content);
		
		$update_rs = $updateStmt->execute();

		return $update_rs;	
	}

 }
