<?php
/**
 * Data Access for Provisionstatus
 *
 */ 
 class ProvisionstatusDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'circuittypes';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_orastmt = null;	
	
	/**
	 * Contructor for ProvisionstatusDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
		
		$this->getOraConnection();		
	
	}
	
      /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	{
		$dimObjectQuery = "select typeid, name from objecttypes where objecttype ='dimobject' and user = " .$this->_userid . " order by typeid";
		$dimobject_rs = $this->executeQuery($dimObjectQuery);
		
		// push result set to array
		$dropDownArray["envlist"] = $this->getEnvConnectionDropDownValues();
		$dropDownArray["dimobjectlist"] = $dimobject_rs;
		
		return $dropDownArray;
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getStatusById($_formValues)
	{
		$this->_log->info("getStatusById() - start");
		
		if ($_formValues['statusid'] != "")
		{
			$statusId = $_formValues['statusid'];	
		}		
		
		if ($_formValues['dimobjectid'] != "")
		{
			$dimObjectId = $_formValues['dimobjectid'];	
		}
		
		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		$query = "SELECT ps.provisionstatusid, ps.name AS provisionstatus_name, d.name AS dimobject_name ".
  				" FROM provisionstatus ps, dimensionobject d where ps.ps2dimensionobject = d.dimensionobjectid ";
		
		if (isset($statusId))
		{
			$query = $query . " AND ps.provisionstatusid = :provisionstatusid";
		}		
		
		if (isset($dimObjectId))
		{
			$query = $query . " AND ps.ps2dimensionobject = :dimobjectid";
		}
		
		$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			if (isset($statusId))
			{
				oci_bind_by_name($this->_orastmt, ":provisionstatusid", $statusId);
			}				
			
			if (isset($dimObjectId))
			{
				oci_bind_by_name($this->_orastmt,":dimobjectid", $dimObjectId);
			}		
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			if (isset($statusId))
			{
				$outputArray["statusid"] = $statusId;
			}				
			
			if (isset($dimObjectId))
			{
				$outputArray["dimobjectid"] = $dimObjectId;
			}			
				
			$this->_log->info("getStatusById() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}	
	}
 }
