<?php
/**
 * Data Access for Scribble
 *
 */ 
 class ScribbleDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'scribble';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for ShoppinglistDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from scribble s ".
	      		              " where s.user = ". $this->_userid . 
	      		              " order by 1",
		);
		
		return $queriesArray;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->executeQuery($this->_getAllRecords);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into " .  $this->tableName ." (id, user) values ".
						"(:id, :user)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':user', $this->_userid);		
		
		$result = $stmt->execute();
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		//$this->_log->info("id : " . $_formValues['id']);
		
		$updateQuery = "update " .  $this->tableName ." set text=:text where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':text', $_formValues['scribbletext']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		$this->_log->info("update() - end");
		
		return $result;		
	}
	
 }