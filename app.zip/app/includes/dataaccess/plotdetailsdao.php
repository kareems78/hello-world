<?php
/**
 * Data Access for Plot Details
 *
 */ 
 class PlotdetailsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'plotdetails';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for PlotdetailsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select p.id, p.datesent, ".
							  "p.amount, p.notes from plotdetails p ".
	      		              " where p.user = ". $this->_userid . 
	      		              " order by p.datesent",
		);
		
		return $queriesArray;
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->executeQuery($this->_getAllRecords);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();	
		
		$addQuery = "insert into plotdetails (id, datesent, amount, user, notes) values ".
						"(:id, :datesent, :amount, :user, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':datesent', '0000-00-00');
		$stmt->bindValue(':amount', 'Set Amount');
		$stmt->bindValue(':user', $this->_userid);
		$stmt->bindValue(':notes', '');
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			//echo "date before : ".$_formValues['datesent'][$row];
			
			$dateSent = CommonUtil::convertToSQLiteDateFormat($_formValues['datesent'][$row]);
			
			//echo "date after : ".$dateSent;
			
			$updateQuery = "update plotdetails set datesent=:datesent, amount=:amount, ".
						   "notes=:notes where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':datesent', $dateSent);
			$stmt->bindValue(':amount', $_formValues['amount'][$row]);
			$stmt->bindValue(':notes', $_formValues['notes'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;	
	}
	
 }