<?php
 /**
 * Data Access for Projected Expenses
 *
 */ 
 class ProjExpDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'projections';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for ProjExpDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select p.id, p.name, p.estimatedcost, ".
							  "p.actualcost, p.notes from projections p ".
	      		              " where p.user = ". $this->_userid . 
	      		              " order by p.id",
		);
		
		return $queriesArray;
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->executeQuery($this->_getAllRecords);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();
		
		echo "id :".$id;
		
		$addQuery = "insert into projections (id, name, user, estimatedcost, actualcost, notes) values ".
						"(:id, :name, :user, :estimatedcost, :actualcost, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', 'Set Name');
		$stmt->bindValue(':user', $this->_userid);
		$stmt->bindValue(':estimatedcost', 'Set Estimated Cost');
		$stmt->bindValue(':actualcost', 'Set Actual Cost');
		$stmt->bindValue(':notes', '');
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$objectIds = $_formValues['objectIds'];
		echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update projections set name=:name, estimatedcost=:estimatedcost, ".
						   "actualcost=:actualcost, notes=:notes ".
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':name', $_formValues['prjname'][$row]);
			$stmt->bindValue(':estimatedcost', $_formValues['estimatedcost'][$row]);
			$stmt->bindValue(':actualcost', $_formValues['actualcost'][$row]);
			$stmt->bindValue(':notes', $_formValues['notes'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;	
	}
	
 }