<?php

 require_once APP_DATAACCESS . 'roledao.php';
 
 define(ADMIN_ROLE, '1');
 define(ADMIN_APPS_MODULE, 'Admin Apps');
 define(SUB_MODULE_CATEGORY, 'submodulecategory');
 define(SUB_MODULE_CATEGORY_VALUE, '2');
 define(NETWORK_SETTING, 'networksetting');
 define(NETWORK_SETTING_VALUE, 'AMD'); 
 
/**
 * Data Access for Users
 *
 */ 
 class UsersDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'user';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var usersettings
	 */
	public $usersettings = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var searchstrsettings
	 */
	public $submodulesearchstr = null;		
	
	/**
	 * 
	 * Object to hold current month
	 * @var String
	 */
	public $_currentMonth = null;
	
	/**
	 * 
	 * Object to hold current year
	 * @var String
	 */
	public $_currentYear = null;
	
	/**
	 * Contructor for UsersDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
		
					
		$current = CommonUtil::getCurrentMonthAndYearArray();
		
		$this->_currentYear = $current['year'];	
		$this->_currentMonth = $current['month'];	
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select u.id, u.username, u.password, r.name as role, u.createddate, ". 
								 "u.updateddate, u.tableid, ud.firstname, ud.lastname, ud.emailid, ud.phone,ud.address, ".
								 "ud.city, ud.state, ud.zip from user u, userdetails ud, user2role ur, role r ".
								 "where u.id=ud.userid and u.id=ur.userid and ur.roleid=r.id ".
								 "order by u.id"
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for expense category will be
      * retrieved and stored in array
      *
      * @return list - result of expense category
      *
      */
     public function getDropDownValues()
	{
		$roleDAO = new RoleDAO();
		
		// get info from ecategory
		$userrole_rs = $roleDAO->getOrderByName();
		
		return $userrole_rs;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->executeQuery($this->_getAllRecords);
	}
			

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
    public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$currentUser = $this->getUserCount() + 1;
		
		//echo 'curr user : '.$currentUser;
		
		$tableID = $this->generateTableID($currentUser);
		
		//echo 'table id : '.$tableID;
		
		$addUserQuery = "insert into user (username, password, createddate, updateddate, tableid) values ".
						"(:username, :password, :createddate, :updateddate, :tableid)";
		
		$stmt = $this->_conn->prepare($addUserQuery);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', md5($_formValues['password']));
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':tableid', $tableID);
		
		$result = $stmt->execute();
		
		$roleid = $_formValues['role'];

		if ($this->userExists($_formValues['username']))
		{
			$userid = $this->getUserId($_formValues['username'], $_formValues['password']);
			
			$this->addUserToRole($userid, $roleid);
			
			$this->addUserDetails($userid, $_formValues);	

			$this->initializeUserSettings($userid, $roleid);
			
			$this->addSubModuleSearchStrings($userid);
			
			$this->addScribbleData($tableID, $userid);
		}

		$this->_log->info("insert() - end");
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
	/**
	 * 
	 */
	public function userExists($username)
	{
		$this->_log->info("userExists() - start");
		
		$query = "SELECT * FROM USER WHERE USERNAME='".$username."'";
		$result = $this->executeQuery($query);	
			
		$rowsReturned = sizeof($result);

		if ($rowsReturned == 1)
		{
			$this->_log->info("userExists() - true");
			$this->_log->info("userExists() - end");
			return true;
		}
		else
		{
			$this->_log->info("userExists() - false");
			$this->_log->info("userExists() - end");			
			return false;
		}
	}
	
	/**
	 * Gets userid when username & password is given
	 * 
	 * @param $username
	 * @param $password
	 * 
	 * @return userid
	 */
	public function getUserId($username, $password)
	{
		$userid = null;

		$query = "select * from user where username='".$username."' and password='".md5($password)."'";

		$rs = $this->executeQuery($query);	
			
		$rowsReturned = count($rs);	

		if ($rowsReturned == 1)
		{		
			$row = $rs[0];
			
			$userid = $row['id']; 
		}
		
		return $userid;
	}

	/**
	 * Adds user to a role
	 * 
	 * @param  $userid
	 * @param  $roleid
	 */
	public function addUserToRole($userid, $roleid)
	{
		$this->_log->info("addUserToRole() - start");
		
		$addUserRoleQuery = "insert into user2role (userid, roleid) values ".
						    "(:userid, :roleid)";
		
		$stmt = $this->_conn->prepare($addUserRoleQuery);
		$stmt->bindValue(':userid', $userid);
		$stmt->bindValue(':roleid', $roleid);
		
		$result = $stmt->execute(); 
		
		$this->_log->info("addUserToRole() - end");
	}
	
	/**
	 * Adds a record into userdetails table
	 * 
	 * @param  $userid
	 * @param  $_formValues
	 */
	public function addUserDetails($userid, $_formValues)
	{
		$this->_log->info("addUserDetails() - start");
		
		$addUserRoleQuery = "insert into userdetails (userid, firstname, lastname, emailid, phone, address, city, state, zip) values ".
						    "(:userid, :firstname, :lastname, :emailid, :phone, :address, :city, :state, :zip)";
		
		$stmt = $this->_conn->prepare($addUserRoleQuery);
		$stmt->bindValue(':userid', $userid);
		$stmt->bindValue(':firstname', $_formValues['firstname']);
		$stmt->bindValue(':lastname', $_formValues['lastname']);
		$stmt->bindValue(':emailid', $_formValues['emailid']);
		$stmt->bindValue(':phone', $_formValues['phone']);
		$stmt->bindValue(':address', $_formValues['address']);
		$stmt->bindValue(':city', $_formValues['city']);
		$stmt->bindValue(':state', $_formValues['state']);
		$stmt->bindValue(':zip', $_formValues['zip']);
		
		$result = $stmt->execute(); 

		$this->_log->info("addUserDetails() - end");
	}
	
	/**
	 * Returns user role and details for given userid
	 * 
	 * @param $userid
	 */
	public function getUserAndRoleDetails($userid)
	{
		$this->_log->info("getUserAndRoleDetails() - start");
		
		$query = "select u.id, u.username, u.password, r.id as role, u.createddate, ". 
				 "u.updateddate, ud.firstname, ud.lastname, ud.emailid, ud.phone,ud.address, ".
				 "ud.city, ud.state, ud.zip from user u, userdetails ud, user2role ur, role r ".
				 "where u.id=ud.userid and u.id=ur.userid and ur.roleid=r.id and u.id=".$userid;
		
		$result = $this->executeQuery($query);
		
		$this->_log->info("getUserAndRoleDetails() - end");
		
		return $result;
	}
	
     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
    public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$updatePWD = true;
		$result = null;
		
		$updatedDate = CommonUtil::getCurrentDate();
		
		if ($_formValues['password'] == md5('nochange'))
		{
			$updatePWD = false;
		}
		
		if ($updatePWD)
		{
			$updateQuery = "update user set username=:username, password=:password, updateddate=:updateddate ".
						          "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':username', $_formValues['username']);		
			$stmt->bindValue(':password', md5($_formValues['password']));
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':id', $_formValues['id']);
			
			$result = $stmt->execute();
		}
		else
		{
			$updateQuery = "update user set username=:username, updateddate=:updateddate ".
						          "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':username', $_formValues['username']);		
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':id', $_formValues['id']);
			
			$result = $stmt->execute();			
		}
		
		if ($result == 1)
		{
			$this->updateUserRole($_formValues['id'], $_formValues['role']);
			
			$this->updateUserDetails($_formValues['id'], $_formValues);			
		}

		
		//echo "result : ".$result."<br>";
		
		$this->_log->info("update() - end");
		
		return $result;	
	}
	
	/**
	 * Updates user role
	 * 
	 * @param $userid
	 * @param $roleid
	 */
	public function updateUserRole($userid, $roleid)
	{
		$this->_log->info("updateUserRole() - start");
		
		$updateUserRoleQuery = "update user2role set roleid=:roleid ".
					           "where userid=:userid";
		
		$stmt = $this->_conn->prepare($updateUserRoleQuery);
		$stmt->bindValue(':roleid', $roleid);		
		$stmt->bindValue(':userid', $userid);
		
		$result = $stmt->execute();	

		$this->_log->info("updateUserRole() - end");
	}
	
	/**
	 * Updates user details
	 * 
	 * @param $userid
	 * @param $_formValues
	 */
	public function updateUserDetails($userid, $_formValues)
	{
		$this->_log->info("updateUserDetails() - start");
		
		$updateUserRoleQuery = "update userdetails set firstname=:firstname, lastname=:lastname, ".
							   "emailid=:emailid, phone=:phone, address=:address, city=:city, ".
		                       "state=:state, zip=:zip ".
					           "where userid=:userid";
		
		$stmt = $this->_conn->prepare($updateUserRoleQuery);
		$stmt->bindValue(':firstname', $_formValues['firstname']);		
		$stmt->bindValue(':lastname', $_formValues['lastname']);
		$stmt->bindValue(':emailid', $_formValues['emailid']);
		$stmt->bindValue(':phone', $_formValues['phone']);
		$stmt->bindValue(':address', $_formValues['address']);
		$stmt->bindValue(':city', $_formValues['city']);
		$stmt->bindValue(':state', $_formValues['state']);
		$stmt->bindValue(':zip', $_formValues['zip']);
		$stmt->bindValue(':userid', $userid);
		
		$result = $stmt->execute();	

		$this->_log->info("updateUserDetails() - end");
	}
	

	/**
	 * Delete selected users 
     *
	 */
	public function delete()
	{
		$this->_log->info("deleteUsers() - start");
		
		$userroledetails_rs = $this->deleteUserRoleDetails();
		
		$usersettings_rs = $this->deleteUserSettings();
		
		$submodsearchsettings_rs = $this->deleteSubModuleSearchSettings();
		
		$result = $this->deleteUsers();
		
		$this->_log->info("deleteUsers() - end");
		
		return $result;		

	}
	
	/**
	 * 
	 * Deletes user details and user2role details
	 * 
	 */
	public function deleteUserRoleDetails()
	{
		$this->_log->info("deleteUserRoleDetails() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete user dao : count : ".count($deleteIDs)."<br>";	

		foreach ($deleteIDs as &$id) {
			//echo "id : ".$id."<br>";
			
			$deleteUserDetailsQuery = "delete from userdetails where userid=".$id;
			$this->executeQuery($deleteUserDetailsQuery);

			$deleteUserRoleQuery = "delete from user2role where userid=".$id;
			$this->executeQuery($deleteUserRoleQuery);
		}		

		$this->_log->info("deleteUserRoleDetails() - end");
	}
	
	public function deleteUserSettings()
	{
		$this->_log->info("deleteUserSettings() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete user dao : count : ".count($deleteIDs)."<br>";	

		foreach ($deleteIDs as &$id) {
			//echo "id : ".$id."<br>";
			
			$deleteUserSettingsQuery = "delete from usersettings where user=".$id;
			$this->executeQuery($deleteUserSettingsQuery);
		}	

		$this->_log->info("deleteUserSettings() - end");
	}
	
	public function deleteSubModuleSearchSettings()
	{
		$this->_log->info("deleteSubModuleSearchSettings() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete user dao : count : ".count($deleteIDs)."<br>";	

		foreach ($deleteIDs as &$id) {
			//echo "id : ".$id."<br>";
			
			$deleteSubModSearchSettingsQuery = "delete from submodulesrchstr where user=".$id;
			$this->executeQuery($deleteSubModSearchSettingsQuery);
		}	

		$this->_log->info("deleteSubModuleSearchSettings() - end");		
	}
	
	public function deleteUsers()
	{
		$this->_log->info("deleteUsers() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		foreach ($deleteIDs as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$query = "delete from ".$this->_tableName." where id=".$id;
			$this->executeQuery($query);
		}		

		$this->_log->info("deleteUsers() - end");
	}
	
	/**
	 * 
	 * Gets the user count from database
	 * 
	 * @return user count
	 */
	public function getUserCount()
	{
		$query = "select * from user";
		$result = $this->executeQuery($query);
		
		$userCount = count($result);
		
		//echo 'user count : '.$userCount;
		
		return $userCount;		
	}
	
 	/**
	 * 
	 * Gets the max user id
	 * 
	 * @return max user id
	 */
	public function getMaxUserId()
	{
		$query = "select max(id) as maxid from user";
		$result = $this->executeQuery($query);
		
		$user = $result[0];
		
		$maxUserId = $user['maxid'];
		
		//echo 'maxUserId : '.$maxUserId;
		
		return $maxUserId;		
	}	
	
 	/**
	 * 
	 * Generates table id as per user count
	 * which is used for each user and can be 
	 * used while inserting rows into table so that 
	 * when data is migrated we will not face issues 
	 * with ids
	 * 
	 * @param $user
	 * @return id
	 */
	public function generateTableID($user)
	{
		$id = ($user * 100).($user * 100).(1*1);
		return $id;		
	}	
	
	/**
	 * 
	 * Initial User Settings required for a new user are set here
	 * @param unknown_type $userid
	 */
	public function initializeUserSettings($user, $roleid)
	{
		$this->_log->info("initializeUserSettings() - start");
		
		$adminAppsId = null;
		
		$homePageSettings = new usersettings($user, 'homepage', '123123', null, null);
		$this->insertUserSettingEntry($homePageSettings);
		
		$getModulesQuery = "select id, name from module";
		$modules_rs = $this->executeQuery($getModulesQuery);
		
		foreach($modules_rs as $modules => $module)
		{
			if ($roleid == ADMIN_ROLE)
			{
				$moduleSettings = new usersettings($user, 'module', $module['id'], 'yes', $module['name']);	
			}
			else 
			{
				if ($module['name'] == ADMIN_APPS_MODULE)
				{
					$adminAppsId = $module['id'];
					$moduleSettings = new usersettings($user, 'module', $module['id'], 'no', $module['name']);
				}
				else
				{
					$moduleSettings = new usersettings($user, 'module', $module['id'], 'yes', $module['name']);
				}
			}
			
			$this->insertUserSettingEntry($moduleSettings);
		}		
		
		$getSubModulesQuery = "select id, name, module from submodule";
		$sub_modules_rs = $this->executeQuery($getSubModulesQuery);		
		
		foreach($sub_modules_rs as $submodules => $submodule)
		{
			if ($roleid == ADMIN_ROLE)
			{
				$subModuleSettings = new usersettings($user, 'submodule', $submodule['id'], 'yes', $submodule['name']);	
			}
			else 
			{
				if ($submodule['module'] == $adminAppsId)
				{
					$subModuleSettings = new usersettings($user, 'submodule', $submodule['id'], 'no', $submodule['name']);
				}
				else
				{
					$subModuleSettings = new usersettings($user, 'submodule', $submodule['id'], 'yes', $submodule['name']);
				}
			}
			
			$this->insertUserSettingEntry($subModuleSettings);
		}

		$monthlyExpYearSettings = new usersettings($user, MONTHLY_EXPENSES_YEAR, $this->_currentYear, null, 'Monthly Expenses Report Year');
		$this->insertUserSettingEntry($monthlyExpYearSettings);
		
		$categorizedExpMonthSettings = new usersettings($user, CATEGORIZED_EXPENSES_MONTH, $this->_currentMonth, null, 'Expense Category Month');
		$this->insertUserSettingEntry($categorizedExpMonthSettings);
		
		$categorizedExpYearSettings = new usersettings($user, CATEGORIZED_EXPENSES_YEAR, $this->_currentYear, null, 'Expense Category Year');
		$this->insertUserSettingEntry($categorizedExpYearSettings);
		
		$categorizedChartExpMonthSettings = new usersettings($user, CATEGORIZED_CHART_EXPENSES_MONTH, $this->_currentMonth, null, 'Expense Category Chart Month');
		$this->insertUserSettingEntry($categorizedChartExpMonthSettings);
		
		$categorizedChartExpYearSettings = new usersettings($user, CATEGORIZED_CHART_EXPENSES_YEAR, $this->_currentYear, null, 'Expense Category Chart Year');
		$this->insertUserSettingEntry($categorizedChartExpYearSettings);		
		
		$weeklyExpMonthSettings = new usersettings($user, WEEKLY_EXPENSES_MONTH, $this->_currentMonth, null, 'Expense Weekly Month');
		$this->insertUserSettingEntry($weeklyExpMonthSettings);
		
		$weeklyExpYearSettings = new usersettings($user, WEEKLY_EXPENSES_YEAR, $this->_currentYear, null, 'Expense Weekly Year');
		$this->insertUserSettingEntry($weeklyExpYearSettings);		
		
		$subModuleCategorySettings = new usersettings($user, SUB_MODULE_CATEGORY, SUB_MODULE_CATEGORY_VALUE, null, 'Sub Module Category');
		$this->insertUserSettingEntry($subModuleCategorySettings);
		
		$enviromentSettings = new usersettings($user, NETWORK_SETTING, NETWORK_SETTING_VALUE, null, 'Network Setting');
		$this->insertUserSettingEntry($enviromentSettings);		
		
		$this->_log->info("initializeUserSettings() - end");
		
	}
	
	public function insertUserSettingEntry($usersettings)
	{
		$this->_log->info("insertUserSettingEntry() - start");
		
		$addUserSettingsQuery = "insert into usersettings (user, identifier, value, visible, description) values ".
						    "(:user, :identifier, :value, :visible, :description)";
		
		$stmt = $this->_conn->prepare($addUserSettingsQuery);
		$stmt->bindValue(':user', $usersettings->_user);
		$stmt->bindValue(':identifier', $usersettings->_identifier);
		$stmt->bindValue(':value', $usersettings->_value);
		$stmt->bindValue(':visible', $usersettings->_visible);
		$stmt->bindValue(':description', $usersettings->_description);
		
		$result = $stmt->execute();		

		$this->_log->info("insertUserSettingEntry() - end");
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $user
	 */
	public function addSubModuleSearchStrings($user)
	{
		$this->_log->info("addSubModuleSearchStrings() - start");
		
		$getSubModulesQuery = "select id, name, module from submodule";
		$sub_modules_rs = $this->executeQuery($getSubModulesQuery);		
		
		foreach($sub_modules_rs as $submodules => $submodule)
		{
			$id = $this->generateIDWithTableForUser('submodulesrchstr', $user);
			
			$subModuleSearchSettings = new submodulesearchstr($id, $user, $submodule['id']);	

			$this->insertSubModSearchEntry($subModuleSearchSettings);
		}	

		$this->_log->info("addSubModuleSearchStrings() - end");
		
	}
	

	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $subModuleSearchSettings
	 */
	public function insertSubModSearchEntry($subModuleSearchSettings)
	{
		$this->_log->info("insertSubModSearchEntry() - start");
		
		$addSubModSearchSettingsQuery = "insert into submodulesrchstr (id, searchstring, submodule, user, lastmodifieddate) values ".
						    "(:id, :searchstring, :submodule, :user, :lastmodifieddate)";
		
		$stmt = $this->_conn->prepare($addSubModSearchSettingsQuery);
		$stmt->bindValue(':id', $subModuleSearchSettings->_id);
		$stmt->bindValue(':searchstring', $subModuleSearchSettings->_searchstr);
		$stmt->bindValue(':submodule', $subModuleSearchSettings->_submodule);
		$stmt->bindValue(':user', $subModuleSearchSettings->_user);
		$stmt->bindValue(':lastmodifieddate', $subModuleSearchSettings->_lastmodifieddate);
		
		$result = $stmt->execute();	

		$this->_log->info("insertSubModSearchEntry() - end");
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $tableID
	 * @param unknown_type $userId
	 */
	public function addScribbleData($tableID, $userId)
	{
		$this->_log->info("addScribbleData() - start");
		
		$addScribbleDataQuery = "insert into scribble (id, user) values ".
						    "(:id, :user)";	
		
		$stmt = $this->_conn->prepare($addScribbleDataQuery);
		$stmt->bindValue(':id', $tableID);
		$stmt->bindValue(':user', $userId);
		
		$result = $stmt->execute();			

		$this->_log->info("addScribbleData() - end");
	}
	
 }