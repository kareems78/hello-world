<?php
/**
 * Data Access for Otwhours
 *
 */ 
 class OtwhoursDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'otwhours';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
     *
     */	 
	public static $_formValues = null;
	
 	/**
	 * Contructor for OtwhoursDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}	

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" =>"select * from otwhours ".
        					   "where user = " . $this->_userid . " order by otwhdate desc",
						  
		);
		
		return $queriesArray;
	}
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$this->_log->info("insert() - start");
	 	
		$otwhoursDate = CommonUtil::convertToSQLiteDateFormat($_formValues['otwhdate']);
		
		$id = $this->generateID();
		
		$addQuery = "insert into " . $this->tableName . " (id, otwhdate, otwhdesc, noofhours, user, used, notes) values ".
						"(:id, :otwhdate, :otwhdesc, :noofhours, :user, :used, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':otwhdate', $otwhoursDate);
		$stmt->bindValue(':otwhdesc', $_formValues['otwhdesc']);
		$stmt->bindValue(':noofhours', $_formValues['noofhours']);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':used', 'no');
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		$this->_log->info("insert() - end");
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		
		$otwhoursDate = CommonUtil::convertToSQLiteDateFormat($_formValues['otwhdate']);
		
		if ($_formValues['utiliseddate'] != '' && strtolower($_formValues['used']) == 'yes')
		{
			$utilisedDate = CommonUtil::convertToSQLiteDateFormat($_formValues['utiliseddate']);
		}
		else
		{
			$utilisedDate = '';
		}
		
		$updateQuery = "update " . $this->tableName . " set otwhdate=:otwhdate, otwhdesc=:otwhdesc, noofhours=:noofhours, ".
					   "used=:used, utiliseddate=:utiliseddate, notes=:notes where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':otwhdate', $otwhoursDate);
		$stmt->bindValue(':otwhdesc', $_formValues['otwhdesc']);
		$stmt->bindValue(':noofhours', $_formValues['noofhours']);
		$stmt->bindValue(':used', $_formValues['used']);
		$stmt->bindValue(':utiliseddate', $utilisedDate);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

      /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
     {

         if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '')
         {
             $this->_log->info("no value is sent");
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['fromdate'] != '')
             {
                 $fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
             }

             if ($_formValues['todate'] != '')
             {
                 $toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
             }

             if ($_formValues['fromdate'] != '')
             {
                 // only if fromdate is selected
                 if ($_formValues['todate'] == '')
                 {
                     $searchQuery = "(o.otwhdate between '". $fromDate . "' and '" . $fromDate . "') ";
                 }

                 // both fromdate & todate is selected
                 if ($_formValues['todate'] != '')
                 {
                     $searchQuery = "(o.otwhdate between '". $fromDate . "' and '" . $toDate . "') ";
                 }
             }
         }
         
         $this->updateSubModuleSearchString($searchQuery);

         return $searchQuery;

     }

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($records_per_page)
     {
     	$searchStr = $this->getSubModuleSearchString();
     	
         if ($searchStr != '')
         {
             $searchQuery = "select * from otwhours o where ". $searchStr ." and o.user = " . $this->_userid . " order by o.otwhdate";
         }
         else
         {
             $searchQuery = "select * from otwhours where user = " . $this->_userid . " order by otwhdate";
         }

         //echo "search query -> ".$getSTQuery."<br>";

         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

 }