<?php
/**
 * Data Access for Daily Aamal Tracker
 *
 */ 
 class DatrackerDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'datracker';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Object to hold dialy aamal tracker values
	 * @var dialy aamal tracker dto
	 */
	protected $datracker = null;

	/**
	 * 
	 * Object to hold current start date.
	 * @var String
	 */
	public $_currStartDate = null;
	
	/**
	 * 
	 * Object to hold current end date.
	 * @var String
	 */
	public $_currEndDate = null;
	
	/**
	 * Contructor for DatrackerDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
         $dateRange = CommonUtil::dateRangeForCurrent();
         $this->_currStartDate = $dateRange['start'];
         $this->_currEndDate = $dateRange['end'];		
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from datracker where (datdate between '" . $this->_currStartDate . "' and '" . $this->_currEndDate . "') ".
                       "and user = " . $this->_userid . " order by datdate",
		);
		
		return $queriesArray;
	}

    	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insertDATracker()
	{
		$this->_log->info("insertDATracker() - start");
		
		$id = $this->generateID();
		
		//echo "id : ".$id;		
		
		$addQuery = "insert into datracker (id, datdate, createddate, updateddate, user, morningdhikr, ishraq, eveningdhikr, ".
		             "taleem, muzakira, recitequran, notes) values ".
					 "(:id, :datdate, :createddate, :updateddate, :user, :morningdhikr, :ishraq, :eveningdhikr, ".
					 ":taleem, :muzakira, :recitequran, :notes)";
		try
		{
			$stmt = $this->_conn->prepare($addQuery);
			$stmt->bindValue(':id', $id);
			$stmt->bindValue(':datdate', $this->datracker->_datdate);
			$stmt->bindValue(':createddate', $this->datracker->_createddate);
			$stmt->bindValue(':updateddate', $this->datracker->_updateddate);
			$stmt->bindValue(':user', $this->datracker->_user);
			$stmt->bindValue(':morningdhikr', $this->datracker->_morningdhikr);
			$stmt->bindValue(':ishraq', $this->datracker->_ishraq);		
			$stmt->bindValue(':eveningdhikr', $this->datracker->_eveningdhikr);
			$stmt->bindValue(':taleem', $this->datracker->_taleem);
			$stmt->bindValue(':muzakira', $this->datracker->_muzakira);
			$stmt->bindValue(':recitequran', $this->datracker->_recitequran);
			$stmt->bindValue(':notes', $this->datracker->_notes);
			
			$result = $stmt->execute();
		
		}
		catch(PDOException $Exception)
		{
			return $Exception->getCode();
			throw new DatabaseException($Exception->getMessage() , $Exception->getCode());
		} 
		
		$this->_log->info("insertDATracker() - end");
		
		//echo "result : ".$result."<br>";
		return $result;
	
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		$morningdhikrIds = $_formValues['morningdhikr'];
		
		$row = 0;
		
		foreach ($morningdhikrIds as $morningdhikrId) 
		{
			
			if ($_formValues['datdate'.$row] != '')
			{
				//echo "<br> Expense : " . $row . " will be inserted";
				
				$this->datracker = new datracker($_formValues['datdate'.$row], $_formValues['userid'], 
					$_formValues['morningdhikr'][$row], $_formValues['ishraq'][$row], 
					$_formValues['eveningdhikr'][$row], $_formValues['taleem'][$row], 
					$_formValues['muzakira'][$row], $_formValues['recitequran'][$row],
					$_formValues['notes'][$row]);
					
				$result = $this->insertDATracker();				
			}
			
			$row = $row + 1;
		}
		
		$this->_log->info("insert() - end");
		
		return $result;
	}	

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$updatedDate = CommonUtil::getCurrentSqliteFormatDate();
		$datDate = CommonUtil::convertToSQLiteDateFormat($_formValues['datdate']);
		
		$updateQuery = "update datracker set datdate=:datdate, updateddate=:updateddate, morningdhikr=:morningdhikr, ishraq=:ishraq, ".
		               "eveningdhikr=:eveningdhikr, taleem=:taleem, muzakira=:muzakira, recitequran=:recitequran, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':datdate', $datDate);
		$stmt->bindValue(':updateddate', $updatedDate);
		$stmt->bindValue(':morningdhikr', $_formValues['morningdhikr']);
		$stmt->bindValue(':ishraq', $_formValues['ishraq']);		
		$stmt->bindValue(':eveningdhikr', $_formValues['eveningdhikr']);
		$stmt->bindValue(':taleem', $_formValues['taleem']);
		$stmt->bindValue(':muzakira', $_formValues['muzakira']);
		$stmt->bindValue(':recitequran', $_formValues['recitequran']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     public function search($records_per_page)
     {
     	 $searchStr = $this->getSubModuleSearchString();
     	
         if ($searchStr != '')
         {
             $searchQuery = "select * from datracker d where ". $searchStr ." and d.user = " . $this->_userid . " order by d.datdate";
         }
         else
         {
             $searchQuery = "select * from datracker where user = " . $this->_userid . " order by datdate";
         }

         //echo "search query -> ".$getSTQuery."<br>";

         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
     {

         if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '')
         {
             $this->_log->info("no value is sent");
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['fromdate'] != '')
             {
                 $fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
             }

             if ($_formValues['todate'] != '')
             {
                 $toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
             }

             if ($_formValues['fromdate'] != '')
             {
                 // only if fromdate is selected
                 if ($_formValues['todate'] == '')
                 {
                     $searchQuery = "(d.datdate between '". $fromDate . "' and '" . $fromDate . "') ";
                 }

                 // both fromdate & todate is selected
                 if ($_formValues['todate'] != '')
                 {
                     $searchQuery = "(d.datdate between '". $fromDate . "' and '" . $toDate . "') ";
                 }
             }
         }
         
         $this->updateSubModuleSearchString($searchQuery);

         return 	$searchQuery;

     }
     
     /**
      * created to update dates when added after designing the table.
      * gets datdate and updates them in createddate and updateddate.
      * Used only once
      * 
      */
     public function updateDates()
     {
     	
     	$query = 'select id, datdate from datracker';
     	
     	$result = $this->executeQuery($query);
     	
     	while($row = mysqli_fetch_array($result))
    	{
    		$updateQ = "update datracker set createddate=:createddate, updateddate=:updateddate where id=:id"; 
			
			$stmtUp = $this->_conn->prepare($updateQ);
			$stmtUp->bindValue(':updateddate', $row['datdate']);
			$stmtUp->bindValue(':createddate', $row['datdate']);
			$stmtUp->bindValue(':id', $row['id']);
			
			$result2 = $stmtUp->execute();    		
		}
     }
	
 }