<?php

/**
 * Data Access for DB Env Details
 *
 */
class DBEnvDetailsDAO extends BaseDAO
{
    /**
     * Object to hold table associated with
     * this DAO
     *
     */
    protected $tableName = 'dbenvdetails';

    /**
     * Object to hold get all records query
     *
     */
    public $_getAllRecords = null;

    /**
     *
     */
    public static $_formValues = null;

    /**
     * Contructor for EnvDAO
     * Calls BaseDAO construction and sets the table name.
     *
     *
     */
    public function __construct($userid)
    {
    	//echo "in dao constructor .. " . $userid;
    	parent::__construct($this->tableName, $userid);

        $queries = $this->getQueries();

        // sets the query to get all records
        $this->_getAllRecords = $queries['getAllRecordsQuery'];
        
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);        

    }

    /**
     * All the queries required
     *
     * return of array of all queries
     */
    protected function getQueries()
    {
        $queriesArray = array(
            "getAllRecordsQuery" => "select * from dbenvdetails ".
        							"where user = " . $this->_userid . " order by id desc",
        );

        return $queriesArray;
    }
    
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		$records_per_page = 3;
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	   

    /**
     * Inserts a row into the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function insert($_formValues)
    {
        //echo "user id : " . $userid;
        $id = $this->generateID();

        $addQuery = "insert into dbenvdetails (id, envname, dbenvdetails, user, description) values ".
            		"(:id, :envname, :dbenvdetails, :user, :description)";

		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
        $stmt->bindValue(':envname', 'Set Env Name');
        $stmt->bindValue(':dbenvdetails', 'Set DB Env Details');
        $stmt->bindValue(':user', $this->_userid);	
        $stmt->bindValue(':description', ' ');

        $result = $stmt->execute();

        //echo "result : ".$result."<br>";

        return $result;
    }

    /**
     * Updates a row in the database
     *
     * @param $_formValues
     * @return bool
     *
     */
    public function update($_formValues)
    {
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update dbenvdetails set envname=:envname, dbenvdetails=:dbenvdetails, description=:description ".
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':envname', $_formValues['envname'][$row]);
			$stmt->bindValue(':dbenvdetails', $_formValues['dbenvdetails'][$row]);
			$stmt->bindValue(':description', $_formValues['description'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;
    }

}