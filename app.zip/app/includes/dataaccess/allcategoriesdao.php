<?php
/**
 * Data Access for All Categories
 *
 */ 
 class AllCategoriesDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'submodule';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllSubModCategories = null;
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllSubModWithCategoryExists = null;	
	
	/**
     *
     */	 
	public static $_formValues = null;
	
	/**
	 * Contructor for AllCatDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllSubModCategories = $queries['getAllSubModCategoriesQuery'];	
		
		$this->_getAllSubModWithCategoryExists = $queries['getAllSubModWithCategoryExistsQuery'];
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllSubModCategoriesQuery" => "select id, name, category from submodule ".
									  "where id in (select value from usersettings ".
									  "where identifier='submodulecategory' and user = ". $this->_userid .")",
		"getAllSubModWithCategoryExistsQuery" => "select id, name, category from submodule where category != ''",
		);
		
		return $queriesArray;
	}

     /**
      * Retrieves module categories
      *
      * @return mixed
      *
      */
     public function getSubModCategories()
	{
		
		$this->_log->info("getSubModCategories() - start");
		
		// get info from submenu to display in drop down
		$subModDropDrownValues_rs = $this->executeQuery($this->_getAllSubModWithCategoryExists);
		
		$tmp_rs = $this->executeQuery($this->_getAllSubModCategories);
		
		
		if ($tmp_rs != null)
		{
			$row = $tmp_rs[0];
		}
		else 
		{
			$this->_log->info("usersetting for submodulecategory does not exist");
			$this->_log->info("default sub category value will be set to : " . $subModDropDrownValues_rs[0]['id']);
			$this->updateDefaultValues($subModDropDrownValues_rs[0]['id']);
			
			$tmp_rs = $this->executeQuery($this->_getAllSubModCategories);
			
			$row = $tmp_rs[0];
		}
		
		
		$subModCategories = new CategoryDAO($row['category']);
		
		// get info for above category for which isdefault set as 'yes'
		$subModCategories_rs = $subModCategories->getOrderByName();
		
		// push result set to array
		$rsArray["SUBMODULEDROPDOWNVALUES"] = $subModDropDrownValues_rs;
		$rsArray["SUBMODCATEGORIES"] = $subModCategories_rs;
		$rsArray["SUBMODNAME"] = $row['name'];	
		
		$this->_log->info("getSubModCategories() - end");

		return $rsArray;		
		
	}

     /**
      * Insert is done after validating category
      *
      * @param $_formValues
      * @return int
      *
      */
     public function insertAfterValidation($_formValues)
	{
		$this->_log->info("insertAfterValidation() - start");
		
		$rowCount = $this->validateCategoryName($_formValues);
		
		if ($rowCount == 1)
		{
			// if row count is 1 that means 
			$this->_log->info("Category name entered already exists, returning row count : ". $rowCount);
			$this->_log->info("insertAfterValidation() - end");
			return $rowCount;
		}
		else
		{
			$result = $this->insert($_formValues);
			$this->_log->info("Result from insert : ". $result);
			$this->_log->info("insertAfterValidation() - end");
			return $result;
		}
	}

     /**
      * Validates category name
      *
      * @param $_formValues
      * @return int - count
      *
      */
     public function validateCategoryName($_formValues)
	{
		$this->_log->info("validateCategoryName() - start");
		
		$categoryTable = $this->getCategoryTableById($_formValues['submoduleid']);
		$name = strtolower($_formValues['name']);
		
		$vCatNameQuery = "select * from ".$categoryTable." where lower(name)='".$name."'";
		
		$rowCount = $this->getNumOfRows($vCatNameQuery);
		
		$this->_log->info("Rows returned for category name : " . $name . " is : " . $rowCount);
		
		$this->_log->info("validateCategoryName() - end");
		
		return $rowCount;
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return int
      *
      */
     public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		$returnOnSuccess = 1;
		$categoryTable = $this->getCategoryTableById($_formValues['submoduleid']);
		$desc = $_formValues['desc'];
		
		$this->_log->info("Category Table - " . $categoryTable);
		
		if (strtolower($categoryTable) == 'ecategory')
		{
			$categoryDAO = new ECategoryDAO($categoryTable);
			$add_rs = $categoryDAO->insert($_formValues);			
		}
		else
		{
			$categoryDAO = new CategoryDAO($categoryTable);
			$add_rs = $categoryDAO->insert($_formValues);			
		}

		
		$this->updateDefaultValues($_formValues['submoduleid']);
		
		//echo "result : ".$result."<br>";
		
		if ($add_rs == 1)
		{
			$this->_log->info("setting returnOnSuccess to 0");
			$returnOnSuccess = 0;
		}
		
		$this->_log->info("insert() - end");
		
		return $returnOnSuccess;	
	}

     /**
      * Update default value to yes for a given
      * category name
      *
      * @param $categoryTable
      *
      */
     public function updateDefaultValues($submodule)
	{
		$this->_log->info("updateDefaultValues() - start");
		//set "yes" for current category to view
		$updateQuery = "update usersettings set value=:value where identifier=:identifier and user=:user";
		
		$updateStmt = $this->_conn->prepare($updateQuery);
		$updateStmt->bindValue(':value', $submodule);
		$updateStmt->bindValue(':identifier', 'submodulecategory');
		$updateStmt->bindValue(':user', $this->_userid);
		
		$update_rs = $updateStmt->execute();	

		$this->_log->info("updateDefaultValues() - end");
	}

     /**
      * Deletes category linked to sub menu
      *
      * @param $_formValues
      *
      */
     public function delete($_formValues)
	{
		$this->_log->info("delete() - start");
		
		$categoryTable = $this->getCategoryTable($_formValues['submodforcategory']);
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$result = $categoryDAO->deleteCategories($_formValues);		
		
		$this->_log->info("delete() - end");
	}
	
     /**
      * Finds category from sub menu table
      * for given input of sub menu
      *
      * @param $smenu
      * @return mixed
      *
      */
     private function getCategoryTable($submodule)
	 {
		$this->_log->info("getCategoryTable() - start");
		
		$query = "select category from submodule where lower(name)='".strtolower($submodule)."'";
		
		$result = $this->executeQuery($query);
		
		$row = $result[0];
		
		$this->_log->info("getCategoryTable() - end");
		
		return $row['category'];
		
	}
	
      /**
      * Finds category from sub menu table
      * for given input of sub menu
      *
      * @param $smenu
      * @return mixed
      *
      */
     private function getCategoryTableById($subModuleId)
	 {
	 	$this->_log->info("getCategoryTableById() - start");
	 	
		$query = "select category from submodule where id='".$subModuleId."'";
		
		$result = $this->executeQuery($query);
		
		$row = $result[0];
		
		$this->_log->info("getCategoryTableById() - end");
		
		return $row['category'];
		
	}	

     /**
      * Retrieves category for given sub menu
      *
      * @param $id
      * @param $smenu
      * @return mixed
      *
      */
     public function getCategoryBySubModule($id, $submodule)
	{
		$this->_log->info("getCategoryBySubModule() - start");
		
		$this->_log->info("getCategoryBySubModule() - submodule passed => ".$submodule);
		
		$categoryTable = $this->getCategoryTable($submodule);
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$category_rs = $categoryDAO->getByID($id);
		
		//$row = $category_rs[0];
		
		// push result set to array
		//$rsArray["category"] = $row;
		//$rsArray["submodule"] = $submodule;
		
		$this->_log->info("getCategoryBySubModule() - end");

		return $category_rs;		
	}

     /**
      * Update category in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function updateCategories($_formValues)
	{
		$this->_log->info("updateCategories() - start");
		
		$categoryTable = $this->getCategoryTable($_formValues['submodulename']);
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$result = $categoryDAO->update($_formValues);
		
		$this->_log->info("updateCategories() - end");
		
		return $result;
	}

 }