<?php
/**
 * Data Access for Credential
 *
 */ 
 class CredentialDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'credential';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for CredentialDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select c.id, c.name, c.createddate, c.username, c.password, cc.name as cname, ".
							  "c.url, c.notes from Credential c, CCategory cc ".
	      		              " where c.category = cc.id and c.user = ".$this->_userid." order by c.createddate desc",
		);
		
		return $queriesArray;
	}
	
	/**
	 * Values required to display in drop down list
	 * for credential category will be 
	 * retrieved and stored in array
	 *
	 * returns result of credential category
	 */
	public function getDropDownValues()
	{
		$this->_log->info("getDropDownValues() - start");
		
		$ccategoryDAO = new CategoryDAO('ccategory');
		
		// get info from ccategory
		$ccategory_rs = $ccategoryDAO->getOrderByName();
		
		$this->_log->info("getDropDownValues() - end");
		
		return $ccategory_rs;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into credential (id, name, createddate, username, password, user, category, url, notes) values ".
						"(:id, :name, :createddate, :username, :password, :user, :category, :url, :notes)";
		
		//$this->_log->info("cred name --- ". $_formValues['name']);
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', $_formValues['password']);
		$stmt->bindValue(':user', $_formValues['userid']);				
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		$this->_log->info("insert() - end");
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$updateQuery = "update credential set name=:name, username=:username, password=:password, category=:category, url=:url, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', $_formValues['password']);		
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		$this->_log->info("update() - end");
		
		return $result;	
	}

     /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
	{
		
		$this->_log->info("generateSearchQuery() - start");
		
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['createddate'] == '' and $_formValues['name'] == '' and $_formValues['category'] == '')
		{
			$this->_log->info("no value is sent");
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['createddate'] != '')
			{
				$createdDate = CommonUtil::convertToSQLiteDateFormat($_formValues['createddate']);
			}
			
			if ($_formValues['name'] != '')
			{
				$name = strtolower($_formValues['name']);
			}			
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			
			if ($_formValues['name'] != '')
			{
				// only if name is selected
				if ($_formValues['createddate'] == '' and $_formValues['category'] == '')
				{
					$searchQuery = "and lower(c.name) like '%". $name ."%'";
				}
				
				// both name & createddate are selected
				if ($_formValues['createddate'] != '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (c.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
					               "and lower(c.name) like '%". $name ."%'";
				}	

				// both name and category are selected
				if ($_formValues['category'] != '' and $_formValues['createddate'] == '')
				{
					$searchQuery = "and lower(c.name) like '%". $name ."%' ".
					               "and c.category in (".$categoryIDs.")";
				}					

				// name, createddate and category are selected
				if ($_formValues['createddate'] != '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (c.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
					               "and lower(c.name) like '%". $name ."%' ".
					               "and c.category in (".$categoryIDs.")";
				}				
			}
			// createddate and category is selected
			elseif ($_formValues['name'] == '' and $_formValues['category'] != '' and $_formValues['createddate'] != '')
			{
				$searchQuery = "and (c.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
				               "and c.category in (".$categoryIDs.")";
			}				
			elseif ($_formValues['category'] != '' and $_formValues['name'] == '')
			{
				$searchQuery = "and c.category in (".$categoryIDs.")";
			}
			elseif ($_formValues['name'] == '' and $_formValues['createddate'] != '' and $_formValues['category'] == '')
			{
				$searchQuery = "and (c.createddate  between '". $createdDate . "' and '" . $createdDate . "')";
			}
		}
		
		
		$this->_log->info("Search Query String ==> ".$searchQuery);
		
		$this->updateSubModuleSearchString($searchQuery);
		
		$this->_log->info("generateSearchQuery() - end");

		return 	$searchQuery;
		
	}

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($records_per_page)
	{
		$this->_log->info("search() - start");
		
		$searchStr = $this->getSubModuleSearchString();
		
		$searchQuery = "select c.id, c.name, c.createddate, c.username, c.password, cc.name as cname, ".
				 "c.url, c.notes from Credential c, CCategory cc ".
	      		 " where c.category = cc.id ".$searchStr." and c.user = ". $this->_userid .
				 " order by c.createddate desc";
		
		$this->_log->info("Search Query ==> ".$searchQuery);
		
		//echo "Search Query => " . $searchQuery;
				 
		$result = $this->getViewDataResultSets($searchQuery, $records_per_page);
		
		$this->_log->info("search() - end");
		
		return $result;
	}
	

 }