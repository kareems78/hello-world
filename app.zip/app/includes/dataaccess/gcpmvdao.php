<?php
/**
 * Data Access for GCP-MV
 *
 */ 
 class GcpmvDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'circuittypes';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_orastmt = null;	
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_actionHistoryId = null;
	
	/**
	 * 
	 * Object to hold expense values
	 * @var mvextract info dto
	 */
	public $mvextract = null;
	
	/**
	 * 
	 * Object to hold expense values
	 * @var mvrefresh info dto
	 */
	public $mvrefresh = null;	
	
	/**
	 * Contructor for GcpmvDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
		
		$this->getOraConnection();		
	
	}
	
       /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	{
		$mvConfigQuery = "select id, name from mvconfig order by id";
		$mvconfig_rs = $this->executeQuery($mvConfigQuery);
		
		$mvRefModQuery = "select id, name from mvrefreshmodule order by name";
		$mvrefmod_rs = $this->executeQuery($mvRefModQuery);	

		$gcpMVProcQuery = "select distinct procname from mvrefreshmodule where schema='GCP_USER' order by procname";
		$gcpmvproc_rs = $this->executeQuery($gcpMVProcQuery);			
		
		$cramerMVProcQuery = "select distinct procname from mvrefreshmodule where schema='CRAMER' order by procname";
		$cramermvproc_rs = $this->executeQuery($cramerMVProcQuery);			
		
		$mvActionsQuery = "select id, name, value from mvactions order by name";
		$mvactions_rs = $this->executeQuery($mvActionsQuery);				
		
		// push result set to array
		$dropDownArray["envlist"] = $this->getEnvConnectionDropDownValues();
		$dropDownArray["mvconfiglist"] = $mvconfig_rs;
		$dropDownArray["mvrefmodlist"] = $mvrefmod_rs;
		$dropDownArray["gcpmvproclist"] = $gcpmvproc_rs;
		$dropDownArray["cramermvproclist"] = $cramermvproc_rs;
		$dropDownArray["mvactionslist"] = $mvactions_rs;
		
		return $dropDownArray;
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function getMvConfigInfo($_formValues)
	{
		$this->_log->info("getMvConfigInfo() - start");
		
		$mvConfigType = $_formValues['mvconfigtype'];
		
		if ($_formValues['configname'] != "")
		{
			$configName = $_formValues['configname'];	
		}
		
		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		if ($mvConfigType == 'JOBMANAGEMENT')
		{
			$query = "select configid, name, configtype, value from gcp_mv_config where configtype=:configtype order by value";
		}
		else 
		{
			$query = "select configid, name, configtype, value from gcp_mv_config where configtype=:configtype order by 1";	
		}
		
		if (isset($configName))
		{
			$query = $query . " AND name = :configname";
		}
		
		//$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
	
			oci_bind_by_name($this->_orastmt, ":configtype", $mvConfigType);
			
			if (isset($configName))
			{
				oci_bind_by_name($this->_orastmt,":configname", $configName);
			}		
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["mvconfigtype"] = $mvConfigType;
				
			$this->_log->info("getMvConfigInfo() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}
	
	}
	
  	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function setMvFlags($_formValues)
	{
		$this->_log->info("setMvFlags() - start");
		
		if(array_key_exists('enable' , $_formValues))
        {
        	$flag = 'ENABLE';	
        }		
        
		if(array_key_exists('disable' , $_formValues))
        {
        	$flag = 'DISABLE';	
        }        
		
	    if(!array_key_exists('mvrefreshmodule' , $_formValues))
        {
            $_formValues['mvrefreshmodule'] = "";
        }	
		else 	
        {
	         $tmp_mvRefreshModules = CommonUtil::generateStringWithCommas($_formValues['mvrefreshmodule']);
	         if (sizeof($_formValues['mvrefreshmodule']) > 1)
	         {
	         	$mvRefreshModules = CommonUtil::generateStringWithQuoteCommas($tmp_mvRefreshModules);	
	         }
	         else
	         {
	         	$mvRef = explode("_REFRESH", $tmp_mvRefreshModules);
	         	$mvRefreshModules = $mvRef[0];
	         }
        }         
		
		$mvConfigType = $_formValues['mvconfigtype'];
		
		$this->_log->info ("Length of Array ==> " . sizeof($_formValues['mvrefreshmodule']));
		$this->_log->info (" mvRefreshModules ==> " . $mvRefreshModules);
		
		if ($mvConfigType != null and $_formValues['mvrefreshmodule'] != "")
		{
			if (sizeof($_formValues['mvrefreshmodule']) > 1)
			{
				
				$query = "select name, complete_refresh, process_missing_data, process_missing_update, process_missing_delete from gcp_mv_module_settings where name in (".$mvRefreshModules.") ";
			}
			else
			{
				//$mvRef = explode("_REFRESH", $mvRefreshModules);
				$query = "select name, complete_refresh, process_missing_data, process_missing_update, process_missing_delete from gcp_mv_module_settings where name like '" . $mvRefreshModules. "%'"; 	
			}
		}
		elseif ($mvConfigType == null) 
		{
			if (sizeof($_formValues['mvrefreshmodule']) > 1)
			{
				$query = "select name, complete_refresh, process_missing_data, process_missing_update, process_missing_delete from gcp_mv_module_settings where name in (".$mvRefreshModules.") ";
			}
			else
			{
				$query = "select name, complete_refresh, process_missing_data, process_missing_update, process_missing_delete from gcp_mv_module_settings where name like '" .$mvRefreshModules. "%'";
			}	
		}	

		// Will be used to retreive result after update is done
		$tmp_query = $query;

		if ($flag != null)
		{
			$this->_log->info ("Setting flag for Config Type : " . $mvConfigType . " to " . $flag);
			
			if (sizeof($_formValues['mvrefreshmodule']) > 1)
			{
				if ($mvConfigType == 'COMPLETE_REFRESH')
				{
					$query = "update gcp_mv_module_settings set complete_refresh=:value where name in (".$mvRefreshModules.") ";
				}
				elseif ($mvConfigType == 'PROCESS_MISSING_DATA')
				{
					$query = "update gcp_mv_module_settings set process_missing_data=:value where name in (".$mvRefreshModules.") ";
				}
				elseif ($mvConfigType == 'PROCESS_MISSING_UPDATE')
				{
					$query = "update gcp_mv_module_settings set process_missing_update=:value where name in (".$mvRefreshModules.") ";
				}
				elseif ($mvConfigType == 'PROCESS_MISSING_DELETE')
				{
					$query = "update gcp_mv_module_settings set process_missing_delete=:value where name in (".$mvRefreshModules.") ";
				}				
			}
			else
			{
				if ($mvConfigType == 'COMPLETE_REFRESH')
				{
					$query = "update gcp_mv_module_settings set complete_refresh=:value where name = '".$mvRefreshModules."_REFRESH'";
				}
				elseif ($mvConfigType == 'PROCESS_MISSING_DATA')
				{
					$query = "update gcp_mv_module_settings set process_missing_data=:value where name = '".$mvRefreshModules."_REFRESH'";
				}
				elseif ($mvConfigType == 'PROCESS_MISSING_UPDATE')
				{
					$query = "update gcp_mv_module_settings set process_missing_update=:value where name = '".$mvRefreshModules."_REFRESH'";
				}	
				elseif ($mvConfigType == 'PROCESS_MISSING_DELETE')
				{
					$query = "update gcp_mv_module_settings set process_missing_delete=:value where name = '".$mvRefreshModules."_REFRESH'";
				}							
				
			}	
		}
		
		$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
	
			/*if ($mvConfigType != null)
			{
				oci_bind_by_name($this->_orastmt, ":configtype", $mvConfigType);
			}*/
			
			
			if ($flag != null)
			{
				if ($_formValues['mvrefreshmodule'] != "" and $mvConfigType != null)
				{
					oci_bind_by_name($this->_orastmt, ":value", $flag);
					$r = oci_execute($this->_orastmt);					
				}
				else 
				{
					
					if ($_formValues['mvrefreshmodule'] == "" and $mvConfigType == null)
					{
						$userDefinedErrorMsg = 'Please Select MV Refresh Module and Config Type';
					}
					elseif ($_formValues['mvrefreshmodule'] != "" and $mvConfigType == null)
					{
						$userDefinedErrorMsg = 'Please Select Config Type';
					} 
					elseif ($_formValues['mvrefreshmodule'] == "" and $mvConfigType != null)
					{
						$userDefinedErrorMsg = 'Please Select MV Refresh Module';
					}
					
			        $outputArray["ORA_ERROR"] = $userDefinedErrorMsg;	
			        $outputArray["env_name"] = $this->_environment->_envname;
		
			        return $outputArray;					
				}
			}
			else
			{
				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);				
			}
			
			if ($resultset == null and $flag != null)
			{
				$this->_orastmt = oci_parse($this->_oraconn, $tmp_query);
				
				/*if ($mvConfigType != null)
				{
					oci_bind_by_name($this->_orastmt, ":configtype", $mvConfigType);
				}*/	

				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);				
			}

			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["mvconfigtype"] = $mvConfigType;
				
			$this->_log->info("setMvFlags() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}
	
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function executeMvActions($_formValues)
	{
		$this->_log->info("executeMvActions() - start");
		
		$allowProdOperation = false;
		$isProdEnv = false;
		
		$mvAction = $_formValues['mvaction'];
		
		//$this->setEnvConnDetails($_formValues['envid']);
		
		if (CommonUtil::contains('PGG', $this->_environment->_envname))
		{
			//$this->_log->info("is prod env : ".$this->_environment->_envname);
			$isProdEnv = true;
		}		
		
		
		if ($isProdEnv)
		{
			if ($_formValues['pin'] != "")
			{
				//$this->_log->info("PIN : ".$_formValues['pin']);
				if ($_formValues['pin'] == PRODUCTION_OPER_PIN)
				{
					$allowProdOperation = true;
				}				
			}
		}
		
		//$this->_log->info("Allowed Prod Oper flag : ".$allowProdOperation);

		if ($allowProdOperation or !($isProdEnv))
		{
		
			//$this->getOraConnection();
	
			$this->_actionHistoryId = $this->insertEntryIntoActionsHistory($mvAction);
			
			//execute required mv action
			switch (strtoupper($mvAction))
			{
				// Disable Job Monitor
				case strtoupper('DISABLE_GCP_MV_JOB_MONITOR'):
					$result = $this->action_updateJobMonitorFlag('DISABLE', $mvAction);
					break;
	
				// Enable Job Monitor
				case strtoupper('ENABLE_GCP_MV_JOB_MONITOR'):
					$result = $this->action_updateJobMonitorFlag('ENABLE', $mvAction);
					break;	
					
				// Generate Full MV Refresh Status
				case strtoupper('GENERATE_FULL_GCP_MV_REF'):
					$result = $this->action_generateFullMVRefresh($mvAction);
					break;	
					
				// Show Full MV Refresh Status
				case strtoupper('SHOW_FULL_GCP_MV_REF'):
					$result = $this->action_showFullMVRefresh($mvAction);
					break;					
					
				// Run manage jobs procedure
				case strtoupper('RUN_MANAGE_JOBS_CRAMER'):
					//$result = $this->action_runManageJobs($mvAction);
					$result = null;
					break;					
	
				// Start GCP-MV Jobs
				case strtoupper('START_GCP_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;	
					
				// Start GCP-MV Non Prod Jobs
				case strtoupper('START_GCP_NONPROD_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;					
	
				// Stop GCP-MV Jobs
				case strtoupper('STOP_GCP_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;	
					
				// Start Cramer MV Jobs
				case strtoupper('START_CRAMER_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;	
					
				// Start Cramer Non Prod MV Jobs
				case strtoupper('START_CRAMER_NONPROD_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;					
	
				// Stop Cramer MV Jobs
				case strtoupper('STOP_CRAMER_MV_JOBS'):
					$result = $this->action_execjobutils($mvAction);
					break;					
					
				// Delete Job Management Entries
				case strtoupper('DEL_GCP_MV_JOB_MGMT_ENTRIES'):
					//$result = $this->action_processJobMgmtOperation('DELETE', $mvAction);
					$result = null;
					break;	
	
				// Delete Job Management Entries
				case strtoupper('SEL_GCP_MV_JOB_MGMT_ENTRIES'):
					//$result = $this->action_processJobMgmtOperation('SELECT', $mvAction);
					$result = null;
					break;	
	
				// Get data by doing by order by startdate desc
				case strtoupper('GCP_MV_REF_ORDER_BY_START_DATE'):
					$result = $this->action_getMvDataOrderByStartDate('DESC', $mvAction);
					break;	
	
				// Get data by doing by order by startdate desc
				case strtoupper('GCP_MV_DBA_JOBS_INFO'):
					$result = $this->action_dbaJobsInfo($mvAction);
					break;	
	
				// Get data by doing by order by startdate desc
				case strtoupper('CRAMER_MV_DBA_JOBS_INFO'):
					$result = $this->action_dbaJobsInfo($mvAction);
					break;	
	
				// Show Cramer MV Job Sessions
				case strtoupper('SHOW_CRAMER_MV_JOB_SESSIONS'):
					$result = $this->action_showMvJobSessions($mvAction);
					break;
	
				// Show GCP MV Job Sessions
				case strtoupper('SHOW_GCP_MV_JOB_SESSIONS'):
					$result = $this->action_showMvJobSessions($mvAction);
					break;	
					
				// Show Temp GCP-MV Job Monitor Log
				case strtoupper('SHOW_TMP_GCP_MV_JOB_MONITOR_LOG'):
					$result = $this->action_showTempJobMonitorLog($mvAction);
					break;	
	
				// Show GCP-MV Job Monitor Log
				case strtoupper('SHOW_GCP_MV_JOB_MONITOR_LOG'):
					$result = $this->action_showJobMonitorLog($mvAction);
					break;	

				// Show GCP-MV Time Consuming Modules
				case strtoupper('SHOW_GCP_MV_TIME_CONSUMING_MODULES'):
					$result = $this->action_showGcpMvTimeConsumingModules($mvAction);
					break;		

				// Show DART Report Status
				case strtoupper('SHOW_CRAMER_DART_REPORT_STATUS'):
					$result = $this->action_showDartReportStatus($mvAction);
					break;					
	
				default:
					die("Error occurred : <font color='red'>MV Action : " . $mvAction . " not found.</font>");
					
			}		
			
			$this->_log->info("executeMvActions() - end");
			
			return $result;
		}
		else
		{
			
	        $outputArray["ORA_ERROR"] = "Please check either PIN is not entered or it is incorrect";	
	        
	        $this->_log->info("******************** E R R O R ********************");
	        $this->_log->info("Please check either PIN is not entered or it is incorrect");
	        
	        $this->_log->info("executeMvActions() - end");

	        return $outputArray;			
		}	
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $input
	 * @param String $mvAction
	 */
	public function action_getMvDataOrderByStartDate($input, $mvAction)
	{
		$this->_log->info("getMvDataOrderByStartDate() - start");
		
		if (isset($input))
		{
			if ($input == 'DESC')
			{
				$query = "select * from (select logid, module, startdate, enddate, noofrows, status from mv_stage_tab_refresh_log order by startdate desc) where rownum <= 15";
			}
			
			if ($this->_oraconn != null)
			{
				$this->_orastmt = oci_parse($this->_oraconn, $query);
				
				oci_execute($this->_orastmt);
			
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				$outputArray['display_action_msg'] = "YES";
				$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
				
				$this->updateActionsHistory("Success", "Action performed successfully");
				
				$this->_log->info("getMvDataOrderByStartDate() - end");
				
				return $outputArray;			
			}
			else 
			{
		        $e = oci_error();
		        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
		        $outputArray["ORA_ERROR"] = $e["message"];	
		        
		        $this->_log->info("Error Occurred : " . $e["message"]);
		        
		        $this->updateActionsHistory("Failure", $e["message"]);
		        
		        $this->_log->info("getMvDataOrderByStartDate() - end");
	
		        return $outputArray;
			}			
		}		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_runManageJobs($mvAction)
	{
		$this->_log->info("runManageJobs() - start");
		
		if ($this->_oraconn != null)
		{
			$manageJobsQuery = "select job from dba_jobs where schema_user='CRAMER' and upper(what) like '%PKGJOBMANAGEMENT.MANAGEJOBS%'";
			
			$this->_orastmt = oci_parse($this->_oraconn, $manageJobsQuery);
			
			oci_execute($this->_orastmt);
		
			$managejobs_nrows = oci_fetch_all($this->_orastmt, $manageJobsResult);
			
			oci_free_statement($this->_orastmt);
			
			$jobId = $manageJobsResult[JOB][0];
			
			$this->_log->info("Job Id : " . $jobId);

			if (isset($jobId))
			{
				$query = "BEGIN SYS.DBMS_JOB.RUN(:jobid); END;";
				
				$this->_orastmt = oci_parse($this->_oraconn, $query);

				oci_bind_by_name($this->_orastmt,":jobid", $jobId);
				
				//oci_bind_by_name($this->_orastmt,":jobid", $jobId);
				$r = oci_execute($this->_orastmt);	

				if (!$r) 
				{    
				    $e = oci_error($this->_orastmt);
				    oci_rollback($this->_oraconn);  // rollback changes to both tables
				    $this->updateActionsHistory("Failure", $e["message"]);
				    trigger_error(htmlentities($e['message']), E_USER_ERROR);
				}
		
				// Commit the changes to both tables
				$r = oci_commit($this->_oraconn);
				if (!$r) {
				    $e = oci_error($this->_oraconn);
				    trigger_error(htmlentities($e['message']), E_USER_ERROR);
				}
			}				
			
			oci_free_statement($this->_orastmt);			
			
			$this->closeOracleConnection();

			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("runManageJobs() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("runManageJobs() - end");

	        return $outputArray;
		}			
	
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $value
	 * @param String $mvAction
	 */
	public function action_updateJobMonitorFlag($value, $mvAction)
	{
		$query = "update gcp_mv_config set value=:value where configtype='JOB_MONITOR' and name='FLAG'";
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
	
			oci_bind_by_name($this->_orastmt, ":value", $value);
			
			$r = oci_execute($this->_orastmt);	
			
			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    $this->updateActionsHistory("Failure", $e["message"]);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}			
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<b>Action : </b>" . $mvAction . " is performed successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);

	        return $outputArray;
		}		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
	public function action_execjobutils($mvAction)
	{
		$this->_log->info("execjobutils() - start");
		
		if (CommonUtil::contains('GCP', $mvAction))
		{
			if (CommonUtil::contains('STOP', $mvAction))
			{
				$query = "declare begin pkggcpmvjobutils.stopjobs; end;";
			}
			else if (CommonUtil::contains('START', $mvAction))
			{
				if (CommonUtil::contains('NONPROD', $mvAction))
				{
					$query = "declare begin pkggcpmvjobutils.startnonprodjobs; end;";
				}
				else 
				{
					$query = "declare begin pkggcpmvjobutils.startjobs; end;";
				}
			}
		}
		else if (CommonUtil::contains('CRAMER', $mvAction))	
		{
			if (CommonUtil::contains('STOP', $mvAction))
			{
				$query = "declare begin pkgcramermvjobutils.stopjobs; end;";
			}
			else if (CommonUtil::contains('START', $mvAction))
			{
				if (CommonUtil::contains('NONPROD', $mvAction))
				{
					$query = "declare begin pkgcramermvjobutils.startnonprodjobs; end;";
				}
				else 
				{
					$query = "declare begin pkgcramermvjobutils.startjobs; end;";
				}
			}			
		}	
		
		$this->_log->info("Oracle Query :: " . $query);
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			$r = oci_execute($this->_orastmt);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is performed successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("execjobutils() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	         $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("execjobutils() - end");

	        return $outputArray;
		}			
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_generateFullMVRefresh($mvAction)
	{
		$this->_log->info("action_generateFullMVRefresh() - start");
		
		if ($this->_oraconn != null)
		{
			$query = "declare errmsg varchar2(2000); begin pkggcpmvjobutils.getfullmvrefreshstatus(errmsg); end;";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			@oci_execute($this->_orastmt);

			oci_free_statement($this->_orastmt);
			
			$refreshDataQuery = "select module, startdate, enddate, duration, noofrows, status from tmp_gcp_mv_refresh_log order by startdate";
			
			$this->_orastmt = oci_parse($this->_oraconn, $refreshDataQuery);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_generateFullMVRefresh() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_generateFullMVRefresh() - end");

	        return $outputArray;
		}			
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_showFullMVRefresh($mvAction)
	{
		$this->_log->info("action_showFullMVRefresh() - start");
		
		if ($this->_oraconn != null)
		{
			$query = "select module, startdate, enddate, duration, noofrows, status from tmp_gcp_mv_refresh_log order by startdate";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showFullMVRefresh() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_showFullMVRefresh() - end");

	        return $outputArray;
		}			
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $input
	 * @param String $mvAction
	 */
	public function action_processJobMgmtOperation($input, $mvAction)
	{
		$this->_log->info("processJobMgmtOperation() - start");
		
		if (isset($input))
		{
			if ($input == 'DELETE')
			{
				$query = "delete from gcp_mv_job_management";
			}

			if ($input == 'SELECT')
			{
				$query = "select * from gcp_mv_job_management order by 1";
			}			
			
			if ($this->_oraconn != null)
			{
				$this->_orastmt = oci_parse($this->_oraconn, $query);
				
				oci_execute($this->_orastmt);
			
				if ($input == 'SELECT')
				{				
					$nrows = oci_fetch_all($this->_orastmt, $resultset);
				}	
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				$outputArray['display_action_msg'] = "YES";
				$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
				
				$this->updateActionsHistory("Success", "Action performed successfully");
				
				$this->_log->info("processJobMgmtOperation() - end");
				
				return $outputArray;			
			}
			else 
			{
		        $e = oci_error();
		        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
		        $outputArray["ORA_ERROR"] = $e["message"];	
		        
		        $this->_log->info("Error Occurred : " . $e["message"]);
		        
	        	$this->updateActionsHistory("Failure", $e["message"]);		        
		        
		        $this->_log->info("processJobMgmtOperation() - end");
	
		        return $outputArray;
			}			
		}
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_dbaJobsInfo($mvAction)
	{
		$this->_log->info("action_dbaJobsInfo() - start");
		

		if (CommonUtil::contains('CRAMER', $mvAction))
		{
			$schema = "CRAMER";
		}

		if (CommonUtil::contains('GCP', $mvAction))
		{
			$schema = "GCP_USER";
		}			
		
		if ($this->_oraconn != null)
		{
			$query = "select job, last_date, next_date, broken, SUBSTR(what, INSTR(what, '.')+1, INSTR(what, 'proc') - INSTR(what, '.') - 1) jobname from dba_jobs where schema_user=:schema";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_bind_by_name($this->_orastmt, ":schema", $schema);
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_dbaJobsInfo() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
        	$this->updateActionsHistory("Failure", $e["message"]);		        
	        
	        $this->_log->info("action_dbaJobsInfo() - end");

	        return $outputArray;
		}			
	}

 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
	public function action_showMvJobSessions($mvAction)
	{
		$this->_log->info("action_showMvJobSessions() - start");
		
		if ($this->_oraconn != null)
		{
			if (CommonUtil::contains('CRAMER', $mvAction))	
			{		
				$query = "select * from tmp_cramer_mv_job_sessions";
			}	
			else if (CommonUtil::contains('GCP', $mvAction))	
			{
				$query = "select * from tmp_gcp_mv_job_sessions";
			}
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_execute($this->_orastmt);
		
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showMvJobSessions() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_showMvJobSessions() - end");

	        return $outputArray;
		}			
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_showTempJobMonitorLog($mvAction)
	{
		$this->_log->info("action_showTempJobMonitorLog() - start");
		
		if ($this->_oraconn != null)
		{
			$query = "select module, startdate, enddate, status from tmp_gcp_mv_job_monitor_log order by startdate desc";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showTempJobMonitorLog() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_showTempJobMonitorLog() - end");

	        return $outputArray;
		}			
	}	

 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_showJobMonitorLog($mvAction)
	{
		$this->_log->info("action_showJobMonitorLog() - start");
		
		if ($this->_oraconn != null)
		{
			$query = "select * from gcp_mv_job_monitor_log order by 1";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showJobMonitorLog() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_showJobMonitorLog() - end");

	        return $outputArray;
		}			
	}	

 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
 	public function action_showGcpMvTimeConsumingModules($mvAction)
	{
		$this->_log->info("action_showGcpMvTimeConsumingMods() - start");
		
		$time_limit = 10;
		
		if ($this->_oraconn != null)
		{
			$query = "declare errmsg varchar2(2000); begin pkggcpmvjobutils.timeconsumingmodules(:timelimit, errmsg); end;";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_bind_by_name($this->_orastmt,":timelimit", $time_limit, 32);
			
			@oci_execute($this->_orastmt);

			oci_free_statement($this->_orastmt);
			
			$refreshDataQuery = "select logid, module, startdate, enddate, duration, noofrows, status from time_consuming_modules order by startdate";
			
			$this->_orastmt = oci_parse($this->_oraconn, $refreshDataQuery);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showGcpMvTimeConsumingMods() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_generateFullMVRefresh() - end");

	        return $outputArray;
		}			
	}	
	
  	public function action_showDartReportStatus($mvAction)
	{
		$this->_log->info("action_showDartReportStatus() - start");
		
		if ($this->_oraconn != null)
		{
			$query = "select * from (select name, startdate, enddate, noofrows, status from dart_inl_report_status_log order by startdate desc) where rownum <= 15";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_execute($this->_orastmt);			
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray['display_action_msg'] = "YES";
			$outputArray['action_perform_msg'] = "<br><b>Action : </b>" . $mvAction . " is Performed Successfully";
			
			$this->updateActionsHistory("Success", "Action performed successfully");
			
			$this->_log->info("action_showDartReportStatus() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->updateActionsHistory("Failure", $e["message"]);
	        
	        $this->_log->info("action_showJobMonitorLog() - end");

	        return $outputArray;
		}			
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function getMvSessionsInfo_old($_formValues)
	{
		$this->_log->info("getMvSessionsInfo() - start");

		$owner = strtoupper($this->_environment->_username);
		
		$this->_log->info("owner : " . $owner);

		$query = "select v.SID, v.id2 JOB, j.lowner schema, SUBSTR(j.what, INSTR(j.what, '.')+1, INSTR(j.what, 'proc') - INSTR(j.what, '.') - 1) jobname, j.FAILURES, " . 
    			 "LAST_DATE, substr(to_char(last_date,'HH24:MI:SS'),1,8) LAST_SEC, " . 
    			 "THIS_DATE, substr(to_char(this_date,'HH24:MI:SS'),1,8) THIS_SEC, " .
    			 "v.INST_ID instance " .
  				 "from sys.job$ j, gv\$lock v " .
  				 "where v.type = 'JQ' " .
  				 "and j.job (+)= v.id2 " .
  				 "and j.lowner=:owner";
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			//$this->_log->info("SQL - " . $query);
	
			oci_bind_by_name($this->_orastmt, ":owner", $owner);
			
			@oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			$this->_log->info("getMvSessionsInfo() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("getMvSessionsInfo() - end");

	        return $outputArray;
		}		
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function getMvSessionsInfo($_formValues)
	{
		$this->_log->info("getMvSessionsInfo() - start");

		$owner = strtoupper($this->_environment->_username);
		
		$this->_log->info("owner : " . $owner);
		
		if ($this->_oraconn != null)
		{
			if ($owner == 'CRAMER')
			{
				$jobsessionsquery = "declare begin pkgcramermvjobutils.getmvjobsessions; end;";
				$query = "select * from tmp_cramer_mv_job_sessions";
				
			}
			else
			{
				$jobsessionsquery = "declare begin pkggcpmvjobutils.getmvjobsessions; end;";
				$query = "select * from tmp_gcp_mv_job_sessions";
			}
			
			
			$this->_orastmt = oci_parse($this->_oraconn, $jobsessionsquery);
			
			@oci_execute($this->_orastmt);	
			
			oci_free_statement($this->_orastmt);
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			//$this->_log->info("SQL - " . $query);
			
			@oci_execute($this->_orastmt);	
			
			$nrows = @oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			$this->_log->info("getMvSessionsInfo() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("getMvSessionsInfo() - end");

	        return $outputArray;
		}		
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function getMvRefreshInfo($_formValues)
	{
		$this->_log->info("getMvRefreshInfo() - start");
		
		// If refresh button is submitted then get data from db which will have env details 
		 if(array_key_exists('refresh' , $_formValues))
         {
        	$this->refreshmvinfo();	
         }
		
		//print_r($_formValues);
		
		if ($_formValues['mvrefreshmodule'] != "")
		{
			$mvRefreshModule = $_formValues['mvrefreshmodule'];	
		}
		else if ($this->mvrefresh->_refreshmodule != "")
		{
			$mvRefreshModule = $this->mvrefresh->_refreshmodule;	
		}			
		
		if ($_formValues['mvlogid'] != "")
		{
			$mvLogId = $_formValues['mvlogid'];	
		}
		else if ($this->mvrefresh->_logid != "")
		{
			$mvLogId = $this->mvrefresh->_logid;
		}
		
		if ($_formValues['noofrows'] != "")
		{
			$noOfRows = $_formValues['noofrows'];	
		}
		else if ($this->mvrefresh->_noofrows != "")
		{
			$noOfRows = $this->mvrefresh->_noofrows;
		}
		else
		{
			$noOfRows = 7;
		}
		
		if ($_formValues['envid'] != "")
		{
			$envId = $_formValues['envid'];
		}
		else if ($this->mvrefresh->_dbconndetailsid != "")
		{
			$envId = $this->mvrefresh->_dbconndetailsid;
		}
		
		

		if (isset($envId) and isset($mvRefreshModule) or isset($mvLogId))
		{
			$this->setEnvConnDetails($envId);
				
			 if(!array_key_exists('refresh' , $_formValues))
	         {
				$this->mvrefresh = new mvrefresh($mvRefreshModule, $envId, 
					$noOfRows, $mvLogId, $_formValues['userid']);	         	
	         	
				// inserts row into mvrefreshinfo table
				$this->insertMvRefreshInfo();	
	         }				
	
			$this->getOraConnectionForRefreshOnly();	
	
			if (isset($mvLogId))
			{
				$query = "select logid, module, startdate, enddate, noofrows, status, description from mv_stage_tab_refresh_log where logid = :mvlogid";
			}
			else
			{
				$query = "declare errmsg varchar2(2000); begin pkggcpmvjobutils.generatemvrefresh(:module, :rows, errmsg); end;";
			}
			
			if ($this->_oraconn != null)
			{
				$this->_orastmt = oci_parse($this->_oraconn, $query);
				
				//$this->_log->info("SQL - " . $query);
				
				if (isset($mvLogId))
				{
					oci_bind_by_name($this->_orastmt, ":mvlogid", $mvLogId);
					
					oci_execute($this->_orastmt);
				}
				else
				{
					oci_bind_by_name($this->_orastmt,":module", $mvRefreshModule, 32);
					oci_bind_by_name($this->_orastmt,":rows", $noOfRows, 32);
					
					@oci_execute($this->_orastmt);
		
					oci_free_statement($this->_orastmt);
					
					$refreshDataQuery = "select logid, module, startdate, enddate, duration, noofrows, status from mv_refresh_for_module order by startdate desc";
					
					$this->_orastmt = oci_parse($this->_oraconn, $refreshDataQuery);
					
					oci_execute($this->_orastmt);			
				}			
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				
				if (isset($mvLogId))
				{
					$outputArray["logid_exists"] = true;
				}			
				
				
				$this->_log->info("getMvRefreshInfo() - end");
				
				return $outputArray;			
			}
			else 
			{
		        $e = oci_error();
		        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
		        $outputArray["ORA_ERROR"] = $e["message"];	
		        
		        $this->_log->info("Error Occurred in getMvRefreshInfo : " . $e["message"]);
		        
		        $this->_log->info("getMvRefreshInfo() - end");
	
		        return $outputArray;
			}
		}
		else 
		{
			$this->_log->error("Please check your inputs");
			
	        $outputArray["ORA_ERROR"] = "Please check your inputs";	
	        
	        $this->_log->info("getMvRefreshInfo() - end");

	        return $outputArray;			
		}		
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 */
	private function insertMvRefreshInfo()
	{
		$this->_log->info("insertMvRefreshInfo() - start");
		
		$delMvRefreshInfoQuery = "delete from mvrefreshinfo";
		
		$this->executeQuery($delMvRefreshInfoQuery);
		
		$id = $this->generateIDWithTable("mvrefreshinfo");		
		
		$addMvRefreshInfoQuery = "insert into mvrefreshinfo (id, module, dbconndetailsid, createddate, noofrows, mvlogid, user) ".
					"values (:id, :module, :dbconndetailsid, :createddate, :noofrows, :mvlogid, :user)";	

		$stmt = $this->_conn->prepare($addMvRefreshInfoQuery);
		$stmt->bindValue(':id', $id);		
		$stmt->bindValue(':module', $this->mvrefresh->_refreshmodule);
		$stmt->bindValue(':dbconndetailsid', $this->mvrefresh->_dbconndetailsid);
		$stmt->bindValue(':createddate', $this->mvrefresh->_createddate);
		$stmt->bindValue(':noofrows', $this->mvrefresh->_noofrows);
		$stmt->bindValue(':mvlogid', $this->mvrefresh->_logid);
		$stmt->bindValue(':user', $this->mvrefresh->_user);
		
		$result_addMvRefreshInfo = $stmt->execute();

		$this->_log->info("insertMvRefreshInfo() - end");
	}	
	
	private function refreshmvinfo()
	{
		$this->_log->info("refreshmvinfo() - start");
		
		$countMvRefreshInfoQuery = "select count(1) as count from mvrefreshinfo";
		
		$cnt_result = $this->executeQuery($countMvRefreshInfoQuery);
		
		$row = $cnt_result[0];
		
		$mvInfoCount = $row['count'];
		
		if ($mvInfoCount == 1)
		{
			$getMvRefreshInfoDetailsQuery = "select * from mvrefreshinfo where user = " .$this->_userid;
			$getMvRefreshInfoDetails_rs = $this->executeQuery($getMvRefreshInfoDetailsQuery);
			
			$refresh = $getMvRefreshInfoDetails_rs[0];

			$this->mvrefresh = new mvrefresh($refresh['module'], $refresh['dbconndetailsid'], 
				$refresh['noofrows'], $refresh['mvlogid'], $refresh['user']);			
		}
		else
		{	
			if ($mvInfoCount < 1)
			{
				$this->_log->info("*********** MVREFRESHINFO table is empty ***********");
			}
			else if ($mvInfoCount > 1)
			{
				$this->_log->info("*********** More than one row found in MVREFRESHINFO table ***********");
			}	
		}
		
		$this->_log->info("refreshmvinfo() - end");
	}
	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $mvaction
	 */
	public function insertEntryIntoActionsHistory($mvaction)
	{
		$this->_log->info("insertEntryIntoActionsHistory() - start");
		
		$startdate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateIDWithTable("mvactionshistory");	
		
		$addQuery = "insert into mvactionshistory (id, environment, action, startdate, user) values ".
						"(:id, :environment, :action, :startdate, :user)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':environment', $this->_environment->_envname);
		$stmt->bindValue(':action', $mvaction);
		$stmt->bindValue(':startdate', $startdate);		
		$stmt->bindValue(':user', $this->_userid);
		
		$result = $stmt->execute();		
		
		$this->_log->info("insertEntryIntoActionsHistory() - end");
		
		return $id;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $status
	 * @param String $notes
	 */
	public function updateActionsHistory($status, $notes)
	{
		$this->_log->info("updateActionsHistory() - start");
		
		$enddate = CommonUtil::getCurrentSqliteFormatDate();
		
		$updateQuery = "update mvactionshistory set enddate=:enddate, status=:status, notes=:notes ".
					   "where id=:id";

		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':enddate', $enddate);
		$stmt->bindValue(':status', $status);
		$stmt->bindValue(':notes', $notes);
		$stmt->bindValue(':id', $this->_actionHistoryId);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;			
		
		$this->_log->info("updateActionsHistory() - end");
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
	public function getMvExtractInfo($_formValues)
	{
		$this->_log->info("getMvExtractInfo() - start");
		
		// If refresh button is submitted then get data from db which will have env details 
		 if(array_key_exists('refresh' , $_formValues))
         {
        	$this->extractmvinfo();
         }		
		
		if ($_formValues['mvrefreshmodule'] != "")
		{
			$mvRefreshModule = $_formValues['mvrefreshmodule'];	
		}
		else if ($this->mvextract->_refreshmodule != "")
		{
			$mvRefreshModule = $this->mvextract->_refreshmodule;	
		}			
		
		if ($_formValues['subaction'] != "")
		{
			$subAction = $_formValues['subaction'];	
		}
		else if ($this->mvextract->_subaction != "")
		{
			$subAction = $this->mvextract->_subaction;
		}
		else
		{
			$subAction = null;
		}
		
		if ($_formValues['noofrows'] != "")
		{
			$noOfRows = $_formValues['noofrows'];	
		}
		else if ($this->mvextract->_noofrows != "")
		{
			$noOfRows = $this->mvextract->_noofrows;
		}
		else
		{
			$noOfRows = 7;
		}
		
		if ($_formValues['envid'] != "")
		{
			$envId = $_formValues['envid'];
		}
		else if ($this->mvextract->_dbconndetailsid != "")
		{
			$envId = $this->mvextract->_dbconndetailsid;
		}		
		
		if (isset($envId) and isset($mvRefreshModule) or isset($subAction))
		{		
		
			$this->setEnvConnDetails($envId);
			
			 if(!array_key_exists('refresh' , $_formValues))
	         {
				$this->mvextract = new mvextract($mvRefreshModule, $_formValues['envid'], 
					$noOfRows, $subAction, $_formValues['userid']);	         	
	         	
				// inserts row into mvrefreshinfo table
				$this->insertMvExtractInfo();	
	         }				
	
			$this->getOraConnectionForRefreshOnly();	
	
			if (isset($subAction) and $subAction != null)
			{
				$query = "select logid, extract, datetime, status, subaction from gcpextractlog where subaction like '%".$subAction."%'";
			}
			else
			{
				$query = "select * from (select logid, datetime, status, subaction from gcpextractlog where " .
								"extract=:mvrefreshmodule and subaction not like 'MERGE /%' order by datetime desc) where rownum <= :noofrows";
			}
			
			if ($this->_oraconn != null)
			{
				$this->_orastmt = oci_parse($this->_oraconn, $query);
				
				$this->_log->info("SQL - " . $query);
				
				if (isset($subAction))
				{
					//oci_bind_by_name($this->_orastmt, ":subaction", $subAction);
				}
				else
				{
					oci_bind_by_name($this->_orastmt, ":mvrefreshmodule", $mvRefreshModule);
					oci_bind_by_name($this->_orastmt, ":noofrows", $noOfRows);
				}	
	
				$this->_log->info("SQL after binding value :: " . $query);
				
				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				$outputArray["mvrefreshmodule"] = $mvRefreshModule;
				
				$this->_log->info("getMvExtractInfo() - end");
				
				return $outputArray;			
			}
			else 
			{
		        $e = oci_error();
		        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
		        $outputArray["ORA_ERROR"] = $e["message"];	
		        
		        $this->_log->info("Error Occurred in getMvExtractInfo : " . $e["message"]);
		        
		        $this->_log->info("getMvExtractInfo() - end");
	
		        return $outputArray;
			}	
		}
		else 
		{
			$this->_log->error("Please check your inputs");
			
	        $outputArray["ORA_ERROR"] = "Please check your inputs";	
	        
	        $this->_log->info("getMvExtractInfo() - end");

	        return $outputArray;			
		}			
	}

	/**
	 * 
	 * Enter description here ...
	 */
	private function insertMvExtractInfo()
	{
		$this->_log->info("insertMvExtractInfo() - start");
		
		$delMvExtractInfoQuery = "delete from mvextractinfo";
		
		$this->executeQuery($delMvExtractInfoQuery);
		
		$id = $this->generateIDWithTable("mvextractinfo");		
		
		$addMvExtractInfoQuery = "insert into mvextractinfo (id, module, dbconndetailsid, createddate, noofrows, subaction, user) ".
					"values (:id, :module, :dbconndetailsid, :createddate, :noofrows, :subaction, :user)";	

		$stmt = $this->_conn->prepare($addMvExtractInfoQuery);
		$stmt->bindValue(':id', $id);		
		$stmt->bindValue(':module', $this->mvextract->_refreshmodule);
		$stmt->bindValue(':dbconndetailsid', $this->mvextract->_dbconndetailsid);
		$stmt->bindValue(':createddate', $this->mvextract->_createddate);
		$stmt->bindValue(':noofrows', $this->mvextract->_noofrows);
		$stmt->bindValue(':subaction', $this->mvextract->_subaction);
		$stmt->bindValue(':user', $this->mvextract->_user);
		
		$result_addMvExtractInfo = $stmt->execute();

		$this->_log->info("insertMvExtractInfo() - end");
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
 	private function extractmvinfo()
	{
		$this->_log->info("extractmvinfo() - start");
		
		$countMvExtractInfoQuery = "select count(1) as count from mvextractinfo";
		
		$cnt_result = $this->executeQuery($countMvExtractInfoQuery);
		
		$row = $cnt_result[0];
		
		$mvExtractCount = $row['count'];
		
		if ($mvExtractCount == 1)
		{
			$getMvExtractInfoDetailsQuery = "select * from mvextractinfo where user = " .$this->_userid;
			$getMvExtractInfoDetails_rs = $this->executeQuery($getMvExtractInfoDetailsQuery);
			
			$extract = $getMvExtractInfoDetails_rs[0];

			$this->mvextract = new mvextract($extract['module'], $extract['dbconndetailsid'], 
				$extract['noofrows'], $extract['subaction'], $extract['user']);			
		}
		else
		{	
			if ($mvExtractCount < 1)
			{
				$this->_log->info("*********** MVEXTRACTINFO table is empty ***********");
			}
			else if ($mvExtractCount > 1)
			{
				$this->_log->info("*********** More than one row found in MVEXTRACTINFO table ***********");
			}	
		}
		
		$this->_log->info("extractmvinfo() - end");
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
 	public function removeMvJob($_formValues)
	{
		$this->_log->info("removeMvJob() - start");
		
		if (isset($_formValues['mvjobid']))
		{
			$jobId = $_formValues['mvjobid'];
		}
		
		if ($this->_oraconn != null and isset($jobId))
		{
			$this->_log->info("Job Id : " . $jobId);

			$query = "DECLARE BEGIN DBMS_JOB.BROKEN(:jobid, true); DBMS_JOB.REMOVE(:jobid); END;";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);

			oci_bind_by_name($this->_orastmt,":jobid", $jobId);
			
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			oci_free_statement($this->_orastmt);			
			
			$this->closeOracleConnection();

			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			$this->_log->info("removeMvJob() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("removeMvJob() - end");

	        return $outputArray;
		}			
	}

	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
  	public function removeMvLogEntry($_formValues)
	{
		$this->_log->info("removeMvLogEntry() - start");
		
		if (isset($_formValues['mvlogid']))
		{
			$logId = $_formValues['mvlogid'];
		}
		
		if ($this->_oraconn != null and isset($logId))
		{
			$this->_log->info("Log Id : " . $logId);

			$query = "delete from mv_stage_tab_refresh_log where logid = :logid";
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);

			oci_bind_by_name($this->_orastmt,":logid", $logId);
			
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			oci_free_statement($this->_orastmt);			
			
			$this->closeOracleConnection();

			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["logid"] = $logId;
			
			$this->_log->info("removeMvLogEntry() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("removeMvLogEntry() - end");

	        return $outputArray;
		}			
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param Array $_formValues
	 */
  	public function execCommand($_formValues)
	{
		$this->_log->info("execCommand() - start");
		
		if (isset($_formValues['sqlcmd']))
		{
			$sqlCommand = $_formValues['sqlcmd'];
		}
		
		if ($this->_oraconn != null and isset($sqlCommand))
		{
			$query = $sqlCommand;
			
			$this->_log->info("SQL Command to execute ==> " . $query);
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);			
			
			$this->closeOracleConnection();

			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			$this->_log->info("execCommand() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("execCommand() - end");

	        return $outputArray;
		}			
	}		
	
  	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
	public function stuckJobCleanup($_formValues)
	{
		$this->_log->info("stuckJobCleanup() - start");
		
		$sid = "";
		
		if ($_formValues['mvrefreshmodule'] != "")
		{
			$mvRefreshModule = $_formValues['mvrefreshmodule'];	
		}		
		
		if (isset($_formValues['mvjobid']))
		{
			$jobId = $_formValues['mvjobid'];
		}	

		$owner = strtoupper($this->_environment->_username);
		
		$this->_log->info("owner : " . $owner);		
		
		if ($this->_oraconn != null and isset($jobId))
		{
			if ($owner == 'CRAMER')	
			{		
				$query = "begin pkgcramermvjobutils.stuckjobcleanup(:jobid, :module, :sid); end;";
			}	
			else if ($owner == 'GCP_USER')	
			{
				$query = "begin pkggcpmvjobutils.stuckjobcleanup(:jobid, :module, :sid); end;";
			}
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_bind_by_name($this->_orastmt,":jobid", $jobId, 32);
			oci_bind_by_name($this->_orastmt,":module", $mvRefreshModule, 32);
			oci_bind_by_name($this->_orastmt,":sid", $sid, 32);
		
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			$this->_log->info("SID : " . $sid);	
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["jobid"] = $jobId;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["sid"] = $sid;
			$outputArray["mvrefreshmodule"] = $mvRefreshModule;
			
			$this->_log->info("stuckJobCleanup() - end");
			
			return $outputArray;
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("stuckJobCleanup() - end");

	        return $outputArray;
		}			
	}	
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
	public function createMVJob($_formValues)
	{
		$this->_log->info("createMVJob() - start");
		
		$jobId = "";
		
		if ($_formValues['mvprocname'] != "")
		{
			$procName = $_formValues['mvprocname'];	
		}	

		if ($_formValues['pdegree'] != "")
		{
			$pdegree = $_formValues['pdegree'];	
		}
		else 
		{
			$pdegree = 'NOPARALLEL';
		}			

		$owner = strtoupper($this->_environment->_username);
		
		$this->_log->info("owner : " . $owner);		
		
		if ($this->_oraconn != null and isset($procName))
		{
			if ($owner == 'CRAMER')	
			{		
				$query = "begin pkgcramermvjobutils.createjob(:procname, :pdegree, :job); end;";
			}	
			else if ($owner == 'GCP_USER')	
			{
				$query = "begin pkggcpmvjobutils.createjob(:procname, :pdegree, :job); end;";
			}
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_bind_by_name($this->_orastmt,":procname", $procName, 32);
			oci_bind_by_name($this->_orastmt,":pdegree", $pdegree, 32);
			oci_bind_by_name($this->_orastmt,":job", $jobId, 32);
		
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			$this->_log->info("Job Id : " . $jobId);	
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["jobid"] = $jobId;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["procname"] = $procName;
			
			$this->_log->info("createMVJob() - end");
			
			return $outputArray;
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("createMVJob() - end");

	        return $outputArray;
		}			
	}	
	
    	/**
	 * 
	 * Enter description here ...
	 * @param String $mvAction
	 */
	public function executeMVJob($_formValues)
	{
		$this->_log->info("executeMVJob() - start");
		
		$jobId = "";
		
		if ($_formValues['mvprocname'] != "")
		{
			$procName = $_formValues['mvprocname'];	
		}	

		$owner = strtoupper($this->_environment->_username);
		
		$this->_log->info("owner : " . $owner);		
		
		if ($this->_oraconn != null and isset($procName))
		{
			if ($owner == 'CRAMER')	
			{		
				$query = "begin pkgcramermvjobutils.execjob(:procname, :job); end;";
			}	
			else if ($owner == 'GCP_USER')	
			{
				$query = "begin pkggcpmvjobutils.execjob(:procname, :job); end;";
			}
			
			$this->_orastmt = oci_parse($this->_oraconn, $query);
			
			oci_bind_by_name($this->_orastmt,":procname", $procName, 32);
			oci_bind_by_name($this->_orastmt,":job", $jobId, 32);
		
			$r = oci_execute($this->_orastmt);	

			if (!$r) 
			{    
			    $e = oci_error($this->_orastmt);
			    oci_rollback($this->_oraconn);  // rollback changes to both tables
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
	
			// Commit the changes to both tables
			$r = oci_commit($this->_oraconn);
			if (!$r) {
			    $e = oci_error($this->_oraconn);
			    trigger_error(htmlentities($e['message']), E_USER_ERROR);
			}
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			$this->_log->info("Job Id : " . $jobId);	
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["jobid"] = $jobId;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["procname"] = $procName;
			
			$this->_log->info("executeMVJob() - end");
			
			return $outputArray;
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	
	        
	        $this->_log->info("Error Occurred : " . $e["message"]);
	        
	        $this->_log->info("executeMVJob() - end");

	        return $outputArray;
		}			
	}	

 }
