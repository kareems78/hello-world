<?php
/**
 * Data Access for Home
 *
 */ 
 class HomeDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'home';
	
	/**
	 * Object to hold get all daily fikr records query
	 *
	 */
	public $_getDailyFikrRecords = null;
	
	/**
     *
     */	 
	public static $_formValues = null;
	
 	/**
	 * Contructor for HomeDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getDailyFikrRecords = $queries['getDailyFikrDetailsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}	

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getDailyFikrDetailsQuery" => "select * from dailyfikr d ".
	      		              " where upper(d.display) = 'YES' and d.user = ". $this->_userid . 
	      		              " order by d.id",
		);
		
		return $queriesArray;
	}
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		$dailyFikrResult = $this->executeQuery($this->_getDailyFikrRecords);
		
		// push result set to array
		$resultSetArray["dfikr"] = $dailyFikrResult;
		
		return $resultSetArray;		
	}	

 }