<?php
/**
 * Data Access for Enumerations
 *
 */ 
 class EnumerationsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'enumdefs';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_orastmt = null;

	/**
	 * 
	 * Object to hold task values
	 * @var enumdef dto
	 */
	protected $enumerationdef = null;		
	
	/**
	 * Contructor for EnumerationDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
		
		$this->getOraConnection();
	
	}
	
       /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	 {
	 	$enumNameQuery = "select tablename from enumdefs where user = " .$this->_userid . " order by 1";
	 	$enumname_rs = $this->executeQuery($enumNameQuery);
	 	
		$enumValueQuery = "select enumerationdefid, fieldname from enumdefs where user = " .$this->_userid . " order by 1";
		$enumvalue_rs = $this->executeQuery($enumValueQuery);
		
		$i = 1;
 		foreach($enumname_rs as $rows => $row)
		{
			if ($i == 1)
			{
				$enumname = $row['tablename'];
			}
			
			$i = $i + 1;
		}		
		
		// push result set to array
		$dropDownArray["envlist"] = $this->getEnvConnectionDropDownValues();
		$dropDownArray["enumvaluelist"] = $enumvalue_rs;
		$dropDownArray["enumname"] = $enumname;
		
		return $dropDownArray;
	 }	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getEnumDefs($_formValues)
	{
		$this->_log->info("getEnumDefs() - start");
		
		if ($_formValues['exttblname'] != "")
		{
			$extTableName = strtoupper($_formValues['exttblname']);	
		}		
		
		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		$query = "select * from enumerationdef_m where tablename=:exttablename";
		
		//$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null and isset($extTableName))
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);

			oci_bind_by_name($this->_orastmt, ":exttablename", $extTableName);
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			$this->insertEnumDefs($nrows, $resultset);
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			if (isset($extTableName))
			{
				$outputArray["exttblname"] = $extTableName;
			}				
				
			$this->_log->info("getEnumDefs() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}	
	}
	
  	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getEnumValues($_formValues)
	{
		$this->_log->info("getEnumDefs() - start");
		
		if ($_formValues['exttblname'] != "")
		{
			$extTableName = strtoupper($_formValues['exttblname']);	
		}		
		
		if ($_formValues['enumdefid'] != "")
		{
			$enumDefid = strtoupper($_formValues['enumdefid']);	
		}	

		//$this->_log->info("Ext Tbl Field : " . $extTableFieldName);
		
		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		$query = "SELECT ed.enumerationdefid, ed.tablename, ed.fieldname, ev.sequence, ev.value " . 
  				 "FROM enumerationdef_m ed, enumerationvalue_m ev " .
 				 "WHERE ed.enumerationdefid = :enumdefid " .
   				 "AND ed.enumerationdefid = ev.enumvalue2enumdef " .
		         "ORDER BY ev.sequence";
		
		//$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null and isset($enumDefid))
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);

			oci_bind_by_name($this->_orastmt, ":enumdefid", $enumDefid);
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			
			if (isset($extTableName))
			{
				$outputArray["exttblname"] = $extTableName;
			}				
				
			$this->_log->info("getEnumDefs() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}	
	}	
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function insertEnumDefs($numOfRows, $enumDefs)
	{
		$this->_log->info("insertEnumDefs() - start");
		
		$enumDefId = null;
		$enumName = null;
		$enumTableName = null;
		$enumFieldName = null;
		
		
		$delEnumDefQuery = "delete from enumdefs";
		
		$this->executeQuery($delEnumDefQuery);
		
		$this->_log->info("Clean up of Enum Def is done");
		
		for ($i = 0; $i < $numOfRows; $i++) 
	   	{
	   		$j=0;
		  foreach ($enumDefs as $data) {
			 //$this->_log->info($data[$i]);
			 if ($j == 0)
			 {
			 	$enumDefId = $data[$i];
			 }
			 else if ($j == 1)
			 {
			 	$enumName = $data[$i];
			 }
			 else if ($j == 2)
			 {
			 	$enumTableName = $data[$i];
			 }
			 else if ($j == 3)
			 {
			 	$enumFieldName = $data[$i];
			 }

			 $j = $j + 1;
		  }
		  
  		  $this->enumerationdef = new enumerationdef($enumDefId, $enumName, $enumTableName, $enumFieldName, $this->_userid);
		  
		  $this->insert();
	   	}		

		$this->_log->info("insertEnumDefs() - end");
	}
	
	public function insert()
	{
		$this->_log->info("insert() - start");
		
		//$this->_log->info("size of array : " . sizeof($enumDefArray));
		
		$id = $this->generateID();	
		
		$addQuery = "insert into enumdefs (id, enumerationdefid, name, tablename, fieldname, user, createddate) ".
					"values (:id, :enumerationdefid, :name, :tablename, :fieldname, :user, :createddate)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);		
		$stmt->bindValue(':enumerationdefid', $this->enumerationdef->_id);
		$stmt->bindValue(':name', $this->enumerationdef->_name);
		$stmt->bindValue(':tablename', $this->enumerationdef->_table);
		$stmt->bindValue(':fieldname', $this->enumerationdef->_field);
		$stmt->bindValue(':user', $this->enumerationdef->_user);
		$stmt->bindValue(':createddate', $this->enumerationdef->_createddate);
		
		$result = $stmt->execute();		
		
		$this->_log->info("insert() - end");
		
		return $result;
	}
	
 }
