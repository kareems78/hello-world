<?php
/**
 * Data Access for Reqmnts
 *
 */ 
 class ReqmntsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'reqmnts';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
     *
     */	 
	public static $_formValues = null;
	
 	/**
	 * Contructor for ReqmntsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}	

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "SELECT REQ.ID, REQ.PROJECTDESC, R.NAME AS rname, C.NAME AS cname, REQ.CREATEDDATE, ".
				 "REQ.PID, REQ.CR, REQ.JIRA, REQ.ESTIMATE, REQ.NOTES FROM REQMNTS REQ, RELEASE R, COMPONENT C ".
	      		 " WHERE REQ.RELEASE=R.ID AND REQ.COMPONENT = C.ID AND REQ.USER = ".$this->_userid.
	      		 " ORDER BY rname DESC",
						  
		);
		
		return $queriesArray;
	}
	
      /**
      * Values required to display in drop down list
      * for release, component will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	{
		$releaseDAO = new CategoryDAO('release');
		$componentDAO = new CategoryDAO('component');
		
		// get info from priority, tasktype & status
		$release_rs = $releaseDAO->getOrderByName();
		$component_rs = $componentDAO->getAll();
		
		// push result set to array
		$taskDropDownArray["release"] = $release_rs;
		$taskDropDownArray["component"] = $component_rs;
		
		return $taskDropDownArray;
	}	
	
   	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();
		
		//echo "id : ".$id;
		
		$addQuery = "insert into " . $this->tableName . " (id, projectdesc, release, component, user, createddate, pid, cr, jira, estimate, needtowork, notes) values ".
					"(:id, :projectdesc, :release, :component, :user, :createddate, :pid, :cr, :jira, :estimate, :needtowork, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':projectdesc', $_formValues['projectdesc'] );
		$stmt->bindValue(':release', $_formValues['release']);
		$stmt->bindValue(':component', $_formValues['component']);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':pid', $_formValues['pid']);
		$stmt->bindValue(':cr', $_formValues['cr']);
		$stmt->bindValue(':jira', $_formValues['jira']);
		$stmt->bindValue(':estimate', $_formValues['estimate']);
		$stmt->bindValue(':needtowork', 'No');
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	 {
	 	if (isset($_formValues['needtowork']))
	 	{
	 		$needToWork = $_formValues['needtowork'];
	 	}
	 	else
	 	{
	 		$needToWork = 'No';
	 	}
	 	
		$updateQuery = "update " . $this->tableName . " set projectdesc=:projectdesc, release=:release, ".
					   "component=:component, pid=:pid, cr=:cr, jira=:jira, estimate=:estimate, needtowork=:needtowork, notes=:notes where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':projectdesc', $_formValues['projectdesc'] );
		$stmt->bindValue(':release', $_formValues['release']);
		$stmt->bindValue(':component', $_formValues['component']);
		$stmt->bindValue(':pid', $_formValues['pid']);
		$stmt->bindValue(':cr', $_formValues['cr']);
		$stmt->bindValue(':jira', $_formValues['jira']);
		$stmt->bindValue(':estimate', $_formValues['estimate']);
		$stmt->bindValue(':needtowork', $needToWork);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

      /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
     {
         if(!array_key_exists('release' , $_formValues))
         {
             $this->_log->info("release is not set");
             $_formValues['release'] = "";
         }

         if(!array_key_exists('component' , $_formValues))
         {
             $this->_log->info("component is not set");
             $_formValues['component'] = "";
         }         

         if ($_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['cr'] == '' and $_formValues['jira'] == '')
         {
             //echo "no value is sent<br>";
             $this->_log->info("No value is sent === Setting search query to empty");
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['pid'] != '')
             {
                 $pid = strtolower($_formValues['pid']);
             }

             if ($_formValues['jira'] != '')
             {
                 $jira = strtolower($_formValues['jira']);
             }

             if ($_formValues['cr'] != '')
             {
                 $cr = strtolower($_formValues['cr']);
             }   

             if ($_formValues['needtowork'] != '')
             {
                 $needToWork = strtolower($_formValues['needtowork']);
             }              
             
             
             if ($_formValues['release'] != '')
             {
                 $releaseIDs = CommonUtil::generateStringWithCommas($_formValues['release']);
             }
             
             if ($_formValues['component'] != '')
             {
                 $componentIDs = CommonUtil::generateStringWithCommas($_formValues['component']);
             }             


             if ($_formValues['release'] != '')
             {
                 // only if release is selected
                 if ($_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.")";
                 }

                 // both release & component is selected
                 if ($_formValues['component'] != '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                     	 			"and r.component in (".$componentIDs.")";
                 }
                 
                 // both release & needtowork is selected
                 if ($_formValues['needtowork'] != '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                     	 			"and lower(r.needtowork) like '%". $needToWork ."%' ";
                 }                 
                 
                 // both release, component and needtowork is selected
                 if ($_formValues['needtowork'] != '' and $_formValues['component'] != '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                     				"and lower(r.needtowork) like '%". $needToWork ."%' ".
                     	 			"and r.component in (".$componentIDs.")";
                 }                 

                 // release and pid is selected
                 if ($_formValues['pid'] != '' and $_formValues['component'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and lower(r.pid) like '%". $pid ."%' ";
                 }
                 
                 // release and jira is selected
                 if ($_formValues['jira'] != '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
                 }

                 // release and cr is selected
                 if ($_formValues['cr'] != '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                 }     

                 // release, pid, jira and cr is selected
                 if ($_formValues['pid'] != '' and $_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['component'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.jira) like '%". $jira ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }         

                 // release, component, jira and cr is selected
                 if ($_formValues['component'] != '' and $_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['pid'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.jira) like '%". $jira ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }    

                 // release, component, pid and cr is selected
                 if ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['cr'] != '' and $_formValues['jira'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }    

                 // release, component, pid and jira is selected
                 if ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['jira'] != '' and $_formValues['cr'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                         			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
                     
                 }      

                 // release, pid, and cr is selected
                 if ($_formValues['cr'] != '' and $_formValues['pid'] != '' and $_formValues['jira'] == '' and $_formValues['component'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }   

                 // release, pid, and jira is selected
                 if ($_formValues['jira'] != '' and $_formValues['pid'] != '' and $_formValues['cr'] == '' and $_formValues['component'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
                     
                 }   

                 // release, cr, and jira is selected
                 if ($_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['pid'] == '' and $_formValues['component'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and lower(r.cr) like '%". $cr ."%' ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
                     
                 } 

                 // release, component, and jira is selected
                 if ($_formValues['jira'] != '' and $_formValues['component'] != '' and $_formValues['cr'] == '' and $_formValues['pid'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
                     
                 }   

                 // release, component, and cr is selected
                 if ($_formValues['cr'] != '' and $_formValues['component'] != '' and $_formValues['jira'] == '' and $_formValues['pid'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 } 

                 // release, pid, and cr is selected
                 if ($_formValues['cr'] != '' and $_formValues['pid'] != '' and $_formValues['component'] == '' and $_formValues['jira'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }         

                 // release, component and pid is selected
                 if ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['cr'] == '' and $_formValues['jira'] == '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and r.component in (".$componentIDs.") ".
                         			"and lower(r.pid) like '%". $pid ."%' ";
                     
                 }   

                 // release, component, pid, jira and cr is selected
                 if ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['cr'] != '' and $_formValues['jira'] != '')
                 {
                     $searchQuery = "and r.release in (".$releaseIDs.") ".
                          			"and r.component in (".$componentIDs.") ".
                     				"and lower(r.pid) like '%". $pid ."%' ".
                     				"and lower(r.jira) like '%". $jira ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
                     
                 }                  
                 
             }
             // if release and component is not selected, rest are selected
             elseif ($_formValues['pid'] != '' and $_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '')
             {
                    $searchQuery = "and lower(r.pid) like '%". $pid ."%' ".
                          			"and lower(r.jira) like '%". $jira ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
             }
             // if release and pid is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['pid'] == '')
             {
                    $searchQuery = "and r.component in (".$componentIDs.") ".
                          			"and lower(r.jira) like '%". $jira ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
             }     
             // if release and jira is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['jira'] == '')
             {
                    $searchQuery = "and r.component in (".$componentIDs.") ".
                          			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.cr) like '%". $cr ."%' ";
             } 
             // if release and cr is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['jira'] != '' and $_formValues['pid'] != '' and $_formValues['release'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery = "and r.component in (".$componentIDs.") ".
                          			"and lower(r.pid) like '%". $pid ."%' ".
                         			"and lower(r.jira) like '%". $jira ."%' ";
             }    
             // if release, component and pid is not selected, rest are selected
             elseif ($_formValues['jira'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['pid'] == '')
             {
                    $searchQuery = "and lower(r.jira) like '%". $jira ."%' ".
                         		   "and lower(r.cr) like '%". $cr ."%' ";
             } 
             // if release, component and jira is not selected, rest are selected
             elseif ($_formValues['pid'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['jira'] == '')
             {
                    $searchQuery = "and lower(r.pid) like '%". $pid ."%' ".
                         		   "and lower(r.cr) like '%". $cr ."%' ";
             }  
             // if release, component and cr is not selected, rest are selected
             elseif ($_formValues['pid'] != '' and $_formValues['jira'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery = "and lower(r.pid) like '%". $pid ."%' ".
                         		   "and lower(r.jira) like '%". $jira ."%' ";
             }                                                   
             // if release, pid and jira is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '')
             {
                    $searchQuery =  "and r.component in (".$componentIDs.") ".
                         		   "and lower(r.cr) like '%". $cr ."%' ";
             }  
             // if release, pid and cr is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['jira'] != '' and $_formValues['release'] == '' and $_formValues['pid'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and r.component in (".$componentIDs.") ".
                         		   "and lower(r.jira) like '%". $jira ."%' ";
             }   
             // if release, jira and cr is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['pid'] != '' and $_formValues['release'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and r.component in (".$componentIDs.") ".
                         		   "and lower(r.pid) like '%". $pid ."%' ";
             }   
             // if release, component, pid and jira is not selected, rest are selected
             elseif ($_formValues['cr'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '')
             {
                    $searchQuery =  "and lower(r.cr) like '%". $cr ."%' ";
             }   
             // if release, component, pid and cr is not selected, rest are selected
             elseif ($_formValues['jira'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['pid'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and lower(r.jira) like '%". $jira ."%' ";
             }    
             // if release, component, jira and cr is not selected, rest are selected
             elseif ($_formValues['pid'] != '' and $_formValues['release'] == '' and $_formValues['component'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and lower(r.pid) like '%". $pid ."%' ";
             } 
             // if release, pid, jira and cr is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['needtowork'] != '' and $_formValues['release'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and r.component in (".$componentIDs.")".
                         		   	"and lower(r.needtowork) like '%". $needToWork ."%' ";
             } 
             // if release, pid, jira and cr is not selected, rest are selected
             elseif ($_formValues['component'] != '' and $_formValues['needtowork'] == '' and $_formValues['release'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  "and r.component in (".$componentIDs.")";
             }                                                                                      
             // if none is selected
             elseif ($_formValues['component'] == '' and $_formValues['release'] == '' and $_formValues['pid'] == '' and $_formValues['jira'] == '' and $_formValues['cr'] == '')
             {
                    $searchQuery =  " ";
             }              

         }
         
         $this->updateSubModuleSearchString($searchQuery);

         return $searchQuery;

     }

     /**
      * Searches Requirements as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($records_per_page)
     {
     	$searchStr = $this->getSubModuleSearchString();
     	
     	 $this->_log->info("Search string ==> ".$searchStr);
     	 
         if ($searchStr != '')
         {
             $searchQuery = "SELECT R.ID, R.PROJECTDESC, REL.NAME AS rname, C.NAME AS cname, R.CREATEDDATE, ".
				 "R.PID, R.CR, R.JIRA, R.ESTIMATE, R.NOTES FROM REQMNTS R, RELEASE REL, COMPONENT C ".
	      		 " WHERE R.RELEASE=REL.ID AND R.COMPONENT = C.ID " . $searchStr . 
	      		 "AND R.USER = ".$this->_userid.
	      		 " ORDER BY R.ID DESC";
         }
         else
         {
         	$this->_log->info("Search string is null");
             $searchQuery = "SELECT R.ID, R.PROJECTDESC, REL.NAME AS rname, C.NAME AS cname, R.CREATEDDATE, ".
				 "R.PID, R.CR, R.JIRA, R.ESTIMATE, R.NOTES FROM REQMNTS R, RELEASE REL, COMPONENT C ".
	      		 " WHERE R.RELEASE=REL.ID AND R.COMPONENT = C.ID AND R.USER = ".$this->_userid.
	      		 " ORDER BY R.ID DESC";
         }

         //echo "search query -> ".$getSTQuery."<br>";

         return $this->getViewDataResultSets($searchQuery, $records_per_page);
     }

 }