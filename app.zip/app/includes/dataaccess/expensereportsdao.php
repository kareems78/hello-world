<?php

/**
 * Data Access for Expense
 *
 */ 
 class ExpenseReportsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'expense';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Object to hold expense values
	 * @var expense dto
	 */
	protected $expense = null;
	
	/**
	 * Contructor for ExpenseDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	}

 	/**
	 * 
	 * Displays monthly expenses for a given year
	 * @param unknown_type $records_per_page
	 */
	public function getMonthlyExpenses_with_pagination($records_per_page)
	{
		$pagination = new Pagination();
		
		$yearDAO = new CategoryDAO('year');
		
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		$expReportYearQuery = "select value from usersettings where identifier = '". MONTHLY_EXPENSES_YEAR ."' and user = " .$this->_userid;
		
		//echo "<br> expReportYearQuery --> " . $expReportYearQuery;
		
		$expReportYearResult = $this->executeQuery($expReportYearQuery);
		$row = $expReportYearResult[0];
		$expReportYear = $row['value'];

		$monthlyExpensesQuery = "select month, totalamount from totalexpenses where year = " . $expReportYear . " and totalamount !=0 and user = " .$this->_userid;
		
		$rows = count($this->executeQuery($monthlyExpensesQuery));
		
		$monthlyExpensesQuery = $monthlyExpensesQuery . ' LIMIT ' . (($pagination->get_page() - 1) * $records_per_page) . ', ' . $records_per_page . ' ';	
		
		//echo "<br> monthly expenses report -> " .$monthlyExpensesQuery; 
		
		/** @var $monthly_expenses_rs TYPE_NAME */
        $monthly_expenses_rs = $this->executeQuery($monthlyExpensesQuery);
		
         // pass the total number of records to the pagination class
         $pagination->records($rows);

         // records per page
         $pagination->records_per_page($records_per_page);			
		
		
		// push result set to array
		$rsArray["year_dd_list"] = $year_rs;
		$rsArray["expense_report_year"] = $expReportYear;
		$rsArray["monthlyexpenses"] = $monthly_expenses_rs;
		$rsArray["pagination"] = $pagination;		
		
		return $rsArray;		
	}	
	
	
	/**
	 * 
	 * Displays monthly expenses for a given year
	 * @param unknown_type $records_per_page
	 */
	public function getMonthlyExpenses($records_per_page)
	{
		$pagination = new Pagination();
		
		$yearDAO = new CategoryDAO('year');
		
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		$expReportYearQuery = "select value from usersettings where identifier = '". MONTHLY_EXPENSES_YEAR ."' and user = " .$this->_userid;
		
		//echo "<br> expReportYearQuery --> " . $expReportYearQuery;
		
		$expReportYearResult = $this->executeQuery($expReportYearQuery);
		$row = $expReportYearResult[0];
		$expReportYear = $row['value'];

		$monthlyExpensesQuery = "select month, totalamount from totalexpenses where year = " . $expReportYear . " and totalamount !=0 and user = " .$this->_userid;
		
		//$rows = count($this->executeQuery($monthlyExpensesQuery));
		
		//$monthlyExpensesQuery = $monthlyExpensesQuery . ' LIMIT ' . (($pagination->get_page() - 1) * $records_per_page) . ', ' . $records_per_page . ' ';	
		
		//echo "<br> monthly expenses report -> " .$monthlyExpensesQuery; 
		
		/** @var $monthly_expenses_rs TYPE_NAME */
        $monthly_expenses_rs = $this->executeQuery($monthlyExpensesQuery);
		
         // pass the total number of records to the pagination class
         //$pagination->records($rows);

         // records per page
         //$pagination->records_per_page($records_per_page);			
		
		
		// push result set to array
		$rsArray["year_dd_list"] = $year_rs;
		$rsArray["expense_report_year"] = $expReportYear;
		$rsArray["monthlyexpenses"] = $monthly_expenses_rs;
		//$rsArray["pagination"] = $pagination;		
		
		return $rsArray;		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function setExpenseReportYear($_formValues)
	{
		//echo "in setExpenseReportYear - year value : " . $_formValues['expense_report_year'];
		$year = $_formValues['expense_report_year'];
		
		$updateExpenseReportYearQuery = "update UserSettings set value=:value where identifier=:identifier and user=:user";
		$updExpRptYearStmt = $this->_conn->prepare($updateExpenseReportYearQuery);
		$updExpRptYearStmt->bindValue(':value', $year);
		$updExpRptYearStmt->bindValue(':identifier', MONTHLY_EXPENSES_YEAR);
		$updExpRptYearStmt->bindValue(':user', $this->_userid);			
	
		$updExpRptYearResult = $updExpRptYearStmt->execute();		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function getWeeklyExpenses($_formValues, $records_per_page)
	{
		$pagination = new Pagination();
		
		$weeklyExpMonthQuery = "select value from usersettings where identifier = '".WEEKLY_EXPENSES_MONTH."' and user = " .$this->_userid;
		$weeklyExpYearQuery = "select value from usersettings where identifier = '".WEEKLY_EXPENSES_YEAR."' and user = " .$this->_userid;
		
		$weeklyExpMonthResult = $this->executeQuery($weeklyExpMonthQuery);
		$weeklyExpYearResult = $this->executeQuery($weeklyExpYearQuery);
		$mm = $weeklyExpMonthResult[0]['value'];
		$yy = $weeklyExpYearResult[0]['value'];	

		//$this->_log->info("mm ==> ".$mm);
		//$this->_log->info("yy ==> ".$yy);
		
		$result = CommonUtil::getWeekDates($mm,$yy);
		
		$count_week = $result['num_of_weeks'];
		$week_array = $result['weeks_of_array'];
		
		$counter = 0;
		
		for($i=0;$i<$count_week;$i++)
		{   
			$startDate= $week_array[$i]['wsdate'];
			$this->_log->info("Week Start Date : " . $startDate);
			
			$endDate = $week_array[$i]['wedate'];
			$this->_log->info("Week End Date : " . $endDate);
			
			$getExpQuery = "select sum(amount) as totalamount from Expense ".
							  "where (expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							  "and user = ". $this->_userid;

			$exp_rs = $this->executeQuery($getExpQuery);
			
			$totalamount = round($exp_rs[0]['totalamount'],2,PHP_ROUND_HALF_EVEN);
			
			if ($totalamount == 0)
				$counter = $counter + 1;
			
			$tmpWeeklyExpAmountArray = array(
			"week_num" => $i+1,
			"week_start_date" => $startDate,
			"week_end_date" => $endDate,
			"totalamount" => $totalamount,
			);	
			
			//echo "<br>";
			//print_r($tmpWeeklyExpAmountArray);					
			
			$weeklyExpAmountArray[] = $tmpWeeklyExpAmountArray;				
				 
			
		}	
		
		//$this->_log->info("Count of Weeks = ".$count_week." Counter = ".$counter);
		
		if ($counter == $count_week)
			$weeklyExpAmountArray = null;

		
		$yearDAO = new CategoryDAO('year');
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		$monthDAO = new CategoryDAO('month');
		$month_rs = $monthDAO->getAll();	

		
		$rsArray["year_dd_list"] = $year_rs;
		$rsArray["month_dd_list"] = $month_rs;
		$rsArray["num_of_weeks"] = $count_week;
		$rsArray["weekly_exp_array"] = $weeklyExpAmountArray;
		$rsArray['weekly_exp_month'] = CommonUtil::getFullMonthName($mm);
		$rsArray['weekly_exp_year'] = $yy;		
		
		return $rsArray;		
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function getCategorizedExpenses()
	{
		//echo "<br>inside getCategorizedExpenses ...";
		
		// Get Month and Year from User Settings table
		$expCategoryMonthQuery = "select value from usersettings where identifier = '".CATEGORIZED_EXPENSES_MONTH."' and user = " .$this->_userid;
		$expCategoryYearQuery = "select value from usersettings where identifier = '".CATEGORIZED_EXPENSES_YEAR."' and user = " .$this->_userid;
		
		$expCategoryMonthResult = $this->executeQuery($expCategoryMonthQuery);
		$expCategoryYearResult = $this->executeQuery($expCategoryYearQuery);
		$expCategoryMonthUserSetting = $expCategoryMonthResult[0];
		$expCategoryYearUserSetting = $expCategoryYearResult[0];
		
		//echo "<br> Month : " . $expCategoryMonthUserSetting['value'];
		//echo "<br> Year : " . $expCategoryYearUserSetting['value'];
		
		// Get the start and end date 
		$dateRange = CommonUtil::dateRangeFromMonthAndYear($expCategoryMonthUserSetting['value'], $expCategoryYearUserSetting['value']);
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$getExpMainCategoryQuery = "select distinct emaincat.id, emaincat.name from ecategory ecat, emaincategory emaincat ".
							  	   " where ecat.id in (select distinct category from expense e".
	      		                   " where (e.expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							       " and e.user = ". $this->_userid ." )and ecat.emaincategory = emaincat.id";

		//echo "<br> sql getExpMainCategoryQuery --> " . $getExpMainCategoryQuery;
		
		$exp_main_cat_rs = $this->executeQuery($getExpMainCategoryQuery);
		$expMainCatCount = count($exp_main_cat_rs);
		//echo "<br> count of exp_main_cat_rs : " . count($exp_main_cat_rs);
		
		foreach($exp_main_cat_rs as $emaincategories => $exp_main_category)
		{
			$getExpCategoryQuery = "select id, name  from ecategory where emaincategory = " .$exp_main_category['id'];
			$exp_cat_rs = $this->executeQuery($getExpCategoryQuery);
			
			//echo "<br> sql getExpCategoryQuery --> " . $getExpCategoryQuery;	
			
			$categorizedAmount = null;
			$expCatCount = 0;
			$grandTotal = 0;
			
			foreach($exp_cat_rs as $ecategories => $exp_category)
			{
				$getCategoryCountQuery = "select count(1) as count from expense ".
										 " where (expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							             " and user = ". $this->_userid . " and category = " . $exp_category['id'];
				
				
				//echo "<br> sql getCategoryCountQuery --> " . $getCategoryCountQuery;
				$getCategoryCountResult = $this->executeQuery($getCategoryCountQuery);
				$row = $getCategoryCountResult[0];
				
				//echo "<br> count : " . $row['count'];

				if ($row['count'] != 0)
				{
					$getTotalAmountForCat = "select sum(amount) as totamt from expense ".
											 " where (expensedate between '" . $startDate . "' and '" . $endDate . "') ".
								             " and user = ". $this->_userid . " and category = " . $exp_category['id'];
					
					
					//echo "<br> sql getTotalAmountForCat --> " . $getTotalAmountForCat;
					
					$exp_cat_amt_rs = $this->executeQuery($getTotalAmountForCat);
					$expCatAmountRow = $exp_cat_amt_rs[0];
					
					$grandTotal = $grandTotal + $expCatAmountRow['totamt'];

					$expCatCount++;
					
					$tmpCategorizedAmountArray = array(
					"categoryid" => $exp_category['id'],
					"categoryname" => $exp_category['name'],
					"totalamount" => round($expCatAmountRow['totamt'],2,PHP_ROUND_HALF_EVEN),
					);	
					
					//echo "<br>";
					//print_r($tmpCategorizedAmountArray);					
					
					$categorizedAmount[] = $tmpCategorizedAmountArray;					
				}	

				//echo "<br> count of categorizedAmount array : " . count($categorizedAmount);
			}
			
			//echo "<br> count of categorizedAmount array : " . $expCatCount;
			//echo "<br>";
			//print_r($categorizedAmount);
			
			//echo "<br> Setting values for main category => " . $exp_main_category['name'];
			
			$tmpExpMainCategoryArray = array(
			"maincategoryid" => $exp_main_category['id'],
			"maincategoryname" => $exp_main_category['name'],
			"categorizedAmountArray" => $categorizedAmount,
			"grandtotal" => round($grandTotal,2,PHP_ROUND_HALF_EVEN),
			"exp_category_count" => $expCatCount,
			);
			
			//echo "<br>";
			//print_r($tmpExpMainCategoryArray);
			
			$expMainCategoryArray[] = $tmpExpMainCategoryArray;
		}
		
		//echo"<br>";
		//print_r($expMainCategoryArray);
		
		$yearDAO = new CategoryDAO('year');
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		$monthDAO = new CategoryDAO('month');
		$month_rs = $monthDAO->getAll();	
		
		$resultArray["year_dd_list"] = $year_rs;
		$resultArray["month_dd_list"] = $month_rs;
		$resultArray['exp_cat_month'] = CommonUtil::getFullMonthName($expCategoryMonthUserSetting['value']);
		$resultArray['exp_cat_year'] = $expCategoryYearUserSetting['value'];
		$resultArray['result'] = $expMainCategoryArray;
		$resultArray['exp_main_cat_count'] = $expMainCatCount;

		return $resultArray;
	}
	
 	/**
	 * 
	 * Enter description here ...
	 */
	public function getCategorizedChartExpenses()
	{
		//echo "<br>inside getCategorizedExpenses ...";
		
		// Get Month and Year from User Settings table
		$expCategoryChartMonthQuery = "select value from usersettings where identifier = '".CATEGORIZED_CHART_EXPENSES_MONTH."' and user = " .$this->_userid;
		$expCategoryChartYearQuery = "select value from usersettings where identifier = '".CATEGORIZED_CHART_EXPENSES_YEAR."' and user = " .$this->_userid;
		
		$expCategoryChartMonthResult = $this->executeQuery($expCategoryChartMonthQuery);
		$expCategoryChartYearResult = $this->executeQuery($expCategoryChartYearQuery);
		$expCategoryChartMonthUserSetting = $expCategoryChartMonthResult[0];
		$expCategoryChartYearUserSetting = $expCategoryChartYearResult[0];
		
		//echo "<br> Month : " . $expCategoryMonthUserSetting['value'];
		//echo "<br> Year : " . $expCategoryYearUserSetting['value'];
		
		// Get the start and end date 
		$dateRange = CommonUtil::dateRangeFromMonthAndYear($expCategoryChartMonthUserSetting['value'], $expCategoryChartYearUserSetting['value']);
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$getExpMainCategoryQuery = "select distinct emaincat.id, emaincat.name from ecategory ecat, emaincategory emaincat ".
							  	   " where ecat.id in (select distinct category from expense e".
	      		                   " where (e.expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							       " and e.user = ". $this->_userid ." )and ecat.emaincategory = emaincat.id";

		//echo "<br> sql getExpMainCategoryQuery --> " . $getExpMainCategoryQuery;
		
		$exp_main_cat_rs = $this->executeQuery($getExpMainCategoryQuery);
		$expMainCatCount = count($exp_main_cat_rs);
		//echo "<br> count of exp_main_cat_rs : " . count($exp_main_cat_rs);
		
		foreach($exp_main_cat_rs as $emaincategories => $exp_main_category)
		{
			$getExpCategoryQuery = "select id, name  from ecategory where emaincategory = " .$exp_main_category['id'];
			$exp_cat_rs = $this->executeQuery($getExpCategoryQuery);
			
			//echo "<br> sql getExpCategoryQuery --> " . $getExpCategoryQuery;	
			
			$categorizedAmount = null;
			$expCatCount = 0;
			$grandTotal = 0;
			
			foreach($exp_cat_rs as $ecategories => $exp_category)
			{
				$getCategoryCountQuery = "select count(1) as count from expense ".
										 " where (expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							             " and user = ". $this->_userid . " and category = " . $exp_category['id'];
				
				
				//echo "<br> sql getCategoryCountQuery --> " . $getCategoryCountQuery;
				$getCategoryCountResult = $this->executeQuery($getCategoryCountQuery);
				$row = $getCategoryCountResult[0];
				
				//echo "<br> count : " . $row['count'];

				if ($row['count'] != 0)
				{
					$getTotalAmountForCat = "select sum(amount) as totamt from expense ".
											 " where (expensedate between '" . $startDate . "' and '" . $endDate . "') ".
								             " and user = ". $this->_userid . " and category = " . $exp_category['id'];
					
					
					//echo "<br> sql getTotalAmountForCat --> " . $getTotalAmountForCat;
					
					$exp_cat_amt_rs = $this->executeQuery($getTotalAmountForCat);
					$expCatAmountRow = $exp_cat_amt_rs[0];
					
					$grandTotal = $grandTotal + $expCatAmountRow['totamt'];

					$expCatCount++;
					
					$tmpCategorizedAmountArray = array(
					"categoryid" => $exp_category['id'],
					"categoryname" => $exp_category['name'],
					"totalamount" => round($expCatAmountRow['totamt'],2,PHP_ROUND_HALF_EVEN),
					);	
					
					//echo "<br>";
					//print_r($tmpCategorizedAmountArray);					
					
					$categorizedAmount[] = $tmpCategorizedAmountArray;					
				}	

				//echo "<br> count of categorizedAmount array : " . count($categorizedAmount);
			}
			
			//echo "<br> count of categorizedAmount array : " . $expCatCount;
			//echo "<br>";
			//print_r($categorizedAmount);
			
			//echo "<br> Setting values for main category => " . $exp_main_category['name'];
			
			$tmpExpMainCategoryArray = array(
			"maincategoryid" => $exp_main_category['id'],
			"maincategoryname" => $exp_main_category['name'],
			"categorizedAmountArray" => $categorizedAmount,
			"grandtotal" => round($grandTotal,2,PHP_ROUND_HALF_EVEN),
			"exp_category_count" => $expCatCount,
			);
			
			//echo "<br>";
			//print_r($tmpExpMainCategoryArray);
			
			$expMainCategoryArray[] = $tmpExpMainCategoryArray;
		}
		
		//echo"<br>";
		//print_r($expMainCategoryArray);
		
		$yearDAO = new CategoryDAO('year');
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		$monthDAO = new CategoryDAO('month');
		$month_rs = $monthDAO->getAll();	
		
		$resultArray["year_dd_list"] = $year_rs;
		$resultArray["month_dd_list"] = $month_rs;
		$resultArray['exp_cat_month'] = CommonUtil::getFullMonthName($expCategoryChartMonthUserSetting['value']);
		$resultArray['exp_cat_year'] = $expCategoryChartYearUserSetting['value'];
		$resultArray['result'] = $expMainCategoryArray;
		$resultArray['exp_main_cat_count'] = $expMainCatCount;

		return $resultArray;
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function setExpReportsMonthAndYear($_formValues)
	{
		//echo "in setCategoryMonthAndYear - year value : " . $_formValues['expense_category_year'];
		
		$this->_log->info("Start of setExpReportsMonthAndYear");
		
		$month = CommonUtil::getDoubleDigitMonth($_formValues['expense_report_month']);
		$year = $_formValues['expense_report_year'];
		$exp_rpt_month_identifier = $_formValues['exprptmonthidentifier'];
		$exp_rpt_year_identifier = $_formValues['exprptyearidentifier'];
		
		$updateExpenseReportMonthQuery = "update UserSettings set value=:value where identifier=:identifier and user=:user";
		$updExpReportMonthStmt = $this->_conn->prepare($updateExpenseReportMonthQuery);
		$updExpReportMonthStmt->bindValue(':value', $month);
		$updExpReportMonthStmt->bindValue(':identifier', $exp_rpt_month_identifier);
		$updExpReportMonthStmt->bindValue(':user', $this->_userid);			
	
		$updExpReportMonthStmtResult = $updExpReportMonthStmt->execute();		
		
		$updateExpenseReportYearQuery = "update UserSettings set value=:value where identifier=:identifier and user=:user";
		$updExpReportYearStmt = $this->_conn->prepare($updateExpenseReportYearQuery);
		$updExpReportYearStmt->bindValue(':value', $year);
		$updExpReportYearStmt->bindValue(':identifier', $exp_rpt_year_identifier);
		$updExpReportYearStmt->bindValue(':user', $this->_userid);			
	
		$updExpReportYearStmttResult = $updExpReportYearStmt->execute();	

		$this->_log->info("End of setExpReportsMonthAndYear");
	}
	
 }