<?php

 /**
  * Base Data Access Class 
  * 
  *
  */
 abstract class BaseDAO extends PDO
 {
 
	protected $_tableName = null;
	
	protected $_formInputs = null;
	
	protected $_result = null;
	
	protected $_userid = null;
	
    protected $_conn = null;
    
    protected $_log = null;
    
    protected $_logmsg = null;

	protected $_environment = null;	    

	protected $_oraconn = null;	
    
 	/**
	 * Base Constructor which is used to set default values.
	 *
	 */    
    function __construct($tableName, $userid)
    {
        try
        {
			//echo "<br>in base dao constructor ..."	;
			//echo "<br>in base dao constructor app root ..." . APP_ROOT	;
            $this->_conn = new PDO("sqlite:".SQLITE3_DBFILE);
            $this->_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
			
            $this->_tableName = $tableName;
		
			$this->_userid = $userid;      

			Logger::configure(APP_LOGGER . 'config.xml');
			//$this->_log = Logger::getRootLogger();			
			$this->_log = Logger::getLogger(__CLASS__);
			//$this->_log = Logger::getLogger("main");
			
        }  
        catch (PDOException $e){
            $e->getMessage();
        }
    }	
	
     /**
      * Retrieves all the rows from a
      * table when table name is set
      *
      * @return list - returns the result set of rows
      *
      */
     public function getAll()
	 {
		$this->_result = $this->getAllRecords($this->_tableName);			
		
		return $this->_result;		
	 }

	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function getAllRecords($tableName)
	 {
 		$query = "SELECT * FROM ".$tableName;
		//echo "query -> " . $query; 
	 	
	 	$stmt = $this->_conn->query($query);
	 	
	 	return $stmt->fetchAll(PDO::FETCH_ASSOC);	 	
	 }	 
	 
	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function executeQuery($query)
	 {
	 	$len = strlen(strstr(strtoupper($query), 'PASSWORD'));
	 	
	 	//$this->_log->info("executeQuery len => " . $len);
	 	
	 	if ($len == 0)
	 	{
	 		$this->_log->info("executeQuery => " . $query);
	 	}	
		$stmt = $this->_conn->query($query);
	 	
	 	return $stmt->fetchAll(PDO::FETCH_ASSOC);
	 }	

	 /**
	  * 
	  * Enter description here ...
	  * 
	  * @param String $query
	  * @param String $records_per_page
	  */
 	 public function getViewDataResultSets($query, $records_per_page)
	 {
	 	$this->_log->info("getViewDataResultSets() - start");
	 	
	 	//$this->_log->info("Records per Page : " . $records_per_page);
	 	
		 $pagination = new Pagination();
		 
		 $rows =$this->getNumOfRows($query);
		 //echo "<br>no of rows : " . $rows;
		 
		 $query = $query . ' LIMIT ' . (($pagination->get_page() - 1) * $records_per_page) . ', ' . $records_per_page . ' ';

		 //echo "<br>query -> " . $query;
		 
		 $result = $this->executeQuery($query);

         // pass the total number of records to the pagination class
         $pagination->records($rows);

         // records per page
         $pagination->records_per_page($records_per_page);
		
		 // push to array
		 $viewDataSet["tabledata"] = $result;
		 $viewDataSet["pagination"] = $pagination;
		 
		 $this->_log->info("getViewDataResultSets() - end");
		
		 return $viewDataSet;			
	 }	

	 /**
	  * 
	  * Returns num of rows in a table
	  */	
	 public function getNumOfRows($query)
	 {
		$result = $this->executeQuery($query);
		return count($result);
	 }	 

	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function executeQueryWithOneParam($query, $param)
	 {
	 	
	 	$query_programs = $this->_conn->prepare($query);
		if($query_programs->execute(array($param)))
		{
			$query_programs->setFetchMode(PDO::FETCH_OBJ);
			return $query_programs->fetchAll();
		}
		else
		{
			return false;
		}	 	
	 }		 

     /**
      * Retrieves rows order by id
      *
      * @return list
      *
      */
     public function getByOrderID()
	 {
		$query = "select * from ".$this->_tableName." order by id";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }
	
      /**
      * Retrieves rows order by id
      *
      * @return list
      *
      */
     public function getByOrderIdDesc()
	 {
		$query = "select * from ".$this->_tableName." order by id desc";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }	


     /**
      * Retrieves rows order by name
      *
      * @return list
      *
      */
     public function getOrderByName()
	 {
		$query = "select * from ".$this->_tableName." order by name";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }		
	
      /**
      * Retrieves rows order by name
      *
      * @return list
      *
      */
     public function getOrderByNameDesc()
	 {
		$query = "select * from ".$this->_tableName." order by name desc";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }	

     /**
      * set the form input values to local variable
      *
      * @param $formInputs
      *
      */
     public function setFormInputs($formInputs)
	 {
		$this->_formInputs = $formInputs;
	 }
	
     /**
      * Retrieves data from database
      * from any table as per given
      * id and table name set
      *
      * @param $id
      * @return list
      */
     public function getByID($id)
	 {
		$query = "select * from ".$this->_tableName." where id=".$id;
		$this->_result = $this->executeQuery($query);
		return $this->_result;
	 }
	 
      /**
      * Retrieves name from database
      * from any table as per given
      * id and table name set
      *
      * @param $id
      * @return name
      */
     public function getNameByID($id, $categoryTable)
	 {
		$query = "select name from ".$categoryTable." where id=".$id;
		$this->_result = $this->executeQuery($query);
		return $this->_result[0]['name'];
	 }	 
	
	/**
	 * Deleted multiple rows
	 * from database
	 */
	public function delete()
	{
		$this->_log->info("delete() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		foreach ($deleteIDs as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$query = "delete from ".$this->_tableName." where id=".$id;
			$this->executeQuery($query);
		}		
		
		$this->_log->info("delete() - end");
	}	
	
	/**
	 * Gets all pages required for settings
	 * 
	 */
	public function getAllPageNames()
	{
		$query = "select distinct(page) from pagesettings where tablename = '".$this->_tableName."' and user = ".$this->_userid;
		$this->_result = $this->executeQuery($query);
		return $this->_result;		
	}
	
	/**
	 * Gets column info about a particular page
	 * @param $pageName
	 * 
	 */
	public function getPageSettings($pageName)
	{
		$query = "select * from pagesettings where tablename = '".$this->_tableName."' and user = ".$this->_userid.
		         " and page = '".$pageName."'";
		$this->_result = $this->executeQuery($query );
		return $this->_result;		
	}
	
      /**
      * 
      * @param $_formValues
      */
     public function performFinalPageSettings($_formValues)
     {
     	$result = null;
		$rs = $this->getPageSettings($_formValues['pagename']);

		
		foreach($rs as $rows => $row)
		{
			echo"row['columnname'] -- ".$row['columnname']."<br>";
			if (array_key_exists($row['columnname'] , $_formValues))
			{
				$colname = $row['columnname'];
				
				$updateQuery = "update pagesettings set visible=:visible ".
							   "where page=:page and columnname=:columnname and user=:user";
				
				$stmt = $this->_conn->prepare($updateQuery);
				$stmt->bindValue(':visible', $_formValues[$colname]);
				$stmt->bindValue(':page', $_formValues['pagename']);
				$stmt->bindValue(':columnname', $row['columnname']);
				$stmt->bindValue(':user', $this->_userid);
				
				$result = $stmt->execute();
				
				//echo "result : ".$result."<br>";
				
				//echo"exists -- ".$_formValues[$colname]."<br>";
			}			
		}	

		return $result;
     }		
     
     /**
      * 
      * Generates unique id per row for an user
      * 
      * @return next available id for user
      */
     public function generateID()
     {
     	$tableID = null;
   		$tableName = $this->_tableName;
     	
     	$rowCountQuery = "select * from ".$tableName." where user = ".$this->_userid;
     	$result = $this->executeQuery($rowCountQuery);
     	
     	if (sizeof($result)== 0)
     	{
     		$query = "select tableid from user where id = ".$this->_userid;
     		$result = $this->executeQuery($query);
     		
     		$row = $result[0];
     		     		
     		return $row['tableid'];
     	}
     	else 
     	{
     		$maxQuery = "select max(id) as maxid from ".$tableName." where user = ".$this->_userid;
    		
     		//echo "query -> ".$maxQuery;
     		
			$max_rs = $this->executeQuery($maxQuery);
			$row = $max_rs[0];	
     	   
        	$tableID = $row['maxid'] + 1;
     		
     		return $tableID;     		
     	}
     	
     }
     
     /**
      * 
      * Generates unique id per row for an user with 
      * given table name
      * 
      * @return next available id for user
      */
     public function generateIDWithTable($name)
     {
     	$tableID = null;
     	$tableName = null;
     	
     	if (isset($name))
     	{
     		$tableName = $name;
     	}
     	else
     	{
     		$tableName = $this->_tableName;
     	}
     	
     	$rowCountQuery = "select * from ".$tableName." where user = ".$this->_userid;
     	$result = $this->executeQuery($rowCountQuery);
     	
     	if (sizeof($result) == 0)
     	{
     		$query = "select tableid from user where id = ".$this->_userid;
     		$result = $this->executeQuery($query);
     		
     		$row = $result[0];
     		
     		return $row['tableid'];
     	}
     	else 
     	{
     		$maxQuery = "select max(id) as maxid from ".$tableName." where user = ".$this->_userid;
    		
     		//echo "query -> ".$maxQuery;
     		
			$max_rs = $this->executeQuery($maxQuery);
			$row = $max_rs[0];	
     	   
        	$tableID = $row['maxid'] + 1;
     		
     		return $tableID;     		
     	}
     	
     }     
     
      /**
      * 
      * Generates unique id per row for an user with 
      * given table name
      * 
      * @return next available id for user
      */
     public function generateIDWithTableForUser($name, $user)
     {
     	$tableID = null;
     	$tableName = null;
     	
     	if (isset($name))
     	{
     		$tableName = $name;
     	}
     	else
     	{
     		$tableName = $this->_tableName;
     	}
     	
     	$rowCountQuery = "select * from ".$tableName." where user = ".$user;
     	$result = $this->executeQuery($rowCountQuery);
     	
     	if (sizeof($result) == 0)
     	{
     		$query = "select tableid from user where id = ".$user;
     		$result = $this->executeQuery($query);
     		
     		$row = $result[0];
     		
     		return $row['tableid'];
     	}
     	else 
     	{
     		$maxQuery = "select max(id) as maxid from ".$tableName." where user = ".$user;
    		
     		//echo "query -> ".$maxQuery;
     		
			$max_rs = $this->executeQuery($maxQuery);
			$row = $max_rs[0];	
     	   
        	$tableID = $row['maxid'] + 1;
     		
     		return $tableID;     		
     	}
     	
     }     
     
     /**
      * 
      * Enter description here ...
      * @param $tableID
      * @param $table
      */
     public function updateWithTempIDsIfIDExists($tableID, $table, $user)
     {
     	//echo "in updateWithTempIDsIfIDExists ...";
     	
     	$tableIDExists = false;
     	$savedTableID = $tableID;
     	
	 	$query = "select id from ".$table." where user = ".$user;
	 	$result = $this->executeQuery($query);  

	 	foreach($result as $rows => $row)
		{
	 		if ($row['id'] == $tableID)
	 		{
	 			$tableIDExists = true;
	 			break;
	 		}
	 			
 			$tableID = $tableID + 1;
		}	

		if ($tableIDExists)
		{
			$tmpTableID = (9*1).$savedTableID;
			
			//echo "<br>tmpTableID : ".$tmpTableID;
			
		 	$getIDsQuery = "select id from ".$table." where user = ".$user;
		 	$rs = $this->executeQuery($getIDsQuery); 			
			
		 	foreach($rs as $rows => $row)
			{
	 			//echo "<br>row[id] : ".$row['id']." tmpTableID : ".$tmpTableID;
	 			
	 			$updateTableQuery = "update ".$table." set id = ".$tmpTableID." where id = ".$row['id'].
	 			                    " and user = ".$user;
	 			
	 			//echo "<br>Update Query -> ".$updateTableQuery;
	 			
	 			$updateRs = $this->executeQuery($updateTableQuery);
	 			
	 			$tmpTableID = $tmpTableID + 1;
	 		}			
		}
     }
	
     
     public function getDropDownValues()
     {
     	
     }
     
     public function generateSearchQueryByMonth()
     {
     	
     }
     
      /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getEnvConnectionDropDownValues()
	{
		$getNetworkSettingValueQuery = "select value from usersettings where identifier = 'networksetting' and user = " . $this->_userid;
		$rs = $this->executeQuery($getNetworkSettingValueQuery);
		$row = $rs[0];
		$network  = $row['value'];		
		
		$envNamesQuery = "select id, envname from dbconndetails where envname like '%" . $network . "%' order by envname";
		$envNames_rs = $this->executeQuery($envNamesQuery);
		
		return $envNames_rs;
	}     
	
	
 	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function setEnvConnDetails($envId)
	{
		$getEnvConnDetailsQuery = "select * from dbconndetails where id = ". $envId;
		$getEnvConnDetails_rs = $this->executeQuery($getEnvConnDetailsQuery);
		
		$env = $getEnvConnDetails_rs[0];
		
		$this->_environment =  new environment($env['envname'], $this->_userid, $env['username'], 
						$env['password'], $env['dbhost'], $env['dbport'], $env['sid']);
					
	}	
	
 	/**
	 * 
	 * Enter description here ...
	 */
	public function getOraConnection()
	{
		if (isset($_POST['envid']) and $_POST['envid'] != "")
		{		
			$this->setEnvConnDetails($_POST['envid']);
			
			$this->_log->info("env name : ".$this->_environment->_envname);
			
			$connect_url = "//".$this->_environment->_dbhost.":".$this->_environment->_dbport."/".$this->_environment->_sid;
			
			$this->_log->info("Connecting to User :: " . $this->_environment->_username);
			$this->_log->info("Connection URL : ".$connect_url);
	
			// If you only need to suppress the warning on oci_connect and oci_execute(), prepend it with @
			$this->_oraconn = @oci_connect($this->_environment->_username, $this->_environment->_password, $connect_url);
			
			if ($this->_oraconn != null) 
			{
				return $this->_oraconn;
			}
			else
			{
				$this->_log->info("****** Failed to Connect to Oracle Database ******");
			}	
		}			
	}

  	/**
	 * 
	 * Enter description here ...
	 */
	public function getOraConnectionForRefreshOnly()
	{
		
		$this->_log->info("env name : ".$this->_environment->_envname);
		
		$connect_url = "//".$this->_environment->_dbhost.":".$this->_environment->_dbport."/".$this->_environment->_sid;
		
		$this->_log->info("Connecting to User :: " . $this->_environment->_username);
		$this->_log->info("Connection URL : ".$connect_url);

		// If you only need to suppress the warning on oci_connect and oci_execute(), prepend it with @
		$this->_oraconn = @oci_connect($this->_environment->_username, $this->_environment->_password, $connect_url);
		
		if ($this->_oraconn != null) 
		{
			return $this->_oraconn;
		}
		else
		{
			$this->_log->info("****** Failed to Connect to Oracle Database ******");
		}	
	}	
	
	/**
	 * 
	 * Enter description here ...
	 */
 	public function closeOracleConnection()
	{
		$this->_log->info("closeOracleConnection() - start");
		
		if (isset($this->_oraconn))
		{
			$this->_log->info("Closing Oracle Connection ...");
			// Close the Oracle connection
			oci_close($this->_oraconn);
		}
		else
		{
			$this->_log->info("Connection is not available");
		}
		
		$this->_log->info("closeOracleConnection() - end");
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $subModuleName
	 */
	public function getSubModuleIdFromName($subModuleName)
	{
		$this->_log->info("getSubModuleIdFromName() - start");
		
		$getSubModuleIDQuery = "select id from submodule where aliasname = '".CONTROLLER::$_submodule."'";
     	$result = $this->executeQuery($getSubModuleIDQuery);
     	$row = $result[0];		
		
		$this->_log->info("getSubModuleIdFromName() - end");
		
		return $row['id'];
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $searchStr
	 */
	public function updateSubModuleSearchString($searchStr)
	{
		$this->_log->info("updateSubModuleSearchString() - start");
		
		//$this->_log->info("Search String : " . $searchStr);
		//$this->_log->info("Sub Module : " . CONTROLLER::$_submodule);
		
		$this->_log->info("User in  updateSubModuleSearchString() : " . $this->_userid);
		
		$currentDate = CommonUtil::getCurrentSqliteFormatDate();

     	$subModuleId = $this->getSubModuleIdFromName(CONTROLLER::$_submodule);
		
		$updateQuery = "update submodulesrchstr set searchstring=:searchstring, lastmodifieddate=:lastmodifieddate where submodule=:submodule and user = :user";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':searchstring', $searchStr);
		$stmt->bindValue(':lastmodifieddate', $currentDate);
		$stmt->bindValue(':submodule', $subModuleId);
		$stmt->bindValue(':user', $this->_userid);
		
		$result = $stmt->execute();		
		
		$this->_log->info("updateSubModuleSearchString() - end");
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function getSubModuleSearchString()
	{
		$this->_log->info("getSubModuleSearchString() - start");

     	$query = "select ss.searchstring from submodulesrchstr ss, submodule s where ss.submodule = s.id and s.aliasname = '" . CONTROLLER::$_submodule . "' and ss.user = ".$this->_userid;
     	$result = $this->executeQuery($query);
     		
     	$row = $result[0];
     	
     	$this->_log->info("getSubModuleSearchString() - end");
     		
     	return $row['searchstring'];		
	}
	
	public function flushSubModuleSearchString()
	{
		$this->_log->info("flushSubModuleSearchString() - start");
		
		$currentDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$subModuleId = $this->getSubModuleIdFromName(CONTROLLER::$_submodule);
		
		$updateQuery = "update submodulesrchstr set searchstring=null, lastmodifieddate=:lastmodifieddate where submodule = :submodule and user = :user";
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':lastmodifieddate', $currentDate);
		$stmt->bindValue(':submodule', $subModuleId);
		$stmt->bindValue(':user', $this->_userid);
		
		$result = $stmt->execute();
		
		$this->_log->info("flushSubModuleSearchString() - end");
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $colname
	 * @param unknown_type $colvalue
	 */
	public function entryExist($colname, $colvalue, $coldatatype)
	{
		$entryExist = false;
		
		if (isset($coldatatype))
		{
			if ($coldatatype = 'text')
			{
				$query = "select count(1) as cnt from " . $this->_tableName . " where " . $colname . " = '" . $colvalue . "'";
			}	
			else
			{
				$query = "select count(1) as cnt from " . $this->_tableName . " where " . $colname . " = " . $colvalue;
			}

	     	$result = $this->executeQuery($query);
	     	$row = $result[0];	
	
	     	if ($row['cnt'] > 0)
	     	{
	     		$entryExist = true;
	     	}
		}
		
		return $entryExist;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $colname
	 * @param unknown_type $colvalue
	 */
	public function getIdByColNameValue($colname, $colvalue, $coldatatype)
	{
		if (isset($coldatatype))
		{
			if ($coldatatype = 'text')
			{
				$query = "select id from " . $this->_tableName . " where " . $colname . " = '" . $colvalue . "'";
			}	
			else
			{
				$query = "select id from " . $this->_tableName . " where " . $colname . " = " . $colvalue;
			}		

	     	$result = $this->executeQuery($query);
	     	$row = $result[0];
	
	     	return $row['id'];
		}
		else 
		{
			return null;
		}	
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public function getMaxId()
	{
		$query = "select max(id) as maxid from " . $this->_tableName;
     	$result = $this->executeQuery($query);
     	$row = $result[0];

     	return $row['maxid'];
	}
	
 	/**
	 * 
	 * Enter description here ...
	 */
	public function getMaxIdWithUserInfo()
	{
		$query = "select max(id) as maxid from " . $this->_tableName ." where user = ".$this->_userid;
     	$result = $this->executeQuery($query);
     	$row = $result[0];	

     	return $row['maxid'];
	}	
	
	public function getAllUserIds()
	{
		$query = "select id from user";
		$result = $this->executeQuery($query);

		return $result;
	}
	
 }