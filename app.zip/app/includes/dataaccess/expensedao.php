<?php
/**
 * Data Access for Expense
 *
 */ 
 class ExpenseDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'expense';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Object to hold expense values
	 * @var expense dto
	 */
	protected $expense = null;
	
	
	/**
	 * Contructor for ExpenseDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		$this->_log = Logger::getLogger(__CLASS__);
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select e.id, e.expensedate, ec.name as cname, ".
							  "e.taxpercent, e.amount, e.notes from Expense e, ECategory ec ".
	      		              " where e.category = ec.id and e.user = ". $this->_userid . 
	      		              " order by e.expensedate asc",
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for expense category will be
      * retrieved and stored in array
      *
      * @return list - result of expense category
      *
      */
     public function getDropDownValues()
	{
		$this->_log->info("getDropDownValues() - start");
		
		$ecategoryDAO = new CategoryDAO('ecategory');
		$monthDAO = new CategoryDAO('month');
		$yearDAO = new CategoryDAO('year');
		$taxPercentDAO = new CategoryDAO('taxpercent');
		
		// get info from ecategory, month
		$ecategory_rs = $ecategoryDAO->getOrderByName();
		$month_rs = $monthDAO->getAll();
		$year_rs = $yearDAO->getOrderByNameDesc();
		$taxpercent_rs = $taxPercentDAO->getAll();
		
		// push result set to array
		$expenseDropDownArray["ecategory"] = $ecategory_rs;
		$expenseDropDownArray["month"] = $month_rs;
		$expenseDropDownArray["year"] = $year_rs;
		$expenseDropDownArray["taxpercent"] = $taxpercent_rs;
		
		$this->_log->info("getDropDownValues() - end");
		
		return $expenseDropDownArray;		
	}

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insertExpense()
	{
		$this->_log->info("insertExpense() - start");
		
		$this->_log->info("Current Month :: " . $this->expense->_currentMonth . " Current Year :: " . $this->expense->_currentYear);

        $this->populateTotalExpColIfNotExist($this->expense->_currentMonth, $this->expense->_currentYear);
		
        $this->_log->info("Expense Date after converting to required format :: " . $this->expense->_date);
		
		$id = $this->generateIDWithTable("Expense");	
		
		$addQuery = "insert into expense (id, expensedate, category, user, taxpercent, amount, notes) values ".
						"(:id, :expensedate, :category, :user, :taxpercent, :amount, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':expensedate', $this->expense->_date);
		$stmt->bindValue(':category', $this->expense->_category);
		$stmt->bindValue(':user', $this->expense->_user);
		$stmt->bindValue(':taxpercent', $this->expense->_taxPercentId);
		$stmt->bindValue(':amount', $this->expense->_amount);		
		$stmt->bindValue(':notes', $this->expense->_notes);
		
		$result = $stmt->execute();

		$this->populateAmtInTotExpenses($this->expense->_date);
		
		//echo "result : ".$result."<br>";
		
		$this->_log->info("insertExpense() - end");
		
		return $result;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
 	public function addExpense($_formValues)
	{
		$this->_log->info("addExpense() - start");
		
		//$this->_log->info(" taxPercent sent from GUI => " . $_formValues['taxpercent']);
		
		$taxPercentName = $this->getNameByID($_formValues['taxpercent'], 'taxpercent');
		
		//$this->_log->info(" taxPercent value retrieved => " . $taxPercentName);		
		
		$this->expense = new expense($_formValues['expensedate'], $_formValues['taxpercent'], $taxPercentName, 
			$_formValues['amount'], $_formValues['category'], 
			$_formValues['userid'], $_formValues['notes']);
			
		$result = $this->insertExpense();
		
		$this->_log->info("addExpense() - end");
		
		return $result;
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function insert($_formValues)
	{
		$this->_log->info("insert() - start");
		
		$categoryIds = $_formValues['category'];
		
		$row = 0;
		
		foreach ($categoryIds as $categoryId) 
		{
			// push form inputs to array
			$formInputsArray["0"] = $_formValues['expensedate'.$row];
			$formInputsArray["1"] = $_formValues['category'][$row];
			$formInputsArray["2"] = $_formValues['amount'][$row];	

			//echo "<br>Set : " . $row . " Result returned : " . CommonUtil::allRequiredEntriesExist($formInputsArray);
			
			if (CommonUtil::allRequiredEntriesExist($formInputsArray))
			{
				//echo "<br> Expense : " . $row . " will be inserted";
				
				//$this->_log->info(" taxPercent sent from GUI => " . $_formValues['taxpercent'][$row]);
				
				$taxPercentName = $this->getNameByID($_formValues['taxpercent'][$row], 'taxpercent');
				
				//$this->_log->info(" taxPercent value retrieved => " . $taxPercentName);					
				
				$this->expense = new expense($_formValues['expensedate'.$row], 
					$_formValues['taxpercent'][$row], $taxPercentName, 
					$_formValues['amount'][$row], $_formValues['category'][$row], 
					$_formValues['userid'], $_formValues['notes'][$row]);
					
				$result = $this->insertExpense();				
			}
			
			$row = $row + 1;
		}
		
		$this->_log->info("insert() - end");
		
		return $result;
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$expenseDate = CommonUtil::convertToSQLiteDateFormat($_formValues['expensedate']);

		//$this->_log->info(" taxPercent sent from GUI => " . $_formValues['taxpercent']);
		
		$taxPercentName = $this->getNameByID($_formValues['taxpercent'], 'taxpercent');
		
		//$this->_log->info(" taxPercent value retrieved => " . $taxPercentName);	
		
		if ($taxPercentName != 0)
		{
			$amt = $_formValues['amount'] + ($_formValues['amount'] * $taxPercentName)/100;
		}
		else
		{
			$amt = $_formValues['amount'];
		}		
		
		$updateQuery = "update expense set expensedate=:expensedate, category=:category, taxpercent=:taxpercent, amount=:amount, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':expensedate', $expenseDate);		
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':taxpercent', $_formValues['taxpercent']);
		$stmt->bindValue(':amount', $amt);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		$this->populateAmtInTotExpenses(CommonUtil::convertToSQLiteDateFormat($_formValues['expensedate']));
		
		$this->_log->info("update() - end");
		
		return $result;	
	}

     /**
      * Populates row into the table when there is no entry exists for current
      * month and year
      *
      * @param $month
      * @param $year
      *
      */
     public function populateTotalExpColIfNotExist($month, $year)
	{
		$this->_log->info("populateTotalExpColIfNotExist() - start");
		
		$countQuery = "select count(*) as count from TotalExpenses ".
		              "where month = '". $month . "' and year = '". $year . "' and user = ".$this->_userid;
		
		$this->_log->info("countQuery => " . $countQuery);

		$count_rs = $this->executeQuery($countQuery);

        $row = $count_rs[0];
        
        $this->_log->info("Count returned from countQuery => " . $row['count']);

		if ($row['count'] == 0)
		{
			$id = $this->generateIDWithTable("TotalExpenses");			
			
			$insetRowQuery = "insert into TotalExpenses (id, month, year, totalamount, user) values (:id, :month, :year, :totamt, :user)";

			$stmt = $this->_conn->prepare($insetRowQuery);
			$stmt->bindValue(':id', $id);
			$stmt->bindValue(':month', $month);
			$stmt->bindValue(':year', $year);
			$stmt->bindValue(':totamt', 0);
			$stmt->bindValue(':user', $this->_userid);
			
			$qResult = $stmt->execute();
			
		}
		
		$this->_log->info("populateTotalExpColIfNotExist() - end");
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getExpenses($records_per_page);
	}	
	
     /**
      * To get all expenses for current month and year
      * as well as total amount from TotalExpenses
      *
      * @return mixed
      */
     public function getExpenses($records_per_page)
	{
		$this->_log->info("getExpenses() - start");
		
		$pagination = new Pagination();
		
		$dateRange = CommonUtil::dateRangeForCurrent();
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$currentMonth = date('M');
		$currentYear = date('Y');		
		
		$getExpQuery = "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              "where e.category = ec.id ".
							  "and (e.expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							  "and e.user = ". $this->_userid ." order by e.expensedate";
		
		$rows = count($this->executeQuery($getExpQuery));
		
		$getExpQuery = $getExpQuery . ' LIMIT ' . (($pagination->get_page() - 1) * $records_per_page) . ', ' . $records_per_page . ' ';	
		
		//echo "sql tot exp -> ".$getExpQuery;

		/** @var $exp_rs TYPE_NAME */
        $exp_rs = $this->executeQuery($getExpQuery);
        
		$ids = CommonUtil::generateIdWithCommas($exp_rs);     
        
        //echo "ids -> " . $ids;
        
		$sumAmtQuery = "select sum(amount) as totalamount from Expense where id in (". $ids . ")";      

		//echo "sum amt query -> " . $sumAmtQuery;
        
		$totexp_rs = $this->executeQuery($sumAmtQuery);
		
		//No of records
		/*$recordsCountQuery = "select * from Expense e ".
	      		              "where (e.expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							  "and e.user = ". $this->_userid;
		
		$rows = count($this->executeQuery($recordsCountQuery));*/
		
		$expense = $totexp_rs[0];
		
		//echo "total amt -> " .$row['totalamount'];
		
         // pass the total number of records to the pagination class
         $pagination->records($rows);

         // records per page
         $pagination->records_per_page($records_per_page);		
		
		// push result set to array
		$rsArray["expenses"] = $exp_rs;
		$rsArray["totamt"] = $expense['totalamount'];
		$rsArray["pagination"] = $pagination;
		
		$this->_log->info("getExpenses() - end");
		
		return $rsArray;			
		
	}
	
	/**
	 * Calculate sum of amounts for current month
	 * and year and populate total amount in 
	 * total expenses
	 * 
	 */
	private function populateAmtInTotExpenses($date)
	{
		$this->_log->info("populateAmtInTotExpenses() - start");
		
		$dateRange = CommonUtil::getStartAndEndDate($date);
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$this->_log->info("Date sent :: " . $date);
		$this->_log->info("Start Date :: " . $startDate . " End Date :: " . $endDate);
		
		$MonYYYY = CommonUtil::getMonthAndYYYY($date);
		
		$currentMonth = $MonYYYY['Mon'];
		$currentYear = $MonYYYY['YYYY'];
		
		$this->_log->info("Current Month :: " . $currentMonth . " Current Year :: " . $currentYear);
		
		$countQuery = "select count(1) as count from Expense where ".
	               "(expensedate between '" . $startDate . "' and '" . $endDate . "') and user = ".$this->_userid;			
		
		$countResultSet = $this->executeQuery($countQuery);
		
		$countRow = $countResultSet[0];
		
		$count = $countRow['count'];
		
		if ($count != 0)
		{
			$sumAmtQuery = "select sum(amount) as tamt from Expense where ".
			               "(expensedate between '" . $startDate . "' and '" . $endDate . "') and user = ".$this->_userid;
			
			//echo "<br>sql in populate total -> ".$sumAmtQuery;
			
			$sumAmtResult = $this->executeQuery($sumAmtQuery);
			$row = $sumAmtResult[0];
			
			$totalAmount = $row['tamt'];	

			$updateTExpQuery = "update TotalExpenses set totalamount=:totamt where month=:month and year=:year and user=:user";
			$updStmt = $this->_conn->prepare($updateTExpQuery);
			$updStmt->bindValue(':totamt', $totalAmount);
			$updStmt->bindValue(':month', $currentMonth);
			$updStmt->bindValue(':year', $currentYear);
			$updStmt->bindValue(':user', $this->_userid);	

			$this->_log->info("populateAmtInTotExpenses() - Updating an entry in total expenses table");
		
			$updateResult = $updStmt->execute();			
		}
		else
		{
			$delTotalExpQuery = "delete from TotalExpenses where month = '" . $currentMonth . "' and year = '" . $currentYear
								. "' and user= " . $this->_userid;
								
			//echo "<br> delete total exp query => " . $delTotalExpQuery;	
			
			$this->_logmsg = "Deleting entry from total expenses for month : ";
			$this->_logmsg = $this->_logmsg . $currentMonth . " and year : ";
			$this->_logmsg = $this->_logmsg . $currentYear . " since count is " . $count;

			$this->_log->warn("populateAmtInTotExpenses() - " . $this->_logmsg);								

			$this->executeQuery($delTotalExpQuery);			
		}
		
		$this->_log->info("populateAmtInTotExpenses() - end");
	}

	/**
	 * Delete selected expenses and 
	 * update total expenses
     *
	 */
	public function delete()
	{
		$this->_log->info("deleteExpenses() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		$expenseDateArray = $this->generateDateArrayFromIDs();
		
		foreach ($deleteIDs as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$query = "delete from ".$this->_tableName." where id=".$id;
			$result = $this->executeQuery($query);			

		}
		
	    for ($i = 0; $i <  count($expenseDateArray); $i++) {
    		$key=key($expenseDateArray);
    		$val=$expenseDateArray[$key];
    		
    		if ($val<> ' ') {
       			//echo "<br> key : " . $key ." value : ".  $val ." <br> ";
       			$this->populateAmtInTotExpenses($val);
       		}
     		next($expenseDateArray);
    	}		
    	
    	$this->_log->info("deleteExpenses() - end");
		
		return $result;
	}
	
	/**
	 * 
	 * Unique dates will be inserted into array
	 * as per given deletion ids, which is used 
	 * to calculate total amount at the end after 
	 * deleting records from expense table.
	 * 
	 * @return array of unique dates
	 */
	private function generateDateArrayFromIDs()
	{
		$this->_log->info("generateDateArrayFromIDs() - start");
		
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		$i = 1;
		
		foreach ($deleteIDs as &$id) {	

			$expDateQuery = "select expensedate from expense where id = ".$id;
			$expdate_rs = $this->executeQuery($expDateQuery);
			$row = $expdate_rs[0];
			
			//echo "<br>";
			//echo "<br>expensedate -> ".$row['expensedate'];
			
			$dateArray = explode("-", $row['expensedate']);
			//echo "<br> date array in generateDateArrayFromIDs : " . var_export($dateArray);
			$tmpDate = $dateArray['0'] . "-" . $dateArray['1'] . "-01";	
			
			//echo "<br> tmp date : " . $tmpDate;

			$expenseDateArray[$i] = $tmpDate;
			
			$i++;
		}
		
		//echo "<br> size before -> ".sizeof($expenseDateArray);
		
		// Removing duplicate values set above
		$expenseDateArray = array_unique($expenseDateArray);
		
		//print_r($expenseDateArray);
		
		//echo "<br> size after -> ".sizeof($expenseDateArray);
		
		
		$this->_log->info("generateDateArrayFromIDs() - end");
		
		return $expenseDateArray;

	}

     /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     public function search($records_per_page)
	{
		$this->_log->info("search() - start");
		
		$searchStr = $this->getSubModuleSearchString();
		
		$pagination = new Pagination();
		
		//$searchQ = $this->generateSearchQuery($_formValues);
		
		//echo "search query in main -> ".$searchQ."<br>";
		
		$getEQuery = "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              "where e.category = ec.id ". $searchStr . "and e.user = ". $this->_userid .
							  " order by e.expensedate";
		
		$rows = count($this->executeQuery($getEQuery));		
		
		
		$getEQuery = $getEQuery . ' LIMIT ' . (($pagination->get_page() - 1) * $records_per_page) . ', ' . $records_per_page . ' ';	
		
		//echo "whole query in main -> ".$getEQuery."<br>";
	
		
		/*if ($searchStr == '')	
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e";
		}	
		else
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e where ".substr($searchStr, 3);
		}*/
		
		//echo "amount query in main -> ".$getTEQuery."<br>";	
		
		$exp_rs = $this->executeQuery($getEQuery);
		
		$ids = CommonUtil::generateIdWithCommas($exp_rs);     
        
        //echo "ids -> " . $ids;
        
		$sumAmtQuery = "select sum(amount) as totalamount from Expense where id in (". $ids . ")";      

		//echo "sum amt query -> " . $sumAmtQuery;
		
		$totexp_rs = $this->executeQuery($sumAmtQuery);
		
		$expense = $totexp_rs[0];
		
         // pass the total number of records to the pagination class
         $pagination->records($rows);

         // records per page
         $pagination->records_per_page($records_per_page);		
		
		// push result set to array
		$rsArray["expenses"] = $exp_rs;
		$rsArray["totamt"] = $expense['totalamount'];
		$rsArray["pagination"] = $pagination;
		
		$this->_log->info("search() - end");
		
		return $rsArray;		
	}

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
	{
		$this->_log->info("generateSearchQuery() - start");
		
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '' and $_formValues['category'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['fromdate'] != '')
			{
				$fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
			}
			
			if ($_formValues['todate'] != '')
			{
				$toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
			}
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			
			if ($_formValues['fromdate'] != '')
			{
				// only if fromdate is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ";
				}
				
				// both fromdate & todate is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ";
				}				
				
				// fromdate and category is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}	

				// fromdate, todate and category is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}					
				
				
			}
			elseif ($_formValues['category'] != '' and $_formValues['todate'] == '')
			{
				$searchQuery = "and e.category in (".$categoryIDs.")";
			}
		}
		
		$this->updateSubModuleSearchString($searchQuery);

		$this->_log->info("generateSearchQuery() - end");
		
		return 	$searchQuery;
		
	}
	
      /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQueryByMonth($_formValues)
	{
		$this->_log->info("generateSearchQueryByMonth() - start");
		
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['month'] == '' and $_formValues['year'] == '' and $_formValues['category'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['month'] != '')
			{
				$mon = $_formValues['month'];
			}
			
			if ($_formValues['year'] != '')
			{
				$year = $_formValues['year'];
			}			
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			$dateRange = CommonUtil::dateRangeFromMonthAndYear($mon, $year);
			$startDate = $dateRange['start'];
			$endDate = $dateRange['end'];			
			
			
			if ($_formValues['month'] != '' and $_formValues['year'] != '')
			{
				// only if month is selected
				if ($_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $startDate . "' and '" . $endDate . "') ";
				}
				
				// month and category is selected
				if ($_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $startDate . "' and '" . $endDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}	
				
				
			}
			elseif ($_formValues['category'] != '')
			{
				$searchQuery = "and e.category in (".$categoryIDs.")";
			}
		}
		//echo "<br>search query => " . $searchQuery;
		
		$this->updateSubModuleSearchString($searchQuery);
		
		$this->_log->info("generateSearchQueryByMonth() - end");
		
		return 	$searchQuery;
		
	}	
	
 }