<?php
/**
 * Data Access for Circuit
 *
 */ 
 class CircuitDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'circuittypes';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @var unknown_type
	 */
	public $_orastmt = null;	
	
	/**
	 * Contructor for CircuitDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
	
		$this->getOraConnection();				
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getCircuitsByNode($_formValues)
	{
		$this->_log->info("getCircuitsByNode() - start");
		
		$nodeId = $_formValues['nodeid'];
		
		if ($_formValues['circuittypeid'] != "")
		{
			$circuitTypeId = $_formValues['circuittypeid'];	
		}
		
		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		$query = "SELECT c.circuitid, c.NAME, ct.name as circuittype, c.createddate, ps.NAME AS status ".
  				" FROM circuit c, circuittype_m ct, provisionstatus ps ".
 				" WHERE (c.circuit2startnode = :startnodeid OR c.circuit2endnode = :endnodeid) ".
   				" AND c.circuit2circuittype = ct.circuittypeid ".
   				" AND c.circuit2provisionstatus = ps.provisionstatusid";
		
		if (isset($circuitTypeId))
		{
			$query = $query . " AND c.circuit2circuittype = :circuittypeid";
		}
		
		//$this->_log->info ("Query ==> " . $query);
		
		if ($this->_oraconn != null)
		{
			$this->_orastmt = oci_parse($this->_oraconn, $query);
	
			oci_bind_by_name($this->_orastmt, ":startnodeid", $nodeId);
			oci_bind_by_name($this->_orastmt,":endnodeid", $nodeId);
			
			
			if (isset($circuitTypeId))
			{
				oci_bind_by_name($this->_orastmt,":circuittypeid", $circuitTypeId);
			}		
			
			oci_execute($this->_orastmt);	
			
			$nrows = oci_fetch_all($this->_orastmt, $resultset);
			
			oci_free_statement($this->_orastmt);
			
			$this->closeOracleConnection();
			
			// push to array
			$outputArray["query_output"] = $resultset;
			$outputArray["num_rows"] = $nrows;
			$outputArray["env_name"] = $this->_environment->_envname;
			$outputArray["nodeid"] = $nodeId;
				
			$this->_log->info("getCircuitsByNode() - end");
			
			return $outputArray;			
		}
		else 
		{
	        $e = oci_error();
	        //trigger_error(htmlentities($e["message"], ENT_QUOTES), E_USER_ERROR);
	        $outputArray["ORA_ERROR"] = $e["message"];	

	        return $outputArray;
		}
	
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function setEnvConnDetails_Obsolete($_formValues)
	{
		$getEnvConnDetailsQuery = "select * from dbconndetails where id = ". $_formValues['envid'] . " and user = " .$this->_userid;
		$getEnvConnDetails_rs = $this->executeQuery($getEnvConnDetailsQuery);
		
		$env = $getEnvConnDetails_rs[0];
		
		return new environment($env['envname'], $_formValues['userid'], $env['username'], 
						$env['password'], $env['dbhost'], $env['dbport'], $env['sid']);
	}
	
  	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function getCircuitsByType()
	{
		$this->_log->info("getCircuitsByType() - start");

		//$query = "select circuitid, name from circuit where (circuit2startnode=:startnodeid or circuit2endnode=:endnodeid)";
		
		$query = "SELECT circuittypeid, NAME, tablename ".
  				"FROM circuittype_m ".
 				"WHERE circuittypeid IN".
 				"(150000064, 150000063, 1761020016, 1761020002, 150000059)";
		
		$this->_orastmt = oci_parse($this->_oraconn, $query);

		oci_execute($this->_orastmt);	
		
		$nrows = oci_fetch_all($this->_orastmt, $resultset);
		
		oci_free_statement($this->_orastmt);
		
		$this->closeOracleConnection();
		
		// push to array
		$outputArray["query_output"] = $resultset;
		$outputArray["num_rows"] = $nrows;
		$outputArray["env_name"] = $this->_environment->_envname;
			
		$this->_log->info("getCircuitsByType() - end");
		
		return $outputArray;	
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function getCktPortNodeInfo($_formValues)
	{
		$this->_log->info("getCktPortNodeInfo() - start");
		
		if ($_formValues['cktname'] != "")
		{		
			$circuitName = $_formValues['cktname'];
		}	
		
		if ($_formValues['cktid'] != "")
		{
			$circuitId = $_formValues['cktid'];	
		}

		$query = "SELECT c.circuitid, c.NAME AS cktname, cps.NAME ckt_status, " .
		       "sn.nodeid AS startnodeid, sn.NAME AS startnode, snps.NAME snode_status, " .
		       "sp.portid AS startlogicalportid, sp.NAME AS startlogicalport, spps.NAME startlogicalport_status, " .
		       "spp.portid AS startphysicalportid, spp.NAME AS startphyportname, sppps.NAME startphysicalport_status, " .
		       "en.nodeid AS endnodeid, en.NAME AS endnode, enps.NAME enode_status, " .
			   "ep.portid AS endlogicalportid, ep.NAME AS endlogicalport, " .
		       "epps.NAME endlogicalport_status, epp.portid AS endphysicalportid, epp.NAME AS endphyportname, " .
		       "eppps.NAME endphysicalport_status " .
		  	   "FROM circuit c, node sn, node en, port sp, port ep, " .
		       "port spp, port epp, provisionstatus cps, provisionstatus snps, " . 
		       "provisionstatus enps, provisionstatus spps, provisionstatus epps, " .
		       "provisionstatus sppps, provisionstatus eppps " .
		 	   "WHERE c.circuit2startport = sp.portid " .
		   	   "AND c.circuit2endport = ep.portid " .
		       "AND c.circuit2startnode = sn.nodeid " .
		       "AND c.circuit2endnode = en.nodeid " .
		       "AND sp.parentport2port = spp.portid " .
		       "AND ep.parentport2port = epp.portid " .
		       "AND c.circuit2provisionstatus = cps.provisionstatusid " .
		       "AND sn.node2provisionstatus = snps.provisionstatusid " .
		       "AND en.node2provisionstatus = enps.provisionstatusid " .
		       "AND sp.port2provisionstatus = spps.provisionstatusid " .
		       "AND ep.port2provisionstatus = epps.provisionstatusid " .
		       "AND spp.port2provisionstatus = sppps.provisionstatusid " .
		       "AND epp.port2provisionstatus = eppps.provisionstatusid ";
		
		if (isset($circuitName))
		{
			$query = $query . " AND c.name = :circuitname";
		}	
		else if (isset($circuitId))	
		{
			$query = $query . " AND c.circuitid = :circuitid";
		}
		
		if ($this->_oraconn != null)
		{
		
			if (isset($circuitName) or isset($circuitId))
			{
				$this->_orastmt = oci_parse($this->_oraconn, $query);
				
				if (isset($circuitName))
				{
					oci_bind_by_name($this->_orastmt,":circuitname", $circuitName);
				}

				if (isset($circuitId))
				{
					oci_bind_by_name($this->_orastmt,":circuitid", $circuitId);
				}				
		
				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				//$this->_log->info($resultset);
				//$this->_log->info($resultset['CKT_STATUS'][0]);
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				
				if (isset($circuitName))
				{
					$outputArray["ckt_name"] = $circuitName;
				}

				if (isset($circuitId))
				{
					$outputArray["ckt_id"] = $circuitId;
				}				
					
				$this->_log->info("getCktPortNodeInfo() - end");
				
				return $outputArray;			
			}
			else
			{
				$this->_log->info("No input received ... returning null");
				$this->_log->info("getCktPortNodeInfo() - end");
				return null;
			}
		}
		else
		{
			$this->_log->error("No Oracle Connection available");
		}
	}
	
	public function do_fetch()
	{
		
		$this->_log->info("do_fetch() - start");	
		
	  	// Fetch the results in an associative array
		print '<table border="1">';
		while ($row = oci_fetch_array($this->_orastmt, OCI_RETURN_NULLS+OCI_ASSOC)) 
		{
		  print '<tr>';
		  foreach ($row as $item) 
		  {
		    print '<td>'.($item?htmlentities($item):'&nbsp;').'</td>';
		  }
		  
		  //$this->_log->info("id :: ".$row['id']);
		  //$this->_log->info("name :: ".$row['name']);
		    
		  print '</tr>';
		  
		}
		  
		print '</table>';
		
		$this->_log->info("do_fetch() - end");
	}
	
	
 	public function do_fetch_all()
	{
		
		$this->_log->info("do_fetch_all() - start");	
		
		$nrows = oci_fetch_all($this->_orastmt, $results);
		if ($nrows > 0) {
		   echo "<table border=\"1\">\n";
		   echo "<tr>\n";
		   foreach ($results as $key => $val) {
		      echo "<th>$key</th>\n";
		   }
		   echo "</tr>\n";
		   
		   for ($i = 0; $i < $nrows; $i++) {
		      echo "<tr>\n";
		      foreach ($results as $data) {
		         echo "<td>$data[$i]</td>\n";
		      }
		      echo "</tr>\n";
		   }
		   echo "</table>\n";
		} else {
		   echo "No data found<br />\n";
		}      
		echo "$nrows Records Selected<br />\n";
		
		$this->_log->info("do_fetch_all() - end");
	}	

	public function getAllCircuitTypes($records_per_page)
	{
		$this->_log->info("getAllCircuitTypes() - start");
		
		$query = "select * from circuittypes where user = " .$this->_userid;
		
		$this->_log->info("getAllCircuitTypes() - end");
		
		return $this->getViewDataResultSets($query, $records_per_page);
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
	public function getUnderlyingCircuits($_formValues)
	{
		$this->_log->info("getUnderlyingCircuits() - start");
		
		if ($_formValues['cktname'] != "")
		{		
			$circuitName = $_formValues['cktname'];
		}	
		
		if ($_formValues['cktid'] != "")
		{
			$circuitId = $_formValues['cktid'];	
		}
		
		if ($this->_oraconn != null)
		{
		
			if (isset($circuitName) or isset($circuitId))
			{
				
				if (isset($circuitName))
				{
					// Query to get cirucit id from name
					$circuitIdQuery = "select circuitid from circuit where name = :circuitname";
					
					$this->_orastmt = oci_parse($this->_oraconn, $circuitIdQuery);
					
					oci_bind_by_name($this->_orastmt,":circuitname", $circuitName);
					
					oci_execute($this->_orastmt);
					
					$ckt_nrows = oci_fetch_all($this->_orastmt, $ckt_resultset);
					
					oci_free_statement($this->_orastmt);
					
					$circuitId = $ckt_resultset[CIRCUITID][0];					
				}
				
				$query = "SELECT circuitid, name, createddate " .
  						 "FROM circuit WHERE circuitid IN " .
				         "(SELECT DISTINCT cc.uses2circuit " .
						 "FROM circuitcircuit cc " .
						 "WHERE cc.usedby2circuit = :circuitid)";
				
				$this->_orastmt = oci_parse($this->_oraconn, $query);

				if (isset($circuitId))
				{
					oci_bind_by_name($this->_orastmt,":circuitid", $circuitId);
				}				
		
				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				//$this->_log->info($resultset);
				//$this->_log->info($resultset['CKT_STATUS'][0]);
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				
				if (isset($circuitName))
				{
					$outputArray["ckt_name"] = $circuitName;
				}

				if (isset($circuitId))
				{
					$outputArray["ckt_id"] = $circuitId;
				}				
					
				$this->_log->info("getUnderlyingCircuits() - end");
				
				return $outputArray;			
			}
			else
			{
				$this->_log->info("No input received ... returning null");
				$this->_log->info("getUnderlyingCircuits() - end");
				return null;
			}
		}
		else
		{
			$this->_log->error("No Oracle Connection available");
		}
		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $_formValues
	 */
 	public function getOverlyingCircuits($_formValues)
	{
			$this->_log->info("getUnderlyingCircuits() - start");
		
		if ($_formValues['cktname'] != "")
		{		
			$circuitName = $_formValues['cktname'];
		}	
		
		if ($_formValues['cktid'] != "")
		{
			$circuitId = $_formValues['cktid'];	
		}
		
		if ($this->_oraconn != null)
		{
		
			if (isset($circuitName) or isset($circuitId))
			{
				
				if (isset($circuitName))
				{
					// Query to get cirucit id from name
					$circuitIdQuery = "select circuitid from circuit where name = :circuitname";
					
					$this->_orastmt = oci_parse($this->_oraconn, $circuitIdQuery);
					
					oci_bind_by_name($this->_orastmt,":circuitname", $circuitName);
					
					oci_execute($this->_orastmt);
					
					$ckt_nrows = oci_fetch_all($this->_orastmt, $ckt_resultset);
					
					oci_free_statement($this->_orastmt);
					
					$circuitId = $ckt_resultset[CIRCUITID][0];					
				}
				
				$query = "SELECT circuitid, name, createddate " .
  						 "FROM circuit WHERE circuitid IN " .
				         "(SELECT DISTINCT cc.UsedBy2Circuit " .
						 "FROM circuitcircuit cc " .
						 "WHERE cc.Uses2Circuit = :circuitid)";
				
				$this->_orastmt = oci_parse($this->_oraconn, $query);

				if (isset($circuitId))
				{
					oci_bind_by_name($this->_orastmt,":circuitid", $circuitId);
				}				
		
				oci_execute($this->_orastmt);	
				
				$nrows = oci_fetch_all($this->_orastmt, $resultset);
				
				oci_free_statement($this->_orastmt);
				
				$this->closeOracleConnection();
				
				//$this->_log->info($resultset);
				//$this->_log->info($resultset['CKT_STATUS'][0]);
				
				// push to array
				$outputArray["query_output"] = $resultset;
				$outputArray["num_rows"] = $nrows;
				$outputArray["env_name"] = $this->_environment->_envname;
				
				if (isset($circuitName))
				{
					$outputArray["ckt_name"] = $circuitName;
				}

				if (isset($circuitId))
				{
					$outputArray["ckt_id"] = $circuitId;
				}				
					
				$this->_log->info("getUnderlyingCircuits() - end");
				
				return $outputArray;			
			}
			else
			{
				$this->_log->info("No input received ... returning null");
				$this->_log->info("getUnderlyingCircuits() - end");
				return null;
			}
		}
		else
		{
			$this->_log->error("No Oracle Connection available");
		}		
	}	
 }
