<?php
/**
 * Data Access for Daily Tasks
 *
 */ 
 class DTasksDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'dtasks';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for DTasksDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select d.id, d.tasktimetext, d.tasktime, d.createddate, ".
							  "d.updateddate, d.task, d.notes from dtasks d ".
	      		              " where d.user = ". $this->_userid . 
	      		              " order by d.tasktime",
		);
		
		return $queriesArray;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into dtasks (id, tasktimetext, tasktime, createddate, updateddate, task, user, notes) values ".
						"(:id, :tasktimetext, :tasktime, :createddate, :updateddate, :task, :user, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':tasktimetext', 'Set Time');
		$stmt->bindValue(':tasktime', '24:59');
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':task', 'Set Task');
		$stmt->bindValue(':user', $this->_userid);		
		$stmt->bindValue(':notes', '');
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$updatedDate = CommonUtil::getCurrentDate();
		$objectIds = $_formValues['objectIds'];
		//echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			//echo "<br>id : ".$id."<br>";
			//echo "query : ".$query;
			
			//echo "<br> task time : ".$_formValues['tasktimetext'][$row];
			
			$taskTime = CommonUtil::performTimeConversation($_formValues['tasktimetext'][$row]);
			
			//echo "<br>task time : ".$taskTime;
			
			//if ($taskTime)
			
			$updateQuery = "update dtasks set tasktimetext=:tasktimetext, tasktime=:tasktime, updateddate=:updateddate, ".
						   "task=:task, notes=:notes ".
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':tasktimetext', $_formValues['tasktimetext'][$row]);
			$stmt->bindValue(':tasktime', $taskTime);
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':task', $_formValues['task'][$row]);
			$stmt->bindValue(':notes', $_formValues['notes'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1; 
		}		
		
		return $result;		
	}
	
 }