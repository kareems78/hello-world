<?php
/**
 * Data Access for Biometrics
 *
 */ 
 class BiometricsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'biometrics';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for BiometricsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from biometrics where user = ".$this->_userid,
		);
		
		return $queriesArray;
	}
	
 	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		$biotestDate = CommonUtil::convertToSQLiteDateFormat($_formValues['biotestdate']);
		
		$id = $this->generateID();		
		
		$addQuery = "insert into biometrics (id, createddate, biotestdate, user, weight, bmi, waist, bp, glucosefasting, glucosenonfasting, ".
		            "totalcholestrol, hdlcholestrol, ldlcholestrol, riskratio, notes) values (:id, :createddate, :biotestdate, :user, :weight, ".
					":bmi, :waist, :bp, :glucosefasting, :glucosenonfasting, :totalcholestrol, :hdlcholestrol, :ldlcholestrol, ".
					":riskratio, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);		
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':biotestdate', $biotestDate);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':weight', $_formValues['weight']);
		$stmt->bindValue(':bmi', $_formValues['bmi']);
		$stmt->bindValue(':waist', $_formValues['waist']);
		$stmt->bindValue(':bp', $_formValues['bp']);
		$stmt->bindValue(':glucosefasting', $_formValues['glucosefasting']);
		$stmt->bindValue(':glucosenonfasting', $_formValues['glucosenonfasting']);
		$stmt->bindValue(':totalcholestrol', $_formValues['totalcholestrol']);
		$stmt->bindValue(':hdlcholestrol', $_formValues['hdlcholestrol']);
		$stmt->bindValue(':ldlcholestrol', $_formValues['ldlcholestrol']);
		$stmt->bindValue(':riskratio', $_formValues['riskratio']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @throws DatabaseException
      * @return bool
      */
	public function update($_formValues)
	{
		$biotestDate = CommonUtil::convertToSQLiteDateFormat($_formValues['biotestdate']);
		
		$updateQuery = "update biometrics set biotestdate=:biotestdate, weight=:weight, bmi=:bmi, waist=:waist, bp=:bp, ".
		               "glucosefasting=:glucosefasting, glucosenonfasting=:glucosenonfasting, totalcholestrol=:totalcholestrol, ".
					   "hdlcholestrol=:hdlcholestrol, ldlcholestrol=:ldlcholestrol, riskratio=:riskratio, notes=:notes ".
					   "where id=:id";

			
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':biotestdate', $biotestDate);
		$stmt->bindValue(':weight', $_formValues['weight']);
		$stmt->bindValue(':bmi', $_formValues['bmi']);
		$stmt->bindValue(':waist', $_formValues['waist']);
		$stmt->bindValue(':bp', $_formValues['bp']);
		$stmt->bindValue(':glucosefasting', $_formValues['glucosefasting']);
		$stmt->bindValue(':glucosenonfasting', $_formValues['glucosenonfasting']);
		$stmt->bindValue(':totalcholestrol', $_formValues['totalcholestrol']);
		$stmt->bindValue(':hdlcholestrol', $_formValues['hdlcholestrol']);
		$stmt->bindValue(':ldlcholestrol', $_formValues['ldlcholestrol']);
		$stmt->bindValue(':riskratio', $_formValues['riskratio']);
		$stmt->bindValue(':notes', $_formValues['notes']);			
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	

 }
