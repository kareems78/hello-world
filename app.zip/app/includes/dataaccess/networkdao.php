<?php
/**
 * Data Access for Shopping List
 *
 */ 
 class NetworkDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'usersettings';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for NetworkDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from usersettings s ".
	      		              " where s.user = ". $this->_userid . 
	      		              " and s.identifier = 'networksetting'",
		);
		
		return $queriesArray;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param String $records_per_page
	 */
	public function view($records_per_page)
	{
		return $this->getViewDataResultSets($this->_getAllRecords, $records_per_page);
	}	

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$getUserSettingIdQuery = "select id from usersettings where identifier = 'networksetting' and user = " . $this->_userid;
		$rs = $this->executeQuery($getUserSettingIdQuery);
		$row = $rs[0];
		$id  = $row['id'];
		
		//$this->_log->info("user settings id : " . $id);
		
		//$this->_log->info("user settings value  : " . $_formValues['networksetting']);
		
		$updateQuery = "update usersettings set value=:value where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':value', $_formValues['networksetting']);
		$stmt->bindValue(':id', $id);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		$this->_log->info("update() - end");
		
		return $result;		
	}
	
 }