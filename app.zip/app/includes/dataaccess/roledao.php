<?php
 /**
 * Data Access for Role
 *
 */ 
 class RoleDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'role';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for RoleDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);		
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from role",
		);
		
		return $queriesArray;
	}

     /**
      * Inserts a row into database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentSqliteFormatDate();
		
		$addQuery = "insert into role (name, createddate, updateddate, notes) values ".
						"(:name, :createddate, :updateddate, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      * @throws DatabaseException
      */
     public function update($_formValues)
	{
		
		$updatedDate = CommonUtil::convertToMySQLDateFormat($_formValues['updateddate']);
		
		$updateQuery = "update role set name=:name, updateddate=:updateddate, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':updateddate', $updatedDate);
		$stmt->bindValue(':notes', $_formValues['notes']);			
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	

 }
