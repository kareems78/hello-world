<?php
 /**
  *	Data Access for Priority
  *
  */
 class ECategoryDAO extends BaseDAO
 {
 
 
  	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = null;
	
	/**
	 * Contructor for CategoryDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($tableName)
	{
		$this->tableName = $tableName;
		parent::__construct($tableName, 0);
				
		//Set log object
		$this->_log = Logger::getLogger(__CLASS__);
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		$this->_log->info("ecategorydao.insert() - start");
		
		$expMainCategoryId = $this->findExpMaincategoryId($_formValues['name']);
		
		if (isset($expMainCategoryId))
		{
			$this->_log->info("Expenses Main Category ID Returned : " . $expMainCategoryId);
			
			$addQuery = "insert into ".$this->tableName." (name, emaincategory, description) values (:name, :emaincategory, :description)";		
			
			$stmt = $this->_conn->prepare($addQuery);
			$stmt->bindValue(':name', $_formValues['name']);
			$stmt->bindValue(':emaincategory', $expMainCategoryId);
			$stmt->bindValue(':description', $_formValues['desc']);
			
			$result = $stmt->execute();	
			
			$this->_log->info("ecategorydao.insert() - end");
			
			return $result;			
		}
		else 
		{
			$this->_log->info("Expense Main category id is not found. Please check and fix and then retry");
			
			$this->_log->info("ecategorydao.insert() - end");
		}

	}
	
	private function findExpMaincategoryId($categoryName)
	{
		$this->_log->info("findExpMaincategoryId() - start");
		
		$expMainCategoryName = "";
		$expMainCategoryId = "";
		
		if (CommonUtil::contains($categoryName, '/'))
		{
			$expMainCategoryNameArray = explode("/", $categoryName);
			$expMainCategoryName = $expMainCategoryNameArray[0];
		}
		else
		{
			$expMainCategoryName = $categoryName;
		}
		
		$query = "select id from emaincategory where name = '" . $expMainCategoryName . "'";
		$rs = $this->executeQuery($query);
		$row = $rs[0];	

		if (isset($row['id']))
		{
			$expMainCategoryId = $row['id'];	
		}
		
		$this->_log->info("findExpMaincategoryId() - end");
		 
		return $expMainCategoryId;
	}

     /**
      * Delete categories
      *
      * @param $_formValues
      */
     public function deleteCategories($_formValues)
	{
		$this->_log->info("deleteCategories() - start");
		$this->setFormInputs($_formValues);
		return $this->delete();
		$this->_log->info("deleteCategories() - end");
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		$this->_log->info("update() - start");
		
		$updateQuery = "update ".$this->tableName." set name=:name, description=:description where id=:id";
		
		$this->_log->info("updateQuery ==> ".$updateQuery);
		
		//$this->_log->info("name ==> ".$_formValues['name']." description ==> ".$_formValues['desc']." id ==> ".$_formValues['id']);
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':description', $_formValues['desc']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();	
		
		$this->_log->info("update() - end");
		
		return $result;		
	}

 }