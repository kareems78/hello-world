<?php

class CommonUtil
{
	
    /**
     * Load definitions from root
     *
     * @param $appRootPath
     *
     */
    public static function reloadDefinitions($appRootPath)
	{
		define('APP_BASE', $appRootPath);
		
		//require_once $appRootPath . '\includes\defines.php';
		self::loadFile($appRootPath . '\includes\defines.php');
	}
	
	public static function loadFile($filename)
	{
		require_once $filename;		
	}	
	
    /**
     * Converts date to MySQL format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function convertToMySQLDateFormat($date)
	{
		$formattedMySQLDate = date("Y-m-d H:i:s", strtotime($date));
		
		return $formattedMySQLDate;
	}
	
    /**
     * Converts date to SQLite3 format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function convertToSQLiteDateFormat($date)
	{
		$formattedSQLiteDate = date("Y-m-d", strtotime($date));
		
		return $formattedSQLiteDate;
	}	

    /**
     * Converts date into MMDDYYYY format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function dateInMMDDYYYY($date)
	{
		
		/**
		 * Added below in php.ini file
		 * date.timezone = "America/New_York"
		 */
		//date_default_timezone_set('UTC');
		
		$formattedDate = date("m/d/Y", strtotime($date));
		
		return $formattedDate;
	}

    /**
     * Returns current or today's date
     *
     * @return bool|string
     *
     */
    public static function getCurrentDate()
	{
		date_default_timezone_set('America/New_York');
		$currentDate = date("Y-m-d H:i:s");
		
		return $currentDate;
	}
	
    /**
     * Returns current or today's date
     *
     * @return bool|string
     *
     */	
    public static function getCurrentSqliteFormatDate()
	{
		date_default_timezone_set('America/New_York');
		$currentDate = date("Y-m-d H:i:s");
		
		//return CommonUtil::convertToSQLiteDateFormat($currentDate);
		return $currentDate;
	}	

    /**
     * Generates date range for today's date
     *
     * @return array of start and end date
     *
     */
    public static function dateRangeForCurrent()
	{
		$today = getdate();
		$mon = self::getNumericMonthValue($today['month']);
		$startDate = $today['year']."-". $mon ."-01";
		$endDate = $today['year']."-". $mon ."-31";
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
		
	}
	
	public function getNumericMonthValue($month)
	{
		$monthArray = array(
			"January" => "01",
			"February" => "02",
			"March" => "03",
			"April" => "04",
			"May" => "05",
			"June" => "06",
			"July" => "07",
			"August" => "08",
			"September" => "09",
			"October" => "10",
			"November" => "11",
			"December" => "12",
		);
		
		return $monthArray[$month];		
	}
	
    /**
     * Generates date range from month and year
     *
     * @return array of start and end date
     *
     */
    public static function dateRangeFromMonthAndYear($mon, $year)
	{
		$mon = self::getDoubleDigitMonth($mon);
		$startDate = $year."-".$mon."-01";
		$endDate = $year."-".$mon."-31";
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
		
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $mon
	 */
	public static function getDoubleDigitMonth($mon)
	{
		$monthArray = array(
			"1" => "01",
			"01"=> "01",
			"2" => "02",
			"02"=> "02",
			"3" => "03",
			"03"=> "03",
			"4" => "04",
			"04"=> "04",
			"5" => "05",
			"05"=> "05",
			"6" => "06",
			"06"=> "06",
			"7" => "07",
			"07"=> "07",
			"8" => "08",
			"08"=> "08",
			"9" => "09",
			"09"=> "09",
			"10" => "10",
			"11" => "11",
			"12" => "12",
		);
		
		return $monthArray[$mon];			
	}
	
	public static function getStartAndEndDate($date)
	{
		//echo "<br> date in getStartAndEndDate : " . $date;
		$dateArray = explode("-", $date);
		
		$mon = $dateArray['1'];
		$year = $dateArray['0'];
		
		$startDate = $year . "-". $mon ."-01";
		$endDate = $year . "-". $mon ."-31";
		
		//echo "<br>start date -> ".$startDate;
		//echo "<br>end date -> ".$endDate;
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	private function getMonth()
	{
		$monthArray = array(
			"01" => "Jan",
			"02" => "Feb",
			"03" => "Mar",
			"04" => "Apr",
			"05" => "May",
			"06" => "Jun",
			"07" => "Jul",
			"08" => "Aug",
			"09" => "Sept",
			"10" => "Oct",
			"11" => "Nov",
			"12" => "Dec",
		);
		
		return $monthArray;
			
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public static function getFullMonthName($mon)
	{
		$monthArray = array(
			"01" => "January",
			"02" => "February",
			"03" => "March",
			"04" => "April",
			"05" => "May",
			"06" => "June",
			"07" => "July",
			"08" => "August",
			"09" => "September",
			"10" => "October",
			"11" => "November",
			"12" => "December",
		);
		
		return $monthArray[$mon];
			
	}	
	
	/**
	 * 
	 * Enter description here ...
	 */
	public static function getMonthAndYYYY($date)
	{
		self::getLogger(__CLASS__)->info("Date passed : " . $date);
		
		$date = str_replace("/", "-", $date, $countStr);
		
		//Since we are replacing slash with hiphen using str_replace in the beginiing
		//We can assume that date will have hiphen always
		$dateArray = explode("-", $date);
		//echo "<br>date array if hipen exists : " . var_export($dateArray);
		
		$MonYYYY = array(
		"Mon" => self::getFullMonthName($dateArray['1']),
		"YYYY" => $dateArray['0'],
		);			
		
		return $MonYYYY;		
	}

    /**
     * Checks result set
     *
     * @param $result
     * @return bool
     *
     */
    public static function validateResultSet($result)
	{
		if ($result !=null and sizeof($result)>=1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

    /**
     * Generate given list with commas
     *
     * @param $items
     * @return string
     *
     */
    public static function generateStringWithCommas($items)
	{
		$count = count($items);

		if($count === 0) {
			return '';
		} else if($count === 1) {
			return $items[0];
		} else {
			return implode(', ', array_slice($items, 0, $count));
		}		
	}	
	
	public static function getWeekDates($mm, $yy)
	{
		$log = self::getLogger(__CLASS__);
		
		$startdate=date($yy."-".$mm."-01") ;
		$current_date=date('Y-m-t');
		$ld= cal_days_in_month(CAL_GREGORIAN, $mm, $yy);
		$lastday=$yy.'-'.$mm.'-'.$ld;
		$start_date = date('Y-m-d', strtotime($startdate));
		$end_date = date('Y-m-d', strtotime($lastday));
		$end_date1 = date('Y-m-d', strtotime($lastday." + 6 days"));
		
		$log->info("###########################");
		
		$log->info("num of days : " . $ld);
		
		$log->info("start date : " . $start_date);
		
		$log->info("end date : " . $end_date);
		
		$log->info("end date1 : " . $end_date1);
		
		$log->info("###########################");
		
		$count_week=0;
		$week_array = array();
		
		for($date = $start_date; $date <= $end_date1; $date = date('Y-m-d', strtotime($date. ' + 7 days')))
		{
		    $getarray=self::calculateWeekDates($date, $start_date, $end_date, $mm, $yy);
			//echo "<br>";
			
		    if (isset($getarray))
		    {
				$week_array[]=$getarray;
			    //echo "\n";
				$count_week++;		    	
		    }
		}
		
		// its give the number of week for the given month and year
		//echo "<br>num of weeks - ".$count_week;
		//print_r($week_array);	

		// push result set to array
		$resultArray["num_of_weeks"] = $count_week;
		$resultArray["weeks_of_array"] = $week_array;
		
		return $resultArray;		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $date
	 * @param unknown_type $start_date
	 * @param unknown_type $end_date
	 */
	public static function calculateWeekDates($date, $start_date, $end_date, $mm, $yy)
	{
		$log = self::getLogger(__CLASS__);
		
		$log->info("In Calculate Week Dates ....");
		
		$log->info("date ...." . $date);
		
		$log->info("Start_date ...." . $start_date);
		
		$log->info("End_date ...." . $end_date);
		
	    $week =  date('W', strtotime($date));
	    $year =  date('Y', strtotime($date));
	    $from = date("Y-m-d", strtotime("{$year}-W{$week}+1"));
	    
	    $log->info("week ...." . $week);
		$log->info("year ...." . $year);
		$log->info("from before cond ...." . $from);
		
		$from_year = date('Y', strtotime($from));
		
		$log->info("from year...." . $from_year);
	    
	    if($from < $start_date )
	    {
	    	$from = $start_date;
	    } 
	    elseif ($from_year != $year)
	    {
	    	$from = $start_date;
	    }
	    	
	    
	    $log->info("form after condition ...." . $from);
	    
	    $fromDateArray = explode("-", $from);
	
	    $log->info("month fromdate array ...." . $fromDateArray['1']);
	    $log->info("date fromdate array ...." . $fromDateArray['2']);
	    
	    $to = date("Y-m-d", strtotime("{$year}-W{$week}-6")); 
	    
	    $log->info("to before cond ...." . $to);
	    
	    if($to > $end_date)
	    {
	    	if ($fromDateArray['1'] == '01' && $fromDateArray['2'] == '01')
	    	{
	    		if ($week > '01')
	    		{
	    			$week = '01';
	    			$next_week_start = date("Y-m-d", strtotime("{$year}-W{$week}-0"));
	    			$to = date('Y-m-d',(strtotime ( '-1 day' , strtotime ( $next_week_start))));
	    		}
	    	}
	    	else
	    	{
	    		$to = $end_date;
	    	}
	    } 
	    
	    $log->info("to after cond ...." . $to);
	
	    //echo "<br> Start Date --> ".$from." End Date --> ".$to;
	    
	    
	    $toDateArray = explode("-", $to);
	    
	    if ($fromDateArray['1'] == $mm && $toDateArray['1'] == $mm)
	    {
	    	//if ($fromDateArray['0'] == $yy && $toDateArray['0'] == $yy)
	    	//{
			    $array1 = array(
			        "wsdate" => $from,
			        "wedate" => $to,
				);
			
				return $array1;	  	    		
	    	//}
	    }
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public static function getCurrentMonthAndYearArray()
	{
		$currentDateArray =  explode("-", CommonUtil::getCurrentSqliteFormatDate());
		
	    $month_year_array = array(
	        "year" => $currentDateArray['0'],
	        "month" => $currentDateArray['1'],
		);
	
		return $month_year_array;			
	}
	
	public static function getWeekDates_1($mm, $yy)
	{
		$ld = cal_days_in_month(CAL_GREGORIAN, $mm, $yy);
		
		$start_date = date($yy."-".$mm."-01") ;
		$end_date = date($yy."-".$mm."-".$ld) ;
		
		$num_of_weeks = self::weeksInMonth($mm, $yy);
		
		echo "<br> num of weeks : " . $num_of_weeks;
		
		
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $month
	 * @param unknown_type $year
	 */
	private function weeksInMonth($month=null,$year=null)
	{
	
	    if( null==($year) ) {
	        $year =  date("Y",time());  
	    }
	
	    if(null==($month)) {
	        $month = date("m",time());
	    }
	
	    // find number of days in this month
	    $daysInMonths =  date('t',strtotime($year.'-'.$month.'-01'));
	
	    $numOfweeks = ($daysInMonths%7==0?0:1) + intval($daysInMonths/7);
	
	    $monthEndingDay= date('N',strtotime($year.'-'.$month.'-'.$daysInMonths));
	
	    $monthStartDay = date('N',strtotime($year.'-'.$month.'-01'));
	
	    if($monthEndingDay<$monthStartDay){
	
	        $numOfweeks++;
	
	    }
	
	    return $numOfweeks;
	}	
	
	public function getWeekStartEndDates($year, $week, $start=true)
	{
	    $from = date("Y-m-d", strtotime("{$year}-W{$week}-1")); //Returns the date of monday in week
	    $to = date("Y-m-d", strtotime("{$year}-W{$week}-7"));   //Returns the date of sunday in week
	 
	    if($start) {
	        return $from;
	    } else {
	        return $to;
	    }
	    //return "Week {$week} in {$year} is from {$from} to {$to}.";
	}	
		
	/**
	 * Find day of week like Monday, Tuesday etc
	 * 
	 * @param $date
	 * @return dayofWeek
	 * 
	 */
	public static function dayOfWeek($date)
	{
		return date('l', strtotime($date));
	}
	
	/**
	 * 
	 * @param $rows
	 * 
	 */
	public static function displayPageSettingColumns($rows)
	{
		for ($i = 0; $i < sizeof($rows); $i++) 
		{ 
		  //echo "<br>rows[$i] : ".$rows[$i]."<br>";
		  $cols = explode(":", $rows[$i]);
		  //echo sizeof($cols)."<br>";
		 // print_r($cols);
		 
		  echo"<label>".$cols['2']."</label><br>";
		  
		  echo"<div class='container'>";
          
		  if ($cols['3'] != 'yes')
		  {
		  	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='yes'/>";
		  }	
		  else 
		  {
		  	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='yes' checked='checked'/>";	
		  }
          echo"&nbsp;&nbsp;&nbsp;<label for='".$cols['0']."'>yes</label>&nbsp;&nbsp;&nbsp;"; 
          
          
          if ($cols['3'] != 'no')
          {
          	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='no'/>";
          }
          else
          {
          	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='no' checked='checked'/>";
          }
          echo"&nbsp;&nbsp;&nbsp;<label for='".$cols['0']."'>no</label><br>";

          echo"</div>";									  
		  
		  //echo"columnname : ".$cols['1']."<br>";
		} 
	}	
	
	/**
	 * Enter description here ...
	 * 
	 * @param $timeStr
	 */
	public static function performTimeConversation($timeStr)
	{
		$formattedTime = null;
		//echo "in ComonUtil::performTimeConversation : ".$timeStr;
		
	  	$strarray = explode(" ", $timeStr);
	  	//echo "<br>".sizeof($strarray)."<br>";
	 	//print_r($strarray);	

	 	if (strtolower($strarray[1]) == 'am')
	 	{
	 		if ($tmpArray[0] != '12')
	 		{
	 			$formattedTime = $strarray[0];
	 		}
	 		else 
	 		{
	 			$formattedTime = strval(intval($tmpArray[0])+12).":".$tmpArray[1];
	 		}	
	 	}
	 	elseif (strtolower($strarray[1]) == 'pm')
	 	{
	 		$tmpArray = explode(":", $strarray[0]);
	 		
	 		if ($tmpArray[0] != '12')
	 		{
	 			$formattedTime = strval(intval($tmpArray[0])+12).":".$tmpArray[1];	
	 		}
	 		else
	 		{
	 			$formattedTime = $strarray[0];
	 		}
	 		
	 	}
	 	
	 	return $formattedTime;
	}
	
	/**
	 * Enter description here ...
	 * 
	 * @param $timeStr
	 */
	public static function validateTaskTime($timeStrArray)
	{
		//echo "<br>in ComonUtil::validateTaskTime : Array Count : ".count($timeStrArray)."<br>";
		
		$timeFlag = true;
		
		foreach ($timeStrArray as &$timeStr) {
			
			$strArray = explode(" ", $timeStr);
			
			//print_r($strArray);
			
			if (strtolower($strArray[1]) != 'am' and strtolower($strArray[1]) != 'pm')
		 	{
		 		$timeFlag = false;
		 		break;
		 	}
		}
		
		return $timeFlag;
	}	
	
	/**
	 * Test function
	 * 
	  */
	 public static function testMe() 
	 {
		 echo "I am in testMe Func ...";
	 }
	 
	 /**
	  * 
	  * Result Set will be processed to generate 
	  * ids with commas
	  * 
	  * @param result set $result
	  */
	 public static function generateIdWithCommas($result)
	 {
        $cnt = 0;
        foreach($result as $rows => $row)
		{
			if ($cnt == 0)
			{
				$ids = $row['id'];
			}
			else
			{
				$ids = $ids . "," . $row['id'];
			}
			
			$cnt = $cnt + 1;
		} 	

		return $ids;
	 }
	 
	 public static function generateStringWithQuoteCommas($strArray)
	 {
	 	$log = self::getLogger(__CLASS__);
	 	
	 	$tmp_str_array = explode(',', $strArray);
	 	
	 	//$log->info("Array Size  ==> " . sizeof($tmp_str_array));

        for ($i = 0; $i < sizeof($tmp_str_array); $i++) 
		{
			//$log->info("i ==> " . $i);
			
			if ($i == 0)
			{
				$str = "'" . trim($str) . trim($tmp_str_array[$i]) . "','";
			}
			else 
			{
				if ($i == sizeof($tmp_str_array)-1)
				{
					$str = trim($str) . trim($tmp_str_array[$i]) . "'";
				}
				else
				{
					$str = trim($str) . trim($tmp_str_array[$i]) . "','";
				}
					
			}
			
			//$log->info("str ==> " . $str);
		} 	

		return $str;
	 }	 
	 
	 
	 public static function allRequiredEntriesExist($formInputsArray)
	 {
	 	//echo "<br> count -- > " . count($formInputsArray);
	 	$requiredEntriesExist = true;
	 	
	 	
	 	$i = 0;
        foreach($formInputsArray as $formInputs => $formInput)
		{
			//echo "<br> Entry : " . $i . " --> " . $formInputsArray[$i];
			if ($formInputsArray[$i] == '')
			{
				$requiredEntriesExist = false;
				//echo "<br>requiredEntriesExist in if : " . $requiredEntriesExist;
				return $requiredEntriesExist;
				break;
			}
			
			$i = $i + 1;
		}
		
		//echo "<br>requiredEntriesExist at the end : " . $requiredEntriesExist;
		
		return $requiredEntriesExist;
	 }
	 
	 /**
	  * 
	  * Enter description here ...
	  */
	 public static function getLogger($classname)
	 {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		//print_r(Logger::getLogger($classname));  	
			
		return Logger::getLogger($classname);  	 	
	 }
	 
	 public static function getConfigValue($key)
	 {
	 	$config = new AppConfig();
	 	
	 	//self::getLogger(__CLASS__)->info("Key == ".$key);
	 	//self::getLogger(__CLASS__)->info("Value == ".$config->$key);
	 	
	 	return $config->$key;
	 }
	 
 

	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $str
	  * @param unknown_type $word
	  */
	public static function  contains($str, $word)
	{
		$log = self::getLogger(__CLASS__);
		
		//$log->info("inside contains");
		
		//$log->info("Word :: " . $word . " String to search :: " . $str);
		
	    $found = false;
	
		if (strlen(strstr($word,$str))>0) 
		{
			$found = true;
		}		    
	    
	    //$log->info("Result :: " . $found);
	    
	    return $found;		
	}	 
}