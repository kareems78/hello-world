<?php

 /**
  *
  *
  */
class DatabaseException extends Exception
{
    /**
     * Constructor to generate exception message with code
     *
     * @param string $message
     * @param int $code
     *
     */
    public function __construct($message, $code)
	{
		//die("Exception occurred : ".$message." with code : ".$code);
		die();
	}	
	
	/**
	 * 
	 * Returns error message as per code.
	 * @param $code - error code
	 * @return error message
	 */
	public static function getErrorMsg($code)
	{
		$message = "";
		
		if ($code == 23000)
		{
			//echo "Error : Please enter unique value";
			$message = "Please enter unique value";
		}
		else 
		{
			$message = "Error occurred : Please check your inputs";
		}
		
		return $message;
	}
}