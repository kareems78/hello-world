<?php
class session{
    
    public static function init(){
        @session_start();
    }
    public static function set($key,$value){
        $_SESSION[$key] = $value;
		return true;
    }
    
    public static function get($key){
        if(isset($_SESSION[$key]))
        return  $_SESSION[$key];
    }
    
    public static function destroy($key){
        unset($_SESSION[$key]);
        //session_destroy();
    }

    function  redirect($url){
            if (!headers_sent()){    
                header('Location: '.$url);
                exit;
            }else{  
                print '<script type="text/javascript">';
                print 'window.location.href="'.$url.'";';
                print '</script>';
                print '<noscript>';
                print '<meta http-equiv="refresh" content="0;url='.$url.'" />';
                print '</noscript>'; 
                exit(1);
            }
        }

    
}
?>
