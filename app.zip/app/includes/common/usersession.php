<?php
// Inialize session
session_start();

$log = CommonUtil::getLogger("USERSESSION");
$indexUrl = HTTP_PATH . CommonUtil::getConfigValue('index');


//$log->info("Get username from session ==> " . $_SESSION['username']);

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['username'])) 
{
	$_SESSION['errorMsg'] = 'Your session might have been invalid. Please login ...';
	$log->info("Invalid Session :: Redirecting to  " .  $indexUrl);
	header("Location: $indexUrl");
}

if (isset($_SESSION['userdetails']))
{
	$userDetails = $_SESSION['userdetails'];
} 

if (isset($_SESSION['userrole']))
{
	$userRole = $_SESSION['userrole'];
} 