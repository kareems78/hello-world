<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class submodulesearchstr
{
	public $_id = null;
	
	public $_user = null;
	
	public $_searchstr = null;
	
	public $_submodule = null;
	
	public $_lastmodifieddate = null;

    function __construct($id, $user, $submodule)
    {
    	$this->_id = $id;
		$this->_user = $user;
		$this->_submodule = $submodule;
		$this->_searchstr = "";
		$this->_lastmodifieddate = CommonUtil::getCurrentSqliteFormatDate();;
    }	

}