<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class stracker
{
	public $_id = null;
	
	public $_sdate = null;
	
	public $_createddate = null;
	
	public $_updateddate = null;
	
	public $_user = null;
	
	public $_fazr = null;
	
	public $_dhuhr = null;
	
	public $_asr = null;
	
	public $_maghrib = null;
	
	public $_isha = null;
	
	public $_notes = null;
	
	protected $_log = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $salahDate
	 * @param unknown_type $user
	 * @param unknown_type $fazr
	 * @param unknown_type $dhuhr
	 * @param unknown_type $asr
	 * @param unknown_type $maghrib
	 * @param unknown_type $isha
	 * @param unknown_type $notes
	 */
    function __construct($salahDate, $user, $fazr, $dhuhr, $asr, $maghrib, $isha, $notes)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
		
		$this->_sdate = CommonUtil::convertToSQLiteDateFormat($salahDate);
		
		$this->_createddate = CommonUtil::getCurrentSqliteFormatDate();
		
		$this->_updateddate = CommonUtil::getCurrentSqliteFormatDate();
		
		$this->_user = $user;
		
		$this->_fazr = $fazr;
		
		$this->_dhuhr = $dhuhr;
		
		$this->_asr = $asr;
		
		$this->_maghrib = $maghrib;
		
		$this->_isha = $isha;
		
		$this->_notes = $notes;

    }	
}