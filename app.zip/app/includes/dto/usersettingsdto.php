<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class usersettings
{
	public $_user = null;
	
	public $_identifier = null;
	
	public $_value = null;
	
	public $_visible = null;
	
	public $_description = null;

    function __construct($user, $identifier, $value, $visible, $description)
    {
		$this->_user = $user;
		$this->_identifier = $identifier;
		$this->_value = $value;
		$this->_visible = $visible;
		$this->_description = $description;
    }	

}