<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class expense
{
	public $_id = null;
	
	public $_date = null;
	
	public $_taxPercentId = null;
	
	public $_taxPercentName = null;
	
	public $_amount = null;
	
	public $_category = null;
	
	public $_user = null;
	
	public $_notes = null;
	
	public $_currentMonth = null;
	
	public $_currentYear = null;
	
	public $_actualDate = null;
	
	protected $_log = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $expenseDate
	 * @param unknown_type $taxPercentId
	 * @param unknown_type $taxPercentName
	 * @param unknown_type $amount
	 * @param unknown_type $category
	 * @param unknown_type $user
	 * @param unknown_type $notes
	 */
    function __construct($expenseDate, $taxPercentId, $taxPercentName, $amount, $category, $user, $notes)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
    	
		$this->setValues($expenseDate, $taxPercentId, $taxPercentName, $amount, $category, $user, $notes);
    }	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $expenseDate
	 * @param unknown_type $taxPercentId
	 * @param unknown_type $taxPercentName
	 * @param unknown_type $amount
	 * @param unknown_type $category
	 * @param unknown_type $user
	 * @param unknown_type $notes
	 */
    private function setValues($expenseDate, $taxPercentId, $taxPercentName, $amount, $category, $user, $notes)
    {
    	$this->_date = CommonUtil::convertToSQLiteDateFormat($expenseDate);
    	
		$MonYYYY = CommonUtil::getMonthAndYYYY($this->_date);
		
		$this->_currentMonth = $MonYYYY['Mon'];
		$this->_currentYear = $MonYYYY['YYYY'];
		
		$this->_taxPercentId = $taxPercentId;
		
		$this->_taxPercentName = (int)$taxPercentName;
		
    	if ($this->_taxPercentName != 0)
		{
			$this->_amount = $amount + ($amount * $this->_taxPercentName)/100;
		}
		else
		{
			$this->_amount = $amount;
		}	

		$this->_user = $user;
		
		$this->_notes = $notes;
		
		$this->_category = $category;
		
		$this->_actualDate = $expenseDate;
		
    }
}