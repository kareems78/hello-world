<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class task
{
	public $_user = null;
	
	public $_name = null;
	
	public $_priority = null;
	
	public $_type = null;
	
	public $_notes = null;
	
	public $_duedate = null;
	
	public $_status = null;
	
	protected $_log = null;

    function __construct($name, $priority, $type, $duedate, $user, $notes)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);     	
    	
		$this->_user = $user;
		$this->_name = $name;
		$this->_priority = $priority;
		$this->_type = $type;
		$this->_notes = $notes;
		$this->_status = 1;
		
		$this->_duedate = CommonUtil::convertToSQLiteDateFormat($duedate);
    }	

}