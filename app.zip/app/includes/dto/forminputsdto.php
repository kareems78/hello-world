<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class forminputs
{
	public $_id = null;
	
	public $_userid = null;
	
	public $_oper = null;
	
	public $_smod = null;
	
	public $_getparamvalue = null;
	
	public $_page = null;

    function __construct($id, $userid, $oper, $smod, $page, $getparamvalue)
    {
		$this->_id = isset($id) ? $id : null;
		$this->_userid = isset($userid) ? $userid : null;
		$this->_oper = isset($oper) ? $oper : null;
		$this->_smod = isset($smod) ? $smod : null;
		$this->_page = isset($page) ? $page : null;
		$this->_getparamvalue = isset($getparamvalue) ? $getparamvalue : null;
    }	
}