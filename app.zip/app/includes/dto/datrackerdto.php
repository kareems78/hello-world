<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class datracker
{
	public $_id = null;
	
	public $_datdate = null;
	
	public $_createddate = null;
	
	public $_updateddate = null;
	
	public $_user = null;
	
	public $_moningdhikr = null;
	
	public $_ishraq = null;
	
	public $_eveningdhikr = null;
	
	public $_taleem = null;
	
	public $_muzakira = null;
	
	public $_recitequran = null;
	
	public $_notes = null;
	
	protected $_log = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $datDate
	 * @param unknown_type $user
	 * @param unknown_type $morningdhikr
	 * @param unknown_type $ishraq
	 * @param unknown_type $eveningdhikr
	 * @param unknown_type $taleem
	 * @param unknown_type $muzakira
	 * @param unknown_type $recitequran
	 * @param unknown_type $notes
	 */
    function __construct($datDate, $user, $morningdhikr, $ishraq, $eveningdhikr, $taleem, $muzakira, $recitequran, $notes)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
		
		$this->_datdate = CommonUtil::convertToSQLiteDateFormat($datDate);
		
		$this->_createddate = CommonUtil::getCurrentSqliteFormatDate();
		
		$this->_updateddate = CommonUtil::getCurrentSqliteFormatDate();
		
		$this->_user = $user;
		
		$this->_moningdhikr = $morningdhikr;
		
		$this->_ishraq = $ishraq;
		
		$this->_eveningdhikr = $eveningdhikr;
		
		$this->_taleem = $taleem;
		
		$this->_muzakira = $muzakira;
		
		$this->_recitequran = $recitequran;
		
		$this->_notes = $notes;

    }	
}