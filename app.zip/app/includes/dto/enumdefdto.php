<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class enumerationdef
{
	public $_id = null;
	
	public $_name = null;
	
	public $_table = null;
	
	public $_field = null;
	
	public $_user = null;
	
	public $_createddate = null;
	
	protected $_log = null;
	

    function __construct($id, $name, $table, $field, $user)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
		
		$this->_id = $id;
		
		$this->_name = $name;
		
		$this->_table = $table;
		
		$this->_field = $field;
		
		$this->_user = $user;
		
		$this->_createddate = CommonUtil::getCurrentSqliteFormatDate();
    }	
}