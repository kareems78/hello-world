<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class mvrefresh
{
	public $_id = null;
	
	public $_refreshmodule = null;
	
	public $_dbconndetailsid = null;
	
	public $_createddate = null;
	
	public $_noofrows = null;
	
	public $_logid = null;
	
	public $_user = null;
	
	protected $_log = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $refreshmodule
	 * @param unknown_type $dbconndetailsid
	 * @param unknown_type $noofrows
	 * @param unknown_type $logid
	 * @param unknown_type $user
	 */
    function __construct($refreshmodule, $dbconndetailsid, $noofrows, $logid, $user)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
		
		$this->_refreshmodule = $refreshmodule;
		
		$this->_dbconndetailsid = $dbconndetailsid;
		
		$this->_noofrows = $noofrows;
		
		$this->_logid  = $logid;
		
		$this->_user = $user;
		
		$this->_createddate = CommonUtil::getCurrentSqliteFormatDate();

    }	
}