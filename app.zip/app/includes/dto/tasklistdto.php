<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class tasklist
{
	public $_user = null;
	
	public $_task = null;
	
	public $_taskdate = null;
	
	public $_status = null;
	
	protected $_log = null;

    function __construct($task, $taskdate, $user, $status)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);     	
    	
		$this->_user = $user;
		$this->_task = $task;
		$this->_status = $status;
		
		$this->_taskdate = CommonUtil::convertToSQLiteDateFormat($taskdate);
    }	

}