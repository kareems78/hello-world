<?php
/**
 * 
 * Class to hold data objects
 * @author KAREEMS
 *
 */
class environment
{
	public $_id = null;
	
	public $_envname = null;
	
	public $_username = null;
	
	public $_password = null;
	
	public $_user = null;
	
	public $_dbhost = null;
	
	public $_dbport = null;
	
	public $_sid = null;
	
	protected $_log = null;
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $envname
	 * @param unknown_type $user
	 * @param unknown_type $username
	 * @param unknown_type $password
	 * @param unknown_type $dbhost
	 * @param unknown_type $dbport
	 * @param unknown_type $sid
	 */
    function __construct($envname, $user, $username, $password, $dbhost, $dbport, $sid)
    {
		Logger::configure(APP_LOGGER . 'config.xml');
		
		$this->_log = Logger::getLogger(__CLASS__);      	
		
		$this->_envname = $envname;
		
		$this->_user = $user;
		
		$this->_username = $username;
		
		$this->_password = $password;
		
		$this->_dbhost = $dbhost;
		
		$this->_dbport = $dbport;
		
		$this->_sid = $sid;

    }	
}