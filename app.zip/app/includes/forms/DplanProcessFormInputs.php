<?php

/**
 *	Processes the dplan form inputs
 *
 */ 
 class DplanProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, DPLAN_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
