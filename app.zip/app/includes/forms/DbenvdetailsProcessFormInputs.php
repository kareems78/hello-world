<?php

/**
 *	Processes the dbenvdetails form inputs
 *
 */ 
 class DbenvdetailsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, DBENVDETAILS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
