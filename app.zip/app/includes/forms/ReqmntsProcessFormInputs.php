<?php

/**
 *	Processes the reqmnts form inputs
 *
 */ 
 class ReqmntsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, REQMNTS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}		 
 }
