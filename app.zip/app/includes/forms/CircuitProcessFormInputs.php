<?php

/**
 *	Processes the circuit form inputs
 *
 */ 
 class CircuitProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, CIRCUIT_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}	
 }
