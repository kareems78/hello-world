<?php

/**
 *	Processes the provision status form inputs
 *
 */ 
 class ProvisionstatusProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, PS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}	
 }
