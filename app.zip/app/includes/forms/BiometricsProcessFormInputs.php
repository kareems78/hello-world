<?php

/**
 *	Processes the biometrics form inputs
 *
 */ 
 class BiometricsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, BIOMETRICS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);					
		$this->processForm();
	}		 
 }
