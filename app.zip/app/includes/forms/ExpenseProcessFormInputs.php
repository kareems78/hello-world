<?php

/**
 *	Processes the expense form inputs
 *
 */ 
 class ExpenseProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, EXPENSE_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
