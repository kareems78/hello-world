<?php

/**
 *	Processes the Objectsbytype form inputs 
 *
 */ 
 class ObjectsbytypeProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, OBJECTSBYTYPE_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);	
		$this->processForm();
	}		 
 }
