<?php

/**
 *	Processes the dbconndetails form inputs
 *
 */ 
 class DbconndetailsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, DBCONNDETAILS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
