<?php

/**
 *	Processes the plotdetails form inputs
 *
 */ 
 class PlotdetailsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, PDETAILS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
