<?php

/**
 *	Processes the dbopers form inputs
 *
 */ 
 class DbopersProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, UPDATEIDS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
	
	protected function processForm()
	{
		//Retrieve dbopers home from config file
		$updateIdsUrl = UPDATEIDS_HOME . $this->getRedirectFileName('updateIds_' . $this->_forminputs->_smod);
		
		if(isset($_POST['submitted']))
		{
			/*echo '<pre>';
			var_export($_POST);
			echo '</pre>';*/	

			$result = Controller::processForm($_POST);
			
			if ($_POST['oper'] == 'generatecsv')
			{
				$_SESSION['MESSAGE'] = 'Successfully generated csv file.';
			}
			elseif ($_POST['oper'] == 'updateids')
			{
				if ($result != 1)
				{
					$_SESSION['MESSAGE'] = 'Error occurred while updating ids.';
				}
				else 
				{
					$_SESSION['MESSAGE'] = 'Successfully updated ids for selected data table.';
				}			

				header("Location: $updateIdsUrl");
			}
				
		}	
		
	}
	
 	
 }
