<?php

/**
 *	Processes the module form inputs
 *
 */ 
 class ModuleProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, MODULES_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
