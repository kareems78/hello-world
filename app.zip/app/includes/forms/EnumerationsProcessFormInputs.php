<?php

/**
 *	Processes the enumeration form inputs
 *
 */ 
 class EnumerationsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, ENUM_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}	
 }
