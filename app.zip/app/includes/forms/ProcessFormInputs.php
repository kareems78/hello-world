<?php

require_once APP_ROOT . '\config.php';
require_once APP_CONTROLLER . 'controller.php';

/**
 *	Processes the form inputs
 *
 */ 
 class ProcessFormInputs
 {
	 
	public static $_oper = null;
	
	public static $_smod = null;

	public static $_id = null;	 
	
	public static $_page = null;
	
	public static $_getparamvalue = null;
	
	public static $_userid = null;
	
	protected $_SUB_MODULE_PATH = null;
	
	protected $_log = null;
	
	protected $_addfile = null;
	
	protected $_viewfile = null;
	
	protected $_editfile = null;
	
	protected $_searchfile = null;
	
	protected $_forminputs = null;
	
 	
	/**
	 * Contructor for ProcessFormInputs
	 * 
	 */	
 	public function __construct($forminputsdto, $path)
	{
		$this->_log = CommonUtil::getLogger(__CLASS__);
		
		$this->_SUB_MODULE_PATH = $path;
		
		$this->_forminputs = $forminputsdto;

		$this->setFilenames($this->_forminputs->_smod);
		
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $smod
	 */
	private function setFilenames($smod)
	{
		$this->_addfile = 'add' . $smod;
		$this->_editfile = 'edit' . $smod;
		$this->_viewfile = 'view' . $smod;
		$this->_searchfile = 'search' . $smod;	

		$this->_log->info("add file set ==> " . $this->_addfile);
		$this->_log->info("edit file set ==> " . $this->_editfile);
		$this->_log->info("view file set ==> " . $this->_viewfile);
		$this->_log->info("search file set ==> " . $this->_searchfile);
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
 	protected function processForm()
	{
		$this->_log->info("processForm() - Start");
		
		//echo '<pre>';

		//var_export($_POST);

		//echo '</pre>';
		
		//If page is redirected from search then set view file to search view - so that after the processing
		//page will be forwarded to search results page instead of view page
		$this->setRedirectToPageOriginator();
		
		$this->_log->info("view file in processForm ==> " . $this->_viewfile);
		
		if(isset($_POST['submitted']))
		{
			if ($_POST['mainmodule'] == 'drapps')
			{
				$this->processDrAppsFormSubmission();
			}
			else
			{
				$this->processFormSubmission();
			}
		}
		elseif ($this->_forminputs->_oper == 'edit')
		{
			$this->processEditOperation();
		}	
		elseif ($this->_forminputs->_oper == 'add')
		{
			$this->processAddOperation();
		}	

		$this->_log->info("processForm() - End");
	}	
	
	public function setRedirectToPageOriginator()
	{
		$this->_log->info("setRedirectToPageOriginator() - Start");
		
		if (isset($_GET['pagename']) or isset($_POST['pagename']))
		{
			$file = isset($_GET['pagename']) ? explode(".", $_GET['pagename']) : explode(".", $_POST['pagename']); 
			
			$this->_viewfile = $file[0];
	
			$this->_log->info("Setting view file is set to ==> " . $this->_viewfile);			
		}	

		$this->_log->info("setRedirectToPageOriginator() - End");
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $file
	 */
	public function getRedirectFileName($file)
	{
		return CommonUtil::getConfigValue($file);
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	private function processDrAppsFormSubmission()
	{
		$this->_log->info("processDrAppsFormSubmission() - Start");
		
		//echo '<pre>';

		//var_export($_POST);

		//echo '</pre>';	

		//$this->_log->info("page name inside processDrAppsFormSubmission ==> " . $_POST['pagename']);
		
		$file = explode(".", $_POST['pagename']);
		
		$pageurl = $this->_SUB_MODULE_PATH . $_POST['pagename'];
		
		//$this->_log->info("page url ==> " . $pageurl);
		
		$result = Controller::processForm($_POST);
		
		$_SESSION['pagename'] = $_POST['pagename'];
		
		if (isset($result['ORA_ERROR']))
		{
			$_SESSION['errorMsg'] = $result['ORA_ERROR'];
		}
		else
		{
			$_SESSION['output_array'] = $result;
		}
		
		
		//header("Location: $pageurl");
		$this->redirectToPage('view'.$file[0]);		
		
		$this->_log->info("processDrAppsFormSubmission() - End");
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	private function processFormSubmission()
	{
		$this->_log->info("processFormSubmission() - Start");
		
		$oper = $this->_forminputs->_oper;
		$page = $this->_forminputs->_page;
		
		//$this->_log->info(var_export($_POST));
		
		if ($oper == 'delete')
		{
			//echo '<pre>';

			//$this->_log->info(var_export($_POST));
			
			if (array_key_exists('Save' , $_POST))
			{
				//echo "process form input -- Save block";
				$oper = 'save';
			}			

			//echo '</pre>';	
			if (isset($_POST['deleteObject']))
			{
				$result = Controller::processForm($_POST);
			}
			elseif ($oper == 'delete')
			{
				$_SESSION['errorMsg'] = 'Please select row to delete';	
			}
			elseif ($oper == 'save') 
			{
				//Forcing the oper to save, so that data is saved into db
				$_POST['oper'] = 'save';
				$result = Controller::processForm($_POST);
			}			
			else
			{
				$_SESSION['errorMsg'] = 'Please select row/s to delete';
			}
			
			if ($page == 'ctasks')
			{
				$this->redirectToPage($compfile);
			}
			elseif ($page == 'srch')
			{
				$this->redirectToPage($this->_searchfile);
			}
			else
			{
				$this->redirectToPage($this->_viewfile);
			}	
			
		}
		else
		{
			
			$result = Controller::processForm($_POST);

			if ($oper == 'searchstr' || $oper == 'searchstrbymonth')
			{
				$this->redirectToPage($this->_searchfile);
			}
			else
			{
				if ($result != 1)
				{
					//echo "inputs are not correct. please check.";
					
					 $_SESSION['errorMsg'] = "Error Occurred : ".DatabaseException::getErrorMsg($result);
					
					if ($oper == 'add')
					{
						$this->redirectToPage($this->_addfile);
					}
					else
					{
						$this->redirectToPage($this->_editfile);
					}
				}
				else
				{
					if (isset($page) and $page == 'srch')
					{
						$this->redirectToPage($this->_searchfile);
					}	
					elseif (isset($page) and $page == 'ctasks')
					{
						$this->redirectToPage($compfile);
					}
					else
					{
						//$this->_log->info("view file sent ==> " . $this->_viewfile);
						$this->redirectToPage($this->_viewfile);		
					}
				}
			}
		}	

		$this->_log->info("processFormSubmission() - End");
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	protected function processEditOperation()
	{
		$this->_log->info("processEditOperation() - Start");
		
		$this->_log->info("Redirected from View ==> " . $this->_viewfile);
		
		Controller::$_id = $this->_forminputs->_id;
		
		if (isset($this->_forminputs->_getparamvalue))
		{
			Controller::$_strVar = $this->_forminputs->_getparamvalue;
			$_SESSION['ALL_CAT_SUB_MOD_NAME'] = $this->_forminputs->_getparamvalue;
		}
		
		$result = Controller::findAndProcess($this->_forminputs->_smod, $this->_forminputs->_oper);

		$row = $result[0];
		$_SESSION[$this->_forminputs->_smod] = $row;
		
		$_SESSION["SEARCH_REDIRECTED_FROM"] = $this->_viewfile;
	
		$this->redirectToPage($this->_editfile);	

		$this->_log->info("processEditOperation() - End");
	}
	
 	/**
	 * 
	 * Enter description here ...
	 */
	protected function processAddOperation()
	{
		$this->_log->info("processAddOperation() - Start");
		
		if (isset($this->_forminputs->_userid))
		{
			//$this->_log->info("in if - userid : " . $this->_forminputs->_userid." sub module : ". $this->_forminputs->_smod . " oper : " . $this->_forminputs->_oper);
			$result = Controller::findAndProcessWithUserID($this->_forminputs->_smod, $this->_forminputs->_oper, $this->_forminputs->_userid);
		}
		else
		{
			$result = Controller::findAndProcess($this->_forminputs->_smod, $this->_forminputs->_oper);
		}
		
		$this->redirectToPage($this->_viewfile);	

		$this->_log->info("processAddOperation() - End");
	}	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $file
	 */
	public function redirectToPage($file)
	{
		$pagename = CommonUtil::getConfigValue($file);
		
		/*if (CommonUtil::contains('search', strtolower($file)))
		{
			$pageurl = $this->_SUB_MODULE_PATH . $pagename.'?pagename='.$pagename;
		}
		else
		{
			$pageurl = $this->_SUB_MODULE_PATH . $pagename;	
		}*/
		
		
		$pageurl = $this->_SUB_MODULE_PATH . $pagename.'?pagename='.$pagename;
		
		$this->_log->info("pagename sent ==> " . $pagename);
		
		if (isset($pagename))
		{
			$_SESSION['pagename'] = $pagename;
		}
		
		$this->_log->info("Redirecting to ==> " . $pageurl);
		header("Location: $pageurl");
	}
	
 	
 }
