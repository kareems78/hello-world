<?php

/**
 *	Processes the daily aamal tracker form inputs
 *
 */ 
 class DatrackerProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, DATRACKER_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
