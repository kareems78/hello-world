<?php

/**
 *	Processes the gcpmv form inputs
 *
 */ 
 class GcpmvProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, GCPMV_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}	
 }
