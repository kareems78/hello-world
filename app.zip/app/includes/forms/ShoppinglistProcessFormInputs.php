<?php

/**
 *	Processes the shoppinglist form inputs
 *
 */ 
 class ShoppinglistProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, SHOPPINGLIST_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}	
 	
 }
