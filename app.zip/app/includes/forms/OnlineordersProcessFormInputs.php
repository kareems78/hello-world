<?php

/**
 *	Processes the onlineorders form inputs
 *
 */ 
 class OnlineordersProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, ONLINEORDERS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
