<?php

/**
 *	Processes the zakat calculator form inputs
 *
 */ 
 class ZcalcProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, ZCALC_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}		 
 }
