<?php

/**
 *	Processes the task form inputs
 *
 */ 
 class TaskProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, TASK_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}		 
 }
