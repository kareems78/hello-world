<?php

/**
 *	Processes the fundstransfer form inputs
 *
 */ 
 class FundstransferProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, FUNDSTRANSFER_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
 }
