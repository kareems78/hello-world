<?php

/**
 *	Processes the allcategories form inputs
 *
 */ 
 class AllcategoriesProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, ALLCATEGORIES_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();		
	}		 
	
	protected function processForm()
	{
		if(isset($_POST['submitted']))
		{
			if ($_POST['oper'] == 'delete')
			{
				//echo "process form input -- delete block";
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';	
				
				if (trim($_POST['viewcat']) == 'Go')
				{
					if ($_POST['submodule'] != '')
					{
						Controller::$_formValues = $_POST;
						$result = Controller::findAndProcess('allcategories', 'viewCategories');
					}
					else
					{
						//echo "in here";
						$_SESSION['catErrorMsg'] = 'Please select category.';
					}
					
					$this->redirectToPage($this->_viewfile);
					//header("Location: $viewUrl");
				}
				else
				{
					if (isset($_POST['deleteObject']))
					{
						$result = Controller::processForm($_POST);
					}
					else
					{
						$_SESSION['delErrorMsg'] = 'Please select row to delete';
					}	
					$this->redirectToPage($this->_viewfile);
					//header("Location: $viewUrl");
				}
				
				//header("Location: $viewUrl");
				
			}
			elseif ($_POST['oper'] == 'update' or $_POST['oper'] == 'viewCategories')
			{
				$result = Controller::processForm($_POST);
				
				if ($result != 1 and $_POST['oper'] != 'viewCategories')
				{
					$this->redirectToPage($this->_editfile);
					//header("Location: $editUrl");		
				}
				else
				{
					$this->redirectToPage($this->_viewfile);
					//header("Location: $viewUrl");		
				}	
			}
			else
			{
				$oper = $_POST['oper'] ;
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';
				Controller::$_formValues = $_POST;
				
				$rowCount = Controller::findAndProcess('allcategories', 'insertAfterValidation');
				
				if ($rowCount == 1)
				{
					$_SESSION['errorMsg'] = 'Category/Type already exists. Please input unique value';
					
					$this->redirectToPage($this->_addfile);
					//header("Location: $addUrl");		
				}
				else
				{
					$this->redirectToPage($this->_viewfile);
					//header("Location: $viewUrl");		
				}
			}

		}
		elseif ($this->_forminputs->_oper == 'edit')
		{
			$this->processEditOperation();
		}		
		
	}
	
 	
 }
