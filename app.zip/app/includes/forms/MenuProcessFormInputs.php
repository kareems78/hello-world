<?php

/**
 *	Processes the menu form inputs
 *
 */ 
 class MenuProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, MENU_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
	
	protected function processForm()
	{
		//Retrieve menu home from config file
		$viewUrl = MENU_HOME . $this->getRedirectFileName('view' . parent::$_smod);
		
		if(isset($_POST['submitted']))
		{
			if ($_POST['oper'] == 'delete')
			{
				if (array_key_exists('Save' , $_POST))
				{
					//echo "process form input -- Save block";
					$_POST['oper'] = 'save';
				}
				
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';	
				
				if (isset($_POST['deleteObject']))
				{
					$result = Controller::processForm($_POST);
				}
				elseif ($_POST['oper'] == 'delete')
				{
					$_SESSION['errorMsg'] = 'Please select row to delete';	
				}
				elseif ($_POST['oper'] == 'save') 
				{
					$result = Controller::processForm($_POST);
				}
				
				header("Location: $viewUrl");
				
			}
			else
			{
				$oper = $_POST['oper'] ;
				
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';			
				
				$result = Controller::processForm($_POST);
				

				if ($oper == 'searchstr')
				{
					//echo "s q - >".$result;
					$_SESSION['sq'] = $result;
					
					header("Location: $searchUrl");		
				}
				else
				{
					header("Location: $viewUrl");
				}
			}

		}
		elseif ($_GET['oper'] == 'add')
		{
			$result = Controller::findAndProcess('menu', parent::$_oper);
			
			header("Location: $viewUrl");
		}	
		
	}
	
 	
 }
