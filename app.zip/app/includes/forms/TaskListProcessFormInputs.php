<?php

/**
 *	Processes the task list form inputs
 *
 */ 
 class TaskListProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, TASKLIST_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}		 
 }
