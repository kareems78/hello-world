<?php

/**
 *	Processes the otwhours form inputs
 *
 */ 
 class OtwhoursProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, OTWHOURS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);
		$this->processForm();
	}		 
 }
