<?php

/**
 *	Processes the expense form inputs
 *
 */ 
 class ExpensereportsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, EXPENSE_REPORTS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
	
	protected function processForm()
	{
		//Retrieve expense home from config file
		$monthlyExpensesUrl = EXPENSE_REPORTS_HOME . $this->getRedirectFileName('monthly' . $this->_forminputs->_smod);
		$weeklyExpensesUrl = EXPENSE_REPORTS_HOME . $this->getRedirectFileName('weekly' . $this->_forminputs->_smod);
		$categorizedExpensesUrl = EXPENSE_REPORTS_HOME . $this->getRedirectFileName('categorized' . $this->_forminputs->_smod);
		
		if(isset($_POST['submitted']))
		{
			
			//echo '<pre>';

			//var_export($_POST);

			//echo '</pre>';	

			//$this->_log->info("page name ==> " . $_POST['pagename']);
			
			$pageurl = EXPENSE_REPORTS_HOME . $_POST['pagename'];
			
			//$this->_log->info("page url ==> " . $pageurl);
			
			$result = Controller::processForm($_POST);
			
			$_SESSION['pagename'] = $_POST['pagename'];
			
			header("Location: $pageurl");
		}
	}
	
 	
 }
