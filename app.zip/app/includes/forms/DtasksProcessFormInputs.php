<?php

/**
 *	Processes the dtasks form inputs
 *
 */ 
 class DtasksProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, DTASKS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
	
	protected function processForm()
	{
		if(isset($_POST['submitted']))
		{
			if ($_POST['oper'] == 'delete')
			{
				if (array_key_exists('Save' , $_POST))
				{
					//echo "process form input -- Save block";
					$_POST['oper'] = 'save';
				}
				
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';	
				
				if (isset($_POST['deleteObject']))
				{
					$result = Controller::processForm($_POST);
				}
				elseif ($_POST['oper'] == 'delete')
				{
					$_SESSION['errorMsg'] = 'Please select row to delete';	
				}
				elseif ($_POST['oper'] == 'save') 
				{
					$validTime = CommonUtil::validateTaskTime($_POST['tasktimetext']);
					
					if ($validTime)
					{
						$result = Controller::processForm($_POST);
					}
					else
					{
						$_SESSION['errorMsg'] = 'Please input time in proper format like 5:30 AM or 5:30 PM';
					}
				}
				
				$this->redirectToPage($this->_viewfile);
			}
			else
			{
				$oper = $_POST['oper'] ;
				
				$result = Controller::processForm($_POST);

				if ($oper == 'searchstr')
				{
					//echo "s q - >".$result;
					$_SESSION['sq'] = $result;
					
					$this->redirectToPage($this->_searchfile);	
				}
				else
				{
					//$oper = $_POST['oper'] ;
				
					//echo '<pre>';
			
					//var_export($_POST);
			
					//echo '</pre>';			
					
					$result = Controller::processForm($_POST);
					
			
					if ($oper == 'searchstr')
					{
						//echo "s q - >".$result;
						$_SESSION['sq'] = $result;
						
						$this->redirectToPage($this->_searchfile);							
					}
					else
					{
						$this->redirectToPage($this->_viewfile);
					}		
				}
			}

		}
		elseif ($_GET['oper'] == 'add')
		{
			$result = Controller::findAndProcessWithUserID($this->_forminputs->_smod, $this->_forminputs->_oper, $this->_forminputs->_userid);
			
			$this->redirectToPage($this->_viewfile);
		}	
		
	}
	
 	
 }
