<?php

/**
 *	Processes the network form inputs
 *
 */ 
 class NetworkProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, NETWORK_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}	
 	
 }
