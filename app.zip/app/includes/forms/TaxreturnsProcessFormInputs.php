<?php

/**
 *	Processes the taxreturns form inputs
 *
 */ 
 class TaxreturnsProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, TAXRETURNS_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);					
		$this->processForm();
	}		 
 }
