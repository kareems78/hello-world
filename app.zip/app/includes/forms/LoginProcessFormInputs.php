<?php

/**
 *	Processes the login form inputs
 *
 */ 
 class LoginProcessFormInputs extends ProcessFormInputs
 {
	 
	/**
	 * Contructor for ProcessFormInputs
	 * 
	 */	
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, HTTP_PATH);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}	
	
	protected function processForm()
	{
		$homeUrl = APP_HOME . $this->getRedirectFileName('homepage');
		$indexUrl = HTTP_PATH . $this->getRedirectFileName('index');		
		
		if(isset($_POST['submitted']))
		{
			$result = Controller::processForm($_POST);

			if (sizeof($result) != 0)
			{
				//$this->_log->info("result size ... ".sizeof($result));
				$_SESSION['username'] = $_POST['username'];

				$_SESSION['userdetails'] = $result['user_details'];
				$_SESSION['userrole'] = $result['user_role'];

				header("Location: $homeUrl");
				exit;
				
			}
			else
			{
				//$this->_log->info("in else if result size is zero ...");
				$_SESSION['errorMsg'] = 'Username and Password enetered is not correct. Please check.';
				
				header("Location: $indexUrl");
				exit;
			}		
		
		}	
		
	}
 	
 }
