<?php

/**
 *	Processes the salah tracker form inputs
 *
 */ 
 class StrackerProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, STRACKER_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}		 
	
	protected function processForm()
	{
		
		//If page is redirected from search then set view file to search view - so that after the processing
		//page will be forwarded to search results page instead of view page
		$this->setRedirectToPageOriginator();
		
		$this->_log->info("view file in processForm ==> " . $this->_viewfile);		
		
		if(isset($_POST['submitted']))
		{
			if ($_POST['oper'] == 'delete')
			{
				//echo "process form input -- delete block";
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';	
				if (isset($_POST['deleteObject']))
				{
					$result = Controller::processForm($_POST);
				}
				else
				{
					$_SESSION['errorMsg'] = 'Please select row to delete';
				}
				
				if (isset($_POST['page']) and $_POST['page'] == 'srch')
				{
					$this->redirectToPage($this->_searchfile);
				}	
				else
				{
					$this->redirectToPage($this->_viewfile);		
				}
				
			}
			else
			{
				$oper = $_POST['oper'] ;
				
				//echo '<pre>';

				//var_export($_POST);

				//echo '</pre>';

				if (!isset($_POST['fazr']))
				{
					$_POST['fazr'] = '';
				}
				
				if (!isset($_POST['dhuhr']))
				{
					$_POST['dhuhr'] = '';
				}
				
				if (!isset($_POST['asr']))
				{
					$_POST['asr'] = '';
				}
				
				if (!isset($_POST['maghrib']))
				{
					$_POST['maghrib'] = '';
				}
				
				if (!isset($_POST['isha']))
				{
					$_POST['isha'] = '';
				}
				
				$result = Controller::processForm($_POST);

				if ($oper == 'searchstr')
				{
					//echo "s q - >".$result;
					$_SESSION['sq'] = $result;

					$this->redirectToPage($this->_searchfile);
				}
				else
				{
					//echo "result : ".$result;
					if ($result != 1)
					{
						//echo "inputs are not correct. please check.";

						$_SESSION['errorMsg'] = "Error Occurred : ".DatabaseException::getErrorMsg($result);
						
						if ($oper == 'add')
						{
							header("Location: $addUrl");
						}
						elseif ($oper == 'edit')
						{
							header("Location: $editUrl");
						}
						elseif ($oper == 'settings')
						{
							$_SESSION['errorMsg'] = 'inputs are not correct. please check.';
							header("Location: $pageSettingsUrl");
						}                
					}
					else
					{
						if (isset($_POST['page']) and $_POST['page'] == 'srch')
						{
							header("Location: $searchUrl");
						}	
						elseif ($oper == 'settings')
						{
							if (isset($_SESSION['PAGENAME']))
							{
								$pagename = $_SESSION['PAGENAME'];
							}
							
							$_SESSION['SUBMOD'] = 'sttracker';
							$_SESSION['FWDURL'] = '../iapps/stracker/stsettings.php';
							
							$_SESSION['successMsg'] = 'Page settings have been updated';
							
							header("Location: $fetchPageSettingsUrl");
						}				
						else
						{
							$this->redirectToPage($this->_viewfile);	
						}
					}
				}
			
			}

		}
		elseif ($this->_forminputs->_oper == 'edit')
		{
			$this->processEditOperation();
		}		
		
	}
	
 	
 }
