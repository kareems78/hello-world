<?php

/**
 *	Processes the scribble form inputs
 *
 */ 
 class ScribbleProcessFormInputs extends ProcessFormInputs
 {
	 
 	public function __construct($forminputsdto)
	{
		parent::__construct($forminputsdto, SCRIBBLE_HOME);
		$this->_log = CommonUtil::getLogger(__CLASS__);		
		$this->processForm();
	}	
 	
 }
