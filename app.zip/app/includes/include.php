<?php
if (!defined('APP_ROOT'))
{
	$appRootDir = $_SERVER['DOCUMENT_ROOT'];
	
	require_once $appRootDir . '/includes/common/util.php';
	
	CommonUtil::reloadDefinitions($appRootDir);
}	

require_once APP_ROOT . '\config.php';
require_once APP_CONTROLLER . 'controller.php';
require_once APP_COMMON .'dbexception.php';
require_once APP_COMMON .'usersession.php';
require_once APP_COMMON . 'pagination.php';

require_once APP_FUSIONCHARTS . "fusioncharts.php";

$viewusers = CommonUtil::getConfigValue('viewusers');
$viewmodule = CommonUtil::getConfigValue('viewmodule');
$viewallcategories = CommonUtil::getConfigValue('viewallcategories');
$dbopersview = CommonUtil::getConfigValue('updateIds_dbopers');

$viewtask = CommonUtil::getConfigValue('viewtask');
$viewtasklist = CommonUtil::getConfigValue('viewtasklist');
$viewexpenses = CommonUtil::getConfigValue('viewexpense');
$viewcredentials = CommonUtil::getConfigValue('viewcredential');
$viewurlstore = CommonUtil::getConfigValue('viewurlstore');
$viewdtasks = CommonUtil::getConfigValue('viewdtasks');
$viewshoppinglist = CommonUtil::getConfigValue('viewshoppinglist');

$viewstimings = CommonUtil::getConfigValue('viewstimings');
$viewstracker = CommonUtil::getConfigValue('viewstracker');
$viewdatracker = CommonUtil::getConfigValue('viewdatracker');
$viewdailyfikr = CommonUtil::getConfigValue('viewdailyfikr');

$viewreminder = CommonUtil::getConfigValue('viewreminder');
$viewbiometrics = CommonUtil::getConfigValue('viewbiometrics');
$viewweightrecorder = CommonUtil::getConfigValue('viewweightrecorder');
$viewcreditpayment = CommonUtil::getConfigValue('viewcreditpayment');
$viewfundstransfer = CommonUtil::getConfigValue('viewfundstransfer');
$viewonlineorders = CommonUtil::getConfigValue('viewonlineorders');
$viewtaxreturns = CommonUtil::getConfigValue('viewtaxreturns');

$viewdbenvdetails = CommonUtil::getConfigValue('viewdbenvdetails');
$viewdbconndetails = CommonUtil::getConfigValue('viewdbconndetails');
$viewotwhours = CommonUtil::getConfigValue('viewotwhours');
$viewreqmnts = CommonUtil::getConfigValue('viewreqmnts');

$viewcircuitsbynode = CommonUtil::getConfigValue('viewcircuitsbynode');
$viewnodesbylocname = CommonUtil::getConfigValue('viewnodesbylocname');
$viewcircuitsbytype = CommonUtil::getConfigValue('viewcircuitsbytype');
$viewphyportfrmcktnode = CommonUtil::getConfigValue('viewphyportfrmcktnode');
$viewstatusbyid = CommonUtil::getConfigValue('viewstatusbyid');
$viewmvconfiginfo = CommonUtil::getConfigValue('viewmvconfiginfo');
$viewenumdefs = CommonUtil::getConfigValue('viewenumdefs');
$viewnetworksettings = CommonUtil::getConfigValue('viewnetworksettings');

?>