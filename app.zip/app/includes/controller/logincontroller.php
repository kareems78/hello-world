<?php

require_once APP_DATAACCESS . 'logindao.php';
 
/**
 *	LoginController - controls the flow
 *
 */ 
 class LoginController extends Controller
 {
 	
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
	 	
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new LoginDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('validate'):
				$result = $dao->validateUser(parent::$_formValues);
				break;

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }