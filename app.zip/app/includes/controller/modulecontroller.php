<?php

/**
 *	ModuleController - controls the flow
 *
 */ 
 class ModuleController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }