<?php

/**
 *	DbConnDetailsController - controls the flow
 *
 */
class DbconndetailsController extends Controller
{
 	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
}