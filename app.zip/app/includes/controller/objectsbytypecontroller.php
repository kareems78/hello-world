<?php

/**
 *	ObjectsbytypeController - controls the flow
 *
 */
class ObjectsbytypeController extends Controller
{
 	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
}