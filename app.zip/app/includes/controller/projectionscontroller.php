<?php
 
/**
 *	ProjectionsController - controls the flow
 *
 */ 
 class ProjectionsController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }