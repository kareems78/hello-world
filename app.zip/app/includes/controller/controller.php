<?php

defined('APP_ROOT') or die;

require_once APP_LOGGER . 'Logger.php';

require_once APP_DATAACCESS . 'basedao.php';
require_once APP_DATAACCESS . 'categorydao.php';
require_once APP_COMMON . 'dbexception.php';

/**
 *	Controller - controls the flow
 *
 */ 
 class Controller
 {
	protected static $_oper = null;

	public static $_formValues = null;
	
	protected static $_controller = null;
	
	public static $_id = null;
	
	public static $_userid = null;
	
	public static $_strVar = null;
	
	public static $records_per_page = 7;
	
	public static $_daoClass = null;
	
	public static $_log = null;
	
	public static $_submodule = null;


     /**
      * Finds the controller and process operation requested
      *
      * @param $subModName
      * @param $oper
      * @return bool|list|null|void
      *
      */
     public static function findAndProcess($subModName,$oper)
	{
		self::$_oper = $oper;
		$result = null;
		
		if (!isset(self::$_controller))
		{
			$result = self::initiateController($subModName)->process();
		}
		
		return $result;
	}
	
      /**
      * Finds the controller and process operation requested
      *
      * @param $subModName
      * @param $oper
      * @param $userid
      * @return bool|list|null|void
      *
      */
     public static function findAndProcessWithUserID($subModName,$oper, $userid)
	{
		self::$_oper = $oper;
		self::$_userid = $userid;
		$result = null;
		
		if (!isset(self::$_controller))
		{
			$result = self::initiateController($subModName)->process();
		}
		
		return $result;
	}	

     /**
      * Processes form input values and calls
      * find and process function
      *
      * @param array $formInputs
      * @return bool|list|null|void
      *
      */
     public static function processForm($formInputs = array())
	{
		self::$_formValues = $formInputs;
		
		$result = null;
		
		if (isset($formInputs))
		{
			$smod = $formInputs['submodule'];
			$op = $formInputs['oper'];
			$result = self::findAndProcess($smod,$op);
		}
		
		return $result;
	}

     /**
      * Initiates controller
      *
      * @param $submodule
      * @return instance of controller requested
      */
     private static function initiateController($submodule)
	 {
	 	self::$_submodule = $submodule;
	 	
		$classname = ucfirst($submodule) . 'Controller';
		
		//echo "<br>class name" . $classname;
		
		// load file
		$filename = strtolower($classname) . '.php';
		require_once $filename;
		
		if (!class_exists($classname))
		{
			throw new RuntimeException('Class : ' . $classname . ' not found', 500);
		}		
		
		self::$_controller = new $classname;
		
		return self::$_controller;	
		
	 }
	 
      /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$userid = self::$_userid;
		
		$submodule = self::$_submodule;
		
		$log = self::$_log;
		
		//$log->info("submodule id in controller process ==> " . $submodule);
		
		//Setting userid if sent thru form values
		if (!isset($userid))
		{
			if (isset(self::$_formValues['userid']))
			{
				$userid = self::$_formValues['userid'];
			}
		}			
		
		//$log->info("user id in controller process ==> " . $userid);
		
		$daoclass = $submodule . 'dao';
		
		//$log->info("DAO Class name -- " . $classname);
		
		// load file
		$filename = $daoclass . '.php';
		require_once APP_DATAACCESS . $filename;
		
		if (!class_exists($daoclass))
		{
			throw new RuntimeException('Class : ' . $daoclass . ' not found', 500);
		}		
		
		$log->info("User ID in Controller : " . $userid);
		
		//$log->info("Records per Page in Controller : " . self::$records_per_page);
		
		// Call the required instance of class and process
		$dao = new $daoclass($userid);		
		
		
		//get stored operation
		switch (strtolower(self::$_oper))
		{
			case strtolower('getDropDownValues'):
				$result = $dao->getDropDownValues();	
				break;				
			
			// get all records
			case strtolower('getAll'):
			if (isset(self::$_strVar))
			{
				$result = $dao->view(self::$records_per_page, self::$_strVar);
			}
			else
			{
				$result = $dao->view(self::$records_per_page);
			}
			break;

			// add a record		
			case strtolower('add'):
				$result = $dao->insert(self::$_formValues);
				break;
			
			// delete records	
			case strtolower('delete'):
				$dao->setFormInputs(self::$_formValues);
				$result = $dao->delete();	
				break;	
			
			// retrieve a record to edit
			case strtolower('edit'):
				$result = $dao->getByID(self::$_id);
				break;	
			
			// update a record	
			case strtolower('save'):
				$result = $dao->update(self::$_formValues);
				break;	

			// update a record	
			case strtolower('update'):
				$result = $dao->update(self::$_formValues);
				break;					

			// search str	
			case strtolower('searchstr'):
				$result = $dao->generateSearchQuery(self::$_formValues);
				break;	
				
			// search str	
			case strtolower('searchstrbymonth'):
				$result = $dao->generateSearchQueryByMonth(self::$_formValues);
				break;				

			// search	
			case strtolower('search'):
				$result = $dao->search(self::$records_per_page);
				break;				

			default:
				die("Error occurred : <font color='red'>Operation : ".self::$_oper." not found.</font>");
				
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}	 

 }