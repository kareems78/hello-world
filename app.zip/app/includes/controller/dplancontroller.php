<?php
 
/**
 *	DplanController - controls the flow
 *
 */ 
 class DplanController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }