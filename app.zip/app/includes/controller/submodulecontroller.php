<?php
 
/**
 *	SubModuleController - controls the flow
 *
 */ 
 class SubmoduleController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }