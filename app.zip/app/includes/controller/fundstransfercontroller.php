<?php
 
/**
 *	FundstransferController - controls the flow
 *
 */ 
 class FundstransferController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }