<?php

/**
 *	EnvController - controls the flow
 *
 */
class DbenvdetailsController extends Controller
{
 	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
}