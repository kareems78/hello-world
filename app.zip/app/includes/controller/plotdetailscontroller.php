<?php
 
/**
 *	PlotdetailsController - controls the flow
 *
 */ 
 class PlotdetailsController extends Controller
 {
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
 }