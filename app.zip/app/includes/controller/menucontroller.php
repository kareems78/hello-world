<?php

require_once APP_DATAACCESS . 'menudao.php';
 
/**
 *	MenuController - controls the flow
 *
 */ 
 class MenuController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new MenuDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('getAll'):
				$result = $dao->executeQuery($dao->_getAllRecords);
				break;
				
			// add a record		
			case strtolower('add'):
				$result = $dao->insert();
				break;
			
			// delete records	
			case strtolower('delete'):
				$dao->setFormInputs(parent::$_formValues);
				$result = $dao->delete();	
				break;	

			// retrieve a record to edit
			case strtolower('edit'):
				$result = $dao->getByID(parent::$_id);
				break;	
			
			// update a record	
			case strtolower('save'):
				$result = $dao->update(parent::$_formValues);
				break;				

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }