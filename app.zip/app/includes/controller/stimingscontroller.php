<?php

require_once APP_DATAACCESS . 'stimingsdao.php';
 
/**
 *	StimingsController - controls the flow
 *
 */ 
 class StimingsController extends Controller
 {
 	
  	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}
	 	
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new STimingsDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('getAll'):
				$result = $dao->getViewDataResultSets($dao->_getAllRecords, 8);
				break;

			// get maghrib salah timings		
			case strtolower('getMST'):
				$result = $dao->executeQuery($dao->_getAllMSTRecords);
				break;

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		return $result;		
	}
 }