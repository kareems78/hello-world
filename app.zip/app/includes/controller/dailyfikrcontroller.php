<?php

/**
 *	DailyfikrController - controls the flow
 *
 */ 
 class DailyfikrController extends Controller
 {
 	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}	 
 }