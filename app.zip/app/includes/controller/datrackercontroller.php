<?php

require_once APP_DATAOBJECT . 'datrackerdto.php';

/**
 *	DatrackerController - controls the flow
 *
 */ 
 class DatrackerController extends Controller
 {
 	public function __construct()
	{
		parent::$_log = CommonUtil::getLogger(__CLASS__);
	}	 
 }