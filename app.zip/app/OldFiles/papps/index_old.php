<!--
Link for PHP form validations
https://www.google.com/search?q=form+field+validation+php&aq=f&oq=form+field+validation+php&aqs=chrome.0.59j60j0l3j62.5527j0&sourceid=chrome&ie=UTF-8
-->
<?php
include_once 'defines.php';

// Inialize session
session_start();

// Check, if user is already login, then jump to secured page
if (isset($_SESSION['username'])) {
header('Location: success.php');
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
   <title>:: Login ::</title>
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <link rel="STYLESHEET" type="text/css" href="css/validateanyform.css" />
      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>

  <style>
	body {
		#background: #909eab url(../images/bg.png);
		background-color: #ffffff;
	}
	</style>
	  
</head>   
		
<body>
<br><br>
<!-- Form Code Start -->
<form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Login Form</legend>

<input type='hidden' name='submitted' id='submitted' value='1'/>
<input type='hidden' name='submodule' id='submodule' value='login'/>
<input type='hidden' name='oper' id='oper' value='validate'/>

	<?php
		if (isset($_SESSION['errorMsg']))
		{
			echo "<font class='nohighlighterror'>".$_SESSION['errorMsg']."</font>";
			echo "<br>";
		}
	?>

<div class='short_explanation'>* required fields</div>

<div class='container'>
    <label for='username' >Username*: </label><br/>
    <input type='text' name='username' id='username' maxlength="50" /><br/>
    <span id='validateanyform_username_errorloc' class='error'></span>
</div>
<div class='container'>
    <label for='pwd' >Password*:</label><br/>
    <input type='password' name='pwd' id='pwd' maxlength="50" /><br/>
    <span id='validateanyform_pwd_errorloc' class='error'></span>
</div>

<div class='container'>
    <input class='submit-but' type='submit' name='Submit' value='Submit' />
</div>

</fieldset>
</form>
<!-- client-side Form Validations:
Uses the form validation script from JavaScript-coder.com
See: http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
-->
<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("validateanyform");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("username","req","Please provide your username");

    frmvalidator.addValidation("pwd","req","Please provide your password");

    //frmvalidator.addValidation("email","email","Please provide a valid email address");

    //frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");
// ]]>
</script>
<?php session_destroy(); ?>
</body>

</html>