                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <?php echo"<li><a href='".EXPENSE."addexpense.php'>Add</a></li>";?>
							<?php echo"<li><a href='".EXPENSE."expenses.php'>View</a></li>";?>
							<?php echo"<li><a href='".EXPENSE."search.php'>Search by Date</a></li>";?>
							<?php echo"<li><a href='".EXPENSE."searchbymonth.php'>Search by Month</a></li>";?>
							<?php //echo"<li><a href='".PROJECTIONS."projections.php'>Projections</a></li>";?>
                        </ul> 
                    </div>