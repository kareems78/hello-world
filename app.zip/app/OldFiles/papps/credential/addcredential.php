<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '\usersession.php';

require_once CONTROLLER . 'controller.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Add Credential</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<?php echo"<link href='". BASE_PATH ."css/header.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/menu.css' rel='stylesheet' type='text/css'>";?>
		<?php echo"<link href='". BASE_PATH ."css/task.mainbody.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/footer.css' rel='stylesheet'/>";?>

        <?php echo"<link rel='STYLESHEET' type='text/css' href='". BASE_PATH ."css/validateanyform.css'/>";?>
        <?php echo"<script type='text/javascript' src='". BASE_PATH ."scripts/gen_validatorv31.js'></script>";?>	

		<?php echo"<link href='". BASE_PATH ."dp/themes/base/jquery.ui.all.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."dp/demos.css' rel='stylesheet'/>";?>
		
	    <?php echo"<script src='". BASE_PATH ."dp/jquery-1.4.2.js'></script>";?>
	    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.core.js'></script>";?>
	    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.widget.js'></script>";?>
	    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.datepicker.js'></script>";?>

		<script type="text/javascript">
		$(function() {
			$( "#duedate" ).datepicker();
		});
		</script>		
		
    </head>
    <body>
        
        <div class="wrapper">
		
			<!-- header starts here -->
			<?php require_once ROOT . 'header.php';?>         
			<!-- header ends here -->
			
			<!-- cssmenu starts here -->
			<?php require_once ROOT . 'menu.php';?>
			<!-- cssmenu ends here -->
            
			<!-- main body starts here -->
            <div class="mainbody">
                
                <div class="leftcol">
					<?php require_once CREDS_LEFTNAV;?>
                </div>
                
                <div class="midcol">
                    <div class="middle_holder">
								
						<!-- Form Code Start -->
						<form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
						<fieldset >
						<legend>Add Credential</legend>

						<input type='hidden' name='submitted' id='submitted' value='1'/>
						<input type='hidden' name='submodule' id='submodule' value='credential'/>
						<input type='hidden' name='oper' id='oper' value='add'/>

						<?php 
						
							$result = Controller::findAndProcess('credential', 'getDropDownValues');

							echo"<input type='hidden' name='userid' id='userid' value='".$userDetails['userid']."'/>";
						
						?>

						<div class='short_explanation'>* required fields</div>
						<table border='0'>
						<tr>
						<td valign='top'>
						<div class='container'>
							<label for='name' >Credential For*: </label><br/>
							<input type='text' name='name' id='name' placeholder='Enter Credential Name' maxlength="50" value=''/><br/>
							<span id='validateanyform_name_errorloc' class='error'></span>
						</div>
						
						<div class='container'>
							<label for='url' >Url: </label><br/>
							<input type='text' name='url' id='url' placeholder='http://www.domainname.com' maxlength="500" value=''/><br/>
							<span id='validateanyform_url_errorloc' class='error'></span>
						</div>						
						
						<div class='container'>
							<label for='notes' >Notes:</label><br/>
							<textarea name='notes' id='notes' cols='35' rows='5' placeholder='Enter Credential Notes'></textarea><br/>
							<span id='validateanyform_notes_errorloc' class='error'></span>
						</div>
						
						</td>
						<td width='50'>&nbsp;</td>
						<td valign='top'>
						
						<div class='container'>
							<label for='username' >Username*: </label><br/>
							<input type='text' name='username' id='username' placeholder='Enter Username' maxlength="50" value=''/><br/>
							<span id='validateanyform_username_errorloc' class='error'></span>
						</div>	

						<div class='container'>
							<label for='password' >Password*: </label><br/>
							<input type='text' name='password' id='password' placeholder='************' maxlength="50" value=''/><br/>
							<span id='validateanyform_password_errorloc' class='error'></span>
						</div>						
						
						<div class='container'>
							<label for='category' >Category*:</label><br/>
							<select name="category">
							<option value=''>Select Category</option>
							<?php
								foreach($result as $rows => $row)
								{
									echo "<option value='".$row['id']."'>".$row['name']."</option>";
								}
							?>
							</select>
							<br/>
							<span id='validateanyform_category_errorloc' class='error'></span>
						</div>
							
						</td>
						</tr>
						</table>
						<div class='container'>
							<input class='submit-but' type='submit' name='Submit' value='Submit' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class='submit-but' type='button' name='Cancel' value='      Cancel      ' onclick='history.go(-1);'/>
						</div>

						</fieldset>
						</form>				
					
                       
                    </div>
                </div>
                
                <div class="rightcol">
                    <div class="right_holder">

                    </div>
                    
                    <div class="right_holder">

                    </div>
                </div>
                
            </div>
            <!-- main body ends here -->
			
			<!-- footer starts here -->
			<?php require_once ROOT . 'footer.php';?>
            <!-- footer ends here -->
			
        </div>
		
<!-- client-side Form Validations:
Uses the form validation script from JavaScript-coder.com
See: http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
-->
<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("validateanyform");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("name","req","Please input credential name");
	frmvalidator.addValidation("username","req","Please input username");
	frmvalidator.addValidation("password","req","Please input password");
	frmvalidator.addValidation("category","req","Please input category");

    //frmvalidator.addValidation("pwd","req","Please provide your password");

    //frmvalidator.addValidation("email","email","Please provide a valid email address");

    //frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");
// ]]>
</script>		
    </body>
</html>
