-- === MySQL Queries ===

-- to reset auto increment
ALTER TABLE <TABLE_NAME> AUTO_INCREMENT = 1;

insert into user (username, password, createddate, updateddate) values ('kareems', md5('felisha10'),'2013-05-17','2013-05-17');