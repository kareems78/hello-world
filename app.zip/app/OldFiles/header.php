            <div class="header">
                
                <div class="header_left"></div>
				<div class="header_right">
					<h4>Welcome <?php echo$userDetails['firstname']?> <?php echo"<a href='".BASE_PATH."logout.php'>Logout</a>"?></h4>
				</div>
            </div>  