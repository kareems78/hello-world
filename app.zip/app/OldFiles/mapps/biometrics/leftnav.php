                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <li><a href="addbiometrics.php">Add</a></li>
							<li><a href="biometrics.php">View</a></li>	
                        </ul> 
                    </div>