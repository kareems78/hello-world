<?php
/**
 * Created by JetBrains PhpStorm.
 * User: KAREEMS
 * Date: 6/3/13
 * Time: 12:11 PM
 * To change this template use File | Settings | File Templates.
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '\usersession.php';

require_once CONTROLLER . 'controller.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Funds Transfer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<?php echo"<link href='". BASE_PATH ."css/header.css' rel='stylesheet'/>";?>
	<?php echo"<link href='". BASE_PATH ."css/menu.css' rel='stylesheet' type='text/css'>";?>
	<?php echo"<link href='". BASE_PATH ."css/task.mainbody.css' rel='stylesheet'/>";?>
	<?php echo"<link href='". BASE_PATH ."css/footer.css' rel='stylesheet'/>";?>

    <?php echo"<link rel='STYLESHEET' type='text/css' href='". BASE_PATH ."css/validateanyform.css'/>";?>
    <?php echo"<script type='text/javascript' src='". BASE_PATH ."scripts/gen_validatorv31.js'></script>";?>	

	<?php echo"<link href='". BASE_PATH ."dp/themes/base/jquery.ui.all.css' rel='stylesheet'/>";?>
	<?php echo"<link href='". BASE_PATH ."dp/demos.css' rel='stylesheet'/>";?>
	
    <?php echo"<script src='". BASE_PATH ."dp/jquery-1.4.2.js'></script>";?>
    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.core.js'></script>";?>
    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.widget.js'></script>";?>
    <?php echo"<script src='". BASE_PATH ."dp/ui/jquery.ui.datepicker.js'></script>";?>

    <script type="text/javascript">
        $(function() {
            $( "#fromdate" ).datepicker();
        });

        $(function() {
            $( "#todate" ).datepicker();
        });
    </script>

</head>
<body>

<div class="wrapper">

    <!-- header starts here -->
    <?php require_once ROOT . 'header.php';?>
    <!-- header ends here -->

    <!-- cssmenu starts here -->
    <?php require_once ROOT . 'menu.php';?>
    <!-- cssmenu ends here -->

    <!-- main body starts here -->
    <div class="mainbody">

        <div class="leftcol">
            <?php require_once FT_LEFTNAV;?>
        </div>

        <div class="midcol">
            <div class="middle_holder">

                <!-- Form Code Start -->
                <form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
                    <fieldset >
                        <legend>Search Expenses</legend>

                        <input type='hidden' name='submitted' id='submitted' value='1'/>
                        <input type='hidden' name='submodule' id='submodule' value='fundstransfer'/>
                        <input type='hidden' name='oper' id='oper' value='searchstr'/>

                        <div class='short_explanation'>* required fields</div>

                        <div class='container'>
                            <label for='fromdate' >From Date: </label><br/>
                            <input type='text' name='fromdate' id='fromdate' maxlength="50" placeholder='Select From Date' value=''/><br/>
                            <span id='validateanyform_fromdate_errorloc' class='error'></span>
                        </div>

                        <div class='container'>
                            <label for='todate' >To Date: </label><br/>
                            <input type='text' name='todate' id='todate' maxlength="50" placeholder='Select To Date' value=''/><br/>
                            <span id='validateanyform_todate_errorloc' class='error'></span>
                        </div>

                        <div>
                        &nbsp;
                        </div>

                        <div class='container'>
                            <input class='submit-but' type='submit' name='Submit' value='Submit' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class='submit-but' type='button' name='Cancel' value='      Cancel      ' onclick='history.go(-1);'/>
                        </div>

                    </fieldset>
                </form>


            </div>
        </div>

        <div class="rightcol">
            <div class="right_holder">

            </div>

            <div class="right_holder">

            </div>
        </div>

    </div>
    <!-- main body ends here -->

    <!-- footer starts here -->
    <?php require_once ROOT . 'footer.php';?>
    <!-- footer ends here -->

</div>

<!-- client-side Form Validations:
Uses the form validation script from JavaScript-coder.com
See: http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
-->
<script type='text/javascript'>
    // <![CDATA[

    var frmvalidator  = new Validator("validateanyform");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    //frmvalidator.addValidation("fromdate","req","Please input from date");
    // ]]>
</script>
</body>
</html>
