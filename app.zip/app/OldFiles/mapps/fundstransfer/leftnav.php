                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <li><a href="addfundstransfer.php">Add</a></li>
							<li><a href="fundstransfer.php">View</a></li>	
							<li><a href="search.php">Search</a></li>								
                        </ul> 
                    </div>