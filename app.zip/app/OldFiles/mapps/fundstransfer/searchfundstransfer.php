<?php // content="text/plain; charset=utf-8"
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '\usersession.php';

require_once CONTROLLER . 'controller.php';
require_once COMMON . 'util.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Search Funds Transfer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<?php echo"<link href='". BASE_PATH ."css/header.css' rel='stylesheet'/>";?>
	<?php echo"<link href='". BASE_PATH ."css/menu.css' rel='stylesheet' type='text/css'>";?>
	<?php echo"<link href='". BASE_PATH ."css/task.mainbody.css' rel='stylesheet'/>";?>
	<?php echo"<link href='". BASE_PATH ."css/footer.css' rel='stylesheet'/>";?>
	
	<?php echo"<script src='". BASE_PATH ."scripts/jquery/jquery.tools.min.js'></script>";?>

</head>
<body>

<div class="wrapper">

    <!-- header starts here -->
    <?php require_once ROOT . 'header.php';?>
    <!-- header ends here -->

    <!-- cssmenu starts here -->
    <?php require_once ROOT . 'menu.php';?>
    <!-- cssmenu ends here -->

    <!-- main body starts here -->
    <div class="mainbody">

        <div class="leftcol">
            <?php require_once FT_LEFTNAV;?>
        </div>

        <div class="midcol">
            <div class="middle_holder">

                View Search Funds Transfer >>
                <?php
                if (isset($_SESSION['errorMsg']))
                {
                    echo "<font class='error'>".$_SESSION['errorMsg']."</font>";
                }
                ?>

                <form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
                    <input type='hidden' name='submitted' id='submitted' value='1'/>
                    <input type='hidden' name='submodule' id='submodule' value='fundstransfer'/>
                    <input type='hidden' name='oper' id='oper' value='delete'/>
					<input type='hidden' name='page' id='page' value='srch'/>											
                    <?php


                    if (isset($_SESSION['sq']))
                    {
                        $searchStr = $_SESSION['sq'];
                    }
                    Controller::$_strVar = $searchStr;
                    
                    $result = Controller::findAndProcessWithUserID('fundstransfer', 'search', $userDetails['userid']);

                    if (CommonUtil::validateResultSet($result))
                    {

							$count = 0;
							
							echo "<div id='tbl'><table class='tbl'>
							<tr>
							<th>&nbsp;&nbsp;&nbsp;</th>
							<th align='center'>S.No</th>
							<th>Referenceno</th>
							<th>Date Sent</th>
							<th>Account</th>
							<th>Amount</th>
							<th>Dest Amount</th>
							<th>Notes</th>
							</tr>";

							foreach($result as $rows => $row)
							{
							  //echo "row : ".$count." notes len : ".$row['id']." ";
							  $count = $count+1;
							  if ($count % 2)
							  {
								echo "<tr class='odd' height='27'>";
							  }
							  else
							  {
								echo "<tr height='27'>";
							  }  	
							  
							  $dateSent = CommonUtil::dateInMMDDYYYY($row['datesent']);
							  
							  echo "<td align='center'><input type='checkbox' name='deleteObject[]' value='".$row['id']."'/></td>";
							  echo "<td align='center'>" . $count . "</td>";
							  echo "<td width='100'><a href='./processforminputs.php?id=".$row['id']."&oper=edit'>" . $row['referenceno'] . "</a></td>";
							  echo "<td>" . $dateSent . "</td>";
							  echo "<td width='100'>" . $row['aname'] . "</td>";
							  echo "<td width='50'>$ " . round($row['amount'],2,PHP_ROUND_HALF_EVEN) . "</td>";	
							  echo "<td width='75'>Rs " . round($row['destamount'],2,PHP_ROUND_HALF_EVEN) . "</td>";							  
							  if (strlen($row['notes']) > 0)
							  {
								echo "<td><img src='../../images/notes2.png' title='".nl2br($row['notes'])."'/></td>";
							  }		
							  else
							  {
								echo "<td>&nbsp;</td>";
							  }
								echo "</tr>";
							  }
							  if ($count % 2)
							  {
								echo "<tr height='27'>";
							  }
							  else
							  {
								echo "<tr class='odd' height='27'>";
							  } 
							  echo "<td colspan='8'>&nbsp;</td></tr>";
							  
							  echo "</table></div>";
							
							  echo "<br><input class='submit-but' type='submit' name='Delete' value=' Delete ' />";
                    }
                    else
                    {
                        echo "There are no items to display";
                    }

                    unset($_SESSION['errorMsg']);

                    ?>

                </form>
            </div>
        </div>

        <!-- right col -->
        <!-- <div class="rightcol">
            <div class="right_holder">

            </div>

            <div class="right_holder">

            </div>
        </div> -->

    </div>
    <!-- main body ends here -->

    <!-- footer starts here -->
    <?php require_once ROOT . 'footer.php';?>
    <!-- footer ends here -->

</div>
<script type="text/javascript">
    $('#tbl img[title]').tooltip(
        {
            // custom positioning
            position: 'center right',

            // tweak the position
            offset: [0, 25],

            delay: 0
        });
</script>
</body>
</html>
