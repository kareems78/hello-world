                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <li><a href="addweightrecorder.php">Add</a></li>
							<li><a href="weightrecorder.php">View</a></li>	
                        </ul> 
                    </div>