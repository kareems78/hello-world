<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '\usersession.php';

require_once CONTROLLER . 'controller.php';
require_once COMMON . 'util.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Home Apps | Salah Tracker | Settings</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <?php echo"<link href='". BASE_PATH ."css/header.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/menu.css' rel='stylesheet' type='text/css'>";?>
		<?php echo"<link href='". BASE_PATH ."css/task.mainbody.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/footer.css' rel='stylesheet'/>";?>

        <?php echo"<link rel='STYLESHEET' type='text/css' href='". BASE_PATH ."css/validateanyform.css' />";?>
        <?php echo"<script type='text/javascript' src='". BASE_PATH ."scripts/gen_validatorv31.js'></script>";?>

    </head>
    <body>
        
        <div class="wrapper">
		
			<!-- header starts here -->
			<?php require_once ROOT . 'header.php';?>         
			<!-- header ends here -->
			
			<!-- cssmenu starts here -->
			<?php require_once ROOT . 'menu.php';?>
			<!-- cssmenu ends here -->
            
			<!-- main body starts here -->
            <div class="mainbody">

                <div class="leftcol">
                    <?php require_once ST_LEFTNAV;?>
                </div>
                
                <div class="midcol">
                    <div class="middle_holder">

						<!-- Form Code Start -->
						<form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
						<fieldset >
						<legend>Add Salah Tracker Settings</legend>

						<input type='hidden' name='submitted' id='submitted' value='1'/>
						<input type='hidden' name='submodule' id='submodule' value='stracker'/>
						<input type='hidden' name='oper' id='oper' value='settings'/>
						
						<?php 
						
							$result = Controller::findAndProcessWithUserID('stracker', 'getAllPageNames', $userDetails['userid']);
							
							$_SESSION['SUBMOD'] = 'stracker';
							$_SESSION['FWDURL'] = '../iapps/stracker/stsettings.php';
							
							if (isset($_SESSION['errorMsg']))
							{
								echo "in error message";
								unset($_SESSION['PAGENAME']);
								echo "<font class='nohighlighterror'>".$_SESSION['errorMsg']."</font>";
							}
						
							if (isset($_SESSION['successMsg']))
							{
								echo "<font class='nohighlighterror'>".$_SESSION['successMsg']."</font>";
							}							
							
						?>

						<div class='short_explanation'>* required fields</div>
						
						<div class='container'>
							<label for='pagename'>Page*:</label><br/>
							<select id='pagename' name="pagename" onChange='fetchcolsettings();'>
							<option value=''>Select Page</option>
							<?php
								foreach($result as $rows => $row)
								{
									if (isset($_SESSION['PAGENAME']))
									{
										if ($row['page'] == $_SESSION['PAGENAME'])
										{
											echo "<option value='".$row['page']."' selected>".$row['page']."</option>";
										}
										else
										{					
											echo "<option value='".$row['page']."'>".$row['page']."</option>";
										}										
									}
									else
									{
										echo "<option value='".$row['page']."'>".$row['page']."</option>";
									}
								}
							?>
							</select>
							<br/>
							<span id='validateanyform_pagename_errorloc' class='error'></span>
						</div>
						
						<?php 
							
							if (isset($_SESSION['ROWSFETCHED']))
							{
								$rows = $_SESSION['ROWSFETCHED'];
								
								//echo "size of rows : ".sizeof($rows)."<br>";
								
								CommonUtil::displayPageSettingColumns($rows);

							}
						
							if (!isset($_SESSION['ROWSFETCHED']))
							{
								echo "<div>&nbsp;</div>";
							}
						?>
						
						<div class='container'>
							<input class='submit-but' type='submit' name='Submit' value='  Submit' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<a href='salahtracker.php' class='submit-but'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cancel&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
						</div>

						</fieldset>
						
						<?php 
							unset($_SESSION['ROWSFETCHED']);
							unset($_SESSION['errorMsg']);
							unset($_SESSION['successMsg']);
							//unset($_SESSION['PAGENAME']);
						?>
						
						</form>				
					
                       
                    </div>
                </div>
                
                <div class="rightcol">
                    <div class="right_holder">

                    </div>
                    
                    <div class="right_holder">

                    </div>
                </div>
                
            </div>
            <!-- main body ends here -->
			
			<!-- footer starts here -->
			<?php require_once ROOT . 'footer.php';?>
            <!-- footer ends here -->
			
        </div>
		
<!-- client-side Form Validations:
Uses the form validation script from JavaScript-coder.com
See: http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
-->
<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("validateanyform");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("pagename","req","Please select page");

    //frmvalidator.addValidation("pwd","req","Please provide your password");

    //frmvalidator.addValidation("email","email","Please provide a valid email address");

    //frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");
    
	function fetchcolsettings()
	{
		//alert('hi - value selected : '+document.getElementById('pagename').value);

		var url;

		if (document.getElementById('pagename').value != 0)
		{
			url ='../../settings/fetchpagesettings.php?pagename='+document.getElementById('pagename').value;	
		}
		else
		{	
			url ='./settingerror.php';
		}

		window.location = url;
		
	}    
    
// ]]>
</script>		
    </body>
</html>
