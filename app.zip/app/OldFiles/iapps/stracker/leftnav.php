                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <li><a href="addstracker.php">Add</a></li>
							<li><a href="salahtracker.php">View</a></li>
                            <li><a href="search.php">Search</a></li>
                            <li><a href="stsettings.php">Settings</a></li>
                        </ul> 
                    </div>