<?php

$pageSettingsUrl = 'stsettings.php';

$_SESSION['errorMsg'] = 'inputs are not correct. please check.';

echo "in error setting ..";

header("Location: $pageSettingsUrl");

?>