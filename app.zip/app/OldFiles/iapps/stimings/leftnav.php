                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
							<li><a href="salahtimings.php">Salah Timings</a></li>
                            <li><a href="mstimings.php">Maghrib Salah</a></li>
							<li><a href="salahtimings.php?ramadan=true">Ramadan Salah</a></li>
                        </ul> 
                    </div>