            <div class="footer">
                <ul class="footer_navbar">
					<li class="footer_name">Copyright � 2012. All rights reserved. </li>
				
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Legal</a></li>
                    <li><a href="#">Facebook</a></li>
                </ul>
            </div>