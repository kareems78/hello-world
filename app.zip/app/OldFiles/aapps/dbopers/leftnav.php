                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
                            <?php echo"<li><a href='".DBOPERS."updateids/updateids.php'>Update IDs</a></li>";?>
                            <?php echo"<li><a href='".DBOPERS."generatecsv/generatecsv.php'>Generate CSVs</a></li>";?>
                        </ul> 
                    </div>