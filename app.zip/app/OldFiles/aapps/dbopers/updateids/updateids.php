<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '\usersession.php';

require_once CONTROLLER . 'controller.php';

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Update IDs</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<?php echo"<link href='". BASE_PATH ."css/header.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/menu.css' rel='stylesheet' type='text/css'>";?>
		<?php echo"<link href='". BASE_PATH ."css/task.mainbody.css' rel='stylesheet'/>";?>
		<?php echo"<link href='". BASE_PATH ."css/footer.css' rel='stylesheet'/>";?>

        <?php echo"<link rel='STYLESHEET' type='text/css' href='". BASE_PATH ."css/validateanyform.css'/>";?>
        <?php echo"<script type='text/javascript' src='". BASE_PATH ."scripts/gen_validatorv31.js'></script>";?>	
		
    </head>
    <body>
        
        <div class="wrapper">
		
			<!-- header starts here -->
			<?php require_once ROOT . 'header.php';?>        
			<!-- header ends here -->
			
			<!-- cssmenu starts here -->
			<?php require_once ROOT . 'menu.php';?>
			<!-- cssmenu ends here -->
            
			<!-- main body starts here -->
            <div class="mainbody">
                
                <div class="leftcol">
                    <?php require_once DBOPERS_LEFTNAV;?>
                </div>
                
                <div class="midcol">
                    <div class="middle_holder">
								
						<!-- Form Code Start -->
						<form id='validateanyform' action='processforminputs.php' method='post' accept-charset='UTF-8'>
						<fieldset >
						<legend>Update IDs</legend>

						<input type='hidden' name='submitted' id='submitted' value='1'/>
						<input type='hidden' name='submodule' id='submodule' value='dbopers'/>
						<input type='hidden' name='oper' id='oper' value='updateids'/>

						<?php 
						
							$result = Controller::findAndProcess('dbopers', 'getUpdateIdDropDownValues');
							
							if (isset($_SESSION['MESSAGE']))
							{
								echo "<font class='nohighlighterror'>".$_SESSION['MESSAGE']." </font>";
							}	
						?>

						<div class='short_explanation'>* required fields</div>
						
						<table border='0'>
						<tr><td>
						<div class='container'>
							<label for='user' >Users*:</label><br/>
							<select id='user' name='user' onChange='fetchtableid();'>
							<option value=''>Select User</option>
							<?php
								foreach($result['USERS'] as $rows => $row)
								{									
									echo "<option value='".$row['id']."'>".$row['username']."</option>";
								}
							?>
							</select>
							<br/>
							<span id='validateanyform_user_errorloc' class='error'></span>
						</div>	
						</td>

						</tr>
						</table>
						
						<table border='0'>
						<tr><td valign='top'>	
						<div class='container'>
							<label for='datatable' >Data Tables*:</label><br/>
							<select name="datatable">
							<option value=''>Select Data Table</option>
							<?php
								foreach($result['DATATABLES'] as $rows => $row)
								{									
									echo "<option value='".$row['name']."'>".$row['name']."</option>";
								}
							?>
							</select>
							<br/>
							<span id='validateanyform_datatable_errorloc' class='error'></span>
						</div>						
						</td>
						
						</tr>
						</table>						

						<div class='container'>
							<input class='submit-but' type='submit' name='Submit' value='Update IDs' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class='submit-but' type='button' name='Cancel' value='      Cancel      ' onclick='history.go(-1);'/>
						</div>

						</fieldset>
						</form>	
									
						<!-- unset session object --> 
                       <?php unset($_SESSION['MESSAGE']); ?>					
                       
                    </div>
                </div>
                
                <div class="rightcol">
                    <div class="right_holder">

                    </div>
                    
                    <div class="right_holder">

                    </div>
                </div>
                
            </div>
            <!-- main body ends here -->
			
			<!-- footer starts here -->
			<?php require_once ROOT . 'footer.php';?>
            <!-- footer ends here -->
			
        </div>
		
<!-- client-side Form Validations:
Uses the form validation script from JavaScript-coder.com
See: http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
-->
<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("validateanyform");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("user","req","Please input user");
	frmvalidator.addValidation("datatable","req","Please input datatable");

    //frmvalidator.addValidation("pwd","req","Please provide your password");

    //frmvalidator.addValidation("email","email","Please provide a valid email address");

    //frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");
    
    
// ]]>
</script>		
    </body>
</html>
