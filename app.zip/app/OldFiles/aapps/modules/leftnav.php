                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">
							<li class="leftcolhdr"><b></b></li>
							<?php echo"<li><a href='".MENUS."menus.php'>Menu</a></li>";?>
							<?php echo"<li><a href='".MODULES."addmodule.php'>Add</a></li>";?>
							<?php echo"<li><a href='".MODULES."modules.php'>View</a></li>";?>
                    </div>