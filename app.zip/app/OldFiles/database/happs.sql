/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 50524
Source Host           : localhost:3306
Source Database       : happs

Target Server Type    : MYSQL
Target Server Version : 50524
File Encoding         : 65001

Date: 2013-11-03 01:38:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1', 'Kareem ICICI', null);
INSERT INTO `account` VALUES ('2', 'Kareem SBI', null);
INSERT INTO `account` VALUES ('3', 'Kareem Citi', null);
INSERT INTO `account` VALUES ('4', 'Jakeer Bhai', null);
INSERT INTO `account` VALUES ('5', 'Kareem NRE', null);
INSERT INTO `account` VALUES ('6', 'Kaleemullah Uncle', 'SBI Account');
INSERT INTO `account` VALUES ('7', 'Thoukhir UK Acct', '');

-- ----------------------------
-- Table structure for `bioabbrevations`
-- ----------------------------
DROP TABLE IF EXISTS `bioabbrevations`;
CREATE TABLE `bioabbrevations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desc` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bioabbrevations
-- ----------------------------
INSERT INTO `bioabbrevations` VALUES ('1', 'BMI', 'Body Mass Index');
INSERT INTO `bioabbrevations` VALUES ('2', 'WC', 'Waist Circumference');
INSERT INTO `bioabbrevations` VALUES ('3', 'BP', 'Blood Pressure');
INSERT INTO `bioabbrevations` VALUES ('4', 'GF', 'Glucose Fasting');
INSERT INTO `bioabbrevations` VALUES ('5', 'GNF', 'Glucose Non Fasting');
INSERT INTO `bioabbrevations` VALUES ('6', 'Total Chol', 'Total Cholestrol');
INSERT INTO `bioabbrevations` VALUES ('7', 'HDL Chol', 'HDL Cholestrol');
INSERT INTO `bioabbrevations` VALUES ('8', 'LDL', 'LDL Cholestrol');

-- ----------------------------
-- Table structure for `biometrics`
-- ----------------------------
DROP TABLE IF EXISTS `biometrics`;
CREATE TABLE `biometrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createddate` date NOT NULL,
  `biotestdate` date NOT NULL,
  `user` bigint(20) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `bmi` varchar(10) DEFAULT NULL,
  `waist` varchar(10) DEFAULT NULL,
  `bp` varchar(10) NOT NULL,
  `glucosefasting` varchar(10) DEFAULT NULL,
  `glucosenonfasting` varchar(10) DEFAULT NULL,
  `totalcholestrol` varchar(10) DEFAULT NULL,
  `hdlcholestrol` varchar(10) DEFAULT NULL,
  `ldlcholestrol` varchar(10) DEFAULT NULL,
  `riskratio` varchar(10) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBIO_USER` (`user`),
  CONSTRAINT `FKBIO_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of biometrics
-- ----------------------------
INSERT INTO `biometrics` VALUES ('3', '2012-11-19', '2011-10-25', '2', '132', '23', '32', '111/74', '91', '', '144', '19', '', '7.5', '');
INSERT INTO `biometrics` VALUES ('4', '2012-11-19', '2012-10-24', '2', '129', '22', '30', '110/70', '', '112', '146', '31', '', '4.8', '');

-- ----------------------------
-- Table structure for `ccategory`
-- ----------------------------
DROP TABLE IF EXISTS `ccategory`;
CREATE TABLE `ccategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKCCAT_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ccategory
-- ----------------------------
INSERT INTO `ccategory` VALUES ('1', 'Home', null);
INSERT INTO `ccategory` VALUES ('2', 'Work', null);
INSERT INTO `ccategory` VALUES ('3', 'Misc', null);
INSERT INTO `ccategory` VALUES ('4', 'Mail', null);
INSERT INTO `ccategory` VALUES ('5', 'Medical', null);
INSERT INTO `ccategory` VALUES ('6', 'Insurance', null);
INSERT INTO `ccategory` VALUES ('7', 'Utilities', null);
INSERT INTO `ccategory` VALUES ('8', 'Personal', null);
INSERT INTO `ccategory` VALUES ('9', 'Credit Card', null);
INSERT INTO `ccategory` VALUES ('10', 'Car', 'Car related links');
INSERT INTO `ccategory` VALUES ('11', 'S - Card', 'Shopping Card');

-- ----------------------------
-- Table structure for `cleaning`
-- ----------------------------
DROP TABLE IF EXISTS `cleaning`;
CREATE TABLE `cleaning` (
  `id` int(11) NOT NULL,
  `headline` varchar(500) DEFAULT NULL,
  `text` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cleaning
-- ----------------------------
INSERT INTO `cleaning` VALUES ('1', 'Weekly Cleaning', 0x73746172742068657265);
INSERT INTO `cleaning` VALUES ('2', 'Bi Weekly', null);

-- ----------------------------
-- Table structure for `content`
-- ----------------------------
DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `element_id` int(11) NOT NULL,
  `text` blob NOT NULL,
  PRIMARY KEY (`element_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of content
-- ----------------------------
INSERT INTO `content` VALUES ('1', 0x2D20486F6D6520436C65616E696E67205461736B733C6469763E2D2D204B69746368656E3C2F6469763E3C6469763E5765656B656E64205461736B733A3C2F6469763E3C6469763E30312E20436C65616E204B69746368656E20746F7020616E642072656D6F766520756E206E6563657373617279206974656D733C2F6469763E3C6469763E30322E20436865636B20726566726967657261746F7220746F20736565207768657468657220616E797468696E67206E6565647320746F206265206469736361726465643C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E4269205765656B6C79205461736B733A3C2F6469763E3C6469763E30312E204368616E676520666F696C206F7665722073746F766520746F703C2F6469763E3C6469763E30322E20436C65616E20726566726967657261746F722062792072656D6F76696E6720616C6C20746865207374756666206F75743C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E2D2D2042617468726F6F6D3C2F6469763E3C6469763E3C6469763E5765656B656E64205461736B733A3C2F6469763E3C6469763E30312E204D6F7020666C6F6F723C2F6469763E3C6469763E30322E20436C65616E2062617468207475622026616D703B205761736820626173696E733C2F6469763E3C6469763E30332E20436C65616E20746F696C657420626F776C733C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E4269205765656B6C79205461736B733A3C62723E3C2F6469763E3C2F6469763E3C6469763E30312E20576173682062617468726F6F6D206375727461696E733C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E2D2D204C6976696E6720526F6F6D3C2F6469763E3C6469763E30312E20436C65616E20676C617373206D6972726F7273206F662073696465207461626C653C2F6469763E3C6469763E30322E20436C65616E20746F70207468617420636F6E7461696E73206672756974733C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E2D2D20426564726F6F6D733C2F6469763E3C6469763E30312E20436C65616E206472657373696E67207461626C6520746F703C2F6469763E3C6469763E30322E204368616E676520626564207368656574732069662072657175697265643C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E2D2D204D6973633C2F6469763E3C6469763E30312E205761736820636C6F7468657320616E642073657420757020696E207761726420726F62653C2F6469763E3C6469763E30322E2049726F6E20636C6F746865733C2F6469763E3C6469763E30332E205661636375756D2077686F6C6520686F7573653C2F6469763E3C6469763E30342E20436865636B2073746F72656420656D61696C206F6E2074686520656E7472616E636520616E642064697363617264207468617420617265206E6F74206E65636573736172793C2F6469763E3C6469763E30352E205661636375756D2063617220616E6420736F72742062696C6C732066726F6D206361723C2F6469763E3C6469763E30362E2057697065206365696C696E672066616E7320696E2068616C6C20616E6420626564726F6F6D3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E3C6469763E3C62723E3C2F6469763E);

-- ----------------------------
-- Table structure for `credential`
-- ----------------------------
DROP TABLE IF EXISTS `credential`;
CREATE TABLE `credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `createddate` date DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user` bigint(20) NOT NULL,
  `category` int(11) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCRED_USER` (`user`),
  KEY `FKCRED_CCAT` (`category`) USING BTREE,
  CONSTRAINT `FKCRED_CCAT` FOREIGN KEY (`category`) REFERENCES `ccategory` (`id`),
  CONSTRAINT `FKCRED_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of credential
-- ----------------------------
INSERT INTO `credential` VALUES ('4', 'Yahoo Mail', '2012-11-20', 'mailtokarims', 'Rainbow10', '2', '4', '', '');
INSERT INTO `credential` VALUES ('5', 'Yahoo Mail', '2012-11-20', 'kareem.shaik', 'ilushe**10', '2', '4', '', 'kareem.shaik@ymail.com');
INSERT INTO `credential` VALUES ('6', 'Gmail', '2012-11-20', 'karim.shak', 'f10', '2', '4', '', '');
INSERT INTO `credential` VALUES ('7', 'Hotmail', '2012-11-20', 'kareim_s', 'ilusha**10', '2', '4', '', '');
INSERT INTO `credential` VALUES ('8', 'Progressive', '2012-11-20', 'kareems78', 'f10', '2', '6', 'http://www.progressive.com/login.aspx', 'Policy No# 43611518-5\r\nCustmoer Care: 1-800-876-5581\r\n\r\nFax: 1 800 229 1590');
INSERT INTO `credential` VALUES ('10', 'Prudential 401K', '2012-11-27', 'kareems78', 'f10', '2', '3', 'https://ssologin.prudential.com/app/retirement/Login.fcc', '401K plan\r\n\r\n877-778-2100');
INSERT INTO `credential` VALUES ('11', 'ATT Internet', '2012-11-30', 'kareems78', 'f10', '2', '3', '', '');
INSERT INTO `credential` VALUES ('12', 'ATT Composer', '2012-11-30', 'ks589h', 'ks589h', '2', '2', 'https://bistromatic.mo.sbc.com:9443/rdm/', '');
INSERT INTO `credential` VALUES ('13', 'ATT Redmine', '2012-11-30', 'ks589h', 'F10', '2', '2', 'http://139.76.215.96:7225/redmine/login', '');
INSERT INTO `credential` VALUES ('14', 'ATT QC', '2012-11-30', 'ks589h', 'Rainbow@10', '2', '2', '', '');
INSERT INTO `credential` VALUES ('15', 'ATT Global Login', '2012-11-30', 'ks589h', 'Rainbow@10', '2', '2', '', '');
INSERT INTO `credential` VALUES ('16', 'ATT Crucible', '2012-11-30', 'ks589h', 'ks589h', '2', '2', 'http://jcore-reviews.snt.bst.bls.com/', 'use 1025 as port from Amdocs network');
INSERT INTO `credential` VALUES ('17', 'ATT FTP', '2012-11-30', 'm45678', 'G0ipag!', '2', '2', null, null);
INSERT INTO `credential` VALUES ('18', 'Remit2India', '2012-11-30', 'Yahoo Email ID', 'k10', '2', '8', 'https://www.timesofmoney.com/remittance/secure/r2i', 'Customer ID : 1695742\r\n');
INSERT INTO `credential` VALUES ('19', 'Mint', '2012-11-30', 'Yahoo Email ID', 'f10', '2', '8', 'https://wwws.mint.com/login.event', '');
INSERT INTO `credential` VALUES ('20', 'Davis Vision', '2012-11-30', 'Yahoo Email ID', 'f10', '2', '5', 'www.davisvision.com', 'ID: 789000733095\r\n\r\nCustomer Care : 1 800 999 5431');
INSERT INTO `credential` VALUES ('21', 'CIGNA', '2012-11-30', 'kareems78', 'f10', '2', '5', null, 'ID: U40574366 01\n\nAccount - 3209216\n\nCustomer Care : 800-244-6224\n\nwww.myCigna.com\n\nCigna Dental PPO\n\nRadius Network');
INSERT INTO `credential` VALUES ('22', 'Georgia Power', '2012-11-30', 'kareems78', 'f10', '2', '7', 'http://www.georgiapower.com/', 'Account No : 80852-13009\r\n\r\n1-888-660-5890');
INSERT INTO `credential` VALUES ('23', 'Visa Trax', '2012-11-30', 'kareems78', 'hafsa@10', '2', '2', 'https://app01.visatrax.com/inszoom_hosted_login.aspx?org_id=Ogtree', 'Registered with Amdocs Email ID');
INSERT INTO `credential` VALUES ('24', 'Pure Talk USA', '2012-11-30', '211100014177', 'f10', '2', '8', 'https://www.puretalkusa.com/', 'Customer Care : (877) 820-7873\r\n\r\nEmail : support@puretalkusa.com\r\n\r\nAccount No# 211100014177\r\nOrder No# 1892644\r\nSIM# 89014102255478559752\r\nPhone Number : 678-654-2211');
INSERT INTO `credential` VALUES ('25', 'Oracle', '2012-11-30', 'Gmail ID', 'F10', '2', '8', null, null);
INSERT INTO `credential` VALUES ('26', 'Safari Books Online', '2012-11-30', 'Amdocs EmailID', 'f10', '2', '8', 'http://www.safaribooksonline.com/', '');
INSERT INTO `credential` VALUES ('27', 'Junior Achievement', '2012-11-30', 'Amdocs EmailID', 'f10', '2', '8', 'http://jaog.convio.net/goto/TEAM1', '');
INSERT INTO `credential` VALUES ('28', 'Sears Card', '2012-11-30', 'kareems78', 'f10', '2', '8', 'https://www.citibank.com/us/cards/srs/index.jsp', '');
INSERT INTO `credential` VALUES ('29', 'Homes', '2012-11-30', 'kareemshaik', 'f10', '2', '8', 'http://www.homes.com', '');
INSERT INTO `credential` VALUES ('30', 'ATT Manual Jira ', '2012-11-30', 'ks589h', 'Rainbow@10', '2', '2', 'https://itrack.web.att.com/secure/Dashboard.jspa', '');
INSERT INTO `credential` VALUES ('32', 'eRenterPlan', '2012-11-30', 'Y! Mail', 'f10', '2', '6', 'http://my.erenterplan.com', 'Policy# 0030609238\r\n1 888 205 8118\r\n\r\nAuto Pay: CC ends with 8844');
INSERT INTO `credential` VALUES ('33', 'Zakat.org', '2012-11-30', 'Yahoo Email', 'f10', '2', '8', 'http://www.zakat.org', '');
INSERT INTO `credential` VALUES ('34', 'Comcast', '2012-11-30', 'kareemshaik@comcast.net', 'f10', '2', '8', 'https://login.comcast.net/login', 'Account : 8220177050947301');
INSERT INTO `credential` VALUES ('35', 'AAA', '2012-11-30', 'kareems78', 'f10', '2', '8', null, 'Membership# 429-014-630180570-3');
INSERT INTO `credential` VALUES ('36', 'Evernote', '2012-11-30', 'karimshk', 'Aleena10', '2', '8', '', '');
INSERT INTO `credential` VALUES ('37', 'Apple ID', '2012-11-30', 'Gmail', 'F10', '2', '8', null, null);
INSERT INTO `credential` VALUES ('38', 'Roku', '2012-11-30', 'Y! Mail', 'f10', '2', '8', 'https://owner.roku.com/Login/', '');
INSERT INTO `credential` VALUES ('39', 'Cloud Acct', '2012-11-30', 'Y!Mail', 'f10', '2', '8', 'http://ksh.cloud-ide.com/cloud/ide.jsp', '');
INSERT INTO `credential` VALUES ('40', 'Apple iCloud', '2012-11-30', 'Gmail', 'F10', '2', '8', 'https://www.icloud.com/', '');
INSERT INTO `credential` VALUES ('41', 'DDS GA', '2012-11-30', 'Y! Mail', 'f10', '2', '8', 'https://online.dds.ga.gov/onlineservices/Account/Login.aspx', '');
INSERT INTO `credential` VALUES ('42', 'Old Navy', '2012-11-30', 'Y! Mail', 'f10', '2', '8', 'https://www3.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=oldnavy&accountType=plcc&mlink=5151,5838218,11&clink=5838218', 'Secret questions :\r\n\r\nIn which city your father was born - Vinukonda\r\n(V should be in CAPS)');
INSERT INTO `credential` VALUES ('43', 'American Express', '2012-11-30', 'kareems78', 'f10', '2', '8', 'https://www.americanexpress.com/', '');
INSERT INTO `credential` VALUES ('44', 'JCPenny', '2012-12-11', 'Y! Mail', 'f10', '2', '8', 'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=jcpenney&accountType=generic', 'Challenge Question:\r\nQ: In what city was your father born? (Enter full name of city only)?\r\nA: vinukonda');
INSERT INTO `credential` VALUES ('46', 'Babies R Us CC', '2013-05-13', 'Y! Mail', 'f10', '2', '11', 'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=tru&accountType=generic', '');
INSERT INTO `credential` VALUES ('47', 'Honda Services', '2013-05-14', 'kareems78', 'f10', '2', '10', 'http://www.hondafinancialservices.com/', '5/14\r\nAuto Pay is setup. from next month i.e. June, it will be deducted automatically. Paid already for current month.');
INSERT INTO `credential` VALUES ('48', 'Honda Owners', '2013-06-06', 'Y! Mail', 'f10', '2', '10', 'https://owners.honda.com', '');
INSERT INTO `credential` VALUES ('49', 'SBI Policy', '2013-06-11', 'na', 'na', '2', '6', 'https://mypolicy.sbilife.co.in/Home.aspx', 'Will be added once registration is completed\r\n\r\nPolicy No#\r\n35011356507 (Amt : 51890)\r\n\r\nPolicy No#\r\n44024676304 (Amt : 100000)');
INSERT INTO `credential` VALUES ('50', 'YMCA', '2013-06-12', 'Gmail', 'f10', '2', '1', 'https://spiritonline.ymcaatlanta.org/SpiritWeb/Login', 'ID : 962333');
INSERT INTO `credential` VALUES ('51', 'Paypal US', '2013-06-19', 'Gmail', 'f10', '2', '8', 'https://paypal.com', '');
INSERT INTO `credential` VALUES ('52', 'Paypal UK', '2013-06-19', 'Y! Mail', 'k10', '2', '8', '', '');
INSERT INTO `credential` VALUES ('53', 'Ring Britain', '2013-06-19', 'Y! Mail', 'f10', '2', '1', 'http://ringbritain.com/', 'Access Number : 678 791 4448\r\n\r\nPIN : 4320683709');
INSERT INTO `credential` VALUES ('54', 'SBI Online', '2013-06-25', 'kareems78', 'Hafsa@10', '2', '8', 'https://www.onlinesbi.com/retail/login.htm', 'Account No# 11348672342\r\nBranch: Mudfort\r\n\r\nprofile password : kareem@10\r\n\r\nKit No: C428307043\r\n\r\nIFC Code: SBIN0007111\r\nMICR Code: 500002051\r\n');
INSERT INTO `credential` VALUES ('55', 'SBI NRE Online', '2013-06-25', 'kareemsnre78', 'fnre@10', '2', '8', 'https://www.onlinesbi.com/retail/login.htm#', 'Account No# 31801448384\r\nBranch: Jubilee Hills\r\nKit No: C435807110\r\n\r\nprofile password : kareemnre@10\r\n\r\nFuture Company : my company\r\nIFC Code: SBIN0011745\r\n\r\n');
INSERT INTO `credential` VALUES ('56', 'State Farm', '2013-06-28', 'kareems78', 'f10', '2', '6', 'http://www.statefarm.com/', 'Auto/Home Insurance - Plan Number : 1301502727\r\n\r\nPolicy Nos#\r\nHonda Odyssey :\r\n713 9648-F28-11\r\n\r\nNissan Altima:\r\n713 9649-F28-11\r\n\r\nCustomer Care :  770 442 1440\r\n\r\nTrey : 770 253 2055 (Agent)\r\n\r\n');
INSERT INTO `credential` VALUES ('57', 'CI Medicine Records', '2013-06-30', 'Gmail', 'F10', '2', '5', 'https://my.patientfusion.com/', 'PIN : DRHBHRLC');
INSERT INTO `credential` VALUES ('58', 'HomeApps', '2013-07-02', 'karims', 'karims', '2', '8', 'http://localhost/HomeApps', '');
INSERT INTO `credential` VALUES ('59', 'WorkApps', '2013-07-02', 'kareems', 'f10', '2', '8', 'http://localhost/Work', '');
INSERT INTO `credential` VALUES ('60', 'Amdocs Connect', '2013-07-03', 'kareems', 'F10', '2', '2', 'https://amdocsconnect.uc.att.com/amdocsconnect/meet/?ExEventID=8780915 ', '');
INSERT INTO `credential` VALUES ('61', 'ATT Connect', '2013-07-03', 'Amdocs EmailID', '2428042', '2', '2', 'https://connect7.uc.att.com/attinc3/meet/?ExEventID=89756692', 'Below is the link to the 1 hour training. Once you are finished you would get email for setting up your ATT Connect account.\r\nhttp://etech.it.att.com/conferencing/\r\nATTConnect/Pages/VideoTraining.aspx\r\n \r\nattuid@itservices\r\n');
INSERT INTO `credential` VALUES ('62', 'ATT SVN', '2013-07-15', 'ks589h', 'Shaik10', '2', '2', '', 'SVN Admin : \r\nhttps://scm.it.att.com:8443/scmadmin\r\n\r\nCramer : \r\nsvn://scm.it.att.com:13280\r\n\r\nML : \r\nsvn://scm.it.att.com:13210/\r\n\r\nCore : \r\nsvn://scm.it.att.com:13320\r\n');
INSERT INTO `credential` VALUES ('63', 'Vonage', '2013-07-30', '7708818429', 'F10', '2', '1', 'http://www.vonage.com/customer', '');
INSERT INTO `credential` VALUES ('64', 'Dropbox', '2013-07-30', 'Gmail', 'f10', '2', '8', 'https://www.dropbox.com', '');
INSERT INTO `credential` VALUES ('65', 'Fedex', '2013-08-13', 'kareems10', 'f10', '2', '1', 'http://fedex.com/us/', 'Account : 4759-3766-0');
INSERT INTO `credential` VALUES ('66', 'ADP PayCheck', '2013-08-16', 'kshaik@amdocs', 'f10', '2', '2', 'https://ipay.adp.com/iPay/login.jsf', 'Amdocs PassCode - Amdocs-Amdocs\r\nCity/Town - GUNTUR\r\nMake and Year of first car : 2001 Nissan Altima GXE\r\nWhat was your favorite subject in school : Mathematics\r\n');
INSERT INTO `credential` VALUES ('67', 'Target Credit Card', '2013-09-06', 'kareems78', 'felisha10', '2', '9', 'https://rcam.target.com/default.aspx', '');
INSERT INTO `credential` VALUES ('68', 'Shahana BOA Online', '2013-09-06', 'shameen8609', 'f10', '2', '8', 'http://bankofamerica.com', 'Access ID : 7708818429\r\nPIN : 670812');
INSERT INTO `credential` VALUES ('69', 'NextGen Patient Portal', '2013-10-02', 'kareems78', 'f10', '2', '5', 'https://www.nextmd.com/Login/Login.aspx', 'Security Token : 868-05-597\r\n\r\nGA Urology Address:\r\n1357 Hembree Road, Alpharetta GA\r\n Suite 250\r\n\r\nSecurity Questions :\r\nQ: In which city did you meet your spouse ?\r\nA: hyderabad\r\n\r\nQ: What is the city of honeymoon ?\r\nA: kullu manali');
INSERT INTO `credential` VALUES ('70', 'Reward R Us', '2013-10-09', 'Y! Mail', 'F10', '2', '1', 'https://rewardsrus.toysrus.com/', 'Membership# 2100058690159');
INSERT INTO `credential` VALUES ('71', 'Nissan Leaf Account', '2013-10-22', 'kareems78', 'F10', '2', '1', 'https://www.nissanfinance.com/nmaccss/', 'NMAC Number : 25006904468\r\n\r\nVIN : 1N4AZ0CP2DC414197\r\n\r\nBought in : 10/2013 - Check docs for correct date');
INSERT INTO `credential` VALUES ('72', 'Kohls', '2013-10-22', 'kareems78', 'F10', '2', '11', 'https://credit.kohls.com/eCustService/', '');
INSERT INTO `credential` VALUES ('73', 'Xoom', '2013-10-22', 'Y! Mail', 'f10', '2', '8', 'https://www.xoom.com', '');
INSERT INTO `credential` VALUES ('74', 'Amli Resident Portal', '2013-10-25', 'kareems78', 'f10', '2', '1', 'https://property.onesite.realpage.com/welcomehome/?siteid=1011366#url=%23login', '');

-- ----------------------------
-- Table structure for `creditcard`
-- ----------------------------
DROP TABLE IF EXISTS `creditcard`;
CREATE TABLE `creditcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKCREDITCARD_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of creditcard
-- ----------------------------
INSERT INTO `creditcard` VALUES ('1', 'GAP', null);
INSERT INTO `creditcard` VALUES ('2', 'JCPenny', null);
INSERT INTO `creditcard` VALUES ('3', 'Kohls', null);
INSERT INTO `creditcard` VALUES ('4', 'Old Navy', null);
INSERT INTO `creditcard` VALUES ('5', 'Macys', null);
INSERT INTO `creditcard` VALUES ('6', 'TJX Rewards', null);
INSERT INTO `creditcard` VALUES ('7', 'BOA - 1741', null);
INSERT INTO `creditcard` VALUES ('8', 'BOA - 8844', null);
INSERT INTO `creditcard` VALUES ('9', 'Babies R Us CC', 'Babies R Us Credit Card');
INSERT INTO `creditcard` VALUES ('10', 'BOA - 9384', 'BOA - Better balance rewards card');
INSERT INTO `creditcard` VALUES ('11', 'American Express', 'American Express Credit Card');
INSERT INTO `creditcard` VALUES ('12', 'Target Credit Card', '');

-- ----------------------------
-- Table structure for `creditpayment`
-- ----------------------------
DROP TABLE IF EXISTS `creditpayment`;
CREATE TABLE `creditpayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referenceno` varchar(50) NOT NULL,
  `creditcard` int(11) NOT NULL,
  `datepaid` date NOT NULL,
  `datededucted` date DEFAULT NULL,
  `user` bigint(20) NOT NULL,
  `amount` float(11,5) NOT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426O` (`creditcard`) USING BTREE,
  KEY `FKCREDITPAYMENT_USER` (`user`),
  CONSTRAINT `FKCREDITPAYMENT_CC` FOREIGN KEY (`creditcard`) REFERENCES `creditcard` (`id`),
  CONSTRAINT `FKCREDITPAYMENT_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of creditpayment
-- ----------------------------
INSERT INTO `creditpayment` VALUES ('1', '180396693', '7', '2013-05-29', null, '2', '300.00000', '');
INSERT INTO `creditpayment` VALUES ('2', '180396692', '8', '2013-05-29', null, '2', '100.00000', '');
INSERT INTO `creditpayment` VALUES ('3', '2783469176', '10', '2013-05-29', null, '2', '13.94000', 'Purchase from walmart');
INSERT INTO `creditpayment` VALUES ('4', '531675766', '4', '2013-07-13', null, '2', '28.34000', 'Bought t-shirt & pant for myself');
INSERT INTO `creditpayment` VALUES ('5', '2799444325', '10', '2013-07-16', null, '2', '61.01000', '');
INSERT INTO `creditpayment` VALUES ('6', '4199460424', '8', '2013-07-16', null, '2', '0.72000', '');
INSERT INTO `creditpayment` VALUES ('7', '540030197', '4', '2013-07-30', '2013-08-08', '2', '26.65000', '');
INSERT INTO `creditpayment` VALUES ('8', '3881185523', '7', '2013-08-06', null, '2', '327.12000', '');
INSERT INTO `creditpayment` VALUES ('9', '2825694505', '7', '2013-08-11', '2013-09-03', '2', '12.51000', '');
INSERT INTO `creditpayment` VALUES ('10', '1525744897', '8', '2013-08-11', '2013-08-11', '2', '11.50000', '');
INSERT INTO `creditpayment` VALUES ('11', '225758750', '7', '2013-08-11', '2013-09-03', '2', '50.36000', '');
INSERT INTO `creditpayment` VALUES ('12', '547364900', '4', '2013-08-16', null, '2', '50.00000', '');
INSERT INTO `creditpayment` VALUES ('13', 'S1013', '11', '2013-08-16', null, '2', '72.64000', '');
INSERT INTO `creditpayment` VALUES ('14', '2709091081', '8', '2013-08-21', null, '2', '26.02000', '');
INSERT INTO `creditpayment` VALUES ('15', '3809099314', '7', '2013-08-21', null, '2', '580.03998', '');
INSERT INTO `creditpayment` VALUES ('16', '3809106815', '10', '2013-08-21', '2013-08-21', '2', '57.18000', '');
INSERT INTO `creditpayment` VALUES ('17', 'W0856', '11', '2013-08-22', '2013-09-01', '2', '20.17000', '');
INSERT INTO `creditpayment` VALUES ('18', '554628141', '4', '2013-09-04', '2013-09-05', '2', '2.85000', '');
INSERT INTO `creditpayment` VALUES ('19', '339490878', '7', '2013-09-05', '2013-09-05', '2', '650.00000', '');
INSERT INTO `creditpayment` VALUES ('20', '1639512889', '8', '2013-09-05', '2013-09-05', '2', '10.00000', '');
INSERT INTO `creditpayment` VALUES ('21', '159132290', '12', '2013-09-06', '2013-09-06', '2', '55.00000', '');
INSERT INTO `creditpayment` VALUES ('22', '142890181', '7', '2013-09-17', '2013-09-17', '2', '300.00000', '');
INSERT INTO `creditpayment` VALUES ('23', '1522775514', '7', '2013-09-26', '2013-09-26', '2', '300.00000', '');
INSERT INTO `creditpayment` VALUES ('24', '1602062803', '7', '2013-10-17', '2013-10-17', '2', '500.00000', '');
INSERT INTO `creditpayment` VALUES ('25', '1602075248', '10', '2013-10-17', '2013-10-17', '2', '50.00000', '');
INSERT INTO `creditpayment` VALUES ('26', '2802084054', '8', '2013-10-17', '2013-10-17', '2', '31.28000', '');
INSERT INTO `creditpayment` VALUES ('27', '13102288457221', '3', '2013-10-22', '2013-10-22', '2', '46.39000', '');
INSERT INTO `creditpayment` VALUES ('28', '3770733805', '7', '2013-10-25', '2013-10-25', '2', '500.00000', '');
INSERT INTO `creditpayment` VALUES ('29', '577801941', '4', '2013-10-31', '2013-10-31', '2', '68.44000', 'Discount Code ;\r\nVBZCZ7HFJJTR');

-- ----------------------------
-- Table structure for `dplan`
-- ----------------------------
DROP TABLE IF EXISTS `dplan`;
CREATE TABLE `dplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `breakfast` blob NOT NULL,
  `lunch` blob NOT NULL,
  `snacks` blob NOT NULL,
  `dinner` blob NOT NULL,
  `workouts` blob NOT NULL,
  `user` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDPLAN_USER` (`user`),
  CONSTRAINT `FKDPLAN_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dplan
-- ----------------------------
INSERT INTO `dplan` VALUES ('2', 'Monday', 0x4F617473202620746561, 0x53616C6164202B204275747465726D696C6B, 0x4672756974732C20436F666665652F477265656E20546561, 0x3120526F7469, 0x54726561646D696C6C203A203232206D696E730D0A5075736820557073203A20312D3130206D696E73, '2');
INSERT INTO `dplan` VALUES ('3', 'Tuesday', 0x536372616D626C656420456767202B20546561, 0x52696365202844616C29202B20436869636B656E, 0x4672756974732C20477265656E20546561, 0x3120526F7469, 0x54726561646D696C6C203A203130206D696E730D0A52496E67203A203130206D696E73, '2');
INSERT INTO `dplan` VALUES ('4', 'Wednesday', 0x4F617473202620436F66666565, 0x53616C61642C2042616B65642046697368, 0x4672756974732C20477265656E20546561, 0x3120526F7469, 0x4E6F6E65, '2');
INSERT INTO `dplan` VALUES ('5', 'Thursday', 0x4F6174732C204672756974204A756963652F546561, 0x3220526F746973, 0x4672756974732C20477265656E20546561, 0x4E6F, 0x54726561646D696C6C203A203235206D696E730D0A52696E67203A2035206D696E730D0A5075736820557073203A2035206D696E73, '2');
INSERT INTO `dplan` VALUES ('6', 'Friday', 0x536372616D626C6564204567672C20436F66666565, 0x526F7469202620436869636B656E, 0x4672756974732C20477265656E20546561, 0x53616C6164, 0x54726561646D696C6C3A203135206D696E730D0A52696E67203A2035206D696E0D0A50757368207570733A203135206D696E73, '2');
INSERT INTO `dplan` VALUES ('7', 'Saturday', 0x496E6469616E20427265616B66617374, 0x4E6F2043686F696365, 0x4672756974732C20477265656E20546561, 0x526F7469, 0x4E6F6E65, '2');
INSERT INTO `dplan` VALUES ('8', 'Sunday', 0x4F6174732C20477265656E20546561, 0x4E6F2043686F696365, 0x4672756974732C20477265656E20546561, 0x42616B656420466973682C20312F3220526F7469, 0x54726561646D696C6C203A203130206D696E730D0A52696E67203A203130206D696E73, '2');

-- ----------------------------
-- Table structure for `dtasks`
-- ----------------------------
DROP TABLE IF EXISTS `dtasks`;
CREATE TABLE `dtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasktimetext` varchar(255) NOT NULL,
  `tasktime` time DEFAULT NULL,
  `createddate` date NOT NULL,
  `updateddate` date DEFAULT NULL,
  `task` blob NOT NULL,
  `user` bigint(11) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKDTASKS_USER` (`user`),
  CONSTRAINT `FKDTASKS_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dtasks
-- ----------------------------
INSERT INTO `dtasks` VALUES ('23', '5:30 AM', '05:30:00', '2013-09-11', '2013-09-11', 0x57616B65205570, '2', '');
INSERT INTO `dtasks` VALUES ('24', '5:45 AM', '05:45:00', '2013-09-11', '2013-09-11', 0x526561642053757261682059617365656E, '2', '');
INSERT INTO `dtasks` VALUES ('25', '6:15 AM', '06:15:00', '2013-09-11', '2013-09-11', 0x507261796572, '2', '');
INSERT INTO `dtasks` VALUES ('26', '6:30 AM', '06:30:00', '2013-09-11', '2013-09-11', 0x57616B65205570204861667361, '2', '');
INSERT INTO `dtasks` VALUES ('27', '6:50 AM', '06:50:00', '2013-09-11', '2013-09-11', 0x53746172742066656564696E67204861667361, '2', '');
INSERT INTO `dtasks` VALUES ('28', '7:20 AM', '07:20:00', '2013-09-11', '2013-09-11', 0x4C6561766520666F72205363686F6F6C, '2', '');
INSERT INTO `dtasks` VALUES ('29', '8:30 AM', '08:30:00', '2013-09-11', '2013-09-11', 0x50726179204973687261617120616E642052656369746520517572616E, '2', '');
INSERT INTO `dtasks` VALUES ('30', '9:00 AM', '09:00:00', '2013-09-11', '2013-09-11', 0x47796D20666F72203135206D696E73, '2', '');
INSERT INTO `dtasks` VALUES ('31', '9:20 AM', '09:20:00', '2013-09-11', '2013-09-11', 0x54616B652062617468, '2', '');
INSERT INTO `dtasks` VALUES ('32', '9:30 AM', '09:30:00', '2013-09-11', '2013-09-11', 0x427265616B66617374, '2', '');
INSERT INTO `dtasks` VALUES ('33', '12:00 PM', '12:00:00', '2013-09-11', '2013-09-11', 0x4C756E6368, '2', '');
INSERT INTO `dtasks` VALUES ('34', '12:15 PM', '12:15:00', '2013-09-11', '2013-09-11', 0x4C6561766520746F207069636B204861667361, '2', '');
INSERT INTO `dtasks` VALUES ('35', '12:45 PM', '12:45:00', '2013-09-11', '2013-09-11', 0x4C6561766520666F72206F6666696365, '2', '');
INSERT INTO `dtasks` VALUES ('36', '9:00 PM', '21:00:00', '2013-09-11', '2013-09-11', 0x44696E6E6572, '2', 0x74727920746F2066696E697368206265666F72652049736861);

-- ----------------------------
-- Table structure for `ecategory`
-- ----------------------------
DROP TABLE IF EXISTS `ecategory`;
CREATE TABLE `ecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKECAT_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ecategory
-- ----------------------------
INSERT INTO `ecategory` VALUES ('1', 'Electronics', 'Category for electronics');
INSERT INTO `ecategory` VALUES ('2', 'Grocery', null);
INSERT INTO `ecategory` VALUES ('3', 'Clothes', null);
INSERT INTO `ecategory` VALUES ('4', 'Car/Gas', null);
INSERT INTO `ecategory` VALUES ('5', 'Meat', null);
INSERT INTO `ecategory` VALUES ('6', 'Home Decor', null);
INSERT INTO `ecategory` VALUES ('7', 'Restuarants', null);
INSERT INTO `ecategory` VALUES ('8', 'Medical', null);
INSERT INTO `ecategory` VALUES ('9', 'Misc', null);
INSERT INTO `ecategory` VALUES ('10', 'Bills/Electricity', null);
INSERT INTO `ecategory` VALUES ('11', 'Home Appliances', null);
INSERT INTO `ecategory` VALUES ('12', 'Food/Fruits', null);
INSERT INTO `ecategory` VALUES ('13', 'Cosmetics', null);
INSERT INTO `ecategory` VALUES ('14', 'Transport', null);
INSERT INTO `ecategory` VALUES ('15', 'Car/Oil Change', null);
INSERT INTO `ecategory` VALUES ('16', 'Car/Misc', null);
INSERT INTO `ecategory` VALUES ('17', 'Food/Misc', null);
INSERT INTO `ecategory` VALUES ('18', 'Household Items', null);
INSERT INTO `ecategory` VALUES ('19', 'House Rent', null);
INSERT INTO `ecategory` VALUES ('20', 'Bills/Vonage', null);
INSERT INTO `ecategory` VALUES ('21', 'Bills/Wireless', null);
INSERT INTO `ecategory` VALUES ('22', 'Gifts', null);
INSERT INTO `ecategory` VALUES ('23', 'CC Payments', 'credit card payments');
INSERT INTO `ecategory` VALUES ('24', 'Baby Expenses', 'Temporary Category to keep track of Aalia\'s expenses');

-- ----------------------------
-- Table structure for `expense`
-- ----------------------------
DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expensedate` date NOT NULL,
  `category` int(11) NOT NULL,
  `user` bigint(20) NOT NULL,
  `amount` float(11,5) NOT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEXPENSE_USER` (`user`),
  KEY `FKEXPENSE_ECAT` (`category`) USING BTREE,
  CONSTRAINT `FKEXPENSE_ECAT` FOREIGN KEY (`category`) REFERENCES `ecategory` (`id`),
  CONSTRAINT `FKEXPENSE_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of expense
-- ----------------------------
INSERT INTO `expense` VALUES ('13', '2012-11-24', '1', '2', '996.00000', 'Nikon D7000 from BH&P');
INSERT INTO `expense` VALUES ('14', '2012-11-24', '8', '2', '26.74000', 'Prilosec');
INSERT INTO `expense` VALUES ('15', '2012-11-24', '9', '2', '16.95000', 'USPS - Medicines');
INSERT INTO `expense` VALUES ('16', '2012-11-24', '12', '2', '16.44000', 'Walmart');
INSERT INTO `expense` VALUES ('17', '2012-11-25', '8', '2', '5.34000', 'Anti Fungal cream');
INSERT INTO `expense` VALUES ('18', '2012-11-25', '7', '2', '26.08000', 'Karachi Broast');
INSERT INTO `expense` VALUES ('20', '2012-11-27', '12', '2', '4.18000', 'Papaya');
INSERT INTO `expense` VALUES ('21', '2012-11-27', '2', '2', '4.81000', 'Milk & Tomatoes');
INSERT INTO `expense` VALUES ('22', '2012-11-27', '13', '2', '16.05000', 'Eye liner from Macys');
INSERT INTO `expense` VALUES ('23', '2012-11-27', '3', '2', '12.27000', 'Children\'s Place');
INSERT INTO `expense` VALUES ('24', '2012-11-28', '14', '2', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('25', '2012-11-28', '4', '2', '40.08000', 'Gas');
INSERT INTO `expense` VALUES ('26', '2012-11-30', '9', '2', '33.81000', 'Fee Sabilillah for Darul Huda Masjid from Snellville');
INSERT INTO `expense` VALUES ('27', '2012-12-01', '15', '2', '21.23000', '@ Sears Auto Center. Need to change brake fluid, pwr steering fluid');
INSERT INTO `expense` VALUES ('28', '2012-11-30', '2', '2', '20.83000', 'Onions, Eggs, Curd, Chapatis');
INSERT INTO `expense` VALUES ('29', '2012-11-30', '12', '2', '6.99000', 'Oranges');
INSERT INTO `expense` VALUES ('30', '2012-11-30', '18', '2', '27.60000', 'Cascade, Lays, Lysol - 2, Shampoo, Perfume');
INSERT INTO `expense` VALUES ('31', '2012-12-01', '7', '2', '14.96000', 'Amma\'s Kitchen');
INSERT INTO `expense` VALUES ('32', '2012-12-01', '2', '2', '85.66000', 'Spices Hut');
INSERT INTO `expense` VALUES ('33', '2012-12-03', '21', '2', '40.64000', 'Comcast Bill Payment\r\n\r\nConfirmation No# F8MXZ-CFPZ7\r\nWill be paid on 12/4');
INSERT INTO `expense` VALUES ('34', '2012-12-04', '2', '2', '3.41000', 'Milk from Harys Market');
INSERT INTO `expense` VALUES ('35', '2012-12-04', '9', '2', '1.99000', 'lip balm');
INSERT INTO `expense` VALUES ('36', '2012-12-05', '2', '2', '10.88000', 'India Plaza - Cilantro, Mint, Curd, eggplant and sweet');
INSERT INTO `expense` VALUES ('37', '2012-11-29', '7', '2', '12.84000', 'Papa Johns');
INSERT INTO `expense` VALUES ('38', '2012-11-29', '17', '2', '5.14000', 'Soda & Bagels from Kroger');
INSERT INTO `expense` VALUES ('40', '2012-12-03', '19', '2', '1132.15002', 'Amli');
INSERT INTO `expense` VALUES ('43', '2012-12-05', '18', '2', '6.60000', 'from walmart');
INSERT INTO `expense` VALUES ('44', '2012-12-06', '6', '2', '20.33000', 'Bamboo Matchstick rollup blinds');
INSERT INTO `expense` VALUES ('45', '2012-12-06', '18', '2', '4.16000', 'Walmart');
INSERT INTO `expense` VALUES ('46', '2012-12-07', '10', '2', '91.30000', 'Georgia Power');
INSERT INTO `expense` VALUES ('47', '2012-12-07', '2', '2', '3.29000', 'Milk from Harry\'s Market');
INSERT INTO `expense` VALUES ('48', '2012-12-07', '2', '2', '10.88000', 'India Plaza');
INSERT INTO `expense` VALUES ('49', '2012-12-08', '4', '2', '31.69000', '');
INSERT INTO `expense` VALUES ('50', '2012-12-08', '17', '2', '8.12000', 'Tea snacks & Biscuits');
INSERT INTO `expense` VALUES ('51', '2012-12-10', '2', '2', '16.86000', 'Costco - Rice etc');
INSERT INTO `expense` VALUES ('52', '2012-12-10', '20', '2', '35.91000', '');
INSERT INTO `expense` VALUES ('53', '2012-12-10', '18', '2', '15.38000', 'Walmart');
INSERT INTO `expense` VALUES ('54', '2012-12-12', '18', '2', '43.29000', 'Ross');
INSERT INTO `expense` VALUES ('55', '2012-12-12', '9', '2', '30.34000', 'Nail Polish, Battery, Axe Shaving');
INSERT INTO `expense` VALUES ('56', '2012-12-13', '18', '2', '12.24000', 'Walmart - ToothPaste, Bulb, Pouch');
INSERT INTO `expense` VALUES ('57', '2012-12-13', '12', '2', '6.00000', 'Costco - Watermelon');
INSERT INTO `expense` VALUES ('58', '2012-12-13', '2', '2', '5.31000', 'Costco - Onions');
INSERT INTO `expense` VALUES ('59', '2012-12-15', '1', '2', '32.09000', 'Targus Cooling Mat from Walmart');
INSERT INTO `expense` VALUES ('60', '2012-12-15', '22', '2', '14.02000', 'for Faiz\'s son');
INSERT INTO `expense` VALUES ('61', '2012-12-15', '3', '2', '2.00000', 'for baby - shoes');
INSERT INTO `expense` VALUES ('62', '2012-12-15', '7', '2', '14.09000', 'Panera Bread');
INSERT INTO `expense` VALUES ('63', '2012-12-15', '12', '2', '1.00000', 'Banana');
INSERT INTO `expense` VALUES ('64', '2012-12-15', '2', '2', '13.33000', 'Walmart - Tilapia, Cookies, Eggs, Chips');
INSERT INTO `expense` VALUES ('65', '2012-12-16', '22', '2', '1.04000', 'Gift bag from Walmart');
INSERT INTO `expense` VALUES ('66', '2012-12-16', '2', '2', '3.29000', 'Harry\'s Milk');
INSERT INTO `expense` VALUES ('67', '2012-12-17', '14', '2', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('68', '2013-05-16', '14', '2', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('69', '2013-05-15', '17', '2', '2.04000', 'Choco chips from Walmart');
INSERT INTO `expense` VALUES ('70', '2013-05-15', '9', '2', '20.00000', 'Ijtima');
INSERT INTO `expense` VALUES ('71', '2013-05-16', '7', '2', '6.49000', 'Taco Bell');
INSERT INTO `expense` VALUES ('72', '2013-05-17', '9', '2', '1.36000', 'Marker from Walmart');
INSERT INTO `expense` VALUES ('73', '2013-05-17', '17', '2', '6.36000', 'India Plaza');
INSERT INTO `expense` VALUES ('74', '2013-05-18', '2', '2', '4.91000', 'Methi from India Plaza');
INSERT INTO `expense` VALUES ('75', '2013-05-18', '24', '2', '50.65000', 'Diapers from Costco');
INSERT INTO `expense` VALUES ('76', '2013-05-19', '9', '2', '4.59000', 'Walmart');
INSERT INTO `expense` VALUES ('77', '2013-05-20', '16', '2', '70.00000', 'Power Steering oil leak repair');
INSERT INTO `expense` VALUES ('78', '2013-05-24', '17', '2', '12.82000', 'Milk & Shampoo from Harry\'s');
INSERT INTO `expense` VALUES ('79', '2013-05-26', '2', '2', '59.69000', 'India Plaza - Rice & veg');
INSERT INTO `expense` VALUES ('80', '2013-05-27', '9', '2', '17.54000', 'Formula & Misc from Walmart');
INSERT INTO `expense` VALUES ('81', '2013-05-28', '3', '2', '24.24000', 'Lining clothes from Joan');
INSERT INTO `expense` VALUES ('82', '2013-05-28', '8', '2', '16.35000', 'Tylenol from Walgreens');
INSERT INTO `expense` VALUES ('83', '2013-05-29', '23', '2', '413.94000', 'Credit Card payments');
INSERT INTO `expense` VALUES ('84', '2013-05-27', '24', '2', '24.00000', 'baby formula');
INSERT INTO `expense` VALUES ('104', '2013-05-29', '8', '2', '6.35000', 'Ibrufen from walgreens');
INSERT INTO `expense` VALUES ('105', '2013-05-29', '2', '2', '15.05000', 'Al Madina\r\n- Dates\r\n- Snacks\r\n- Roti');
INSERT INTO `expense` VALUES ('107', '2013-08-01', '2', '1', '10.00000', '');

-- ----------------------------
-- Table structure for `exportmodules`
-- ----------------------------
DROP TABLE IF EXISTS `exportmodules`;
CREATE TABLE `exportmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKEXPMOD_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exportmodules
-- ----------------------------
INSERT INTO `exportmodules` VALUES ('1', 'Fund Transfers', null);
INSERT INTO `exportmodules` VALUES ('2', 'Contacts', null);
INSERT INTO `exportmodules` VALUES ('3', 'Credentials', null);

-- ----------------------------
-- Table structure for `fundstransfer`
-- ----------------------------
DROP TABLE IF EXISTS `fundstransfer`;
CREATE TABLE `fundstransfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referenceno` varchar(255) NOT NULL,
  `datesent` date NOT NULL,
  `transferredto` int(11) NOT NULL,
  `user` bigint(20) NOT NULL,
  `amount` bigint(11) NOT NULL,
  `destamount` bigint(11) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFUNDSTRANSFER_ACCT` (`transferredto`) USING BTREE,
  KEY `FKFUNDSTRANSFER_USER` (`user`),
  CONSTRAINT `FKFUNDSTRANSFER_ACCT` FOREIGN KEY (`transferredto`) REFERENCES `account` (`id`),
  CONSTRAINT `FKFUNDSTRANSFER_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fundstransfer
-- ----------------------------
INSERT INTO `fundstransfer` VALUES ('4', '1695742001', '2008-11-17', '3', '2', '1200', '59709', '');
INSERT INTO `fundstransfer` VALUES ('5', '1695742002', '2008-11-21', '3', '2', '1500', '73950', null);
INSERT INTO `fundstransfer` VALUES ('6', '1695742003', '2008-12-07', '3', '2', '1500', '72195', null);
INSERT INTO `fundstransfer` VALUES ('7', '1695742004', '2008-12-22', '2', '2', '1000', '46909', null);
INSERT INTO `fundstransfer` VALUES ('8', '1695742005', '2008-12-29', '3', '2', '500', '23955', null);
INSERT INTO `fundstransfer` VALUES ('9', '1695742006', '2009-01-06', '2', '2', '1001', '48313', null);
INSERT INTO `fundstransfer` VALUES ('10', '1695742007', '2009-01-19', '3', '2', '1001', '48463', null);
INSERT INTO `fundstransfer` VALUES ('11', '1695742008', '2009-01-21', '2', '2', '1001', '48233', null);
INSERT INTO `fundstransfer` VALUES ('12', '1695742009', '2009-02-20', '3', '2', '1001', '49292', null);
INSERT INTO `fundstransfer` VALUES ('13', '1695742010', '2009-03-06', '2', '2', '1001', '50926', null);
INSERT INTO `fundstransfer` VALUES ('14', '1695742011', '2009-03-24', '2', '2', '1001', '50215', null);
INSERT INTO `fundstransfer` VALUES ('15', '1695742012', '2009-03-24', '3', '2', '1100', '55189', null);
INSERT INTO `fundstransfer` VALUES ('16', '1695742013', '2009-04-24', '3', '2', '1001', '49555', null);
INSERT INTO `fundstransfer` VALUES ('17', '1695742014', '2009-05-12', '2', '2', '1100', '53693', null);
INSERT INTO `fundstransfer` VALUES ('18', '1695742015', '2009-05-20', '3', '2', '1001', '46882', null);
INSERT INTO `fundstransfer` VALUES ('19', '1695742016', '2009-06-08', '2', '2', '1100', '51460', null);
INSERT INTO `fundstransfer` VALUES ('20', '1695742017', '2009-06-08', '3', '2', '1000', '46571', null);
INSERT INTO `fundstransfer` VALUES ('21', '1695742018', '2009-07-11', '3', '2', '1000', '47705', null);
INSERT INTO `fundstransfer` VALUES ('22', '1695742019', '2009-08-24', '3', '2', '1150', '55482', null);
INSERT INTO `fundstransfer` VALUES ('23', '1695742020', '2009-09-19', '3', '2', '1100', '52274', null);
INSERT INTO `fundstransfer` VALUES ('24', '1695742021', '2009-10-16', '3', '2', '1100', '50316', null);
INSERT INTO `fundstransfer` VALUES ('25', '1695742022', '2009-11-10', '3', '2', '1500', '68295', null);
INSERT INTO `fundstransfer` VALUES ('26', '1695742023', '2009-12-15', '3', '2', '1150', '53124', null);
INSERT INTO `fundstransfer` VALUES ('27', '1695742024', '2010-01-05', '2', '2', '1500', '67905', null);
INSERT INTO `fundstransfer` VALUES ('28', '1695742025', '2010-01-19', '3', '2', '1100', '50129', null);
INSERT INTO `fundstransfer` VALUES ('29', '1695742026', '2010-02-22', '3', '2', '1100', '50294', null);
INSERT INTO `fundstransfer` VALUES ('30', '1695742027', '2010-02-25', '2', '2', '1500', '68310', null);
INSERT INTO `fundstransfer` VALUES ('31', '1695742028', '2010-03-22', '3', '2', '1100', '49535', null);
INSERT INTO `fundstransfer` VALUES ('32', '1695742029', '2010-03-29', '2', '2', '2000', '88705', null);
INSERT INTO `fundstransfer` VALUES ('33', '1695742030', '2010-04-26', '2', '2', '2001', '88269', null);
INSERT INTO `fundstransfer` VALUES ('34', '1695742031', '2010-04-26', '3', '2', '1001', '43999', null);
INSERT INTO `fundstransfer` VALUES ('35', '1695742032', '2010-05-17', '2', '2', '1010', '46244', null);
INSERT INTO `fundstransfer` VALUES ('36', '1695742033', '2010-05-17', '3', '2', '1100', '50371', null);
INSERT INTO `fundstransfer` VALUES ('37', '1695742034', '2010-06-21', '2', '2', '2001', '91551', null);
INSERT INTO `fundstransfer` VALUES ('38', '1695742035', '2010-06-21', '3', '2', '1100', '50162', null);
INSERT INTO `fundstransfer` VALUES ('39', '1695742036', '2010-07-19', '2', '2', '1010', '47092', null);
INSERT INTO `fundstransfer` VALUES ('40', '1695742037', '2010-07-19', '3', '2', '1100', '51295', null);
INSERT INTO `fundstransfer` VALUES ('41', '1695742038', '2010-08-24', '2', '2', '2100', '97239', null);
INSERT INTO `fundstransfer` VALUES ('42', '1695742039', '2010-09-21', '3', '2', '1050', '47123', null);
INSERT INTO `fundstransfer` VALUES ('43', '1695742040', '2010-10-18', '3', '2', '1001', '43768', null);
INSERT INTO `fundstransfer` VALUES ('44', '1695742041', '2010-10-18', '2', '2', '2001', '87799', null);
INSERT INTO `fundstransfer` VALUES ('45', '1695742042', '2010-11-24', '3', '2', '1261', '57069', null);
INSERT INTO `fundstransfer` VALUES ('46', '1695742043', '2010-12-20', '2', '2', '1100', '48893', null);
INSERT INTO `fundstransfer` VALUES ('47', '1695742044', '2011-01-13', '2', '2', '2300', '103379', null);
INSERT INTO `fundstransfer` VALUES ('48', '1695742045', '2011-01-26', '2', '2', '2300', '104791', null);
INSERT INTO `fundstransfer` VALUES ('49', '1695742046', '2011-02-15', '2', '2', '1100', '49089', null);
INSERT INTO `fundstransfer` VALUES ('50', '1695742047', '2011-02-15', '3', '2', '2200', '98357', null);
INSERT INTO `fundstransfer` VALUES ('51', '1695742048', '2011-02-23', '2', '2', '3500', '156695', null);
INSERT INTO `fundstransfer` VALUES ('52', '1695742049', '2011-03-28', '4', '2', '1400', '61345', null);
INSERT INTO `fundstransfer` VALUES ('53', '1695742050', '2011-03-28', '2', '2', '2100', '92760', null);
INSERT INTO `fundstransfer` VALUES ('54', '1695742051', '2011-04-04', '3', '2', '3100', '135616', null);
INSERT INTO `fundstransfer` VALUES ('55', '1695742052', '2011-04-18', '3', '2', '2100', '92002', null);
INSERT INTO `fundstransfer` VALUES ('56', '1695742053', '2011-05-18', '2', '2', '1100', '48990', null);
INSERT INTO `fundstransfer` VALUES ('57', '1695742054', '2011-05-18', '3', '2', '1100', '48990', null);
INSERT INTO `fundstransfer` VALUES ('58', '1695742055', '2011-06-06', '3', '2', '1500', '66273', null);
INSERT INTO `fundstransfer` VALUES ('59', '1695742056', '2011-06-20', '3', '2', '1100', '48664', null);
INSERT INTO `fundstransfer` VALUES ('60', '1695742057', '2011-06-30', '2', '2', '1600', '70150', null);
INSERT INTO `fundstransfer` VALUES ('61', '1695742058', '2011-07-11', '5', '2', '1100', '48189', null);
INSERT INTO `fundstransfer` VALUES ('62', '1695742059', '2011-07-18', '2', '2', '1600', '70277', null);
INSERT INTO `fundstransfer` VALUES ('63', '1695742060', '2011-08-05', '2', '2', '1600', '71156', null);
INSERT INTO `fundstransfer` VALUES ('64', '1695742061', '2011-09-19', '2', '2', '1100', '52782', null);
INSERT INTO `fundstransfer` VALUES ('65', '1695742062', '2011-09-27', '2', '2', '2100', '102296', null);
INSERT INTO `fundstransfer` VALUES ('66', '1695742063', '2011-10-18', '1', '2', '1300', '64437', null);
INSERT INTO `fundstransfer` VALUES ('67', '1695742064', '2011-11-09', '1', '2', '1300', '65145', null);
INSERT INTO `fundstransfer` VALUES ('68', '1695742065', '2011-11-29', '5', '2', '1300', '66097', null);
INSERT INTO `fundstransfer` VALUES ('69', '1695742066', '2011-12-13', '1', '2', '1300', '67667', null);
INSERT INTO `fundstransfer` VALUES ('70', '1695742067', '2012-01-19', '1', '2', '1300', '67343', null);
INSERT INTO `fundstransfer` VALUES ('71', '1695742068', '2012-02-08', '4', '2', '6100', '0', 'Closed');
INSERT INTO `fundstransfer` VALUES ('72', '1695742069', '2012-02-16', '4', '2', '6100', '295488', null);
INSERT INTO `fundstransfer` VALUES ('73', '1695742070', '2012-03-12', '4', '2', '1300', '64397', null);
INSERT INTO `fundstransfer` VALUES ('74', '1695742071', '2012-04-09', '4', '2', '1600', '81552', null);
INSERT INTO `fundstransfer` VALUES ('75', '1695742072', '2012-04-16', '1', '2', '1300', '66832', null);
INSERT INTO `fundstransfer` VALUES ('76', '1695742073', '2012-05-06', '2', '2', '2600', '137594', 'SBI Life Insurance');
INSERT INTO `fundstransfer` VALUES ('77', '1695742074', '2012-05-21', '2', '2', '1300', '71262', null);
INSERT INTO `fundstransfer` VALUES ('78', '1695742075', '2012-06-04', '4', '2', '1300', '70786', null);
INSERT INTO `fundstransfer` VALUES ('79', '1695742076', '2012-06-04', '1', '2', '1600', '87138', null);
INSERT INTO `fundstransfer` VALUES ('80', '1695742077', '2012-06-25', '4', '2', '1200', '65809', null);
INSERT INTO `fundstransfer` VALUES ('81', '1695742078', '2012-07-25', '1', '2', '1600', '87598', null);
INSERT INTO `fundstransfer` VALUES ('82', '1695742079', '2012-08-03', '1', '2', '1300', '71066', null);
INSERT INTO `fundstransfer` VALUES ('83', '1695742080', '2012-08-10', '1', '2', '2100', '115431', null);
INSERT INTO `fundstransfer` VALUES ('107', '1695742081', '2012-09-12', '2', '2', '1300', '69752', null);
INSERT INTO `fundstransfer` VALUES ('108', '1695742082', '2012-10-20', '1', '2', '1300', '69044', null);
INSERT INTO `fundstransfer` VALUES ('109', '1695742083', '2012-11-09', '2', '2', '1300', '70124', '');
INSERT INTO `fundstransfer` VALUES ('110', '1695742084', '2012-12-15', '2', '2', '1300', null, '');
INSERT INTO `fundstransfer` VALUES ('111', 'X061897859282994', '2013-08-21', '2', '2', '650', '40641', '');
INSERT INTO `fundstransfer` VALUES ('112', 'X061895073730255', '2013-08-21', '6', '2', '500', '31505', '');
INSERT INTO `fundstransfer` VALUES ('113', 'X061862428712637', '2013-09-13', '7', '2', '355', '216', 'To UK : 216 pounds');
INSERT INTO `fundstransfer` VALUES ('114', 'X061826285974043', '2013-09-26', '2', '2', '670', '40764', '');
INSERT INTO `fundstransfer` VALUES ('115', 'X061899553080381', '2013-10-22', '2', '2', '1050', '63945', '');

-- ----------------------------
-- Table structure for `maghribsalahtimings`
-- ----------------------------
DROP TABLE IF EXISTS `maghribsalahtimings`;
CREATE TABLE `maghribsalahtimings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dayno` int(11) NOT NULL,
  `jan` varchar(10) NOT NULL,
  `feb` varchar(10) NOT NULL,
  `mar` varchar(10) NOT NULL,
  `apr` varchar(10) NOT NULL,
  `may` varchar(10) NOT NULL,
  `jun` varchar(10) NOT NULL,
  `jul` varchar(10) NOT NULL,
  `aug` varchar(10) NOT NULL,
  `sept` varchar(10) NOT NULL,
  `oct` varchar(10) NOT NULL,
  `nov` varchar(10) NOT NULL,
  `dec` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of maghribsalahtimings
-- ----------------------------
INSERT INTO `maghribsalahtimings` VALUES ('1', '1', '5:46', '6:13', '6:40', '8:04', '8:27', '8:49', '8:58', '8:43', '8:08', '7:27', '6:50', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('2', '2', '5:46', '6:15', '6:40', '8:05', '8:27', '8:49', '8:58', '8:42', '8:07', '7:26', '6:50', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('3', '3', '5:46', '6:16', '6:42', '8:05', '8:28', '8:50', '8:57', '8:41', '8:06', '7:24', '6:49', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('4', '4', '5:47', '6:17', '6:42', '8:06', '8:29', '8:50', '8:57', '8:40', '8:04', '7:23', '6:48', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('5', '5', '5:48', '6:18', '6:43', '8:07', '8:30', '8:51', '8:57', '8:40', '8:03', '7:22', '6:47', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('6', '6', '5:49', '6:19', '6:44', '8:08', '8:30', '8:51', '8:57', '8:39', '8:02', '7:20', '6:46', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('7', '7', '5:50', '6:19', '6:45', '8:08', '8:31', '8:52', '8:57', '8:38', '8:00', '7:19', '6:46', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('8', '8', '5:51', '6:20', '7:46', '8:09', '8:32', '8:52', '8:57', '8:37', '7:59', '7:18', '5:45', '5:34');
INSERT INTO `maghribsalahtimings` VALUES ('9', '9', '5:52', '6:22', '7:46', '8:10', '8:33', '8:53', '8:56', '8:36', '7:58', '7:16', '5:44', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('10', '10', '5:52', '6:23', '7:47', '8:11', '8:34', '8:53', '8:56', '8:35', '7:56', '7:15', '5:43', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('11', '11', '5:54', '6:24', '7:48', '8:11', '8:34', '8:54', '8:56', '8:34', '7:55', '7:14', '5:42', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('12', '12', '5:55', '6:25', '7:49', '8:12', '8:35', '8:54', '8:55', '8:33', '7:53', '7:13', '5:42', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('13', '13', '5:56', '6:26', '7:50', '8:13', '8:36', '8:55', '8:55', '8:31', '7:52', '7:11', '5:41', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('14', '14', '5:57', '6:27', '7:50', '8:14', '8:37', '8:55', '8:55', '8:30', '7:51', '7:10', '5:41', '5:35');
INSERT INTO `maghribsalahtimings` VALUES ('15', '15', '5:58', '6:27', '7:51', '8:14', '8:37', '8:55', '8:54', '8:29', '7:49', '7:09', '5:40', '5:36');
INSERT INTO `maghribsalahtimings` VALUES ('16', '16', '5:58', '6:29', '7:52', '8:15', '8:38', '8:56', '8:54', '8:28', '7:48', '7:08', '5:39', '5:36');
INSERT INTO `maghribsalahtimings` VALUES ('17', '17', '5:59', '6:29', '7:53', '8:16', '8:39', '8:56', '8:53', '8:27', '7:46', '7:07', '5:39', '5:37');
INSERT INTO `maghribsalahtimings` VALUES ('18', '18', '6:01', '6:30', '7:53', '8:17', '8:39', '8:56', '8:53', '8:26', '7:45', '7:05', '5:38', '5:37');
INSERT INTO `maghribsalahtimings` VALUES ('19', '19', '6:02', '6:31', '7:54', '8:17', '8:40', '8:56', '8:52', '8:25', '7:44', '7:04', '5:38', '5:38');
INSERT INTO `maghribsalahtimings` VALUES ('20', '20', '6:03', '6:32', '7:55', '8:18', '8:41', '8:57', '8:52', '8:23', '7:42', '7:03', '5:37', '5:38');
INSERT INTO `maghribsalahtimings` VALUES ('21', '21', '6:04', '6:32', '7:56', '8:19', '8:42', '8:57', '8:51', '8:22', '7:41', '7:02', '5:37', '5:38');
INSERT INTO `maghribsalahtimings` VALUES ('22', '22', '6:05', '6:33', '7:56', '8:20', '8:42', '8:57', '8:51', '8:21', '7:39', '7:01', '5:37', '5:39');
INSERT INTO `maghribsalahtimings` VALUES ('23', '23', '6:06', '6:34', '7:57', '8:20', '8:43', '8:57', '8:50', '8:20', '7:38', '7:00', '5:36', '5:40');
INSERT INTO `maghribsalahtimings` VALUES ('24', '24', '6:06', '6:36', '7:58', '8:21', '8:44', '8:57', '8:49', '8:19', '7:37', '6:59', '5:36', '5:40');
INSERT INTO `maghribsalahtimings` VALUES ('25', '25', '6:07', '6:36', '7:59', '8:22', '8:44', '8:58', '8:49', '8:17', '7:35', '6:57', '5:36', '5:41');
INSERT INTO `maghribsalahtimings` VALUES ('26', '26', '6:08', '6:37', '7:59', '8:23', '8:45', '8:58', '8:48', '8:16', '7:34', '6:56', '5:35', '5:41');
INSERT INTO `maghribsalahtimings` VALUES ('27', '27', '6:09', '6:38', '8:00', '8:24', '8:46', '8:58', '8:47', '8:15', '7:33', '6:55', '5:35', '5:42');
INSERT INTO `maghribsalahtimings` VALUES ('28', '28', '6:10', '6:39', '8:01', '8:24', '8:46', '8:58', '8:46', '8:14', '7:31', '6:54', '5:35', '5:42');
INSERT INTO `maghribsalahtimings` VALUES ('29', '29', '6:11', '6:39', '8:02', '8:25', '8:47', '8:58', '8:46', '8:12', '7:30', '6:53', '5:35', '5:43');
INSERT INTO `maghribsalahtimings` VALUES ('30', '30', '6:12', '', '8:02', '8:26', '8:48', '8:58', '8:45', '8:11', '7:28', '6:52', '5:34', '5:44');
INSERT INTO `maghribsalahtimings` VALUES ('31', '31', '6:12', '', '8:03', '', '8:48', '', '8:44', '8:10', '', '6:51', '', '5:45');

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKMEMBER_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('1', 'Kareem', null);
INSERT INTO `member` VALUES ('2', 'Shahana', null);
INSERT INTO `member` VALUES ('3', 'Hafsa', null);
INSERT INTO `member` VALUES ('4', 'Aalia', null);

-- ----------------------------
-- Table structure for `menu`
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `createddate` date DEFAULT NULL,
  `updateddate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKMENU_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', 'Home', '', '2012-10-04', '2013-10-08');
INSERT INTO `menu` VALUES ('2', 'Personal Apps', 'Tasks, Expenses, Credentials, Misc etc', '2012-10-04', '2013-10-08');
INSERT INTO `menu` VALUES ('3', 'Islamic Apps', 'Salah Timings & Tracker, Duas etc', '2012-10-04', '2013-10-08');
INSERT INTO `menu` VALUES ('4', 'Misc Apps', 'Weight Recorder, Biometrics, Online Orders, Credit Payments, Funds Transfer etc', '2012-10-04', '2013-10-08');
INSERT INTO `menu` VALUES ('5', 'Contact', '', '2012-10-04', '2013-10-08');
INSERT INTO `menu` VALUES ('6', 'Admin Apps', '', '2013-10-08', '2013-10-08');

-- ----------------------------
-- Table structure for `month`
-- ----------------------------
DROP TABLE IF EXISTS `month`;
CREATE TABLE `month` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKMONTH_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of month
-- ----------------------------
INSERT INTO `month` VALUES ('1', 'January', 'Jan');
INSERT INTO `month` VALUES ('2', 'February', 'Feb');
INSERT INTO `month` VALUES ('3', 'March', 'Mar');
INSERT INTO `month` VALUES ('4', 'April', 'Apr');
INSERT INTO `month` VALUES ('5', 'May', 'May');
INSERT INTO `month` VALUES ('6', 'June', 'Jun');
INSERT INTO `month` VALUES ('7', 'July', 'Jul');
INSERT INTO `month` VALUES ('8', 'August', 'Aug');
INSERT INTO `month` VALUES ('9', 'September', 'Sept');
INSERT INTO `month` VALUES ('10', 'October', 'Oct');
INSERT INTO `month` VALUES ('11', 'November', 'Nov');
INSERT INTO `month` VALUES ('12', 'December', 'Dec');

-- ----------------------------
-- Table structure for `onlineorders`
-- ----------------------------
DROP TABLE IF EXISTS `onlineorders`;
CREATE TABLE `onlineorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderno` varchar(50) NOT NULL,
  `ordername` varchar(500) NOT NULL,
  `orderdate` date NOT NULL,
  `user` bigint(20) NOT NULL,
  `orderamount` float(11,5) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKOORDERS_ORDERNO` (`orderno`) USING BTREE,
  KEY `UKOORDERS_USER` (`user`),
  CONSTRAINT `UKOORDERS_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of onlineorders
-- ----------------------------
INSERT INTO `onlineorders` VALUES ('1', '11-8905985', 'Nissan Blower Motor Resistor', '2013-07-10', '2', '41.20000', 0x4F7264657265642066726F6D2070617274736765656B2E636F6D);
INSERT INTO `onlineorders` VALUES ('2', '108-0838122-7813048', 'Deva Vegan Capsules', '2013-08-15', '2', '26.02000', 0x46726F6D20416D617A6F6E0D0A0D0A457374696D617465642044656C69766572792028382F3232202D20382F323629);
INSERT INTO `onlineorders` VALUES ('3', '2677176-965090', 'Wireless Keyboard', '2013-10-01', '2', '21.28000', '');
INSERT INTO `onlineorders` VALUES ('4', 'VIB Card', '7776755469', '2013-10-03', '2', '50.00000', '');
INSERT INTO `onlineorders` VALUES ('5', '295284', 'Nissan EMI', '2013-10-22', '2', '311.95001', 0x31302F3232202D20416D6F756E7420697320647565206F6E2031312F31);

-- ----------------------------
-- Table structure for `pagesettings`
-- ----------------------------
DROP TABLE IF EXISTS `pagesettings`;
CREATE TABLE `pagesettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tablename` varchar(50) NOT NULL,
  `page` varchar(30) NOT NULL,
  `columnname` varchar(50) NOT NULL,
  `coldisplay` varchar(50) NOT NULL,
  `visible` varchar(10) NOT NULL,
  `user` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKPAGESETTINGS_USER` (`user`),
  CONSTRAINT `FKPAGESETTINGS_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pagesettings
-- ----------------------------
INSERT INTO `pagesettings` VALUES ('1', 'salahtracker', 'View', 'createddate', 'Created Date', 'yes', '2');
INSERT INTO `pagesettings` VALUES ('2', 'salahtracker', 'View', 'updateddate', 'Updated Date', 'yes', '2');
INSERT INTO `pagesettings` VALUES ('3', 'salahtracker', 'Search', 'createddate', 'Created Date', 'yes', '2');
INSERT INTO `pagesettings` VALUES ('4', 'salahtracker', 'Search', 'updateddate', 'Updated Date', 'yes', '2');

-- ----------------------------
-- Table structure for `plotdetails`
-- ----------------------------
DROP TABLE IF EXISTS `plotdetails`;
CREATE TABLE `plotdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datesent` varchar(20) NOT NULL,
  `amount` float NOT NULL,
  `user` bigint(20) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKPLOTDETAILS_USER` (`user`),
  CONSTRAINT `FKPLOTDETAILS_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of plotdetails
-- ----------------------------
INSERT INTO `plotdetails` VALUES ('1', '2/16/2012', '295488', '2', '');
INSERT INTO `plotdetails` VALUES ('2', '3/12/2012', '64397', '2', '');
INSERT INTO `plotdetails` VALUES ('3', '4/16/2012', '81552', '2', '');
INSERT INTO `plotdetails` VALUES ('4', '6/4/2012', '70786', '2', '');
INSERT INTO `plotdetails` VALUES ('5', '6/25/2012', '65809', '2', '');
INSERT INTO `plotdetails` VALUES ('6', '8/11/2012', '30000', '2', '');
INSERT INTO `plotdetails` VALUES ('7', '8/18/2012', '50000', '2', '');
INSERT INTO `plotdetails` VALUES ('8', '5/29/2013', '60775', '2', '');

-- ----------------------------
-- Table structure for `priority`
-- ----------------------------
DROP TABLE IF EXISTS `priority`;
CREATE TABLE `priority` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKPRIORITY_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of priority
-- ----------------------------
INSERT INTO `priority` VALUES ('1', 'Highest', 'Should be completed with in a day');
INSERT INTO `priority` VALUES ('2', 'High', 'Should be completed in 2 days');
INSERT INTO `priority` VALUES ('3', 'Medium', 'Should be completed in 4 days');
INSERT INTO `priority` VALUES ('4', 'Low', 'Should be completed in a week');

-- ----------------------------
-- Table structure for `projections`
-- ----------------------------
DROP TABLE IF EXISTS `projections`;
CREATE TABLE `projections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user` bigint(20) NOT NULL,
  `estimatedcost` float(11,5) NOT NULL,
  `actualcost` float(11,5) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKPROJECTIONS_USER` (`user`),
  CONSTRAINT `FKPROJECTIONS_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of projections
-- ----------------------------
INSERT INTO `projections` VALUES ('1', 'House Rent', '2', '1160.00000', '1160.00000', '');
INSERT INTO `projections` VALUES ('4', 'Vonage', '2', '18.00000', '18.00000', '');
INSERT INTO `projections` VALUES ('5', 'MARTA', '2', '25.00000', '25.00000', '');

-- ----------------------------
-- Table structure for `remainder`
-- ----------------------------
DROP TABLE IF EXISTS `remainder`;
CREATE TABLE `remainder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remainder` varchar(100) NOT NULL,
  `createddate` date NOT NULL,
  `lastremainder` date NOT NULL,
  `nextremainder` date NOT NULL,
  `user` bigint(20) NOT NULL,
  `daysafter` int(11) DEFAULT NULL,
  `daysbefore` int(11) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKREMAINDER_REM` (`remainder`) USING BTREE,
  KEY `FKREMAINDER_USER` (`user`),
  CONSTRAINT `FKREMAINDER_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of remainder
-- ----------------------------
INSERT INTO `remainder` VALUES ('1', 'Clean hair from body parts', '2012-11-12', '2013-10-05', '2013-11-02', '2', '30', '40', '');
INSERT INTO `remainder` VALUES ('2', 'Hair Cut', '2012-11-12', '2013-09-04', '2013-10-02', '2', '25', '30', '');
INSERT INTO `remainder` VALUES ('3', 'Nissan Oil Change', '2012-11-12', '2013-09-14', '2013-11-16', '2', '90', '100', '');
INSERT INTO `remainder` VALUES ('16', 'TV Subscription', '2012-11-19', '2013-09-18', '2014-01-20', '2', '0', '0', '');
INSERT INTO `remainder` VALUES ('18', 'Honda Oil Change', '2013-06-20', '2013-04-19', '2013-10-22', '2', '180', '190', '');
INSERT INTO `remainder` VALUES ('19', 'Stove top cleaning', '2013-07-27', '2013-10-10', '2013-11-30', '2', '25', '30', '');
INSERT INTO `remainder` VALUES ('20', 'Oven cleaning', '2013-07-27', '2013-08-27', '2013-09-30', '2', '25', '30', '');
INSERT INTO `remainder` VALUES ('27', 'Shahana Cavity filling', '2013-09-18', '2013-09-18', '2013-10-31', '2', '0', '0', '');

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKROLE_NAME` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'admin', '2012-09-26 16:52:45', '2012-09-26 16:52:56', null);
INSERT INTO `role` VALUES ('2', 'normal', '2012-09-26 16:53:16', '2012-09-26 16:53:18', null);

-- ----------------------------
-- Table structure for `salahtimings`
-- ----------------------------
DROP TABLE IF EXISTS `salahtimings`;
CREATE TABLE `salahtimings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dayrange` varchar(10) NOT NULL,
  `month` varchar(11) NOT NULL,
  `Fazr Begin` varchar(10) NOT NULL,
  `Fazr Iqama` varchar(10) NOT NULL,
  `Fazr Ends` varchar(10) NOT NULL,
  `Dhur Begin` varchar(10) NOT NULL,
  `Asr Begin` varchar(10) NOT NULL,
  `Asr Iqama` varchar(10) NOT NULL,
  `Isha Begin` varchar(10) NOT NULL,
  `Isha Iqama` varchar(10) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKSTIMINGS_MONTH` (`month`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of salahtimings
-- ----------------------------
INSERT INTO `salahtimings` VALUES ('1', '1-7', 'Jan', '6:15', '6:45', '7:42', '12:43', '3:28', '4:30', '7:13', '7:45', null);
INSERT INTO `salahtimings` VALUES ('2', '8-14', 'Jan', '6:15', '6:45', '7:42', '12:46', '3:31', '4:30', '7:18', '7:45', null);
INSERT INTO `salahtimings` VALUES ('3', '15-21', 'Jan', '6:15', '6:45', '7:40', '12:49', '3:37', '4:30', '7:24', '7:45', null);
INSERT INTO `salahtimings` VALUES ('4', '22-31', 'Jan', '6:13', '6:45', '7:35', '12:51', '3:46', '4:45', '7:32', '8:00', null);
INSERT INTO `salahtimings` VALUES ('5', '1-7', 'Feb', '6:08', '6:30', '7:30', '12:52', '3:51', '4:45', '7:38', '8:00', null);
INSERT INTO `salahtimings` VALUES ('6', '8-14', 'Feb', '6:04', '6:30', '7:23', '12:52', '3:56', '5:00', '7:44', '8:10', null);
INSERT INTO `salahtimings` VALUES ('7', '15-21', 'Feb', '5:58', '6:20', '7:16', '12:52', '4:00', '5:00', '7:49', '8:10', null);
INSERT INTO `salahtimings` VALUES ('8', '22-END', 'Feb', '5:50', '6:20', '7:07', '12:51', '4:05', '5:15', '7:56', '8:20', null);
INSERT INTO `salahtimings` VALUES ('9', '1-7', 'Mar', '5:42', '6:15', '6:58', '12:50', '4:08', '5:15', '8:01', '8:20', null);
INSERT INTO `salahtimings` VALUES ('10', '8-DST', 'Mar', '5:34', '6:15', '6:50', '12:48', '4:10', '5:30', '8:07', '8:30', null);
INSERT INTO `salahtimings` VALUES ('11', 'DST-21', 'Mar', '6:25', '6:45', '7:39', '1:47', '4:12', '6:15', '9:12', '9:30', null);
INSERT INTO `salahtimings` VALUES ('12', '22-31', 'Mar', '6:14', '6:45', '7:25', '1:44', '4:14', '6:30', '9:21', '9:40', null);
INSERT INTO `salahtimings` VALUES ('13', '1-7', 'Apr', '5:59', '6:30', '7:16', '1:41', '5:15', '6:30', '9:28', '9:45', null);
INSERT INTO `salahtimings` VALUES ('14', '8-14', 'Apr', '5:48', '6:15', '7:07', '1:39', '5:16', '6:30', '9:34', '9:50', null);
INSERT INTO `salahtimings` VALUES ('15', '15-21', 'Apr', '5:38', '6:15', '6:58', '1:37', '5:17', '6:30', '9:42', '10:00', null);
INSERT INTO `salahtimings` VALUES ('16', '22-30', 'Apr', '5:28', '6:00', '6:48', '1:36', '5:17', '6:45', '9:52', '10:05', null);
INSERT INTO `salahtimings` VALUES ('17', '1-7', 'May', '5:15', '6:00', '6:42', '1:35', '5:18', '6:45', '9:59', '10:15', null);
INSERT INTO `salahtimings` VALUES ('18', '8-14', 'May', '5:06', '5:50', '6:36', '1:34', '5:18', '6:45', '10:06', '10:20', null);
INSERT INTO `salahtimings` VALUES ('19', '15-21', 'May', '4:58', '5:50', '6:31', '1:34', '5:19', '6:45', '10:10', '10:25', null);
INSERT INTO `salahtimings` VALUES ('20', '22-31', 'May', '4:52', '5:45', '6:27', '1:35', '5:20', '7:00', '10:15', '10:30', null);
INSERT INTO `salahtimings` VALUES ('21', '1-7', 'Jun', '4:45', '5:45', '6:25', '1:36', '5:21', '7:00', '10:19', '10:35', null);
INSERT INTO `salahtimings` VALUES ('22', '8-14', 'Jun', '4:42', '5:40', '6:25', '1:38', '5:23', '7:00', '10:22', '10:35', null);
INSERT INTO `salahtimings` VALUES ('23', '15-21', 'Jun', '4:41', '5:40', '6:26', '1:39', '5:24', '7:00', '10:24', '10:40', null);
INSERT INTO `salahtimings` VALUES ('24', '22-30', 'Jun', '4:42', '5:45', '6:28', '1:41', '5:26', '7:00', '10:25', '10:40', null);
INSERT INTO `salahtimings` VALUES ('25', '1-7', 'Jul', '4:50', '5:45', '6:30', '1:42', '5:28', '7:00', '10:25', '10:40', null);
INSERT INTO `salahtimings` VALUES ('26', '8-14', 'Jul', '4:56', '5:50', '6:33', '1:43', '5:29', '7:00', '10:24', '10:40', null);
INSERT INTO `salahtimings` VALUES ('27', '15-21', 'Jul', '5:03', '5:50', '6:37', '1:44', '5:29', '7:00', '10:22', '10:35', null);
INSERT INTO `salahtimings` VALUES ('28', '22-31', 'Jul', '5:13', '6:00', '6:41', '1:44', '5:28', '7:00', '10:18', '10:35', null);
INSERT INTO `salahtimings` VALUES ('29', '1-7', 'Aug', '5:20', '6:00', '6:48', '1:44', '5:27', '6:45', '10:11', '10:25', null);
INSERT INTO `salahtimings` VALUES ('30', '8-14', 'Aug', '5:28', '6:10', '6:53', '1:43', '5:26', '6:45', '10:05', '10:15', null);
INSERT INTO `salahtimings` VALUES ('31', '15-21', 'Aug', '5:35', '6:10', '6:58', '1:42', '5:24', '6:45', '9:56', '10:15', null);
INSERT INTO `salahtimings` VALUES ('32', '22-31', 'Aug', '5:44', '6:15', '7:03', '1:40', '5:20', '6:30', '9:45', '10:00', null);
INSERT INTO `salahtimings` VALUES ('33', '1-7', 'Sept', '5:50', '6:15', '7:10', '1:37', '5:14', '6:30', '9:30', '9:45', null);
INSERT INTO `salahtimings` VALUES ('34', '8-14', 'Sept', '5:56', '6:30', '7:15', '1:35', '5:09', '6:15', '9:19', '9:30', null);
INSERT INTO `salahtimings` VALUES ('35', '15-21', 'Sept', '6:02', '6:30', '7:20', '1:32', '5:04', '6:15', '9:08', '9:20', null);
INSERT INTO `salahtimings` VALUES ('36', '22-30', 'Sept', '6:09', '6:40', '7:25', '1:30', '4:57', '6:00', '8:57', '9:15', null);
INSERT INTO `salahtimings` VALUES ('37', '1-7', 'Oct', '6:14', '6:40', '7:31', '1:27', '4:49', '6:00', '8:45', '9:00', null);
INSERT INTO `salahtimings` VALUES ('38', '8-14', 'Oct', '6:19', '6:50', '7:36', '1:25', '4:42', '5:45', '8:35', '8:45', null);
INSERT INTO `salahtimings` VALUES ('39', '15-21', 'Oct', '6:25', '6:50', '7:43', '1:23', '4:36', '5:45', '8:27', '8:45', null);
INSERT INTO `salahtimings` VALUES ('40', '22-31', 'Oct', '6:32', '7:00', '7:50', '1:22', '4:30', '5:30', '8:19', '8:30', null);
INSERT INTO `salahtimings` VALUES ('41', '1-DST', 'Nov', '6:37', '7:00', '7:56', '1:21', '4:22', '5:30', '8:09', '8:30', null);
INSERT INTO `salahtimings` VALUES ('42', 'DST-14', 'Nov', '5:43', '6:15', '7:03', '12:22', '3:18', '4:25', '7:05', '7:45', null);
INSERT INTO `salahtimings` VALUES ('43', '15-21', 'Nov', '5:49', '6:15', '7:10', '12:23', '3:13', '4:25', '7:00', '7:45', null);
INSERT INTO `salahtimings` VALUES ('44', '22-30', 'Nov', '5:56', '6:30', '7:16', '12:26', '3:11', '4:25', '6:58', '7:45', null);
INSERT INTO `salahtimings` VALUES ('45', '1-7', 'Dec', '6:01', '6:30', '7:24', '12:29', '3:10', '4:15', '6:57', '7:45', null);
INSERT INTO `salahtimings` VALUES ('46', '8-14', 'Dec', '6:06', '6:40', '7:30', '12:32', '3:11', '4:15', '6:59', '7:45', null);
INSERT INTO `salahtimings` VALUES ('47', '15-21', 'Dec', '6:10', '6:40', '7:35', '12:36', '3:14', '4:25', '7:02', '7:45', null);
INSERT INTO `salahtimings` VALUES ('48', '22-31', 'Dec', '6:13', '6:40', '7:39', '12:40', '3:10', '4:25', '7:07', '7:45', null);

-- ----------------------------
-- Table structure for `salahtracker`
-- ----------------------------
DROP TABLE IF EXISTS `salahtracker`;
CREATE TABLE `salahtracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime DEFAULT NULL,
  `user` bigint(20) NOT NULL,
  `fazr` varchar(10) DEFAULT NULL,
  `dhuhr` varchar(10) DEFAULT NULL,
  `asr` varchar(10) DEFAULT NULL,
  `maghrib` varchar(10) DEFAULT NULL,
  `isha` varchar(10) DEFAULT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKSTRACKER_SDATE` (`sdate`) USING BTREE,
  KEY `FKSTRACKER_USER` (`user`) USING BTREE,
  CONSTRAINT `FKSTRACKER_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of salahtracker
-- ----------------------------
INSERT INTO `salahtracker` VALUES ('2', '2013-05-28', '2013-05-28 00:00:00', '2013-05-28 00:00:00', '2', 'No', 'Yes', 'Yes', 'No', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('3', '2013-05-29', '2013-05-29 00:00:00', '2013-05-29 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('4', '2013-05-30', '2013-05-30 00:00:00', '2013-05-30 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('5', '2013-05-31', '2013-05-31 00:00:00', '2013-05-31 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('6', '2013-06-01', '2013-06-01 00:00:00', '2013-06-01 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('7', '2013-06-02', '2013-06-02 00:00:00', '2013-06-02 00:00:00', '2', 'Yes', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('8', '2013-06-03', '2013-06-03 00:00:00', '2013-06-03 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('9', '2013-06-04', '2013-06-04 00:00:00', '2013-06-04 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('11', '2013-06-05', '2013-06-05 00:00:00', '2013-06-05 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('12', '2013-06-06', '2013-06-06 00:00:00', '2013-06-06 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('13', '2013-06-07', '2013-06-07 00:00:00', '2013-06-07 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('14', '2013-06-08', '2013-06-08 00:00:00', '2013-06-08 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('15', '2013-06-09', '2013-06-09 00:00:00', '2013-06-09 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('16', '2013-06-10', '2013-06-10 00:00:00', '2013-06-10 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('17', '2013-06-11', '2013-06-11 00:00:00', '2013-06-11 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('18', '2013-06-12', '2013-06-12 00:00:00', '2013-06-12 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('19', '2013-06-13', '2013-06-13 00:00:00', '2013-06-13 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('20', '2013-06-14', '2013-06-14 00:00:00', '2013-06-14 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('21', '2013-06-15', '2013-06-15 00:00:00', '2013-06-15 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('22', '2013-06-16', '2013-06-16 00:00:00', '2013-06-16 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('23', '2013-06-17', '2013-06-17 00:00:00', '2013-06-17 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('24', '2013-06-18', '2013-06-18 00:00:00', '2013-06-18 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('25', '2013-06-19', '2013-06-19 00:00:00', '2013-06-19 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('26', '2013-06-20', '2013-06-20 00:00:00', '2013-06-20 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('27', '2013-06-21', '2013-06-21 00:00:00', '2013-06-21 00:00:00', '2', 'No', 'Yes', 'Yes', 'No', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('28', '2013-06-22', '2013-06-22 00:00:00', '2013-06-22 00:00:00', '2', 'Yes', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('29', '2013-06-23', '2013-06-23 00:00:00', '2013-06-23 00:00:00', '2', 'No', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('30', '2013-06-24', '2013-06-24 00:00:00', '2013-06-24 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('31', '2013-06-25', '2013-06-25 00:00:00', '2013-06-25 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('32', '2013-06-26', '2013-06-26 00:00:00', '2013-06-26 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('33', '2013-06-27', '2013-06-27 00:00:00', '2013-06-27 00:00:00', '2', 'No', 'Yes', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('34', '2013-06-29', '2013-06-29 00:00:00', '2013-06-29 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('35', '2013-06-30', '2013-06-30 00:00:00', '2013-06-30 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('36', '2013-07-01', '2013-07-01 00:00:00', '2013-07-01 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('37', '2013-07-02', '2013-07-02 00:00:00', '2013-07-02 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('38', '2013-07-03', '2013-07-03 00:00:00', '2013-07-03 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('39', '2013-07-04', '2013-07-04 00:00:00', '2013-07-04 00:00:00', '2', 'No', 'Yes', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('40', '2013-07-05', '2013-07-05 00:00:00', '2013-07-05 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('41', '2013-07-06', '2013-07-06 00:00:00', '2013-07-06 00:00:00', '2', 'No', 'Yes', 'Yes', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('42', '2013-07-07', '2013-07-07 00:00:00', '2013-07-07 00:00:00', '2', 'No', 'Yes', 'Yes', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('43', '2013-07-08', '2013-07-08 00:00:00', '2013-07-08 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('44', '2013-07-09', '2013-07-09 00:00:00', '2013-07-09 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('45', '2013-07-10', '2013-07-10 00:00:00', '2013-07-10 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('46', '2013-07-11', '2013-07-11 00:00:00', '2013-07-11 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('47', '2013-07-12', '2013-07-12 00:00:00', '2013-07-12 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('49', '2013-07-13', '2013-07-13 00:00:00', '2013-07-13 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('50', '2013-07-14', '2013-07-14 00:00:00', '2013-07-14 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('51', '2013-07-15', '2013-07-15 00:00:00', '2013-07-15 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('52', '2013-07-16', '2013-07-16 00:00:00', '2013-07-16 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('54', '2013-07-17', '2013-07-17 00:00:00', '2013-07-17 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('71', '2013-07-18', '2013-07-18 00:00:00', '2013-07-18 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('73', '2013-07-19', '2013-07-19 00:00:00', '2013-07-19 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('74', '2013-07-20', '2013-07-20 00:00:00', '2013-07-20 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('76', '2013-07-21', '2013-07-21 00:00:00', '2013-07-21 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('77', '2013-07-22', '2013-07-22 00:00:00', '2013-07-22 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('78', '2013-07-23', '2013-07-23 00:00:00', '2013-07-23 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('79', '2013-07-24', '2013-07-24 00:00:00', '2013-07-24 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('81', '2013-07-25', '2013-07-25 00:00:00', '2013-07-25 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('82', '2013-07-26', '2013-07-26 00:00:00', '2013-07-26 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('83', '2013-07-27', '2013-07-27 00:00:00', '2013-07-27 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('85', '2013-07-28', '2013-07-28 00:00:00', '2013-07-28 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('86', '2013-07-29', '2013-07-29 00:00:00', '2013-07-29 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('87', '2013-07-30', '2013-07-30 00:00:00', '2013-07-30 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('88', '2013-07-31', '2013-07-31 00:00:00', '2013-07-31 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('89', '2013-08-01', '2013-08-01 00:00:00', '2013-08-01 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('90', '2013-08-02', '2013-08-02 00:00:00', '2013-08-02 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('91', '2013-08-03', '2013-08-03 00:00:00', '2013-08-03 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('92', '2013-08-04', '2013-08-04 00:00:00', '2013-08-04 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('93', '2013-08-05', '2013-08-05 00:00:00', '2013-08-05 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('94', '2013-08-06', '2013-08-06 00:00:00', '2013-08-06 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('95', '2013-08-07', '2013-08-07 00:00:00', '2013-08-07 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('96', '2013-08-08', '2013-08-08 00:00:00', '2013-08-08 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('97', '2013-08-09', '2013-08-09 00:00:00', '2013-08-09 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('98', '2013-08-10', '2013-08-10 00:00:00', '2013-08-10 00:00:00', '2', 'Yes', 'No', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('99', '2013-08-12', '2013-08-12 00:00:00', '2013-08-12 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('100', '2013-08-13', '2013-08-13 00:00:00', '2013-08-13 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('101', '2013-08-11', '2013-08-11 00:00:00', '2013-08-11 00:00:00', '2', 'No', 'No', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('102', '2013-08-14', '2013-08-14 00:00:00', '2013-08-14 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('103', '2013-08-15', '2013-08-15 00:00:00', '2013-08-15 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('104', '2013-08-16', '2013-08-16 00:00:00', '2013-08-16 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('105', '2013-08-17', '2013-08-17 00:00:00', '2013-08-17 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('106', '2013-08-18', '2013-08-18 00:00:00', '2013-08-18 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('107', '2013-08-19', '2013-08-19 00:00:00', '2013-08-19 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('108', '2013-08-20', '2013-08-20 00:00:00', '2013-08-20 00:00:00', '2', 'Yes', 'No', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('109', '2013-08-21', '2013-08-21 00:00:00', '2013-08-21 00:00:00', '2', 'No', 'Yes', 'No', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('110', '2013-08-22', '2013-08-22 00:00:00', '2013-08-22 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('111', '2013-08-23', '2013-08-23 00:00:00', '2013-08-23 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('112', '2013-08-24', '2013-08-24 00:00:00', '2013-08-24 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('113', '2013-08-25', '2013-08-25 00:00:00', '2013-08-25 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('114', '2013-08-26', '2013-08-26 00:00:00', '2013-08-26 00:00:00', '2', 'No', 'Yes', 'Yes', 'No', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('115', '2013-08-27', '2013-08-27 00:00:00', '2013-08-27 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('118', '2013-08-28', '2013-08-28 00:00:00', '2013-08-28 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('119', '2013-08-29', '2013-08-29 00:00:00', '2013-08-29 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('120', '2013-08-30', '2013-08-30 00:00:00', '2013-08-30 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('121', '2013-08-31', '2013-08-31 00:00:00', '2013-08-31 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('122', '2013-09-01', '2013-09-01 00:00:00', '2013-09-01 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('123', '2013-09-02', '2013-09-02 00:00:00', '2013-09-02 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('124', '2013-09-03', '2013-09-03 00:00:00', '2013-09-03 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('125', '2013-09-04', '2013-09-04 00:00:00', '2013-09-04 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('126', '2013-09-05', '2013-09-05 00:00:00', '2013-09-05 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('127', '2013-09-06', '2013-09-06 00:00:00', '2013-09-06 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('128', '2013-09-07', '2013-09-07 00:00:00', '2013-09-07 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('129', '2013-09-08', '2013-09-08 00:00:00', '2013-09-08 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('130', '2013-09-09', '2013-09-09 00:00:00', '2013-09-10 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('131', '2013-09-10', '2013-09-10 00:00:00', '2013-09-11 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('133', '2013-09-11', '2013-09-11 00:00:00', '2013-09-12 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('134', '2013-09-12', '2013-09-12 00:00:00', '2013-09-13 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('135', '2013-09-13', '2013-09-13 00:00:00', '2013-09-16 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('136', '2013-09-14', '2013-09-16 00:00:00', null, '2', 'No', 'No', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('137', '1969-12-31', '2013-09-16 00:00:00', null, '2', 'No', 'Yes', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('138', '2013-09-16', '2013-09-16 00:00:00', '2013-09-17 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('139', '2013-09-15', '2013-09-16 00:00:00', null, '2', 'No', 'Yes', 'No', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('140', '2013-09-17', '2013-09-17 00:00:00', '2013-09-18 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('141', '2013-09-18', '2013-09-18 00:00:00', '2013-09-19 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('142', '2013-09-19', '2013-09-19 00:00:00', '2013-09-23 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('143', '2013-09-20', '2013-09-23 00:00:00', null, '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('144', '2013-09-21', '2013-09-23 00:00:00', null, '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('145', '2013-09-22', '2013-09-23 00:00:00', null, '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('147', '2013-09-23', '2013-09-23 00:00:00', '2013-09-24 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('148', '2013-09-24', '2013-09-24 00:00:00', '2013-09-25 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('149', '2013-09-25', '2013-09-25 00:00:00', '2013-09-25 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('150', '2013-09-26', '2013-09-26 00:00:00', '2013-09-27 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('151', '2013-09-27', '2013-09-27 00:00:00', '2013-09-28 00:00:00', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('152', '2013-09-28', '2013-09-28 00:00:00', '2013-10-01 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('153', '2013-09-29', '2013-10-01 00:00:00', null, '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('154', '2013-09-30', '2013-10-01 00:00:00', null, '2', 'No', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('155', '2013-10-01', '2013-10-01 00:00:00', '2013-10-02 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('156', '2013-10-02', '2013-10-02 00:00:00', '2013-10-03 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('157', '2013-10-03', '2013-10-03 00:00:00', '2013-10-04 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('158', '2013-10-04', '2013-10-04 00:00:00', '2013-10-05 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('159', '2013-10-05', '2013-10-06 00:00:00', null, '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('160', '2013-10-06', '2013-10-06 00:00:00', '2013-10-07 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('161', '2013-10-07', '2013-10-07 00:00:00', '2013-10-07 00:00:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('162', '2013-10-08', '2013-10-08 00:00:00', '2013-10-08 21:57:35', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('163', '2013-10-09', '2013-10-09 18:32:25', '2013-10-10 13:45:37', '2', 'Yes', 'No', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('164', '2013-10-10', '2013-10-10 13:45:47', '2013-10-11 10:31:43', '2', 'Yes', 'Yes', 'Yes', 'No', 'No', null);
INSERT INTO `salahtracker` VALUES ('165', '2013-10-11', '2013-10-11 10:31:55', '2013-10-12 20:44:25', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('166', '2013-10-12', '2013-10-12 20:44:34', '2013-10-16 09:53:12', '2', 'No', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('167', '2013-10-13', '2013-10-16 09:53:26', '2013-10-16 09:53:26', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('168', '2013-10-14', '2013-10-16 09:53:40', '2013-10-16 09:53:40', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('169', '2013-10-15', '2013-10-16 09:53:55', '2013-10-16 09:53:55', '2', 'Yes', 'No', 'No', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('170', '2013-10-16', '2013-10-16 09:54:02', '2013-10-17 10:09:24', '2', 'No', 'No', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('171', '2013-10-17', '2013-10-17 10:09:31', '2013-10-18 11:31:42', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('172', '2013-10-18', '2013-10-18 11:31:48', '2013-10-20 23:12:40', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('173', '2013-10-19', '2013-10-20 23:12:55', '2013-10-20 23:12:55', '2', 'No', 'Yes', 'Yes', 'No', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('174', '2013-10-20', '2013-10-20 23:13:06', '2013-10-20 23:13:06', '2', 'Yes', 'No', 'No', 'No', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('175', '2013-10-21', '2013-10-21 10:38:55', '2013-10-22 11:58:17', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('176', '2013-10-22', '2013-10-22 11:58:46', '2013-10-23 15:07:19', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('177', '2013-10-23', '2013-10-23 15:07:25', '2013-10-24 17:28:54', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('178', '2013-10-24', '2013-10-24 17:29:04', '2013-10-24 23:55:17', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', null);
INSERT INTO `salahtracker` VALUES ('179', '2013-10-25', '2013-10-25 12:11:41', '2013-10-26 10:07:46', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', null);
INSERT INTO `salahtracker` VALUES ('180', '2013-10-26', '2013-10-26 10:08:40', '2013-10-28 08:45:16', '2', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 0x4D69737365642046617A72);
INSERT INTO `salahtracker` VALUES ('181', '2013-10-27', '2013-10-28 08:45:42', '2013-10-28 08:45:42', '2', 'No', 'Yes', 'Yes', 'Yes', 'No', 0x4D69737365642046617A7220262049736861);
INSERT INTO `salahtracker` VALUES ('182', '2013-10-28', '2013-10-28 08:46:14', '2013-10-31 00:05:07', '2', 'No', 'Yes', 'No', 'Yes', 'Yes', 0x4D69737365642046617A720D0A4D697373656420417372);
INSERT INTO `salahtracker` VALUES ('183', '2013-10-29', '2013-10-31 00:05:47', '2013-10-31 00:05:47', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 0x4D69737365642049736861);
INSERT INTO `salahtracker` VALUES ('184', '2013-10-30', '2013-10-31 00:06:16', '2013-10-31 00:06:16', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '');
INSERT INTO `salahtracker` VALUES ('185', '2013-10-31', '2013-10-31 17:33:27', '2013-11-01 00:43:27', '2', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 0x4D6973736564204468756872);
INSERT INTO `salahtracker` VALUES ('186', '2013-11-01', '2013-11-01 23:08:00', '2013-11-01 23:08:00', '2', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '');

-- ----------------------------
-- Table structure for `status`
-- ----------------------------
DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKSTATUS_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of status
-- ----------------------------
INSERT INTO `status` VALUES ('1', 'Not Started', null);
INSERT INTO `status` VALUES ('2', 'In Progress', null);
INSERT INTO `status` VALUES ('3', 'Pending', null);
INSERT INTO `status` VALUES ('4', 'Completed', null);
INSERT INTO `status` VALUES ('5', 'Cancelled', null);

-- ----------------------------
-- Table structure for `submenu`
-- ----------------------------
DROP TABLE IF EXISTS `submenu`;
CREATE TABLE `submenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pagename` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `menu` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  `isdefault` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKSMENU_NAME` (`name`) USING BTREE,
  KEY `FKSMENU_MENU` (`menu`) USING BTREE,
  CONSTRAINT `FKSMENU_MENU` FOREIGN KEY (`menu`) REFERENCES `menu` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of submenu
-- ----------------------------
INSERT INTO `submenu` VALUES ('1', 'Blog', 'blog', null, '2', '', '2012-10-07 09:42:21', '2012-10-07 09:42:25', 'no');
INSERT INTO `submenu` VALUES ('2', 'Tasks', 'tasks', null, '2', 'tasktype', '2012-10-07 09:42:52', '2012-10-07 09:42:55', 'yes');
INSERT INTO `submenu` VALUES ('3', 'Expenses', 'expenses', null, '2', 'ecategory', '2012-10-07 09:43:09', '2012-10-07 09:43:15', 'no');
INSERT INTO `submenu` VALUES ('4', 'Credentials', 'credentials', null, '2', 'ccategory', '2012-10-07 09:43:41', '2012-10-07 09:43:44', 'no');
INSERT INTO `submenu` VALUES ('5', 'Contacts', 'contacts', null, '2', '', '2012-10-07 09:43:56', '2012-10-07 09:44:00', 'no');
INSERT INTO `submenu` VALUES ('6', 'Weight Recorder', 'weightrecorder', null, '4', 'member', '2012-10-07 09:42:21', '2012-10-07 09:42:21', 'no');
INSERT INTO `submenu` VALUES ('7', 'Credit Payment', 'creditpayment', null, '4', 'creditcard', '2012-10-07 09:42:21', '2012-10-07 09:42:21', 'no');
INSERT INTO `submenu` VALUES ('8', 'Funds Transfer', 'fundstransfer', null, '4', 'account', '2013-08-21 17:42:55', '2013-08-21 17:42:59', 'no');
INSERT INTO `submenu` VALUES ('9', 'Url Store', 'urlstore', null, '2', 'urltype', '2013-09-14 00:33:37', '2013-09-14 00:33:43', 'no');
INSERT INTO `submenu` VALUES ('11', 'Salah Timings', 'salahtimings', '', '3', '', '2013-10-05 09:31:14', '2013-10-05 09:31:14', 'no');
INSERT INTO `submenu` VALUES ('13', 'Salah Tracker', 'salahtracker', '', '3', '', '2013-10-05 09:40:40', '2013-10-05 09:40:40', 'no');
INSERT INTO `submenu` VALUES ('14', 'Remainders', 'remainders', '', '4', '', '2013-10-05 09:42:37', '2013-10-05 09:42:37', 'no');
INSERT INTO `submenu` VALUES ('15', 'Biometrics', 'biometrics', '', '4', '', '2013-10-05 09:43:02', '2013-10-05 10:15:19', 'no');
INSERT INTO `submenu` VALUES ('20', 'Online Orders', 'onlineorders', '', '4', '', '2013-10-05 11:26:40', '2013-10-05 11:26:40', 'no');
INSERT INTO `submenu` VALUES ('21', 'Users', 'users', '', '6', '', '2013-10-08 22:11:40', '2013-10-08 22:11:40', 'no');
INSERT INTO `submenu` VALUES ('22', 'Roles', 'roles', '', '6', '', '2013-10-08 22:25:06', '2013-10-08 22:25:06', 'no');
INSERT INTO `submenu` VALUES ('23', 'Modules', 'modules', '', '6', '', '2013-10-08 22:25:20', '2013-10-08 22:25:20', 'no');
INSERT INTO `submenu` VALUES ('24', 'Categories', 'allcategories', '', '6', '', '2013-10-08 22:25:54', '2013-10-08 22:25:54', 'no');

-- ----------------------------
-- Table structure for `subsubmenu`
-- ----------------------------
DROP TABLE IF EXISTS `subsubmenu`;
CREATE TABLE `subsubmenu` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  `submenu` int(11) NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_SSMENU_SUBMENU` (`submenu`) USING BTREE,
  CONSTRAINT `FK_SSMENU_SUBMENU` FOREIGN KEY (`submenu`) REFERENCES `submenu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of subsubmenu
-- ----------------------------
INSERT INTO `subsubmenu` VALUES ('1', 'Add', null, '5', '2012-10-07 09:44:27', '2012-10-07 09:44:30');
INSERT INTO `subsubmenu` VALUES ('2', 'View', null, '5', '2012-10-07 09:44:42', '2012-10-07 09:44:46');

-- ----------------------------
-- Table structure for `task`
-- ----------------------------
DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `priority` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `user` bigint(11) NOT NULL,
  `createddate` date NOT NULL,
  `duedate` date NOT NULL,
  `completeddate` date DEFAULT NULL,
  `status` int(11) NOT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKTASK_USER` (`user`),
  KEY `FKTASK_PRIORITY` (`priority`) USING BTREE,
  KEY `FKTASK_STATUS` (`status`) USING BTREE,
  KEY `FKTASK_TYPE` (`type`) USING BTREE,
  CONSTRAINT `FKTASK_PRIORITY` FOREIGN KEY (`priority`) REFERENCES `priority` (`id`),
  CONSTRAINT `FKTASK_STATUS` FOREIGN KEY (`status`) REFERENCES `status` (`id`),
  CONSTRAINT `FKTASK_TYPE` FOREIGN KEY (`type`) REFERENCES `tasktype` (`id`),
  CONSTRAINT `FKTASK_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of task
-- ----------------------------
INSERT INTO `task` VALUES ('110', 'Call Car Insurance Companies', '1', '2', '2', '2013-05-06', '2013-06-04', '2013-06-28', '4', 0x436865636B2077697468205374617465204661726D2066697273740D0A0D0A362F3238202D205374617465206661726D20696E737572616E636520686173206265656E2074616B656E);
INSERT INTO `task` VALUES ('111', 'Find Gastroenterologist', '3', '2', '2', '2013-05-06', '2013-05-16', '2013-06-26', '5', '');
INSERT INTO `task` VALUES ('112', 'Check tag', '2', '2', '2', '2013-05-06', '2013-05-08', '2013-05-11', '4', 0x6966206E6F7420617272697665642063616C6C20486F6E6461206361726C616E6420616E6420636865636B0D0A0D0A352F38202D20436865636B6564207769746820486F6E6461204361726C616E642C2054616720697320616C726561647920646F6E652C2069742077696C6C20636F6D6520696E2066657720646179732E);
INSERT INTO `task` VALUES ('113', 'Enroll into Honda Carland', '1', '1', '2', '2013-05-06', '2013-05-10', '2013-06-06', '4', 0x626F7468206F6E6C696E6520616E642073656E642063617264);
INSERT INTO `task` VALUES ('114', 'Call about ticket', '1', '2', '2', '2013-05-06', '2013-05-15', '2013-06-26', '4', '');
INSERT INTO `task` VALUES ('115', 'Copy Bayaans', '3', '2', '2', '2013-05-06', '2013-06-09', null, '2', 0x696E746F2069506F64);
INSERT INTO `task` VALUES ('116', 'Call Madhu Reddy', '1', '2', '2', '2013-05-06', '2013-05-08', '2013-05-14', '4', 0x666F7220726566696C6C0D0A352F39202D2063616C6C656420746F64617920616E642072657175657374656420746F2073656E6420707265736372697074696F6E20746F2057616C677265656E732E0D0A0D0A352F3134202D207069636B6564207570206D65646963696E652066726F6D2077616C677265656E73);
INSERT INTO `task` VALUES ('117', 'Call walmart cc', '1', '1', '2', '2013-05-06', '2013-05-09', '2013-05-06', '4', 0x436865636B20776879206920646964206E6F742067657420646973636F756E74206F66202432302075706F6E206F70656E696E6720636172640D0A0D0A352F36202D202432302077696C6C206265206465626974656420616E6420616C736F206C61746520666565206F66202432352077696C6C20626520776169766564);
INSERT INTO `task` VALUES ('118', 'Check immigration email', '1', '3', '2', '2013-05-13', '2013-05-13', '2013-05-14', '4', 0x352F3133202D20726573706F6E6420627920454F4420746F6461790D0A0D0A352F3134202D20636865636B6564204931323920616E642069742068617320626F74682074686520616464726573736573);
INSERT INTO `task` VALUES ('119', 'Transfer money', '2', '1', '2', '2013-05-17', '2013-05-20', '2013-05-24', '4', '');
INSERT INTO `task` VALUES ('120', 'Renew Home Lease', '1', '1', '2', '2013-05-28', '2013-06-11', '2013-07-01', '4', 0x362F3134202D2057656E7420746F206C656173696E67206F666669636520616E64207265717565737420746F20636F6E7369646572207265647563696E672072656E742E2057696C6C20676574207265706C79206279206E657874207765656B2E0D0A0D0A362F3330202D205369676E656420646F637320617265207375626D697474656420746F206C656173696E67206F6666696365206F6E2073756E6461792061742061726F756E6420323A333020504D);
INSERT INTO `task` VALUES ('121', 'Pay BOA CC bill', '2', '2', '2', '2013-05-28', '2013-06-05', '2013-05-29', '4', 0x4265747465722062616C616E636520726577617264730D0A0D0A352F3239202D2050616964);
INSERT INTO `task` VALUES ('122', 'Call YMCA', '1', '1', '2', '2013-06-03', '2013-06-03', '2013-06-23', '5', '');
INSERT INTO `task` VALUES ('123', 'Transfer money for Insurance', '1', '1', '2', '2013-06-04', '2013-06-17', '2013-06-18', '4', 0x534249202D20636865636B2077686574686572206973206974206F6B20746F2073656E6420616674657220313574680D0A0D0A362F3134202D205472616E7366657265642032353030);
INSERT INTO `task` VALUES ('124', 'Check error message', '1', '3', '2', '2013-06-07', '2013-06-10', '2013-06-13', '4', 0x362F372D20436865636B206572726F72206D65737361676520656D61696C2066726F6D2042696C6C20616E642073686F756C64207265736F6C76652074686973206279206D6F6E646179);
INSERT INTO `task` VALUES ('125', 'Cramer GUI issues email', '2', '3', '2', '2013-06-07', '2013-06-10', null, '5', 0x362F372D204372616D65722047554920656D61696C2066726F6D205368616E6B61720D0A362F3133202D2041736B65642042696B6B7920746F2074616B652061206C6F6F6B20617420746869732069737375650D0A0D0A362F3138202D2042696B6B792069732061626C6520746F207265706C696361746520616E6420666F756E642069742069732074696D696E67206F75742E0D0A0D0A5965732049207761732061626C6520746F20726570726F647563652E0D0A48617320616E797468696E67206368616E67656420696E205765626C6F6769632073657474696E6720636F6D7061726520746F206F7468657220656E7669726F6E6D656E74733F0D0A51756572792069732074696D696E67206F75743A0D0A0D0A4A756E2031382C203230313320383A34343A333120414D20636F6D2E6372616D65722E6F626A6563746D6F64656C2E0D0A7365727665722E70657273697374656E63652E64616F2E4E6F646544414F2067657443726F7373436F6E6E65637444657461696C730D0A5741524E494E473A2053514C204552524F523A20494F204572726F723A20536F636B657420726561642074696D6564206F75740D0A4A756E2031382C203230313320383A34343A333120414D20636F6D2E6372616D65722E636F72652E0D0A636F6D6D6F6E2E4372616D6572457863657074696F6E203C696E69743E0D0A5741524E494E473A204572726F722067657474696E672063726F737320636F6E6E65637420696E666F0D0A0D0A372F39202D206F6666206D7920706C617465206E6F770D0A);
INSERT INTO `task` VALUES ('126', 'Check 6PM', '1', '2', '2', '2013-06-13', '2013-06-21', null, '5', 0x54727920746F2062757920736F6D652067696674206265666F726520416E6E6976657273617279);
INSERT INTO `task` VALUES ('127', 'Transfer money for loan', '2', '1', '2', '2013-06-17', '2013-06-17', '2013-06-23', '4', '');
INSERT INTO `task` VALUES ('128', 'Check Citi Bank account', '3', '1', '2', '2013-06-17', '2013-06-17', null, '1', 0x43616C6C20436974692042616E6B20746F6E69676874);
INSERT INTO `task` VALUES ('130', 'Call Walmart Credit Card Department', '1', '1', '2', '2013-06-17', '2013-06-22', '2013-06-17', '4', 0x362F3137202D20546F20636865636B2061626F757420243230206475652073656E740D0A0D0A362F3137202D20243230206372656469742077696C6C2062652073656E7420696E20313020627573696E6573732064617973);
INSERT INTO `task` VALUES ('131', 'Kevin email regarding report', '2', '3', '2', '2013-06-18', '2013-06-18', '2013-06-20', '4', 0x362F3138202D20436865636B20776865746865722043495220697320696E204D6270730D0A0D0A362F3139202D204B6576696E207265706C6965642074686174207573657220646F206E6F74206E65656420616E79207265706F7274);
INSERT INTO `task` VALUES ('132', 'Daryl Emux report issue', '1', '3', '2', '2013-06-18', '2013-06-19', '2013-08-28', '4', 0x362F3138202D2048616420612063616C6C20746F6461792C2069206E65656420746F20636F6D7061726520756E6920696E76656E746F7279207265706F7274207769746820656D7578207265706F727420616E642073686F756C642066696E64206F7574207768792074686572652069732061206469666620696E20554E492073657276696365206E616D652028323030302076732038303030290D0A0D0A554E49202D2036302F4B52474E2F3735303835352F53422065786973747320696E20456D757820554E4920496E760D0A0D0A362F3234202D2073656E7420616E20656D61696C207769746820616E616C79736973);
INSERT INTO `task` VALUES ('133', 'L3 CFM report from Bill', '1', '3', '2', '2013-06-18', '2013-06-21', null, '5', 0x4E65656420746F2063726561746520612073637269707420746F2064656C657465204C332043464D);
INSERT INTO `task` VALUES ('134', 'Check Tax refunds', '3', '1', '2', '2013-06-20', '2013-06-24', '2013-06-20', '4', 0x497420686173206265656E207472616E7366657272656420626F7468207461786573);
INSERT INTO `task` VALUES ('135', 'UNI Service Activation Status', '2', '3', '2', '2013-06-25', '2013-06-27', '2013-07-10', '4', 0x362F3235202D2073656E7420616E20656D61696C20746F2042696B6B790D0A0D0A372F32202D202073656E7420616E20656D61696C2050616E6B616A20262044696E65736820736179696E67207468617420697420776F726B6564207573696E67204150490D0A0D0A372F39202D2050616E6B616A20746F6F6B207468697320414920616E642077696C6C20757064617465);
INSERT INTO `task` VALUES ('138', 'Topology Mismatch Report', '2', '3', '2', '2013-06-26', '2013-07-01', null, '5', 0x362F3236202D20436865636B20656D61696C2066726F6D2042696C6C20666F72206D6F726520696E666F0D0A42696C6C20746F6C64206D65206974206973206E6F742072657175697265642C20736F206368616E67696E6720746F2070656E64696E672C206D617920626520697420697320726571756972656420696E20667574757265);
INSERT INTO `task` VALUES ('139', 'NMVLAN 4091 Migration', '3', '3', '2', '2013-06-26', '2013-07-31', null, '5', '');
INSERT INTO `task` VALUES ('140', 'Return Cello tape at Walmart', '3', '1', '2', '2013-07-01', '2013-07-04', '2013-07-03', '4', '');
INSERT INTO `task` VALUES ('141', 'Deposit check in BOA', '3', '1', '2', '2013-07-01', '2013-07-04', '2013-07-05', '4', 0x372F33202D20747269656420746F646179206275742041544D20776173206E6F7420616363657074696E6720636865636B2E2057696C6C2074727920746F6D6F72726F77206265666F7265203520504D);
INSERT INTO `task` VALUES ('142', 'Book resistor for car  from Gwinett Nissan dealer', '2', '1', '2', '2013-07-01', '2013-07-06', null, '5', 0x372F32202D2057656E7420746F204E697373616E206465616C657220616E6420626F6F6B6564207265736973746F722C20626974206974206973206261636B206F7264657265642C206465616C65722077696C6C206C6574206D65206B6E6F7720746F6D6F72726F7720692E652E206F6E20372F332E);
INSERT INTO `task` VALUES ('143', 'Hair cut', '3', '2', '2', '2013-07-01', '2013-07-07', '2013-07-07', '4', '');
INSERT INTO `task` VALUES ('144', 'Buy ACT mouth wash', '4', '2', '2', '2013-07-01', '2013-07-07', '2013-08-24', '4', '');
INSERT INTO `task` VALUES ('145', 'Card migration failure', '2', '3', '2', '2013-07-01', '2013-07-02', '2013-07-17', '4', 0x372F3132202D2041736B6564204E6172656E20746F206F70656E206120646566656374206F6E204D6F6E646179);
INSERT INTO `task` VALUES ('146', 'Sample report for MTSO site types', '2', '3', '2', '2013-07-01', '2013-07-02', '2013-07-05', '4', '');
INSERT INTO `task` VALUES ('147', 'Send cleanup scripts to Chan', '3', '3', '2', '2013-07-01', '2013-07-04', '2013-07-02', '4', '');
INSERT INTO `task` VALUES ('148', 'Aalia Birth Certificate', '3', '1', '2', '2013-07-03', '2013-07-10', '2013-07-15', '4', 0x372F35202D204F7264657220626972746820636572746966696361746520746F6461792066726F6D20766974616C636865636B2E636F6D0D0A0D0A4F72646572204E6F232033353530383934392050696E3A20383331373430);
INSERT INTO `task` VALUES ('149', 'Pay Old Navy CC', '3', '2', '2', '2013-07-05', '2013-07-09', '2013-07-08', '4', 0x372F38202D205061696420746F6461792C20616D6F756E742077696C6C2062652064656475637465642066726F6D2062616E6B206163636F756E74206F6E20372F3133);
INSERT INTO `task` VALUES ('150', 'Check for blower motor ordered', '3', '1', '2', '2013-07-10', '2013-07-15', '2013-07-11', '4', 0x372F3130202D204F72646572656420626C6F776572206D6F746F722066726F6D2070617274736765656B2E636F6D0D0A0D0A4F72646572204E6F230D0A31312D38393035393835);
INSERT INTO `task` VALUES ('151', 'Check comcast plan', '2', '1', '2', '2013-07-16', '2013-07-21', '2013-09-17', '4', 0x382F3231202D2049206861766520746F2063616C6C206F6E20392F313120746F20736565207768657468657220746865726520697320616E792070726F6D6F74696F6E20617661696C61626C650D0A0D0A392F3131202D20476F742070726F6D6F74696F6E20666F722034392E393320616E642069207761732061736B656420746F2063616C6C20616761696E206F6E20392F313820746F2061646A757374207468652062696C6C0D0A0D0A392F3137202D2043616C6C656420666F722062696C6C2061646A7573746D656E742E20492077617320746F6C64207468617420746865792077696C6C2063616C6C206D65206166746572203220686F757273);
INSERT INTO `task` VALUES ('152', 'drop tmp tables', '2', '3', '2', '2013-07-16', '2013-07-20', '2013-07-18', '4', 0x66726F6D20696469735F72707420736368656D6120696E2070726F64);
INSERT INTO `task` VALUES ('153', 'Medicines', '2', '2', '2', '2013-07-18', '2013-07-21', null, '2', '');
INSERT INTO `task` VALUES ('154', 'Calculate Zakat & transfer money', '1', '1', '2', '2013-07-18', '2013-07-21', '2013-08-11', '4', '');
INSERT INTO `task` VALUES ('156', 'Pay $50 to Abdul Razzaq', '2', '5', '2', '2013-07-25', '2013-07-27', '2013-07-25', '4', 0x666F722048756666617A);
INSERT INTO `task` VALUES ('157', 'Send java material', '2', '2', '2', '2013-07-27', '2013-07-29', '2013-07-30', '4', 0x746F20546F6E790D0A0D0A372F3330202D20536861726564204A434620766961204442202864726F70626F7829);
INSERT INTO `task` VALUES ('158', 'Rpplan EVC context switch issue', '1', '3', '2', '2013-07-30', '2013-07-31', '2013-08-14', '4', 0x436865636B20776974682050616E6B616A0D0A0D0A382F3134202D2050616E6B616A2077696C6C20757064617465206279204D6F6E6461792028382F313929);
INSERT INTO `task` VALUES ('161', 'Create roles modules', '3', '2', '1', '2013-08-01', '2013-08-16', null, '1', '');
INSERT INTO `task` VALUES ('162', 'Oil Change for both cars', '1', '1', '2', '2013-08-09', '2013-08-10', '2013-10-26', '4', 0x392F3134202D2066696E697368656420666F72204E697373616E20416C74696D610D0A0D0A31302F3236202D20436F6D706C657465206F696C206368616E676520666F7220486F6E6461204F);
INSERT INTO `task` VALUES ('163', 'Visiting Hafsa school', '1', '1', '2', '2013-08-09', '2013-08-17', '2013-08-18', '4', 0x746F207375626D697420636865636B73);
INSERT INTO `task` VALUES ('164', 'Call Radha krishna', '3', '2', '2', '2013-08-09', '2013-08-13', null, '5', '');
INSERT INTO `task` VALUES ('166', 'Pay Old Navy CC', '3', '1', '2', '2013-08-15', '2013-08-24', '2013-08-16', '4', '');
INSERT INTO `task` VALUES ('167', 'Pay American Express CC', '3', '1', '2', '2013-08-15', '2013-08-24', '2013-08-16', '4', '');
INSERT INTO `task` VALUES ('168', 'Install Toad in kareems01', '3', '3', '2', '2013-08-19', '2013-08-20', null, '5', 0x43616E206E6F7420626520696E7374616C6C6564206265636175736520546F616420392E362E3120696E2041534320697320666F7220333220626974);
INSERT INTO `task` VALUES ('169', 'Add new car to state farm', '2', '1', '2', '2013-08-19', '2013-08-20', '2013-08-21', '4', '');
INSERT INTO `task` VALUES ('170', 'Call State informing aboutt NL', '3', '1', '2', '2013-08-19', '2013-08-26', null, '5', 0x382F3231202D204164646564204E697373616E204C65616620746F205374617465204661726D);
INSERT INTO `task` VALUES ('171', 'Follow up with Renee about Tag', '2', '1', '2', '2013-08-19', '2013-08-20', null, '5', 0x382F3231202D2043616C6C656420746F64617920616E6420696E666F726D65642074686174206920646F6E74206E65656420484F56207461672E2049207761732061736B65642063616C6C20352064617973206265666F726520657870697279206966206920646F6E74207265636569766520746167);
INSERT INTO `task` VALUES ('172', 'Check with Abdul Razzaq about selling Car', '2', '1', '2', '2013-08-20', '2013-08-23', '2013-08-22', '4', '');
INSERT INTO `task` VALUES ('173', 'Umaiza pics to be given in Pen drive to Abdul Razzaq', '2', '5', '2', '2013-08-20', '2013-08-23', '2013-08-28', '4', '');
INSERT INTO `task` VALUES ('174', 'Pay remaining amt of Old Navy', '3', '1', '2', '2013-08-22', '2013-08-30', '2013-09-04', '4', 0x392F34202D20506169642024322E38352077686963682077696C6C206265206465647563746564206F6E20392F35);
INSERT INTO `task` VALUES ('175', 'Delete tmp tables from Dev6', '2', '3', '2', '2013-08-27', '2013-09-02', null, '1', '');
INSERT INTO `task` VALUES ('176', 'Create a doc with duas', '3', '2', '2', '2013-09-11', '2013-09-30', null, '1', '');
INSERT INTO `task` VALUES ('177', 'Check comcast bill', '2', '1', '2', '2013-09-26', '2013-10-01', '2013-10-17', '4', 0x392F3236202D2054616C6B20746F20637573746F6D657220636172652069662062696C6C206973206E6F742061646A75737465640D0A0D0A31302F3137202D2043616C6C6C656420434320746F64617920616E6420692077617320746F6C64202431392077696C6C20626520637265646974656420746F206D79206163636F756E7420776974682032342D343820686F757273);
INSERT INTO `task` VALUES ('178', 'Create diet plan for myself', '3', '2', '2', '2013-10-17', '2013-10-26', null, '1', '');
INSERT INTO `task` VALUES ('179', 'Check for Nissan Leaf tag', '2', '1', '2', '2013-10-21', '2013-10-26', '2013-10-29', '4', 0x31302F3231202D206966206E6F7420666F756E642062792031302F3233207468656E2063616C6C206465616C65720D0A0D0A31302F3232202D2043616C6C65642052656E656520746F6461792C2077696C6C2063616C6C2068657220616761696E20746F6D6F72726F7720617320736865206973206F666620746F20776F726B20746F6461792E0D0A0D0A31302F3234202D2073656E742074657874206D736720746F2052656E65652C20736865207265706C6965642069742077696C6C2062652072656164792062792031312F310D0A);
INSERT INTO `task` VALUES ('180', 'Nissan Leaf auto pay enrollment', '2', '1', '2', '2013-10-21', '2013-10-26', '2013-10-22', '4', '');
INSERT INTO `task` VALUES ('181', 'Complete pending CMT EMUX report', '1', '3', '2', '2013-10-21', '2013-10-24', '2013-10-21', '4', '');
INSERT INTO `task` VALUES ('182', 'Book 24 hour collection box', '3', '2', '2', '2013-10-22', '2013-10-26', null, '1', '');
INSERT INTO `task` VALUES ('183', 'Check YMail for nissan leaf email', '3', '1', '2', '2013-10-22', '2013-10-30', '2013-10-31', '4', '');
INSERT INTO `task` VALUES ('184', 'Enroll into Electronic Vehicle to get amount', '2', '1', '2', '2013-10-23', '2013-11-09', null, '1', '');
INSERT INTO `task` VALUES ('185', 'Prepare home budget', '2', '6', '2', '2013-10-23', '2013-10-23', null, '2', 0x564948202D205031);
INSERT INTO `task` VALUES ('186', 'Finishing off plot debt', '2', '6', '2', '2013-10-23', '2014-03-23', null, '1', 0x564948202D205032);
INSERT INTO `task` VALUES ('187', 'Deciding dates and finding ticket deals', '2', '6', '2', '2013-10-23', '2013-12-14', null, '1', 0x564948202D205033);
INSERT INTO `task` VALUES ('188', 'Opening Chase Credit Card', '2', '6', '2', '2013-10-23', '2013-11-02', null, '1', 0x564948202D205034);
INSERT INTO `task` VALUES ('189', 'Renting Home', '2', '6', '2', '2013-10-23', '2014-02-15', null, '1', 0x564948202D205035);
INSERT INTO `task` VALUES ('190', 'Pay Old Navy CC', '2', '1', '2', '2013-10-28', '2013-10-31', '2013-10-31', '4', '');
INSERT INTO `task` VALUES ('191', 'Setup Auto Pay for Nissan Leaf', '2', '1', '2', '2013-10-31', '2013-11-15', null, '1', '');

-- ----------------------------
-- Table structure for `tasktype`
-- ----------------------------
DROP TABLE IF EXISTS `tasktype`;
CREATE TABLE `tasktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKTASKTYPE_NAME` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tasktype
-- ----------------------------
INSERT INTO `tasktype` VALUES ('1', 'Home', 'Home Desc for Tasks');
INSERT INTO `tasktype` VALUES ('2', 'Personal', '');
INSERT INTO `tasktype` VALUES ('3', 'Work', null);
INSERT INTO `tasktype` VALUES ('4', 'Technical', null);
INSERT INTO `tasktype` VALUES ('5', 'Misc', 'Miscellaneous tasks');
INSERT INTO `tasktype` VALUES ('6', 'VIH', 'Very Important Home Tasks');

-- ----------------------------
-- Table structure for `totalexpenses`
-- ----------------------------
DROP TABLE IF EXISTS `totalexpenses`;
CREATE TABLE `totalexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL,
  `totalamount` float(11,5) NOT NULL DEFAULT '0.00000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of totalexpenses
-- ----------------------------
INSERT INTO `totalexpenses` VALUES ('1', 'Nov', '2012', '1297.15002');
INSERT INTO `totalexpenses` VALUES ('2', 'Dec', '2012', '1758.47998');
INSERT INTO `totalexpenses` VALUES ('3', 'May', '2013', '781.38000');
INSERT INTO `totalexpenses` VALUES ('4', 'Aug', '2013', '10.00000');
INSERT INTO `totalexpenses` VALUES ('5', 'Oct', '2013', '0.00000');

-- ----------------------------
-- Table structure for `urlstore`
-- ----------------------------
DROP TABLE IF EXISTS `urlstore`;
CREATE TABLE `urlstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` blob NOT NULL,
  `urltype` int(11) NOT NULL,
  `url` blob NOT NULL,
  `user` bigint(20) NOT NULL,
  `createddate` date NOT NULL,
  `updateddate` date DEFAULT NULL,
  `notes` blob,
  PRIMARY KEY (`id`),
  KEY `FKURLSTORE_URLTYPE` (`urltype`),
  KEY `FKURLSTORE_USER` (`user`),
  CONSTRAINT `FKURLSTORE_URLTYPE` FOREIGN KEY (`urltype`) REFERENCES `urltype` (`id`),
  CONSTRAINT `FKURLSTORE_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of urlstore
-- ----------------------------
INSERT INTO `urlstore` VALUES ('1', 0x4772616D20466C6F7572204D7572756B756C75, '1', 0x687474703A2F2F7072697961656173796E7461737479726563697065732E626C6F6773706F742E636F6D2F323030392F31302F6772616D666C6F75726B6164616C616D616176752D6D7572756B6B752E68746D6C, '2', '2013-09-13', '2013-09-13', '');
INSERT INTO `urlstore` VALUES ('2', 0x4D616B696E672050756E7567756C75, '1', 0x687474703A2F2F6D79776F726C646F66726563697065732E626C6F6773706F742E636F6D2F323030392F30352F70756E7567756C752E68746D6C, '2', '2013-09-17', '2013-09-17', '');
INSERT INTO `urlstore` VALUES ('3', 0x507265706172696E6720427265616420617420686F6D65, '1', 0x687474703A2F2F7777772E7468656B697463686E2E636F6D2F686F772D746F2D6D616B652D62726561642D646F7567682D686F6D652D682D313038383037, '2', '2013-10-05', '2013-10-05', '');
INSERT INTO `urlstore` VALUES ('4', 0x417070752053657269657320436172746F6F6E73, '5', 0x687474703A2F2F7777772E796F75747562652E636F6D2F77617463683F763D507A315933335654345273, '2', '2013-10-11', '2013-10-11', 0x50726F6261626C79206920776F756C64206C696B6520746F20646F776E6C6F616420616E64206D616B6520612043442F445644206F66206974);

-- ----------------------------
-- Table structure for `urltype`
-- ----------------------------
DROP TABLE IF EXISTS `urltype`;
CREATE TABLE `urltype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of urltype
-- ----------------------------
INSERT INTO `urltype` VALUES ('1', 'Cooking', 0x55726C732072656C6174656420746F20636F6F6B696E67);
INSERT INTO `urltype` VALUES ('2', 'Technical', '');
INSERT INTO `urltype` VALUES ('3', 'Technical/Java', '');
INSERT INTO `urltype` VALUES ('4', 'Technical/JavaScript', '');
INSERT INTO `urltype` VALUES ('5', 'Kids/Cartoons', '');
INSERT INTO `urltype` VALUES ('6', 'Technical/Database', '');
INSERT INTO `urltype` VALUES ('7', 'Miscellaneous', '');
INSERT INTO `urltype` VALUES ('8', 'Temp Urls', '');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `createddate` date NOT NULL,
  `updateddate` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKUSER_UNAME` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2013-07-30', '2013-07-30');
INSERT INTO `user` VALUES ('2', 'karims', '54f9428421cc56c2a9dd0167dfee0cc3', '2013-07-30', '2013-08-01');
INSERT INTO `user` VALUES ('6', 'testuser', '5d9c68c6c50ed3d02a2fcf54f63993b6', '2013-07-30', '2013-07-30');
INSERT INTO `user` VALUES ('7', 'test2', 'ad0234829205b9033196ba818f7a872b', '2013-07-30', '2013-07-30');
INSERT INTO `user` VALUES ('8', 'test3', '8ad8757baa8564dc136c1e07507f4a98', '2013-07-30', '2013-07-30');

-- ----------------------------
-- Table structure for `user2role`
-- ----------------------------
DROP TABLE IF EXISTS `user2role`;
CREATE TABLE `user2role` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `roleid` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKUSER2ROLE_USER` (`userid`) USING BTREE,
  KEY `FKUSER2ROLE_ROLE` (`roleid`) USING BTREE,
  CONSTRAINT `FKUSER2ROLE_ROLE` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`),
  CONSTRAINT `FKUSER2ROLE_USER` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user2role
-- ----------------------------
INSERT INTO `user2role` VALUES ('1', '1', '1');
INSERT INTO `user2role` VALUES ('2', '2', '2');

-- ----------------------------
-- Table structure for `userdetails`
-- ----------------------------
DROP TABLE IF EXISTS `userdetails`;
CREATE TABLE `userdetails` (
  `userid` bigint(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `FKUSERDETAILS_USERID` (`userid`) USING BTREE,
  CONSTRAINT `FKUSERDETAILS_USERID` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userdetails
-- ----------------------------
INSERT INTO `userdetails` VALUES ('1', 'Admin', 'Admin', null, null, null, null, null);
INSERT INTO `userdetails` VALUES ('2', 'Kareem', 'Shaik', 'mailtokarims@yahoo.com', '6789435398', '21021 Gardner Drive', 'Alpharetta', 'Georgia');

-- ----------------------------
-- Table structure for `weightrecorder`
-- ----------------------------
DROP TABLE IF EXISTS `weightrecorder`;
CREATE TABLE `weightrecorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createddate` date NOT NULL,
  `member` int(11) NOT NULL,
  `user` bigint(20) NOT NULL,
  `weight` float(50,5) DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKWEIGHTRECORDER_MEMBER` (`member`) USING BTREE,
  KEY `FKWEIGHTRECORDER_USER` (`user`),
  CONSTRAINT `FKWEIGHTRECORDER_MEMBER` FOREIGN KEY (`member`) REFERENCES `member` (`id`),
  CONSTRAINT `FKWEIGHTRECORDER_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of weightrecorder
-- ----------------------------
INSERT INTO `weightrecorder` VALUES ('1', '2013-07-05', '1', '2', '131.00000', '');
INSERT INTO `weightrecorder` VALUES ('2', '2013-07-05', '2', '2', '166.00000', '');
INSERT INTO `weightrecorder` VALUES ('3', '2013-07-05', '3', '2', '38.40000', '');
INSERT INTO `weightrecorder` VALUES ('4', '2013-07-05', '4', '2', '12.00000', '');
INSERT INTO `weightrecorder` VALUES ('5', '2013-09-17', '1', '2', '127.20000', '');
INSERT INTO `weightrecorder` VALUES ('6', '2013-09-17', '2', '2', '164.00000', '');
INSERT INTO `weightrecorder` VALUES ('7', '2013-09-17', '3', '2', '39.00000', '');
INSERT INTO `weightrecorder` VALUES ('8', '2013-09-17', '4', '2', '17.80000', '');
INSERT INTO `weightrecorder` VALUES ('9', '2013-10-24', '2', '2', '159.00000', '');
