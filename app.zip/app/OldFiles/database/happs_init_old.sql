/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 50524
Source Host           : localhost:3306
Source Database       : happs

Target Server Type    : MYSQL
Target Server Version : 50524
File Encoding         : 65001

Date: 2013-05-19 10:15:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1', 'Kareem ICICI', null);
INSERT INTO `account` VALUES ('2', 'Kareem SBI', null);
INSERT INTO `account` VALUES ('3', 'Kareem Citi', null);
INSERT INTO `account` VALUES ('4', 'Jakeer Bhai', null);
INSERT INTO `account` VALUES ('5', 'Kareem NRE', null);

-- ----------------------------
-- Table structure for `bioabbrevations`
-- ----------------------------
DROP TABLE IF EXISTS `bioabbrevations`;
CREATE TABLE `bioabbrevations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desc` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bioabbrevations
-- ----------------------------
INSERT INTO `bioabbrevations` VALUES ('1', 'BMI', 'Body Mass Index');
INSERT INTO `bioabbrevations` VALUES ('2', 'WC', 'Waist Circumference');
INSERT INTO `bioabbrevations` VALUES ('3', 'BP', 'Blood Pressure');
INSERT INTO `bioabbrevations` VALUES ('4', 'GF', 'Glucose Fasting');
INSERT INTO `bioabbrevations` VALUES ('5', 'GNF', 'Glucose Non Fasting');
INSERT INTO `bioabbrevations` VALUES ('6', 'Total Chol', 'Total Cholestrol');
INSERT INTO `bioabbrevations` VALUES ('7', 'HDL Chol', 'HDL Cholestrol');
INSERT INTO `bioabbrevations` VALUES ('8', 'LDL', 'LDL Cholestrol');

-- ----------------------------
-- Table structure for `biometrics`
-- ----------------------------
DROP TABLE IF EXISTS `biometrics`;
CREATE TABLE `biometrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createddate` date NOT NULL,
  `biotestdate` date NOT NULL,
  `weight` varchar(10) DEFAULT NULL,
  `bmi` varchar(10) DEFAULT NULL,
  `waist` varchar(10) DEFAULT NULL,
  `bp` varchar(10) DEFAULT NULL,
  `glucosefasting` varchar(10) DEFAULT NULL,
  `glucosenonfasting` varchar(10) DEFAULT NULL,
  `totalcholestrol` varchar(10) DEFAULT NULL,
  `hdlcholestrol` varchar(10) DEFAULT NULL,
  `ldlcholestrol` varchar(10) DEFAULT NULL,
  `riskratio` varchar(10) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of biometrics
-- ----------------------------
INSERT INTO `biometrics` VALUES ('3', '2012-11-19', '2011-10-25', '132 lbs', '23', '32', '111/74', '91', '', '144', '19', '', '7.5', '');
INSERT INTO `biometrics` VALUES ('4', '2012-11-19', '2012-10-24', '129 lbs', '22', '30', '110/70', '', '112', '146', '31', '', '4.8', '');

-- ----------------------------
-- Table structure for `ccategory`
-- ----------------------------
DROP TABLE IF EXISTS `ccategory`;
CREATE TABLE `ccategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ccategory
-- ----------------------------
INSERT INTO `ccategory` VALUES ('1', 'Home', null);
INSERT INTO `ccategory` VALUES ('2', 'Work', null);
INSERT INTO `ccategory` VALUES ('3', 'Misc', null);
INSERT INTO `ccategory` VALUES ('4', 'Mail', null);
INSERT INTO `ccategory` VALUES ('5', 'Medical', null);
INSERT INTO `ccategory` VALUES ('6', 'Insurance', null);
INSERT INTO `ccategory` VALUES ('7', 'Utilities', null);
INSERT INTO `ccategory` VALUES ('8', 'Personal', null);
INSERT INTO `ccategory` VALUES ('9', 'Credit Card', null);

-- ----------------------------
-- Table structure for `credential`
-- ----------------------------
DROP TABLE IF EXISTS `credential`;
CREATE TABLE `credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `createddate` date DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `category` int(11) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426L` (`category`) USING BTREE,
  CONSTRAINT `FK3580769128426L` FOREIGN KEY (`category`) REFERENCES `ccategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of credential
-- ----------------------------
INSERT INTO `credential` VALUES ('4', 'Yahoo Mail', '2012-11-20', 'mailtokarims', 'ilusha**10', '4', '', '');
INSERT INTO `credential` VALUES ('5', 'Yahoo Mail', '2012-11-20', 'kareem.shaik', 'ilushe**10', '4', '', 'kareem.shaik@ymail.com');
INSERT INTO `credential` VALUES ('6', 'Gmail', '2012-11-20', 'karim.shak', 'f10', '4', '', '');
INSERT INTO `credential` VALUES ('7', 'Hotmail', '2012-11-20', 'kareim_s', 'ilusha**10', '4', '', '');
INSERT INTO `credential` VALUES ('8', 'Progressive', '2012-11-20', 'kareems78', 'f10', '6', 'http://www.progressive.com/login.aspx', 'Policy No# 43611518-2\r\nCustmoer Care: 1-800-876-5581\r\n\r\nFax: 1 800 229 1590');
INSERT INTO `credential` VALUES ('10', 'Prudential 401K', '2012-11-27', 'kareems78', 'f10', '3', 'https://ssologin.prudential.com/app/retirement/Login.fcc', '401K plan\r\n\r\n877-778-2100');
INSERT INTO `credential` VALUES ('11', 'ATT Internet', '2012-11-30', 'kareems78', 'f10', '3', null, 'Cancel Confirm 1018615600');
INSERT INTO `credential` VALUES ('12', 'ATT Composer', '2012-11-30', 'ks589h', 'ks589h', '2', 'https://bistromatic.mo.sbc.com:9443/rdm/', '');
INSERT INTO `credential` VALUES ('13', 'ATT Redmine', '2012-11-30', 'ks589h', 'F10', '2', 'http://139.76.215.96:7225/redmine/login', '');
INSERT INTO `credential` VALUES ('14', 'ATT QC', '2012-11-30', 'ks589h', 'Hafsa10', '2', null, null);
INSERT INTO `credential` VALUES ('15', 'ATT Global Login', '2012-11-30', 'ks589h', 'Sha***n10', '2', null, null);
INSERT INTO `credential` VALUES ('16', 'ATT Crucible', '2012-11-30', 'ks589h', 'ks589h', '2', 'http://jcore-reviews.snt.bst.bls.com/', 'use 1025 as port from Amdocs network');
INSERT INTO `credential` VALUES ('17', 'ATT FTP', '2012-11-30', 'm45678', 'G0ipag!', '2', null, null);
INSERT INTO `credential` VALUES ('18', 'Remit2India', '2012-11-30', 'Yahoo Email ID', 'k10', '8', 'https://www.timesofmoney.com/remittance/secure/r2i', 'Customer ID : 1695742\r\n');
INSERT INTO `credential` VALUES ('19', 'Mint', '2012-11-30', 'Yahoo Email ID', 'f10', '8', 'https://wwws.mint.com/login.event', '');
INSERT INTO `credential` VALUES ('20', 'Davis Vision', '2012-11-30', 'Yahoo Email ID', 'f10', '5', 'www.davisvision.com', 'ID: 789000733095\r\n\r\nCustomer Care : 1 800 999 5431');
INSERT INTO `credential` VALUES ('21', 'CIGNA', '2012-11-30', 'kareems78', 'f10', '5', null, 'ID: U40574366 01\n\nAccount - 3209216\n\nCustomer Care : 800-244-6224\n\nwww.myCigna.com\n\nCigna Dental PPO\n\nRadius Network');
INSERT INTO `credential` VALUES ('22', 'Georgia Power', '2012-11-30', 'kareems78', 'f10', '7', 'http://www.georgiapower.com/', 'Account No : 80852-13009\r\n\r\n1-888-660-5890');
INSERT INTO `credential` VALUES ('23', 'Visa Trax', '2012-11-30', 'kareems78', 'hafsa@10', '2', 'https://app01.visatrax.com/inszoom_hosted_login.aspx?org_id=Ogtree', 'Registered with Amdocs Email ID');
INSERT INTO `credential` VALUES ('24', 'Pure Talk USA', '2012-11-30', 'add later', 'f10', '8', 'https://www.puretalkusa.com/index.php?o=1', '');
INSERT INTO `credential` VALUES ('25', 'Oracle', '2012-11-30', 'Gmail ID', 'F10', '8', null, null);
INSERT INTO `credential` VALUES ('26', 'Safari', '2012-11-30', 'Amdocs EmailID', 'f10', '8', 'http://www.safaribooksonline.com/', '');
INSERT INTO `credential` VALUES ('27', 'Junior Achievement', '2012-11-30', 'Amdocs EmailID', 'f10', '8', 'http://jaog.convio.net/goto/TEAM1', '');
INSERT INTO `credential` VALUES ('28', 'Sears Card', '2012-11-30', 'kareems78', 'f10', '8', 'https://www.citibank.com/us/cards/srs/index.jsp', '');
INSERT INTO `credential` VALUES ('29', 'Homes', '2012-11-30', 'kareemshaik', 'f10', '8', 'http://www.homes.com', '');
INSERT INTO `credential` VALUES ('30', 'ATT Manual Jira ', '2012-11-30', 'ks589h', 'F@10', '2', 'https://itrack.web.att.com/secure/Dashboard.jspa', '');
INSERT INTO `credential` VALUES ('32', 'eRenterPlan', '2012-11-30', 'Y!Mail', 'f10', '8', 'http://my.erenterplan.com', 'Policy# 0030609238\r\n1 888 205 8118\r\n\r\nAuto Pay: CC ends with 8844');
INSERT INTO `credential` VALUES ('33', 'Zakat.org', '2012-11-30', 'Yahoo Email', 'f10', '8', 'http://www.zakat.org', '');
INSERT INTO `credential` VALUES ('34', 'Comcast', '2012-11-30', 'kareemshaik@comcast.net', 'f10', '8', 'https://login.comcast.net/login', 'Account : 8220177050947301');
INSERT INTO `credential` VALUES ('35', 'AAA', '2012-11-30', 'kareems78', 'f10', '8', null, 'Membership# 429-014-630180570-3');
INSERT INTO `credential` VALUES ('36', 'Evernote', '2012-11-30', 'karimshk', 'f10', '8', null, null);
INSERT INTO `credential` VALUES ('37', 'Apple ID', '2012-11-30', 'Gmail', 'F10', '8', null, null);
INSERT INTO `credential` VALUES ('38', 'Roku', '2012-11-30', 'Y!Mail', 'f10', '8', 'https://owner.roku.com/Login/', '');
INSERT INTO `credential` VALUES ('39', 'Cloud Acct', '2012-11-30', 'Y!Mail', 'f10', '8', 'http://ksh.cloud-ide.com/cloud/ide.jsp', '');
INSERT INTO `credential` VALUES ('40', 'Apple iCloud', '2012-11-30', 'Gmail', 'F10', '8', 'https://www.icloud.com/', '');
INSERT INTO `credential` VALUES ('41', 'DDS GA', '2012-11-30', 'Y!Mail', 'f10', '8', 'https://online.dds.ga.gov/OnlineServices/Account/L', '');
INSERT INTO `credential` VALUES ('42', 'Old Navy', '2012-11-30', 'Y!Mail', 'f10', '8', 'https://www3.onlinecreditcenter6.com/consumergen2/', '');
INSERT INTO `credential` VALUES ('43', 'American Express', '2012-11-30', 'kareems78', 'f10', '8', 'https://online.americanexpress.com/myca/logon/us/a', '');
INSERT INTO `credential` VALUES ('44', 'JCPenny', '2012-12-11', 'Y!Mail', 'f10', '8', 'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=jcpenney&accountType=generic', '');
INSERT INTO `credential` VALUES ('46', 'Babies R Us CC', '2013-05-13', 'Y!Mail', 'f10', '9', 'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=tru&accountType=generic', '');
INSERT INTO `credential` VALUES ('47', 'Honda Services', '2013-05-14', 'kareems78', 'f10', '1', 'http://www.hondafinancialservices.com/', '5/14\r\nAuto Pay is setup. from next month i.e. June, it will be deducted automatically. Paid already for current month.');

-- ----------------------------
-- Table structure for `creditcard`
-- ----------------------------
DROP TABLE IF EXISTS `creditcard`;
CREATE TABLE `creditcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of creditcard
-- ----------------------------
INSERT INTO `creditcard` VALUES ('1', 'GAP', null);
INSERT INTO `creditcard` VALUES ('2', 'JCPenny', null);
INSERT INTO `creditcard` VALUES ('3', 'Kohls', null);
INSERT INTO `creditcard` VALUES ('4', 'Old Navy', null);
INSERT INTO `creditcard` VALUES ('5', 'Macys', null);
INSERT INTO `creditcard` VALUES ('6', 'TJX Rewards', null);
INSERT INTO `creditcard` VALUES ('7', 'BOA - 1741', null);
INSERT INTO `creditcard` VALUES ('8', 'BOA - 8844', null);

-- ----------------------------
-- Table structure for `creditpayment`
-- ----------------------------
DROP TABLE IF EXISTS `creditpayment`;
CREATE TABLE `creditpayment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referenceno` varchar(50) NOT NULL,
  `datepaid` date NOT NULL,
  `creditcard` int(11) NOT NULL,
  `amount` float(11,5) NOT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426O` (`creditcard`) USING BTREE,
  CONSTRAINT `FK3580769128426O` FOREIGN KEY (`creditcard`) REFERENCES `creditcard` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of creditpayment
-- ----------------------------
INSERT INTO `creditpayment` VALUES ('4', '444266853', '2012-11-23', '1', '42.32000', '');
INSERT INTO `creditpayment` VALUES ('5', '1502898076', '2012-11-27', '7', '800.00000', '');
INSERT INTO `creditpayment` VALUES ('6', '4102919595', '2012-11-27', '8', '36.78000', '');
INSERT INTO `creditpayment` VALUES ('7', '450777965 ', '2012-12-11', '2', '5.35000', '');
INSERT INTO `creditpayment` VALUES ('8', '434672325', '2012-12-12', '8', '49.38000', '');
INSERT INTO `creditpayment` VALUES ('9', '434681304', '2012-12-12', '7', '300.00000', '');

-- ----------------------------
-- Table structure for `ecategory`
-- ----------------------------
DROP TABLE IF EXISTS `ecategory`;
CREATE TABLE `ecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ecategory
-- ----------------------------
INSERT INTO `ecategory` VALUES ('1', 'Electronics', 'Category for electronics');
INSERT INTO `ecategory` VALUES ('2', 'Grocery', null);
INSERT INTO `ecategory` VALUES ('3', 'Clothes', null);
INSERT INTO `ecategory` VALUES ('4', 'Car/Gas', null);
INSERT INTO `ecategory` VALUES ('5', 'Meat', null);
INSERT INTO `ecategory` VALUES ('6', 'Home Decor', null);
INSERT INTO `ecategory` VALUES ('7', 'Restuarants', null);
INSERT INTO `ecategory` VALUES ('8', 'Medical', null);
INSERT INTO `ecategory` VALUES ('9', 'Misc', null);
INSERT INTO `ecategory` VALUES ('10', 'Bills/Electricity', null);
INSERT INTO `ecategory` VALUES ('11', 'Home Appliances', null);
INSERT INTO `ecategory` VALUES ('12', 'Food/Fruits', null);
INSERT INTO `ecategory` VALUES ('13', 'Cosmetics', null);
INSERT INTO `ecategory` VALUES ('14', 'Transport', null);
INSERT INTO `ecategory` VALUES ('15', 'Car/Oil Change', null);
INSERT INTO `ecategory` VALUES ('16', 'Car/Misc', null);
INSERT INTO `ecategory` VALUES ('17', 'Food/Misc', null);
INSERT INTO `ecategory` VALUES ('18', 'Household Items', null);
INSERT INTO `ecategory` VALUES ('19', 'House Rent', null);
INSERT INTO `ecategory` VALUES ('20', 'Bills/Vonage', null);
INSERT INTO `ecategory` VALUES ('21', 'Bills/Wireless', null);
INSERT INTO `ecategory` VALUES ('22', 'Gifts', null);

-- ----------------------------
-- Table structure for `expense`
-- ----------------------------
DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expensedate` date NOT NULL,
  `category` int(11) NOT NULL,
  `amount` float(11,5) NOT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426K` (`category`) USING BTREE,
  CONSTRAINT `FK3580769128426K` FOREIGN KEY (`category`) REFERENCES `ecategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of expense
-- ----------------------------
INSERT INTO `expense` VALUES ('13', '2012-11-24', '1', '996.00000', 'Nikon D7000 from BH&P');
INSERT INTO `expense` VALUES ('14', '2012-11-24', '8', '26.74000', 'Prilosec');
INSERT INTO `expense` VALUES ('15', '2012-11-24', '9', '16.95000', 'USPS - Medicines');
INSERT INTO `expense` VALUES ('16', '2012-11-24', '12', '16.44000', 'Walmart');
INSERT INTO `expense` VALUES ('17', '2012-11-25', '8', '5.34000', 'Anti Fungal cream');
INSERT INTO `expense` VALUES ('18', '2012-11-25', '7', '26.08000', 'Karachi Broast');
INSERT INTO `expense` VALUES ('20', '2012-11-27', '12', '4.18000', 'Papaya');
INSERT INTO `expense` VALUES ('21', '2012-11-27', '2', '4.81000', 'Milk & Tomatoes');
INSERT INTO `expense` VALUES ('22', '2012-11-27', '13', '16.05000', 'Eye liner from Macys');
INSERT INTO `expense` VALUES ('23', '2012-11-27', '3', '12.27000', 'Children\'s Place');
INSERT INTO `expense` VALUES ('24', '2012-11-28', '14', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('25', '2012-11-28', '4', '40.08000', 'Gas');
INSERT INTO `expense` VALUES ('26', '2012-11-30', '9', '33.81000', 'Fee Sabilillah for Darul Huda Masjid from Snellville');
INSERT INTO `expense` VALUES ('27', '2012-12-01', '15', '21.23000', '@ Sears Auto Center. Need to change brake fluid, pwr steering fluid');
INSERT INTO `expense` VALUES ('28', '2012-11-30', '2', '20.83000', 'Onions, Eggs, Curd, Chapatis');
INSERT INTO `expense` VALUES ('29', '2012-11-30', '12', '6.99000', 'Oranges');
INSERT INTO `expense` VALUES ('30', '2012-11-30', '18', '27.60000', 'Cascade, Lays, Lysol - 2, Shampoo, Perfume');
INSERT INTO `expense` VALUES ('31', '2012-12-01', '7', '14.96000', 'Amma\'s Kitchen');
INSERT INTO `expense` VALUES ('32', '2012-12-01', '2', '85.66000', 'Spices Hut');
INSERT INTO `expense` VALUES ('33', '2012-12-03', '21', '40.64000', 'Comcast Bill Payment\r\n\r\nConfirmation No# F8MXZ-CFPZ7\r\nWill be paid on 12/4');
INSERT INTO `expense` VALUES ('34', '2012-12-04', '2', '3.41000', 'Milk from Harys Market');
INSERT INTO `expense` VALUES ('35', '2012-12-04', '9', '1.99000', 'lip balm');
INSERT INTO `expense` VALUES ('36', '2012-12-05', '2', '10.88000', 'India Plaza - Cilantro, Mint, Curd, eggplant and sweet');
INSERT INTO `expense` VALUES ('37', '2012-11-29', '7', '12.84000', 'Papa Johns');
INSERT INTO `expense` VALUES ('38', '2012-11-29', '17', '5.14000', 'Soda & Bagels from Kroger');
INSERT INTO `expense` VALUES ('40', '2012-12-03', '19', '1132.15002', 'Amli');
INSERT INTO `expense` VALUES ('43', '2012-12-05', '18', '6.60000', 'from walmart');
INSERT INTO `expense` VALUES ('44', '2012-12-06', '6', '20.33000', 'Bamboo Matchstick rollup blinds');
INSERT INTO `expense` VALUES ('45', '2012-12-06', '18', '4.16000', 'Walmart');
INSERT INTO `expense` VALUES ('46', '2012-12-07', '10', '91.30000', 'Georgia Power');
INSERT INTO `expense` VALUES ('47', '2012-12-07', '2', '3.29000', 'Milk from Harry\'s Market');
INSERT INTO `expense` VALUES ('48', '2012-12-07', '2', '10.88000', 'India Plaza');
INSERT INTO `expense` VALUES ('49', '2012-12-08', '4', '31.69000', '');
INSERT INTO `expense` VALUES ('50', '2012-12-08', '17', '8.12000', 'Tea snacks & Biscuits');
INSERT INTO `expense` VALUES ('51', '2012-12-10', '2', '16.86000', 'Costco - Rice etc');
INSERT INTO `expense` VALUES ('52', '2012-12-10', '20', '35.91000', '');
INSERT INTO `expense` VALUES ('53', '2012-12-10', '18', '15.38000', 'Walmart');
INSERT INTO `expense` VALUES ('54', '2012-12-12', '18', '43.29000', 'Ross');
INSERT INTO `expense` VALUES ('55', '2012-12-12', '9', '30.34000', 'Nail Polish, Battery, Axe Shaving');
INSERT INTO `expense` VALUES ('56', '2012-12-13', '18', '12.24000', 'Walmart - ToothPaste, Bulb, Pouch');
INSERT INTO `expense` VALUES ('57', '2012-12-13', '12', '6.00000', 'Costco - Watermelon');
INSERT INTO `expense` VALUES ('58', '2012-12-13', '2', '5.31000', 'Costco - Onions');
INSERT INTO `expense` VALUES ('59', '2012-12-15', '1', '32.09000', 'Targus Cooling Mat from Walmart');
INSERT INTO `expense` VALUES ('60', '2012-12-15', '22', '14.02000', 'for Faiz\'s son');
INSERT INTO `expense` VALUES ('61', '2012-12-15', '3', '2.00000', 'for baby - shoes');
INSERT INTO `expense` VALUES ('62', '2012-12-15', '7', '14.09000', 'Panera Bread');
INSERT INTO `expense` VALUES ('63', '2012-12-15', '12', '1.00000', 'Banana');
INSERT INTO `expense` VALUES ('64', '2012-12-15', '2', '13.33000', 'Walmart - Tilapia, Cookies, Eggs, Chips');
INSERT INTO `expense` VALUES ('65', '2012-12-16', '22', '1.04000', 'Gift bag from Walmart');
INSERT INTO `expense` VALUES ('66', '2012-12-16', '2', '3.29000', 'Harry\'s Milk');
INSERT INTO `expense` VALUES ('67', '2012-12-17', '14', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('68', '2013-05-16', '14', '25.00000', 'MARTA');
INSERT INTO `expense` VALUES ('69', '2013-05-15', '17', '2.04000', 'Choco chips from Walmart');
INSERT INTO `expense` VALUES ('70', '2013-05-15', '9', '20.00000', 'Ijtima');
INSERT INTO `expense` VALUES ('71', '2013-05-16', '7', '6.49000', 'Taco Bell');

-- ----------------------------
-- Table structure for `exportmodules`
-- ----------------------------
DROP TABLE IF EXISTS `exportmodules`;
CREATE TABLE `exportmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exportmodules
-- ----------------------------
INSERT INTO `exportmodules` VALUES ('1', 'Fund Transfers', null);
INSERT INTO `exportmodules` VALUES ('2', 'Contacts', null);
INSERT INTO `exportmodules` VALUES ('3', 'Credentials', null);

-- ----------------------------
-- Table structure for `fundtransfer`
-- ----------------------------
DROP TABLE IF EXISTS `fundtransfer`;
CREATE TABLE `fundtransfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referenceno` bigint(20) NOT NULL,
  `datesent` date NOT NULL,
  `transferredto` int(11) NOT NULL,
  `amount` bigint(11) NOT NULL,
  `destamount` bigint(11) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426M` (`transferredto`) USING BTREE,
  CONSTRAINT `FK3580769128426M` FOREIGN KEY (`transferredto`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fundtransfer
-- ----------------------------
INSERT INTO `fundtransfer` VALUES ('4', '1695742001', '2008-11-17', '3', '1200', '59709', '');
INSERT INTO `fundtransfer` VALUES ('5', '1695742002', '2008-11-21', '3', '1500', '73950', null);
INSERT INTO `fundtransfer` VALUES ('6', '1695742003', '2008-12-07', '3', '1500', '72195', null);
INSERT INTO `fundtransfer` VALUES ('7', '1695742004', '2008-12-22', '2', '1000', '46909', null);
INSERT INTO `fundtransfer` VALUES ('8', '1695742005', '2008-12-29', '3', '500', '23955', null);
INSERT INTO `fundtransfer` VALUES ('9', '1695742006', '2009-01-06', '2', '1001', '48313', null);
INSERT INTO `fundtransfer` VALUES ('10', '1695742007', '2009-01-19', '3', '1001', '48463', null);
INSERT INTO `fundtransfer` VALUES ('11', '1695742008', '2009-01-21', '2', '1001', '48233', null);
INSERT INTO `fundtransfer` VALUES ('12', '1695742009', '2009-02-20', '3', '1001', '49292', null);
INSERT INTO `fundtransfer` VALUES ('13', '1695742010', '2009-03-06', '2', '1001', '50926', null);
INSERT INTO `fundtransfer` VALUES ('14', '1695742011', '2009-03-24', '2', '1001', '50215', null);
INSERT INTO `fundtransfer` VALUES ('15', '1695742012', '2009-03-24', '3', '1100', '55189', null);
INSERT INTO `fundtransfer` VALUES ('16', '1695742013', '2009-04-24', '3', '1001', '49555', null);
INSERT INTO `fundtransfer` VALUES ('17', '1695742014', '2009-05-12', '2', '1100', '53693', null);
INSERT INTO `fundtransfer` VALUES ('18', '1695742015', '2009-05-20', '3', '1001', '46882', null);
INSERT INTO `fundtransfer` VALUES ('19', '1695742016', '2009-06-08', '2', '1100', '51460', null);
INSERT INTO `fundtransfer` VALUES ('20', '1695742017', '2009-06-08', '3', '1000', '46571', null);
INSERT INTO `fundtransfer` VALUES ('21', '1695742018', '2009-07-11', '3', '1000', '47705', null);
INSERT INTO `fundtransfer` VALUES ('22', '1695742019', '2009-08-24', '3', '1150', '55482', null);
INSERT INTO `fundtransfer` VALUES ('23', '1695742020', '2009-09-19', '3', '1100', '52274', null);
INSERT INTO `fundtransfer` VALUES ('24', '1695742021', '2009-10-16', '3', '1100', '50316', null);
INSERT INTO `fundtransfer` VALUES ('25', '1695742022', '2009-11-10', '3', '1500', '68295', null);
INSERT INTO `fundtransfer` VALUES ('26', '1695742023', '2009-12-15', '3', '1150', '53124', null);
INSERT INTO `fundtransfer` VALUES ('27', '1695742024', '2010-01-05', '2', '1500', '67905', null);
INSERT INTO `fundtransfer` VALUES ('28', '1695742025', '2010-01-19', '3', '1100', '50129', null);
INSERT INTO `fundtransfer` VALUES ('29', '1695742026', '2010-02-22', '3', '1100', '50294', null);
INSERT INTO `fundtransfer` VALUES ('30', '1695742027', '2010-02-25', '2', '1500', '68310', null);
INSERT INTO `fundtransfer` VALUES ('31', '1695742028', '2010-03-22', '3', '1100', '49535', null);
INSERT INTO `fundtransfer` VALUES ('32', '1695742029', '2010-03-29', '2', '2000', '88705', null);
INSERT INTO `fundtransfer` VALUES ('33', '1695742030', '2010-04-26', '2', '2001', '88269', null);
INSERT INTO `fundtransfer` VALUES ('34', '1695742031', '2010-04-26', '3', '1001', '43999', null);
INSERT INTO `fundtransfer` VALUES ('35', '1695742032', '2010-05-17', '2', '1010', '46244', null);
INSERT INTO `fundtransfer` VALUES ('36', '1695742033', '2010-05-17', '3', '1100', '50371', null);
INSERT INTO `fundtransfer` VALUES ('37', '1695742034', '2010-06-21', '2', '2001', '91551', null);
INSERT INTO `fundtransfer` VALUES ('38', '1695742035', '2010-06-21', '3', '1100', '50162', null);
INSERT INTO `fundtransfer` VALUES ('39', '1695742036', '2010-07-19', '2', '1010', '47092', null);
INSERT INTO `fundtransfer` VALUES ('40', '1695742037', '2010-07-19', '3', '1100', '51295', null);
INSERT INTO `fundtransfer` VALUES ('41', '1695742038', '2010-08-24', '2', '2100', '97239', null);
INSERT INTO `fundtransfer` VALUES ('42', '1695742039', '2010-09-21', '3', '1050', '47123', null);
INSERT INTO `fundtransfer` VALUES ('43', '1695742040', '2010-10-18', '3', '1001', '43768', null);
INSERT INTO `fundtransfer` VALUES ('44', '1695742041', '2010-10-18', '2', '2001', '87799', null);
INSERT INTO `fundtransfer` VALUES ('45', '1695742042', '2010-11-24', '3', '1261', '57069', null);
INSERT INTO `fundtransfer` VALUES ('46', '1695742043', '2010-12-20', '2', '1100', '48893', null);
INSERT INTO `fundtransfer` VALUES ('47', '1695742044', '2011-01-13', '2', '2300', '103379', null);
INSERT INTO `fundtransfer` VALUES ('48', '1695742045', '2011-01-26', '2', '2300', '104791', null);
INSERT INTO `fundtransfer` VALUES ('49', '1695742046', '2011-02-15', '2', '1100', '49089', null);
INSERT INTO `fundtransfer` VALUES ('50', '1695742047', '2011-02-15', '3', '2200', '98357', null);
INSERT INTO `fundtransfer` VALUES ('51', '1695742048', '2011-02-23', '2', '3500', '156695', null);
INSERT INTO `fundtransfer` VALUES ('52', '1695742049', '2011-03-28', '4', '1400', '61345', null);
INSERT INTO `fundtransfer` VALUES ('53', '1695742050', '2011-03-28', '2', '2100', '92760', null);
INSERT INTO `fundtransfer` VALUES ('54', '1695742051', '2011-04-04', '3', '3100', '135616', null);
INSERT INTO `fundtransfer` VALUES ('55', '1695742052', '2011-04-18', '3', '2100', '92002', null);
INSERT INTO `fundtransfer` VALUES ('56', '1695742053', '2011-05-18', '2', '1100', '48990', null);
INSERT INTO `fundtransfer` VALUES ('57', '1695742054', '2011-05-18', '3', '1100', '48990', null);
INSERT INTO `fundtransfer` VALUES ('58', '1695742055', '2011-06-06', '3', '1500', '66273', null);
INSERT INTO `fundtransfer` VALUES ('59', '1695742056', '2011-06-20', '3', '1100', '48664', null);
INSERT INTO `fundtransfer` VALUES ('60', '1695742057', '2011-06-30', '2', '1600', '70150', null);
INSERT INTO `fundtransfer` VALUES ('61', '1695742058', '2011-07-11', '5', '1100', '48189', null);
INSERT INTO `fundtransfer` VALUES ('62', '1695742059', '2011-07-18', '2', '1600', '70277', null);
INSERT INTO `fundtransfer` VALUES ('63', '1695742060', '2011-08-05', '2', '1600', '71156', null);
INSERT INTO `fundtransfer` VALUES ('64', '1695742061', '2011-09-19', '2', '1100', '52782', null);
INSERT INTO `fundtransfer` VALUES ('65', '1695742062', '2011-09-27', '2', '2100', '102296', null);
INSERT INTO `fundtransfer` VALUES ('66', '1695742063', '2011-10-18', '1', '1300', '64437', null);
INSERT INTO `fundtransfer` VALUES ('67', '1695742064', '2011-11-09', '1', '1300', '65145', null);
INSERT INTO `fundtransfer` VALUES ('68', '1695742065', '2011-11-29', '5', '1300', '66097', null);
INSERT INTO `fundtransfer` VALUES ('69', '1695742066', '2011-12-13', '1', '1300', '67667', null);
INSERT INTO `fundtransfer` VALUES ('70', '1695742067', '2012-01-19', '1', '1300', '67343', null);
INSERT INTO `fundtransfer` VALUES ('71', '1695742068', '2012-02-08', '4', '6100', '0', 'Closed');
INSERT INTO `fundtransfer` VALUES ('72', '1695742069', '2012-02-16', '4', '6100', '295488', null);
INSERT INTO `fundtransfer` VALUES ('73', '1695742070', '2012-03-12', '4', '1300', '64397', null);
INSERT INTO `fundtransfer` VALUES ('74', '1695742071', '2012-04-09', '4', '1600', '81552', null);
INSERT INTO `fundtransfer` VALUES ('75', '1695742072', '2012-04-16', '1', '1300', '66832', null);
INSERT INTO `fundtransfer` VALUES ('76', '1695742073', '2012-05-06', '2', '2600', '137594', 'SBI Life Insurance');
INSERT INTO `fundtransfer` VALUES ('77', '1695742074', '2012-05-21', '2', '1300', '71262', null);
INSERT INTO `fundtransfer` VALUES ('78', '1695742075', '2012-06-04', '4', '1300', '70786', null);
INSERT INTO `fundtransfer` VALUES ('79', '1695742076', '2012-06-04', '1', '1600', '87138', null);
INSERT INTO `fundtransfer` VALUES ('80', '1695742077', '2012-06-25', '4', '1200', '65809', null);
INSERT INTO `fundtransfer` VALUES ('81', '1695742078', '2012-07-25', '1', '1600', '87598', null);
INSERT INTO `fundtransfer` VALUES ('82', '1695742079', '2012-08-03', '1', '1300', '71066', null);
INSERT INTO `fundtransfer` VALUES ('83', '1695742080', '2012-08-10', '1', '2100', '115431', null);
INSERT INTO `fundtransfer` VALUES ('107', '1695742081', '2012-09-12', '2', '1300', '69752', null);
INSERT INTO `fundtransfer` VALUES ('108', '1695742082', '2012-10-20', '1', '1300', '69044', null);
INSERT INTO `fundtransfer` VALUES ('109', '1695742083', '2012-11-09', '2', '1300', '70124', '');
INSERT INTO `fundtransfer` VALUES ('110', '1695742084', '2012-12-15', '2', '1300', null, '');

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `desc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('1', 'Kareem', null);
INSERT INTO `member` VALUES ('2', 'Shahana', null);
INSERT INTO `member` VALUES ('3', 'Hafsa', null);

-- ----------------------------
-- Table structure for `menu`
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menuid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  `createddate` date DEFAULT NULL,
  `updateddate` date DEFAULT NULL,
  PRIMARY KEY (`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', 'Home', null, '2012-10-04', '2012-10-04');
INSERT INTO `menu` VALUES ('2', 'Personal Apps', null, '2012-10-04', '2012-10-04');
INSERT INTO `menu` VALUES ('3', 'Islamic Apps', null, '2012-10-04', '2012-10-04');
INSERT INTO `menu` VALUES ('4', 'Contact', null, '2012-10-04', '2012-10-04');

-- ----------------------------
-- Table structure for `priority`
-- ----------------------------
DROP TABLE IF EXISTS `priority`;
CREATE TABLE `priority` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKPRIORITY` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of priority
-- ----------------------------
INSERT INTO `priority` VALUES ('1', 'Highest', 'Should be completed with in a day');
INSERT INTO `priority` VALUES ('2', 'High', 'Should be completed in 2 days');
INSERT INTO `priority` VALUES ('3', 'Medium', 'Should be completed in 4 days');
INSERT INTO `priority` VALUES ('4', 'Low', 'Should be completed in a week');

-- ----------------------------
-- Table structure for `remainder`
-- ----------------------------
DROP TABLE IF EXISTS `remainder`;
CREATE TABLE `remainder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remainder` varchar(100) NOT NULL,
  `createddate` date NOT NULL,
  `lastremainder` date DEFAULT NULL,
  `nextremainder` date NOT NULL,
  `daysafter` int(11) DEFAULT NULL,
  `daysbefore` int(11) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKREMAINDER` (`remainder`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of remainder
-- ----------------------------
INSERT INTO `remainder` VALUES ('1', 'Pubic hair removal', '2012-11-12', '2012-12-07', '2013-01-12', '30', '40', '');
INSERT INTO `remainder` VALUES ('2', 'Hair Cut', '2012-11-12', '2012-10-21', '2012-12-23', null, null, null);
INSERT INTO `remainder` VALUES ('3', 'Oil Change', '2012-11-12', '2012-12-01', '2013-03-10', '90', '100', '');
INSERT INTO `remainder` VALUES ('16', 'TV Subscription', '2012-11-19', '2012-08-16', '2013-01-15', null, null, '');

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'admin', '2012-09-26 16:52:45', '2012-09-26 16:52:56');
INSERT INTO `role` VALUES ('2', 'normal', '2012-09-26 16:53:16', '2012-09-26 16:53:18');

-- ----------------------------
-- Table structure for `status`
-- ----------------------------
DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKSTATUS` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of status
-- ----------------------------
INSERT INTO `status` VALUES ('1', 'Not Started', null);
INSERT INTO `status` VALUES ('2', 'In Progress', null);
INSERT INTO `status` VALUES ('3', 'Pending', null);
INSERT INTO `status` VALUES ('4', 'Completed', null);
INSERT INTO `status` VALUES ('5', 'Cancelled', null);

-- ----------------------------
-- Table structure for `submenu`
-- ----------------------------
DROP TABLE IF EXISTS `submenu`;
CREATE TABLE `submenu` (
  `submenuid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  `menuid` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  `isdefault` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`submenuid`),
  KEY `FK3580769128426F` (`menuid`) USING BTREE,
  CONSTRAINT `FK3580769128426F` FOREIGN KEY (`menuid`) REFERENCES `menu` (`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of submenu
-- ----------------------------
INSERT INTO `submenu` VALUES ('1', 'Blog', null, '2', 'bcategory', '2012-10-07 09:42:21', '2012-10-07 09:42:25', 'no');
INSERT INTO `submenu` VALUES ('2', 'Tasks', null, '2', 'tasktype', '2012-10-07 09:42:52', '2012-10-07 09:42:55', 'no');
INSERT INTO `submenu` VALUES ('3', 'Expenses', null, '2', 'ecategory', '2012-10-07 09:43:09', '2012-10-07 09:43:15', 'yes');
INSERT INTO `submenu` VALUES ('4', 'Credentials', null, '2', 'ccategory', '2012-10-07 09:43:41', '2012-10-07 09:43:44', 'no');
INSERT INTO `submenu` VALUES ('5', 'Contacts', null, '2', 'concategory', '2012-10-07 09:43:56', '2012-10-07 09:44:00', 'no');

-- ----------------------------
-- Table structure for `subsubmenu`
-- ----------------------------
DROP TABLE IF EXISTS `subsubmenu`;
CREATE TABLE `subsubmenu` (
  `subsubmenuid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `desc` varchar(100) DEFAULT NULL,
  `submenuid` int(11) NOT NULL,
  `createddate` datetime NOT NULL,
  `updateddate` datetime NOT NULL,
  PRIMARY KEY (`subsubmenuid`),
  KEY `FK3580769128426G` (`submenuid`) USING BTREE,
  CONSTRAINT `FK3580769128426G` FOREIGN KEY (`submenuid`) REFERENCES `submenu` (`submenuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of subsubmenu
-- ----------------------------
INSERT INTO `subsubmenu` VALUES ('1', 'Add', null, '5', '2012-10-07 09:44:27', '2012-10-07 09:44:30');
INSERT INTO `subsubmenu` VALUES ('2', 'View', null, '5', '2012-10-07 09:44:42', '2012-10-07 09:44:46');

-- ----------------------------
-- Table structure for `task`
-- ----------------------------
DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `priority` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `createddate` date NOT NULL,
  `duedate` date NOT NULL,
  `completeddate` date DEFAULT NULL,
  `status` int(11) NOT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKTASK` (`name`) USING BTREE,
  KEY `FK3580769128426H` (`priority`),
  KEY `FK3580769128426I` (`type`),
  KEY `FK3580769128426J` (`status`),
  CONSTRAINT `FK3580769128426H` FOREIGN KEY (`priority`) REFERENCES `priority` (`id`),
  CONSTRAINT `FK3580769128426I` FOREIGN KEY (`type`) REFERENCES `tasktype` (`id`),
  CONSTRAINT `FK3580769128426J` FOREIGN KEY (`status`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of task
-- ----------------------------
INSERT INTO `task` VALUES ('110', 'Call Car Insurance Companies', '2', '2', '2013-05-06', '2013-05-14', '0000-00-00', '1', 'Check with State Farm first');
INSERT INTO `task` VALUES ('111', 'Find Gastroenterologist', '3', '2', '2013-05-06', '2013-05-16', '2013-05-17', '1', '');
INSERT INTO `task` VALUES ('112', 'Check tag', '2', '2', '2013-05-06', '2013-05-08', '2013-05-11', '4', 'if not arrived call Honda carland and check\r\n\r\n5/8 - Checked with Honda Carland, Tag is already done, it will come in few days.');
INSERT INTO `task` VALUES ('113', 'Enroll into Honda Carland', '1', '1', '2013-05-06', '2013-05-10', '0000-00-00', '1', 'both online and send card');
INSERT INTO `task` VALUES ('114', 'Call about ticket', '1', '2', '2013-05-06', '2013-05-15', '2013-05-08', '4', '');
INSERT INTO `task` VALUES ('115', 'Copy Bayaans', '3', '2', '2013-05-06', '2013-05-18', '0000-00-00', '2', 'into iPod');
INSERT INTO `task` VALUES ('116', 'Call Madhu Reddy', '1', '2', '2013-05-06', '2013-05-08', '2013-05-14', '4', 'for refill\r\n5/9 - called today and requested to send prescription to Walgreens.\r\n\r\n5/14 - picked up medicine from walgreens');
INSERT INTO `task` VALUES ('117', 'Call walmart cc', '1', '1', '2013-05-06', '2013-05-09', '2013-05-06', '4', 'Check why i did not get discount of $20 upon opening card\r\n\r\n5/6 - $20 will be debited and also late fee of $25 will be waived');
INSERT INTO `task` VALUES ('118', 'Check immigration email', '1', '3', '2013-05-13', '2013-05-13', '2013-05-14', '4', '5/13 - respond by EOD today\r\n\r\n5/14 - checked I129 and it has both the addresses');
INSERT INTO `task` VALUES ('119', 'Transfer money', '2', '1', '2013-05-17', '2013-05-20', '2013-05-17', '1', '');

-- ----------------------------
-- Table structure for `tasktype`
-- ----------------------------
DROP TABLE IF EXISTS `tasktype`;
CREATE TABLE `tasktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKTASKTYPE` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tasktype
-- ----------------------------
INSERT INTO `tasktype` VALUES ('1', 'Home', 'Home Desc for Tasks');
INSERT INTO `tasktype` VALUES ('2', 'Personal', '');
INSERT INTO `tasktype` VALUES ('3', 'Work', null);
INSERT INTO `tasktype` VALUES ('4', 'Technical', null);
INSERT INTO `tasktype` VALUES ('5', 'Misc', null);

-- ----------------------------
-- Table structure for `totalexpenses`
-- ----------------------------
DROP TABLE IF EXISTS `totalexpenses`;
CREATE TABLE `totalexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL,
  `totalamount` float(11,5) NOT NULL DEFAULT '0.00000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of totalexpenses
-- ----------------------------
INSERT INTO `totalexpenses` VALUES ('1', 'Nov', '2012', '1297.15002');
INSERT INTO `totalexpenses` VALUES ('2', 'Dec', '2012', '1758.47998');
INSERT INTO `totalexpenses` VALUES ('3', 'May', '2013', '53.53000');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `createddate` date NOT NULL,
  `updateddate` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'kareems', 'nDZ0FZSlehhAhGz5/eT3Kjyzk+s=', '2012-09-26', '2012-09-26');
INSERT INTO `user` VALUES ('2', 'admin', '0DPiKuNIrrVmD8IUCuw1hQxNqZc=', '2012-09-27', '2012-09-27');
INSERT INTO `user` VALUES ('3', 'karims', '54f9428421cc56c2a9dd0167dfee0cc3', '2013-05-17', '2013-05-17');

-- ----------------------------
-- Table structure for `user2role`
-- ----------------------------
DROP TABLE IF EXISTS `user2role`;
CREATE TABLE `user2role` (
  `id` int(20) NOT NULL,
  `userid` bigint(20) NOT NULL,
  `roleid` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426D` (`userid`),
  KEY `FK3580769128426E` (`roleid`),
  CONSTRAINT `FK3580769128426E` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`),
  CONSTRAINT `FK3580769128426D` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user2role
-- ----------------------------
INSERT INTO `user2role` VALUES ('1', '1', '2');
INSERT INTO `user2role` VALUES ('2', '2', '1');

-- ----------------------------
-- Table structure for `userdetails`
-- ----------------------------
DROP TABLE IF EXISTS `userdetails`;
CREATE TABLE `userdetails` (
  `userid` bigint(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `FK3580769128426C` (`userid`),
  CONSTRAINT `FK3580769128426C` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userdetails
-- ----------------------------
INSERT INTO `userdetails` VALUES ('3', 'Kareem', 'Shaik', 'mailtokarims@yahoo.com', '6789435398', null, null, null);

-- ----------------------------
-- Table structure for `weightrecorder`
-- ----------------------------
DROP TABLE IF EXISTS `weightrecorder`;
CREATE TABLE `weightrecorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createddate` date NOT NULL,
  `member` int(11) NOT NULL,
  `weight` float(50,5) DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3580769128426N` (`member`) USING BTREE,
  CONSTRAINT `FK3580769128426N` FOREIGN KEY (`member`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of weightrecorder
-- ----------------------------
INSERT INTO `weightrecorder` VALUES ('1', '2012-11-24', '3', '31.60000', '');
INSERT INTO `weightrecorder` VALUES ('2', '2012-11-24', '2', '166.80000', '');
INSERT INTO `weightrecorder` VALUES ('3', '2012-11-24', '1', '127.40000', '');
INSERT INTO `weightrecorder` VALUES ('4', '2012-12-12', '2', '172.00000', '');
