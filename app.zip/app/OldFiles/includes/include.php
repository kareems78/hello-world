<?php
	require_once ROOT."/includes/common/defines.php";
	require_once ROOT."/includes/common/session.php";
	require_once ROOT."/includes/common/usersession.php";
	require_once ROOT."/includes/common/util.php";
?>