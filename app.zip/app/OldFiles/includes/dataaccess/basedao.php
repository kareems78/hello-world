<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 /**
  * Base Data Access Class 
  * 
  *
  */
 abstract class BaseDAO extends PDO
 {
 
	protected $_tableName = null;
	
	protected $_formInputs = null;
	
	protected $_result = null;
	
	protected $_userid = null;
	
    protected $_conn = null;
    
 	/**
	 * Base Constructor which is used to set default values.
	 *
	 */    
    function __construct($tableName, $userid)
    {
        try
        {
            $this->_conn = new PDO("sqlite:".ROOT."uac.sqlite");
            $this->_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
			
            $this->_tableName = $tableName;
		
			$this->_userid = $userid;              
        }  
        catch (PDOException $e){
            $e->getMessage();
        }
    }	
	
     /**
      * Retrieves all the rows from a
      * table when table name is set
      *
      * @return list - returns the result set of rows
      *
      */
     public function getAll()
	 {
		$this->_result = self::getAllRecords($this->_tableName);			
		
		return $this->_result;		
	 }

	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function getAllRecords($tableName)
	 {
	 	$query = "SELECT * FROM ".$tableName;
	 		 	
	 	/*$query_programs = $this->_conn->prepare($query);
	 	
	 	if($query_programs->execute())
		{
			$query_programs->setFetchMode(PDO::FETCH_OBJ);
			return $query_programs->fetchAll();
		}
		else
		{
			return false;
		}*/

	 	$stmt = $this->_conn->query($query);
	 	
	 	return $stmt->fetchAll(PDO::FETCH_ASSOC);	 	
		
	 }	 
	 
	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function executeQuery($query)
	 {
	 	//echo "query -> " . $query;
	 	/*$query_programs = $this->conn->prepare($query);
	 	
	 	if($query_programs->execute())
		{
			$query_programs->setFetchMode(PDO::FETCH_OBJ);
			return $query_programs->fetchAll();
		}
		else
		{
			return false;
		}*/

	 	$stmt = $this->_conn->query($query);
	 	
	 	return $stmt->fetchAll(PDO::FETCH_ASSOC);
		
	 }		

	 /**
	  * 
	  * Enter description here ...
	  * @param unknown_type $tableName
	  */
 	 public function executeQueryWithOneParam($query, $param)
	 {
	 	
	 	$query_programs = $this->_conn->prepare($query);
		if($query_programs->execute(array($param)))
		{
			$query_programs->setFetchMode(PDO::FETCH_OBJ);
			return $query_programs->fetchAll();
		}
		else
		{
			return false;
		}	 	
	 }		 

     /**
      * Retrieves rows order by id
      *
      * @return list
      *
      */
     public function getByOrderID()
	 {
		$query = "select * from ".$this->_tableName." order by id";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }
	
      /**
      * Retrieves rows order by id
      *
      * @return list
      *
      */
     public function getByOrderIdDesc()
	 {
		$query = "select * from ".$this->_tableName." order by id desc";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }	


     /**
      * Retrieves rows order by name
      *
      * @return list
      *
      */
     public function getOrderByName()
	 {
		$query = "select * from ".$this->_tableName." order by name";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }		
	
      /**
      * Retrieves rows order by name
      *
      * @return list
      *
      */
     public function getOrderByNameDesc()
	 {
		$query = "select * from ".$this->_tableName." order by name desc";
		$this->_result = $this->executeQuery($query);			
		
		return $this->_result;		
	 }	

     /**
      * set the form input values to local variable
      *
      * @param $formInputs
      *
      */
     public function setFormInputs($formInputs)
	 {
		$this->_formInputs = $formInputs;
	 }
	
     /**
      * Retrieves data from database
      * from any table as per given
      * id and table name set
      *
      * @param $id
      * @return list
      */
     public function getByID($id)
	 {
		$query = "select * from ".$this->_tableName." where id=".$id;
		$this->_result = $this->executeQuery($query );
		return $this->_result;
	 }
	
	/**
	 * Deleted multiple rows
	 * from database
	 */
	public function delete()
	{
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		foreach ($deleteIDs as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$query = "delete from ".$this->_tableName." where id=".$id;
			$this->executeQuery($query);
		}		
		
	}	
	
	/**
	 * Gets all pages required for settings
	 * 
	 */
	public function getAllPageNames()
	{
		$query = "select distinct(page) from pagesettings where tablename = '".$this->_tableName."' and user = ".$this->_userid;
		$this->_result = $this->executeQuery($query);
		return $this->_result;		
	}
	
	/**
	 * Gets column info about a particular page
	 * @param $pageName
	 * 
	 */
	public function getPageSettings($pageName)
	{
		$query = "select * from pagesettings where tablename = '".$this->_tableName."' and user = ".$this->_userid.
		         " and page = '".$pageName."'";
		$this->_result = $this->executeQuery($query );
		return $this->_result;		
	}
	
      /**
      * 
      * @param $_formValues
      */
     public function performFinalPageSettings($_formValues)
     {
     	$result = null;
		$rs = $this->getPageSettings($_formValues['pagename']);

		
		foreach($rs as $rows => $row)
		{
			echo"row['columnname'] -- ".$row['columnname']."<br>";
			if (array_key_exists($row['columnname'] , $_formValues))
			{
				$colname = $row['columnname'];
				
				$updateQuery = "update pagesettings set visible=:visible ".
							   "where page=:page and columnname=:columnname and user=:user";
				
				$pdo = Database::getPDODBConnection();
				
				$stmt = $pdo->prepare($updateQuery);
				$stmt->bindValue(':visible', $_formValues[$colname]);
				$stmt->bindValue(':page', $_formValues['pagename']);
				$stmt->bindValue(':columnname', $row['columnname']);
				$stmt->bindValue(':user', $this->_userid);
				
				$result = $stmt->execute();
				
				//echo "result : ".$result."<br>";
				
				//echo"exists -- ".$_formValues[$colname]."<br>";
			}			
		}	

		return $result;
     }		
     
     /**
      * 
      * Generates unique id per row for an user
      * 
      * @return next available id for user
      */
     public function generateID()
     {
     	$tableID = null;
   		$tableName = $this->_tableName;
     	
     	$rowCountQuery = "select * from ".$tableName;
     	$result = $this->executeQuery($rowCountQuery);
     	
     	if (sizeof($result)== 0)
     	{
     		$query = "select tableid from user where id = ".$this->_userid;
     		$result = $this->executeQuery($query);
     		
     		$row = $result[0];
     		     		
     		return $row['tableid'];
     	}
     	else 
     	{
     		$maxQuery = "select max(id) as maxid from ".$tableName." where user = ".$this->_userid;
    		
     		//echo "query -> ".$maxQuery;
     		
			$max_rs = $this->executeQuery($maxQuery);
			$row = $max_rs[0];	
     	   
        	$tableID = $row['maxid'] + 1;
     		
     		return $tableID;     		
     	}
     	
     }
     
     /**
      * 
      * Generates unique id per row for an user with 
      * given table name
      * 
      * @return next available id for user
      */
     public function generateIDWithTable($name)
     {
     	$tableID = null;
     	$tableName = null;
     	
     	if (isset($name))
     	{
     		$tableName = $name;
     	}
     	else
     	{
     		$tableName = $this->_tableName;
     	}
     	
     	$rowCountQuery = "select * from ".$tableName;
     	$result = $this->executeQuery($rowCountQuery);
     	
     	if (sizeof($result) == 0)
     	{
     		$query = "select tableid from user where id = ".$this->_userid;
     		$result = $this->executeQuery($query);
     		
     		$row = $result[0];
     		
     		return $row['tableid'];
     	}
     	else 
     	{
     		$maxQuery = "select max(id) as maxid from ".$tableName." where user = ".$this->_userid;
    		
     		//echo "query -> ".$maxQuery;
     		
			$max_rs = $this->executeQuery($maxQuery);
			$row = $max_rs[0];	
     	   
        	$tableID = $row['maxid'] + 1;
     		
     		return $tableID;     		
     	}
     	
     }     
     
     /**
      * 
      * Enter description here ...
      * @param $tableID
      * @param $table
      */
     public function updateWithTempIDsIfIDExists($tableID, $table, $user)
     {
     	$tableIDExists = false;
     	$savedTableID = $tableID;
     	
	 	$query = "select id from ".$table." where user = ".$user;
	 	$result = $this->executeQuery($query);  

     	while ($row = $result[0])
	 	{
	 		if ($row['id'] == $tableID)
	 		{
	 			$tableIDExists = true;
	 			break;
	 		}
	 			
 			$tableID = $tableID + 1;
		}	

		if ($tableIDExists)
		{
			$tmpTableID = (9*1).$savedTableID;
			
			echo "<br>tmpTableID : ".$tmpTableID;
			
		 	$getIDsQuery = "select id from ".$table." where user = ".$user;
		 	$rs = $this->executeQuery($getIDsQuery); 			
			
			while ($row = $rs[0])
	 		{
	 			echo "<br>row[id] : ".$row['id']." tmpTableID : ".$tmpTableID;
	 			
	 			$updateTableQuery = "update ".$table." set id = ".$tmpTableID." where id = ".$row['id'].
	 			                    " and user = ".$user;
	 			
	 			echo "<br>Update Query -> ".$updateTableQuery;
	 			
	 			$updateRs = $this->executeQuery($updateTableQuery);
	 			
	 			$tmpTableID = $tmpTableID + 1;
	 		}			
		}
     }
	
 }