<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Remainder
 *
 */ 
 class RemainderDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'remainder';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for CredentialDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from remainder where user = ".$this->_userid." order by nextremainder",
		);
		
		return $queriesArray;
	}

     /**
      * Inserts a row into database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentDate();
		
		if ($_formValues['lastremainder'] != '')
		{
			$lastRemainder = CommonUtil::convertToSQLiteDateFormat($_formValues['lastremainder']);
		}
		else
		{
			$lastRemainder = $createdDate;
		}
		
		if ($_formValues['nextremainder'] != '')
		{
			$nextRemainder = CommonUtil::convertToSQLiteDateFormat($_formValues['nextremainder']);
		}
		else
		{
			$nextRemainder = $createdDate;
		}
		
		$id = $this->generateID();
		
		$addQuery = "insert into remainder (id, remainder, createddate, lastremainder, nextremainder, user, daysafter, daysbefore, notes) values ".
						"(:id, :remainder, :createddate, :lastremainder, :nextremainder, :user, :daysafter, :daysbefore, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':remainder', $_formValues['remainder']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':lastremainder', $lastRemainder);
		$stmt->bindValue(':nextremainder', $nextRemainder);		
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':daysafter', $_formValues['daysafter']);
		$stmt->bindValue(':daysbefore', $_formValues['daysbefore']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      * @throws DatabaseException
      */
     public function update($_formValues)
	{
		
		$lastRemainder = CommonUtil::convertToMySQLDateFormat($_formValues['lastremainder']);
		$nextRemainder = CommonUtil::convertToMySQLDateFormat($_formValues['nextremainder']);
		
		$updateQuery = "update remainder set remainder=:remainder, lastremainder=:lastremainder, nextremainder=:nextremainder, daysafter=:daysafter, daysbefore=:daysbefore, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':remainder', $_formValues['remainder']);
		$stmt->bindValue(':lastremainder', $lastRemainder);
		$stmt->bindValue(':nextremainder', $nextRemainder);		
		$stmt->bindValue(':daysafter', $_formValues['daysafter']);
		$stmt->bindValue(':daysbefore', $_formValues['daysbefore']);
		$stmt->bindValue(':notes', $_formValues['notes']);			
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	

 }
