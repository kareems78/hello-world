<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 //require_once DATAACCESS . 'userdetailsdao.php';
 require_once DATAACCESS . 'roledao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for User
 *
 */ 
 class UserDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'user';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for UserDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select u.id, u.username, u.password, r.name as role, u.createddate, ". 
								 "u.updateddate, u.tableid, ud.firstname, ud.lastname, ud.emailid, ud.phone,ud.address, ".
								 "ud.city, ud.state, ud.zip from user u, userdetails ud, user2role ur, role r ".
								 "where u.id=ud.userid and u.id=ur.userid and ur.roleid=r.id ".
								 "order by u.id"
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for expense category will be
      * retrieved and stored in array
      *
      * @return list - result of expense category
      *
      */
     public function getDropDownValues()
	{
		$roleDAO = new RoleDAO();
		
		// get info from ecategory
		$userrole_rs = $roleDAO->getOrderByName();
		
		return $userrole_rs;
	}

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
    public function insert($_formValues)
	{
		$createdDate = CommonUtil::getCurrentDate();
		
		$currentUser = $this->getUserCount() + 1;
		
		echo 'curr user : '.$currentUser;
		
		$tableID = $this->generateTableID($currentUser);
		
		echo 'table id : '.$tableID;
		
		$addUserQuery = "insert into user (username, password, createddate, updateddate, tableid) values ".
						"(:username, :password, :createddate, :updateddate, :tableid)";
		
		$stmt = $this->_conn->prepare($addUserQuery);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', md5($_formValues['password']));
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':tableid', $tableID);
		
		$result = $stmt->execute();

		if ($result == 1)
		{
			$userid = $this->getUserId($_formValues['username'], $_formValues['password']);
			
			$this->addUserToRole($userid, $_formValues['role']);
			
			$this->addUserDetails($userid, $_formValues);			
		}

		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
	/**
	 * Gets userid when username & password is given
	 * 
	 * @param $username
	 * @param $password
	 * 
	 * @return userid
	 */
	public function getUserId($username, $password)
	{
		$userid = null;

		$query = "select * from user where username='".$username."' and password='".md5($password)."'";

		$rs = $this->executeQuery($query);	
			
		$rowsReturned = $rs->num_rows;	

		if ($rowsReturned == 1)
		{		
			$row = $rs[0];
			
			$userid = $row['id']; 
		}
		
		return $userid;
	}

	/**
	 * Adds user to a role
	 * 
	 * @param  $userid
	 * @param  $roleid
	 */
	public function addUserToRole($userid, $roleid)
	{
		$addUserRoleQuery = "insert into user2role (userid, roleid) values ".
						    "(:userid, :roleid)";
		
		$stmt = $this->_conn->prepare($addUserRoleQuery);
		$stmt->bindValue(':userid', $userid);
		$stmt->bindValue(':roleid', $roleid);
		
		$result = $stmt->execute(); 
	}
	
	/**
	 * Adds a record into userdetails table
	 * 
	 * @param  $userid
	 * @param  $_formValues
	 */
	public function addUserDetails($userid, $_formValues)
	{
		$addUserRoleQuery = "insert into userdetails (userid, firstname, lastname, emailid, phone, address, city, state, zip) values ".
						    "(:userid, :firstname, :lastname, :emailid, :phone, :address, :city, :state, :zip)";
		
		$stmt = $this->_conn->prepare($addUserRoleQuery);
		$stmt->bindValue(':userid', $userid);
		$stmt->bindValue(':firstname', $_formValues['firstname']);
		$stmt->bindValue(':lastname', $_formValues['lastname']);
		$stmt->bindValue(':emailid', $_formValues['emailid']);
		$stmt->bindValue(':phone', $_formValues['phone']);
		$stmt->bindValue(':address', $_formValues['address']);
		$stmt->bindValue(':city', $_formValues['city']);
		$stmt->bindValue(':state', $_formValues['state']);
		$stmt->bindValue(':zip', $_formValues['zip']);
		
		$result = $stmt->execute(); 		
	}
	
	/**
	 * Returns user role and details for given userid
	 * 
	 * @param $userid
	 */
	public function getUserAndRoleDetails($userid)
	{
		$query = "select u.id, u.username, u.password, r.id as role, u.createddate, ". 
				 "u.updateddate, ud.firstname, ud.lastname, ud.emailid, ud.phone,ud.address, ".
				 "ud.city, ud.state from user u, userdetails ud, user2role ur, role r ".
				 "where u.id=ud.userid and u.id=ur.userid and ur.roleid=r.id and u.id=".$userid;
		
		$result = $this->executeQuery($query);
		
		return $result;
	}
	
     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
    public function update($_formValues)
	{
		$updatePWD = true;
		$result = null;
		
		$updatedDate = CommonUtil::getCurrentDate();
		
		if ($_formValues['password'] == md5('nochange'))
		{
			$updatePWD = false;
		}
		
		if ($updatePWD)
		{
			$updateQuery = "update user set username=:username, password=:password, updateddate=:updateddate ".
						          "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':username', $_formValues['username']);		
			$stmt->bindValue(':password', md5($_formValues['password']));
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':id', $_formValues['id']);
			
			$result = $stmt->execute();
		}
		else
		{
			$updateQuery = "update user set username=:username, updateddate=:updateddate ".
						          "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':username', $_formValues['username']);		
			$stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':id', $_formValues['id']);
			
			$result = $stmt->execute();			
		}
		
		if ($result == 1)
		{
			$this->updateUserRole($_formValues['id'], $_formValues['role']);
			
			$this->updateUserDetails($_formValues['id'], $_formValues);			
		}

		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
	/**
	 * Updates user role
	 * 
	 * @param $userid
	 * @param $roleid
	 */
	public function updateUserRole($userid, $roleid)
	{
		$updateUserRoleQuery = "update user2role set roleid=:roleid ".
					           "where userid=:userid";
		
		$stmt = $this->_conn->prepare($updateUserRoleQuery);
		$stmt->bindValue(':roleid', $roleid);		
		$stmt->bindValue(':userid', $userid);
		
		$result = $stmt->execute();		
	}
	
	/**
	 * Updates user details
	 * 
	 * @param $userid
	 * @param $_formValues
	 */
	public function updateUserDetails($userid, $_formValues)
	{
		$updateUserRoleQuery = "update userdetails set firstname=:firstname, lastname=:lastname, ".
							   "emailid=:emailid, phone=:phone, address=:address, city=:city, ".
		                       "state=:state, zip=:zip ".
					           "where userid=:userid";
		
		$stmt = $this->_conn->prepare($updateUserRoleQuery);
		$stmt->bindValue(':firstname', $_formValues['firstname']);		
		$stmt->bindValue(':lastname', $_formValues['lastname']);
		$stmt->bindValue(':emailid', $_formValues['emailid']);
		$stmt->bindValue(':phone', $_formValues['phone']);
		$stmt->bindValue(':address', $_formValues['address']);
		$stmt->bindValue(':city', $_formValues['city']);
		$stmt->bindValue(':state', $_formValues['state']);
		$stmt->bindValue(':zip', $_formValues['zip']);
		$stmt->bindValue(':userid', $userid);
		
		$result = $stmt->execute();			
	}
	

	/**
	 * Delete selected users 
     *
	 */
	public function deleteUsers()
	{
		$rs_userroledetails = $this->deleteUserRoleDetails();
		
		$result = $this->delete();
		
		return $result;		

	}
	
	/**
	 * 
	 * Deletes user details and user2role details
	 * 
	 */
	public function deleteUserRoleDetails()
	{
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete user dao : count : ".count($deleteIDs)."<br>";	

		foreach ($deleteIDs as &$id) {
			//echo "id : ".$id."<br>";
			
			$deleteUserDetailsQuery = "delete from userdetails where userid=".$id;
			$this->executeQuery($deleteUserDetailsQuery);

			$deleteUserRoleQuery = "delete from user2role where userid=".$id;
			$this->executeQuery($deleteUserRoleQuery);
			
		}			
	}
	
	/**
	 * 
	 * Gets the user count from database
	 * 
	 * @return user count
	 */
	public function getUserCount()
	{
		$query = "select * from user";
		$result = $this->executeQuery($query);
		
		$userCount = $result->num_rows;
		
		//echo 'user count : '.$userCount;
		
		return $userCount;		
	}
	
	/**
	 * 
	 * Generates table id as per user count
	 * which is used for each user and can be 
	 * used while inserting rows into table so that 
	 * when data is migrated we will not face issues 
	 * with ids
	 * 
	 * @param $user
	 * @return id
	 */
	public function generateTableID($user)
	{
		$id = ($user * 100).($user * 100).(1*1);
		return $id;		
	}
	
     /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     /*public function search($searchStr)
	{
	
		//echo "in search ...".$_formValues['fromdate']." ".$_formValues['todate']." ".$_formValues['category'];
		$dateRange = CommonUtil::dateRangeForCurrent();
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$currentMonth = date('M');
		$currentYear = date('Y');		
		
		//$searchQ = $this->generateSearchQuery($_formValues);
		
		//echo "search query in main -> ".$searchQ."<br>";
		
		$getEQuery = "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              "where e.category = ec.id ". $searchStr ." ".
							  "order by e.expensedate desc";
							  
		//echo "whole query in main -> ".$getEQuery."<br>";	
		
		if ($searchStr == '')	
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e";
		}	
		else
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e where ".substr($searchStr, 3);
		}
		
		//echo "amount query in main -> ".$getTEQuery."<br>";	
		
		$exp_rs = $this->executeQuery($getEQuery);
		$totexp_rs = $this->executeQuery($getTEQuery);
		
		$row = mysqli_fetch_array($totexp_rs);
		
		// push result set to array
		$rsArray["e"] = $exp_rs;
		$rsArray["totamt"] = $row['totalamount'];
		
		return $rsArray;		
	}

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     /*public function generateSearchQuery($_formValues)
	{
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			echo "category exists<br>";
		}
		else
		{
			echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '' and $_formValues['category'] == '')
		{
			echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['fromdate'] != '')
			{
				$fromDate = CommonUtil::convertToMySQLDateFormat($_formValues['fromdate']);
			}
			
			if ($_formValues['todate'] != '')
			{
				$toDate = CommonUtil::convertToMySQLDateFormat($_formValues['todate']);
			}
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			
			if ($_formValues['fromdate'] != '')
			{
				// only if fromdate is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ";
				}
				
				// both fromdate & todate is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ";
				}				
				
				// fromdate and category is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}	

				// fromdate, todate and category is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}					
				
				
			}
			elseif ($_formValues['category'] != '' and $_formValues['todate'] == '')
			{
				$searchQuery = "and e.category in (".$categoryIDs.")";
			}
		}

		return 	$searchQuery;
		
	}*/
	
 }