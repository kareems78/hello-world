<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Weight Recorder
 *
 */ 
 class WeightRecorderDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'weightrecorder';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for WeightRecorderDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsOldQuery" => "select wr.id, wr.createddate, m.name as mname, wr.weight, wr.notes ".
								"from weightrecorder wr, member m ".
								"where wr.member=m.id and wr.user = " . $this->_userid . " order by wr.id desc",
		
		"getAllRecordsQuery" => "select m.name as mname, wr.id, wr.createddate, wr.weight, wr.notes ".
								"from member m left join weightrecorder wr on m.id = wr.member ".
								"and wr.user = " . $this->_userid . " order by m.id",		
		
		);
		
		return $queriesArray;
	}
	
	/**
	 * Values required to display in drop down list
	 * for credential category will be 
	 * retrieved and stored in array
	 *
	 * returns result of credential category
	 */
	public function getDropDownValues()
	{
		$memberDAO = new CategoryDAO('member');
		
		// get info from ccategory
		$member_rs = $memberDAO->getAll();
		
		return $member_rs;
	}		
	

	/**
	 * 
	 * 
	 * 
	 */
	public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentDate();
		$biotestDate = CommonUtil::convertToMySQLDateFormat($_formValues['biotestdate']);
		
		$id = $this->generateID();	
		
		$addQuery = "insert into weightrecorder (id, createddate, member, user, weight, notes) values (:id, :createddate, :member, :user, :weight, ".
					":notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':member', $_formValues['member']);
		$stmt->bindValue(':user', $_formValues['userid']);				
		$stmt->bindValue(':weight', $_formValues['weight']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
	/**
	 *
	 *
	 *
	 */
	public function update($_formValues)
	{
		$biotestDate = CommonUtil::convertToMySQLDateFormat($_formValues['biotestdate']);
		
		$updateQuery = "update weightrecorder set member=:member, weight=:weight, notes=:notes ".
					   "where id=:id";
		

		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':member', $_formValues['member']);		
		$stmt->bindValue(':weight', $_formValues['weight']);
		$stmt->bindValue(':notes', $_formValues['notes']);			
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	

 }
