<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Module
 *
 */ 
 class ModuleDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'submenu';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for STimingsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select m.name as menu, sm.id, sm.name as submenu, sm.pagename, sm.category ". 
	 	                        "from menu m left join submenu sm on m.id = sm.menu order by m.id",
		);
		
		return $queriesArray;
	}
	
      /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getDropDownValues()
	 {
		$menu = new CategoryDAO('menu');
		
		// get info from ccategory
		$menu_rs = $menu->getByOrderID();
		
		return $menu_rs;
	 }
	 
	 /**
	  * Gets info of all submenu/modules
	  * 
	  * @return submenu info
	  */
	 public function getAllSubMenus()
	 {
	 	$submenuQuery = "select m.name as menu, sm.id, sm.name as submenu, sm.pagename, sm.category ". 
	 	                "from menu m left join submenu sm on m.id = sm.menu order by m.id";
	 	
	 	$menuQuery = "select name from menu";
	 	
        $submenu_rs = $this->executeQuery($submenuQuery);
		$menu_rs = $this->executeQuery($menuQuery);	 

		// push result set to array
		$rsArray["SUBMENU"] = $submenu_rs;
		$rsArray["MENU"] = $menu_rs;
		
		return $rsArray;		
	 }

      /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentDate();
		
		$addQuery = "insert into submenu (name, pagename, description, menu, category, createddate, updateddate, isdefault) values ".
						"(:name, :pagename, :description, :menu, :category, :createddate, :updateddate, :isdefault)";
		
		try
		{		
			$stmt = $this->_conn->prepare($addQuery);
			$stmt->bindValue(':name', $_formValues['name']);
			$stmt->bindValue(':pagename', $_formValues['pagename']);
			$stmt->bindValue(':description', $_formValues['description']);
			$stmt->bindValue(':menu', $_formValues['menu']);
			$stmt->bindValue(':category', $_formValues['category']);
			$stmt->bindValue(':createddate', $createdDate);
			$stmt->bindValue(':updateddate', $createdDate);
			$stmt->bindValue(':isdefault', 'no');
		
			$result = $stmt->execute();
		}
		catch(PDOException $Exception)
		{
			return $Exception->getCode();
			throw new DatabaseException($Exception->getMessage() , $Exception->getCode());
		}				
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		
		$updatedDate = CommonUtil::getCurrentDate();
		
		$updateQuery = "update submenu set name=:name, pagename=:pagename, description=:description, menu=:menu, ".
		               "category=:category, updateddate=:updateddate ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':pagename', $_formValues['pagename']);
		$stmt->bindValue(':description', $_formValues['description']);		
		$stmt->bindValue(':menu', $_formValues['menu']);
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':updateddate', $updatedDate);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	 
	
 }