<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Credential
 *
 */ 
 class CredentialDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'credential';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for CredentialDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select c.id, c.name, c.createddate, c.username, c.password, cc.name as cname, ".
							  "c.url, c.notes from Credential c, CCategory cc ".
	      		              " where c.category = cc.id and c.user = ".$this->_userid." order by c.createddate desc",
		);
		
		return $queriesArray;
	}
	
	/**
	 * Values required to display in drop down list
	 * for credential category will be 
	 * retrieved and stored in array
	 *
	 * returns result of credential category
	 */
	public function getDropDownValues()
	{
		$ccategoryDAO = new CategoryDAO('ccategory');
		
		// get info from ccategory
		$ccategory_rs = $ccategoryDAO->getOrderByName();
		
		return $ccategory_rs;
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into credential (id, name, createddate, username, password, user, category, url, notes) values ".
						"(:id, :name, :createddate, :username, :password, :user, :category, :url, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', $_formValues['password']);
		$stmt->bindValue(':user', $_formValues['userid']);				
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		
		$dueDate = CommonUtil::convertToMySQLDateFormat($_formValues['duedate']);
		
		$updateQuery = "update credential set name=:name, username=:username, password=:password, category=:category, url=:url, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':username', $_formValues['username']);
		$stmt->bindValue(':password', $_formValues['password']);		
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
	{
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['createddate'] == '' and $_formValues['name'] == '' and $_formValues['category'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['createddate'] != '')
			{
				$createdDate = CommonUtil::convertToSQLiteDateFormat($_formValues['createddate']);
			}
			
			if ($_formValues['name'] != '')
			{
				$name = strtolower($_formValues['name']);
			}			
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			
			if ($_formValues['createddate'] != '')
			{
				// only if createddate is selected
				if ($_formValues['name'] == '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (c.createddate between '". $createdDate . "' and '" . $createdDate . "') ";
				}
				
				// both createddate & name is selected
				if ($_formValues['name'] != '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (c.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
					               "and lower(c.name) like '%". $name ."%'";
				}				

				// createddate and category is selected
				if ($_formValues['name'] == '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (c.createddate  between '". $createdDate . "' and '" . $createdDate . "') ".
					               "and c.category in (".$categoryIDs.")";
				}	

				// createddate, name and category is selected
				if ($_formValues['name'] != '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (c.createddate between '". $createdDate . "' and '" . $createdDate . "') ".
					               "and lower(c.name) like '%". $name ."%' ".
					               "and c.category in (".$categoryIDs.")";
				}				
			}
			elseif ($_formValues['category'] != '' and $_formValues['name'] == '')
			{
				$searchQuery = "and c.category in (".$categoryIDs.")";
			}
			elseif ($_formValues['name'] != '' and $_formValues['createddate'] == '' and $_formValues['category'] == '')
			{
				$searchQuery = "and lower(c.name) like '%". $name ."%'";
			}
		}

		return 	$searchQuery;
		
	}

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($searchStr)
	{
		$searchQuery = "select c.id, c.name, c.createddate, c.username, c.password, cc.name as cname, ".
				 "c.url, c.notes from Credential c, CCategory cc ".
	      		 " where c.category = cc.id ".$searchStr." and c.user = ". $this->_userid .
				 " order by c.createddate desc";
				 
		//echo "Search Query -> ".$searchQuery."<br>";	
				 
		$result = $this->executeQuery($searchQuery);
		
		return $result;
	}
	

 }