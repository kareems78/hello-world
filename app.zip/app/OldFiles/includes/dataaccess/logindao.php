<?php

include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

 /**
 *	Data Access for Login
 *
 */
 class LoginDAO extends BaseDAO
 {
 
  	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'user';
	
	/**
	 * Contructor for LoginDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, null);
	}


     /**
      * @param $_formValues
      * @return mixed|null
      */
     public function validateUser($_formValues)
	{
		$username = $_formValues['username'];
		$password = $_formValues['pwd'];
		
		$query = "SELECT * FROM USER WHERE USERNAME='".$username."' and PASSWORD='".md5($password)."'";
		//echo "$query -- > ".$query."<br/>";
		$result = $this->executeQuery($query);	
			
		$rowsReturned = sizeof($result);	
		
		//echo "rowsReturned : " . sizeof($result);

		if ($rowsReturned == 1)
		{
		
			$row = $result[0];
			
			$userId = $row['id'];
			
			$userDetailsQuery = "SELECT * FROM  USERDETAILS WHERE USERID=?";
			
			$userdetails_rs = $this->executeQueryWithOneParam($userDetailsQuery, $userId);
			
			$userRoleQuery = "SELECT * FROM USER2ROLE WHERE USERID=?";
			
			$userrole_rs = $this->executeQueryWithOneParam($userRoleQuery, $userId);
			
			//return $userdetails_rs;
			
			$userDetailsRow = get_object_vars($userdetails_rs[0]);
			$userRoleRow = get_object_vars($userrole_rs[0]);
			
			// push result set to array
			$rsArray["user_details"] = $userDetailsRow;
			$rsArray["user_role"] = $userRoleRow;
			
			return $rsArray;				
			
		}

		return null;
	}
 }