<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Diet Plans
 *
 */ 
 class DPlanDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'dtasks';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for DPlanDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select d.id, d.day, d.breakfast, d.lunch, ".
							  "d.snacks, d.dinner, d.workouts from dplan d ".
	      		              " where d.user = ". $this->_userid . 
	      		              " order by d.id",
		);
		
		return $queriesArray;
	}

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	 {
		$createdDate = CommonUtil::getCurrentDate();
		
		$id = $this->generateID();		
		
		$addQuery = "insert into dplan (id, day, breakfast, lunch, snacks, dinner, workouts, user) values ".
						"(:id, :day, :breakfast, :lunch, :snacks, :dinner, :workouts, :user)";
	
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':day', 'Set Day');
		$stmt->bindValue(':breakfast', '');
		$stmt->bindValue(':lunch', '');
		$stmt->bindValue(':snacks', '');
		$stmt->bindValue(':dinner', '');
		$stmt->bindValue(':workouts', '');
		$stmt->bindValue(':user', $_formValues['userid']);		
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		$objectIds = $_formValues['objectIds'];
		echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update dplan set day=:day, breakfast=:breakfast, ".
						   "lunch=:lunch, snacks=:snacks, dinner=:dinner, workouts=:workouts ".
						   "where id=:id";
		
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':day', $_formValues['day'][$row]);
			$stmt->bindValue(':breakfast', $_formValues['breakfast'][$row]);
			$stmt->bindValue(':lunch', $_formValues['lunch'][$row]);
			$stmt->bindValue(':snacks', $_formValues['snacks'][$row]);
			$stmt->bindValue(':dinner', $_formValues['dinner'][$row]);
			$stmt->bindValue(':workouts', $_formValues['workouts'][$row]);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;		
	}
	
 }