<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Online Orders
 *
 */ 
 class OnlineOrdersDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'onlineorders';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for CreditPaymentDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from onlineorders where user = " . $this->_userid . " order by id desc",
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for credential category will be
      * retrieved and stored in array
      *
      * @return list
      *
      */
     public function getDropDownValues()
	{
		$creditCardDAO = new CategoryDAO('creditcard');
		
		// get info from ccategory
		$cc_rs = $creditCardDAO->getOrderByName();
		
		return $cc_rs;
	}


     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$orderDate = CommonUtil::convertToMySQLDateFormat($_formValues['orderdate']);
		
		$id = $this->generateID();
		
		echo "id : ".$id;		
		
		$addQuery = "insert into onlineorders (id, orderno, ordername, orderdate, user, orderamount, notes) ".
		            "values (:id, :orderno, :ordername, :orderdate, :user, :orderamount, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':orderno', $_formValues['orderno']);	
		$stmt->bindValue(':ordername', $_formValues['ordername']);		
		$stmt->bindValue(':orderdate', $orderDate);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':orderamount', $_formValues['orderamount']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      * @throws DatabaseException
      *
      */
     public function update($_formValues)
	{
		$orderDate = CommonUtil::convertToMySQLDateFormat($_formValues['orderdate']);
		
		$updateQuery = "update onlineorders set orderno=:orderno, ordername=:ordername, ".
		               "orderdate=:orderdate, orderamount=:orderamount, notes=:notes where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':orderno', $_formValues['orderno']);	
		$stmt->bindValue(':ordername', $_formValues['ordername']);		
		$stmt->bindValue(':orderdate', $orderDate);
		$stmt->bindValue(':orderamount', $_formValues['orderamount']);
		$stmt->bindValue(':notes', $_formValues['notes']);		
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	

 }
