<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
 /**
  *	Data Access for Priority
  *
  */
 class CategoryDAO extends BaseDAO
 {
 
 
  	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = null;
	
	/**
	 * Contructor for CategoryDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($tableName)
	{
		$this->tableName = $tableName;
		parent::__construct($tableName, 0);
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		$addQuery = "insert into ".$this->tableName." (name, description) values (:name, :description)";		
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':description', $_formValues['desc']);
		
		$result = $stmt->execute();	
		
		return $result;
	}

     /**
      * Delete categories
      *
      * @param $_formValues
      */
     public function deleteCategories($_formValues)
	{
		$this->setFormInputs($_formValues);
		return $this->delete();
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		$updateQuery = "update ".$this->tableName." set name=:name, description=:description where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':description', $_formValues['desc']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();	
		
		return $result;		
	}

 }