<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Url Store
 *
 */ 
 class UrlStoreDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'urlstore';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for UrlStoreDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select us.id, us.name, ut.name as utname, ".
							  "us.url, us.createddate, us.updateddate, us.notes from urlstore us, urltype ut ".
	      		              " where us.urltype = ut.id and us.user = ".$this->_userid." order by us.createddate desc",
		);
		
		return $queriesArray;
	}
	
	/**
	 * Values required to display in drop down list
	 * for credential category will be 
	 * retrieved and stored in array
	 *
	 * returns result of credential category
	 */
	public function getDropDownValues()
	{
		$urltypeDAO = new CategoryDAO('urltype');
		
		// get info from ccategory
		$urltype_rs = $urltypeDAO->getOrderByName();
		
		return $urltype_rs;
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$createdDate = CommonUtil::getCurrentDate();
		
		$id = $this->generateID();
		
		//echo "id : ".$id;		
		
		$addQuery = "insert into urlstore (id, name, urltype, url, user, createddate, updateddate, notes) values ".
						"(:id, :name, :urltype, :url, :user, :createddate, :updateddate, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':urltype', $_formValues['urltype']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		
		$updatedDate = CommonUtil::getCurrentDate();
		
		$updateQuery = "update urlstore set name=:name, urltype=:urltype, url=:url, updateddate=:updateddate, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':name', $_formValues['name']);
		$stmt->bindValue(':urltype', $_formValues['urltype']);
		$stmt->bindValue(':url', $_formValues['url']);
		$stmt->bindValue(':updateddate', $updatedDate);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
	{
		if (!array_key_exists('urltype' , $_formValues))
		{
			//echo "urltype does not exist<br>";
			$_formValues['urltype'] = "";
		}

		if ($_formValues['name'] == '' and $_formValues['urltype'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			
			if ($_formValues['urltype'] != '')
			{			
				$urlTypeIDs = CommonUtil::generateStringWithCommas($_formValues['urltype']);
			}	
			
		    if ($_formValues['name'] != '')
            {
                $name = strtolower($_formValues['name']);
            }			
			
			
			if ($_formValues['name'] != '')
			{
				// only if name is selected
				if ($_formValues['urltype'] == '')
				{
					$searchQuery = "and lower(us.name) like '%". $name ."%'";
				}
				
				// if both name and urltype is selected
				if ($_formValues['urltype'] != '')
				{
					$searchQuery =  "and lower(us.name) like '%". $name ."%' ".
                         			"and us.urltype in (".$urlTypeIDs.")";
				}
				
			}
			else 
			{
				$searchQuery =  "and us.urltype in (".$urlTypeIDs.")";				
			}

		}

		return 	$searchQuery;
		
	}

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($searchStr)
	{
		$searchQuery = "select us.id, us.name, ut.name as utname, ".
					   "us.url, us.createddate, us.updateddate, us.notes from urlstore us, urltype ut ".
	      		       " where us.urltype = ut.id ".$searchStr."and us.user = ". $this->_userid .
				 	   " order by us.createddate desc";
				 
		//echo "Search Query -> ".$searchQuery."<br>";	
				 
		$result = $this->executeQuery($searchQuery);
		
		return $result;
	}
	

 }