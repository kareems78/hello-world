<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Funds Transfer
 *
 */ 
 class FundsTransferDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'fundstransfer';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for FundsTransferDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select ft.id, ft.referenceno, ft.datesent, act.name as aname, ". 
		                        "ft.amount, ft.destamount, ft.notes from fundstransfer ft, ".
		                        "account act where ft.transferredto=act.id and ft.user = ". $this->_userid ." order by ft.datesent desc",
		);
		
		return $queriesArray;
	}
	
	/**
	 * Values required to display in drop down list
	 * for account will be 
	 * retrieved and stored in array
	 *
	 * returns result of credential category
	 */
	public function getDropDownValues()
	{
		$accountDAO = new CategoryDAO('account');
		
		// get info from ccategory
		$account_rs = $accountDAO->getOrderByName();
		
		return $account_rs;
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		
		$dateSent = CommonUtil::convertToMySQLDateFormat($_formValues['datesent']);
		
		$id = $this->generateID();
		
		$addQuery = "insert into fundstransfer (id, referenceno, datesent, transferredto, user, amount, destamount, notes) values ".
						"(:id, :referenceno, :datesent, :transferredto, :user, :amount, :destamount, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);		
		$stmt->bindValue(':referenceno', $_formValues['referenceno']);
		$stmt->bindValue(':datesent', $dateSent);
		$stmt->bindValue(':transferredto', $_formValues['transferredto']);
		$stmt->bindValue(':user', $_formValues['userid']);				
		$stmt->bindValue(':amount', $_formValues['amount']);
		$stmt->bindValue(':destamount', $_formValues['destamount']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
	public function update($_formValues)
	{
		
		$dateSent = CommonUtil::convertToMySQLDateFormat($_formValues['datesent']);
		
		$updateQuery = "update fundstransfer set referenceno=:referenceno, datesent=:datesent, transferredto=:transferredto, ". 
		               "amount=:amount, destamount=:destamount, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':referenceno', $_formValues['referenceno']);
		$stmt->bindValue(':datesent', $dateSent);
		$stmt->bindValue(':transferredto', $_formValues['transferredto']);
		$stmt->bindValue(':amount', $_formValues['amount']);
		$stmt->bindValue(':destamount', $_formValues['destamount']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}
	
      /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     public function search($searchStr)
     {
         if ($searchStr != '')
         {
             $getSTQuery = "select ft.id, ft.referenceno, ft.datesent, act.name as aname, ". 
		                        "ft.amount, ft.destamount, ft.notes from fundstransfer ft, ".
		                        "account act where ft.transferredto=act.id and ". $searchStr . 
		                        " and ft.user = " . $this->_userid . " order by ft.datesent";
         }
         else
         {
             $getSTQuery = "select ft.id, ft.referenceno, ft.datesent, act.name as aname, ". 
		                        "ft.amount, ft.destamount, ft.notes from fundstransfer ft, ".
		                        "account act where ft.transferredto=act.id and ".
                                "ft.user = " . $this->_userid . " order by ft.datesent";
         }

         //echo "search query -> ".$getSTQuery."<br>";

         $result = $this->executeQuery($getSTQuery);

         return $result;
     }

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
     {

         if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '')
         {
             echo "no value is sent<br>";
             $searchQuery = "";
         }
         else
         {
             if ($_formValues['fromdate'] != '')
             {
                 $fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
             }

             if ($_formValues['todate'] != '')
             {
                 $toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
             }

             if ($_formValues['fromdate'] != '')
             {
                 // only if fromdate is selected
                 if ($_formValues['todate'] == '')
                 {
                     $searchQuery = "(ft.datesent between '". $fromDate . "' and '" . $fromDate . "') ";
                 }

                 // both fromdate & todate is selected
                 if ($_formValues['todate'] != '')
                 {
                     $searchQuery = "(ft.datesent between '". $fromDate . "' and '" . $toDate . "') ";
                 }
             }
         }

         return 	$searchQuery;

     }	

 }