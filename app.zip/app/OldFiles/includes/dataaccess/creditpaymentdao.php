<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Credit Payment
 *
 */ 
 class CreditPaymentDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'creditpayment';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for CreditPaymentDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select cp.id, cp.referenceno, cc.name as cname, cp.datepaid, cp.datededucted, cp.amount, cp.notes ".
								"from creditpayment cp, creditcard cc ".
								"where cp.creditcard=cc.id and cp.user = " . $this->_userid . " order by cp.id desc",
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for credential category will be
      * retrieved and stored in array
      *
      * @return list
      *
      */
     public function getDropDownValues()
	{
		$creditCardDAO = new CategoryDAO('creditcard');
		
		// get info from ccategory
		$cc_rs = $creditCardDAO->getOrderByName();
		
		return $cc_rs;
	}


     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		if ($_formValues['datepaid'] != '')
		{
			$datePaid = CommonUtil::convertToMySQLDateFormat($_formValues['datepaid']);
		}

		if ($_formValues['datededucted'] != '')
		{
			$dateDeducted = CommonUtil::convertToMySQLDateFormat($_formValues['datededucted']);
		}	
		else
		{
			$dateDeducted = $datePaid;
		}
		
		$id = $this->generateID();
		
		$addQuery = "insert into creditpayment (id, referenceno, creditcard, datepaid, datededucted, user, amount, notes) ".
		            "values (:id, :referenceno, :creditcard, :datepaid, :datededucted, :user, :amount, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':referenceno', $_formValues['referenceno']);		
		$stmt->bindValue(':creditcard', $_formValues['creditcard']);
		$stmt->bindValue(':datepaid', $datePaid);
		$stmt->bindValue(':datededucted', $dateDeducted);
		$stmt->bindValue(':user', $_formValues['userid']);				
		$stmt->bindValue(':amount', $_formValues['amount']);
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}

     /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      * @throws DatabaseException
      *
      */
     public function update($_formValues)
	{
		$datePaid = CommonUtil::convertToMySQLDateFormat($_formValues['datepaid']);
		
		if ($_formValues['datededucted'] != '')
		{
			$dateDeducted = CommonUtil::convertToMySQLDateFormat($_formValues['datededucted']);
		}	
		else
		{
			$dateDeducted = $datePaid;
		}		
		
		$updateQuery = "update creditpayment set referenceno=:referenceno, creditcard=:creditcard, ".
		               "datepaid=:datepaid, datededucted=:datededucted, amount=:amount, notes=:notes where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':referenceno', $_formValues['referenceno']);		
		$stmt->bindValue(':creditcard', $_formValues['creditcard']);
		$stmt->bindValue(':datepaid', $datePaid);
		$stmt->bindValue(':datededucted', $dateDeducted);		
		$stmt->bindValue(':amount', $_formValues['amount']);
		$stmt->bindValue(':notes', $_formValues['notes']);			
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();

		//echo "result : ".$result."<br>";
		
		return $result;	
	}	
	
      /**
      * Generates search string based on input values provided
      *
      * @param $_formValues
      * @return string
      */
     public function generateSearchQuery($_formValues)
	{
		if(!array_key_exists('creditcard' , $_formValues))
		{
			//echo "creditcard does not exist<br>";
			$_formValues['creditcard'] = "";
		}

		if ($_formValues['creditcard'] == '' and $_formValues['datepaid'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['datepaid'] != '')
			{
				$datePaid = CommonUtil::convertToSQLiteDateFormat($_formValues['datepaid']);
			}
			
			if ($_formValues['creditcard'] != '')
			{			
				$creditCardIDs = CommonUtil::generateStringWithCommas($_formValues['creditcard']);
			}	
			
			
			if ($_formValues['creditcard'] != '')
			{
				// only if creditcard is selected
				if ($_formValues['datepaid'] == '')
				{
					$searchQuery = "and cp.creditcard in (".$creditCardIDs.")";
				}
				
				// if both creditcard and datepaid is selected
				if ($_formValues['datepaid'] != '')
				{
					$searchQuery =  "and (cp.datepaid between '". $datePaid . "' and '" . $datePaid . "') ".
									"and cp.creditcard in (".$creditCardIDs.")";
				}
				
			}

		}

		return 	$searchQuery;
		
	}

     /**
      * Searches credentials as per search string
      *
      * @param $searchStr
      * @return list
      */
     public function search($searchStr)
	{
		$searchQuery = "select cp.id, cp.referenceno, cc.name as cname, cp.datepaid, cp.datededucted, cp.amount, cp.notes ".
					   "from creditpayment cp, creditcard cc ".
					   "where cp.creditcard=cc.id ".$searchStr." and cp.user = " . $this->_userid . " order by cp.id desc";
				 
		//echo "Search Query -> ".$searchQuery."<br>";	
				 
		$result = $this->executeQuery($searchQuery);
		
		return $result;
	}	

 }
