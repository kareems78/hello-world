<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Papps Misc
 *
 */ 
 class PMiscDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'cleaning';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for PMiscDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select c.id, c.headline, c.text from Cleaning c order by c.id",
		);
		
		return $queriesArray;
	}

     /**
      * Updates a row in the database
      *
      * @param $content
      * @return bool
      *
      */
     public function update($content)
	{
		$updateQuery = "update content set text=:content where element_id='1'";
		
		$updateStmt = $this->_conn->prepare($updateQuery);
		$updateStmt->bindValue(':content', $content);
		
		$update_rs = $updateStmt->execute();

		return $update_rs;	
	}

 }
