<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for DBOperations
 *
 */ 
 class DBOperationsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'submenu';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for STimingsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select m.name as menu, sm.id, sm.name as submenu, sm.pagename, sm.category ". 
	 	                        "from menu m left join submenu sm on m.id = sm.menu order by m.id",
		);
		
		return $queriesArray;
	}
	
      /**
      * Values required to display in drop down list
      * for priority, task type & status will be
      * retrieved and stored in array
      *
      * @return mixed - returns array of key value pairs
      *
      */
     public function getUpdateIdDropDownValues()
	 {
		$user = new CategoryDAO('user');
		$datatables = new CategoryDAO('datatables');
		
		// user info
		$user_rs = $user->getAll();
		
		// datatables list
		$datatables_rs = $datatables->getOrderByName();
		
		// push result set to array
		$dropDownArray["USERS"] = $user_rs;
		$dropDownArray["DATATABLES"] = $datatables_rs;
		
		return $dropDownArray;
	 }
	 
	 /**
	  * 
	  * Update IDs for a given table
	  * 
	  * @param $_formValues
	  */
	 public function updateIDs($_formValues)
	 {
	 	$user = $_formValues['user'];
	 	$table = $_formValues['datatable'];
	 	
	 	$tableID = $this->getTableIDForUser($user);
	 	
	 	$this->updateWithTempIDsIfIDExists($tableID, $table, $user);
	 	
	 	$query = "select * from ".$table." where user = ".$user;
	 	$result = $this->executeQuery($query);
	 	
	 	if (CommonUtil::validateResultSet($result))
		{	 	
	 		while ($row = $result[0])
	 		{
	 			//echo "<br>row[id] : ".$row['id']." tableID : ".$tableID;
	 			
	 			$updateTableQuery = "update ".$table." set id = ".$tableID." where id = ".$row['id'].
	 			                    " and user = ".$user;
	 			
	 			//echo "<br>Update Query -> ".$updateTableQuery;
	 			
	 			$updateRs = $this->executeQuery($updateTableQuery);
	 			
	 			$tableID = $tableID + 1;
	 		}
		}
		
		if ($updateRs != 1)
		{
			return -1;
		}
		else 
		{
			return 1;
		}
	 	
	 }
	 
	 /**
	  * 
	  * Retrieves tableid set for a particular user
	  * 
	  * @param $userid
	  * @return table id for user
	  */
	 private function getTableIDForUser($userid)
	 {
	 	$query = "select tableid from user where id =".$userid;
	 	$result = $this->executeQuery($query);
	 	
	 	$row = $result[0];
	 	
	 	return $row['tableid'];
	 }

	 /**
	  * 
	  * Enter description here ...
	  */
	 public function getCSVTableDropDownValues()
	 {
		$csvtables = new CategoryDAO('csvtables');
		
		// get info from ccategory
		$csvtables_rs = $csvtables->getOrderByName();
		
		return $csvtables_rs;	 	
	 }
	 
	 /**
	  * 
	  * Generates CSV file from table records
	  * @param $_formValues
	  */
	 public function generateCSVFile($_formValues)
	 {
	 	$table = $_formValues['csvtable'];
	 	
	 	//printf("\n Table : %s",$table);
	 	
	 	$output = "";
	 	
	 	$query = "select * from ".$table;

	 	$fieldCount = $this->getFieldCount($query);
	 	
	 	$query = "select * from ".$table;
	 	$result = $this->executeQuery($query);
	 	
		while ($fieldinfo=mysqli_fetch_field($result))
	    {
			$heading	=	$fieldinfo->name;
			$output		.= '"'.$heading.'",';
	    }
	    
	    $output .="\n";
	    
	 	$query = "select * from ".$table;
	 	$result = $this->executeQuery($query);	    
	    
		while ($row = $result[0]) 
		{
			for ($i = 0; $i < $fieldCount; $i++) 
			{
				$output .='"'.$row["$i"].'",';
			}
			$output .="\n";
		}
		
		// Download the file
		$filename = $table."_".date("d-m-Y_H-i",time()).".csv";
		header('Content-type: application/csv');
		header('Content-Disposition: attachment; filename='.$filename);
		
		echo $output;
	 	
	 }
	
	 /**
	  * 
	  * Finds the no of columns in a table
	  * @param $query
	  * @return column count
	  */
	 public function getFieldCount($query)
	 {
	 	$result = $this->executeQuery($query);
	 	
	 	$fieldCount = 0;
	 	
	 	while ($fieldinfo=$result[0])
	    {	 	
	    	$fieldCount++;
	    }
	 	
	 	//echo "field count : ".$fieldCount;	 

	 	return $fieldCount;
	 }

 }