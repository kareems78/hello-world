<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Menu
 *
 */ 
 class MenuDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'menu';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for MenuDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from menu order by id",
		);
		
		return $queriesArray;
	}
	
	/**
	 * Retrieves all menu and submenu info from database
	 * 
	 */
	public function getAllMenus()
	{
		
	}
	
      /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert()
	 {
		$createdDate = CommonUtil::getCurrentDate();
		
		$addQuery = "insert into menu (name, description, createddate, updateddate) values ".
						"(:name, :description, :createddate, :updateddate)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':name', 'Set Menu Name');
		$stmt->bindValue(':description', '');
		$stmt->bindValue(':createddate', $createdDate);
		$stmt->bindValue(':updateddate', $createdDate);
		
		$result = $stmt->execute();
		
		//echo "result : ".$result."<br>";
		
		return $result;	
	}	
	
      /**
      * Updates a row into the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	 {
	 	$updatedDate = CommonUtil::getCurrentDate();
	 	
		$objectIds = $_formValues['objectIds'];
		echo "in dao : count : ".count($objectIds)."<br>";
		
		$row = 0;
		
		foreach ($objectIds as &$id) {
			
			echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$updateQuery = "update menu set name=:name, description=:description, ".
						   "updateddate=:updateddate ".
						   "where id=:id";
			
			$stmt = $this->_conn->prepare($updateQuery);
			$stmt->bindValue(':name', $_formValues['menuname'][$row]);
			$stmt->bindValue(':description', $_formValues['description'][$row]);
		    $stmt->bindValue(':updateddate', $updatedDate);
			$stmt->bindValue(':id', $id);
			
			$result = $stmt->execute();
			
			$row = $row + 1;
		}		
		
		return $result;	
	}	
	
 }