<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for All Categories
 *
 */ 
 class AllCatDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'submenu';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllModCategories = null;
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllModWithCategoryExists = null;	
	
	/**
     *
     */	 
	public static $_formValues = null;
	
	/**
	 * Contructor for AllCatDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all tasks
		$this->_getAllModCategories = $queries['getAllModCategoriesQuery'];	
		
		$this->_getAllModWithCategoryExists = $queries['getAllModWithCategoryExistsQuery'];
	
	}

	/**
	 * All the queries required for task operations
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllModCategoriesQuery" => "select id, name, category ".
	      		              "from submenu where isdefault='yes'",
		"getAllModWithCategoryExistsQuery" => "select id, name, category from submenu where category != ''",
		);
		
		return $queriesArray;
	}

     /**
      * Retrieves module categories
      *
      * @return mixed
      *
      */
     public function getModCategories()
	{
		// get info from submenu to display in drop down
		$moddropdrownvalues_rs = $this->executeQuery($this->_getAllModWithCategoryExists);
		
		$tmp_rs = $this->executeQuery($this->_getAllModCategories);
		
		
		if ($tmp_rs != null)
		{
			$row = $tmp_rs[0];
		}	
		
		$modCategories = new CategoryDAO($row['category']);
		
		// get info for above category for which isdefault set as 'yes'
		$modCategories_rs = $modCategories->getOrderByName();
		
		// push result set to array
		$rsArray["MODULEDROPDOWNVALUES"] = $moddropdrownvalues_rs;
		$rsArray["MODCATEGORIES"] = $modCategories_rs;
		$rsArray["MODULE"] = $row['name'];	

		return $rsArray;		
		
	}

     /**
      * Insert is done after validating category
      *
      * @param $_formValues
      * @return int
      *
      */
     public function insertAfterValidation($_formValues)
	{
		$rowCount = $this->validateCategoryName($_formValues);
		
		if ($rowCount == 1)
		{
			// if row count is 1 that means 
			$this->updateDefaultValues($_formValues['categorytable']);
			return $rowCount;
		}
		else
		{
			$result = $this->insert($_formValues);
			return $result;
		}
	}

     /**
      * Validates category name
      *
      * @param $_formValues
      * @return int - count
      *
      */
     public function validateCategoryName($_formValues)
	{
		$categoryTable = $_formValues['categorytable'];
		$name = strtolower($_formValues['name']);
		
		$vCatNameQuery = "select * from  ".$categoryTable." where name=:name";
		
		//echo "vCatNameQuery : ".$vCatNameQuery;
		
		$stmt = $this->_conn->prepare($vCatNameQuery);
		$stmt->bindValue(':name', $name);
		
		$result = $stmt->execute();		
		
		//echo $stmt->rowCount();
		
		return $stmt->rowCount();
	}

     /**
      * Inserts a row into the database
      *
      * @param $_formValues
      * @return int
      *
      */
     public function insert($_formValues)
	{
		$returnOnSuccess = 1;
		$categoryTable = $_formValues['categorytable'];
		$desc = $_formValues['desc'];
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$add_rs = $categoryDAO->insert($_formValues);
		
		$this->updateDefaultValues($categoryTable);
		
		//echo "result : ".$result."<br>";
		
		if ($add_rs == 1)
		{
			$returnOnSuccess = 0;
		}
		
		return $returnOnSuccess;	
	}

     /**
      * Update default value to yes for a given
      * category name
      *
      * @param $categoryTable
      *
      */
     public function updateDefaultValues($categoryTable)
	{
		// set all cols to "NO"
		$updateDef2NoQuery = "update submenu set isdefault='no'";
		$updatedef_rs = $this->executeQuery($updateDef2NoQuery);
		
		//set "yes" for current category to view
		$updateQuery = "update submenu set isdefault='yes' where category=:category";
		
		$updateStmt = $this->_conn->prepare($updateQuery);
		$updateStmt->bindValue(':category', $categoryTable);
		
		$update_rs = $updateStmt->execute();		
	}

     /**
      * Deletes category linked to sub menu
      *
      * @param $_formValues
      *
      */
     public function delete($_formValues)
	{
		$categoryTable = $this->getCategoryTable($_formValues['smenu']);
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$result = $categoryDAO->deleteCategories($_formValues);		
		
	}
	
     /**
      * Finds category from sub menu table
      * for given input of sub menu
      *
      * @param $smenu
      * @return mixed
      *
      */
     private function getCategoryTable($smenu)
	{
		$query = "select category from submenu where name='".$smenu."'";
		
		$result = $this->executeQuery($query);
		
		$row = $result[0];
		
		return $row['category'];
		
	}

     /**
      * Retrieves category for given sub menu
      *
      * @param $id
      * @param $smenu
      * @return mixed
      *
      */
     public function getCategoryBySMenu($id, $smenu)
	{
		$categoryTable = $this->getCategoryTable($smenu);
		
		$categoryDAO = new CategoryDAO($categoryTable);
		$category_rs = $categoryDAO->getByID($id);
		
		$row = $category_rs[0];
		
		// push result set to array
		$rsArray["category"] = $row;
		$rsArray["smenu"] = $smenu;

		return $rsArray;		
	}

     /**
      * Update category in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function updateCategories($_formValues)
	{
		$categoryDAO = new CategoryDAO($_formValues['categorytable']);
		$result = $categoryDAO->update($_formValues);
		
		return $result;
	}

 }