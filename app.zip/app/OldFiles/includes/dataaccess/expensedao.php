<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 require_once DATAACCESS . 'categorydao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Expense
 *
 */ 
 class ExpenseDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'expense';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for ExpenseDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 */
 	public function __construct($userid)
	{
		parent::__construct($this->tableName, $userid);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
	
	}

     /**
      * All the required queries will be pushed into
      * array
      *
      * @return array of queries
      */
     protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              " where e.category = ec.id and e.user = ". $this->_userid . 
	      		              " order by e.expensedate asc",
		);
		
		return $queriesArray;
	}
	
     /**
      * Values required to display in drop down list
      * for expense category will be
      * retrieved and stored in array
      *
      * @return list - result of expense category
      *
      */
     public function getDropDownValues()
	{
		$ecategoryDAO = new CategoryDAO('ecategory');
		$monthDAO = new CategoryDAO('month');
		$yearDAO = new CategoryDAO('year');
		
		// get info from ecategory, month
		$ecategory_rs = $ecategoryDAO->getOrderByName();
		$month_rs = $monthDAO->getAll();
		$year_rs = $yearDAO->getOrderByNameDesc();
		
		// push result set to array
		$expenseDropDownArray["ecategory"] = $ecategory_rs;
		$expenseDropDownArray["month"] = $month_rs;
		$expenseDropDownArray["year"] = $year_rs;
		
		return $expenseDropDownArray;		
	}

     /**
      * Inserts a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function insert($_formValues)
	{
		$MonYYYY = CommonUtil::getMonthAndYYYY($_formValues['expensedate']);
		
		$currentMonth = $MonYYYY['Mon'];
		$currentYear = $MonYYYY['YYYY'];
		
		//echo "<br>curr mon ->".$currentMonth." curr year ".$currentYear;

        $this->populateTotalExpColIfNotExist($currentMonth, $currentYear);
		
		$expenseDate = CommonUtil::convertToSQLiteDateFormat($_formValues['expensedate']);
		
		//echo"<br>expense date after conversion: ".$expenseDate;
		
		$id = $this->generateIDWithTable("Expense");	

		if ($_formValues['taxpercent'] != 0)
		{
			$amt = $_formValues['amount'] + ($_formValues['amount'] * $_formValues['taxpercent'])/100;
		}
		else
		{
			$amt = $_formValues['amount'];
		}
		
		$addQuery = "insert into expense (id, expensedate, category, user, amount, notes) values ".
						"(:id, :expensedate, :category, :user, :amount, :notes)";
		
		$stmt = $this->_conn->prepare($addQuery);
		$stmt->bindValue(':id', $id);
		$stmt->bindValue(':expensedate', $expenseDate);
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':user', $_formValues['userid']);
		$stmt->bindValue(':amount', $amt);		
		$stmt->bindValue(':notes', $_formValues['notes']);
		
		$result = $stmt->execute();

		$this->populateAmtInTotExpenses($_formValues['expensedate']);
		
		//echo "result : ".$result."<br>";
		
		return $result;
		//return null;
	}

     /**
      * Updates a row in the database
      *
      * @param $_formValues
      * @return bool
      *
      */
     public function update($_formValues)
	{
		
		$expenseDate = CommonUtil::convertToSQLiteDateFormat($_formValues['expensedate']);
		
		if ($_formValues['taxpercent'] != 0)
		{
			$amt = $_formValues['amount'] + ($_formValues['amount'] * $_formValues['taxpercent'])/100;
		}
		else
		{
			$amt = $_formValues['amount'];
		}		
		
		$updateQuery = "update expense set expensedate=:expensedate, category=:category, amount=:amount, notes=:notes ".
					   "where id=:id";
		
		$stmt = $this->_conn->prepare($updateQuery);
		$stmt->bindValue(':expensedate', $expenseDate);		
		$stmt->bindValue(':category', $_formValues['category']);
		$stmt->bindValue(':amount', $amt);
		$stmt->bindValue(':notes', $_formValues['notes']);
		$stmt->bindValue(':id', $_formValues['id']);
		
		$result = $stmt->execute();
		
		$this->populateAmtInTotExpenses($_formValues['expensedate']);
		
		return $result;	
	}

     /**
      * Populates row into the table when there is no entry exists for current
      * month and year
      *
      * @param $month
      * @param $year
      *
      */
     public function populateTotalExpColIfNotExist($month, $year)
	{
		$countQuery = "select count(*) as count from TotalExpenses ".
		              "where month = '". $month . "' and year = '". $year . "' and user = ".$this->_userid;
		
		//echo "SQL -> ".$countQuery;

		$count_rs = $this->executeQuery($countQuery);

        $row = $count_rs[0];
        
        //echo "count : ".$row['count'];

		if ($row['count'] == 0)
		{
			$id = $this->generateIDWithTable("TotalExpenses");			
			
			$insetRowQuery = "insert into TotalExpenses (id, month, year, totalamount, user) values (:id, :month, :year, :totamt, :user)";

			$stmt = $this->_conn->prepare($insetRowQuery);
			$stmt->bindValue(':id', $id);
			$stmt->bindValue(':month', $month);
			$stmt->bindValue(':year', $year);
			$stmt->bindValue(':totamt', 0);
			$stmt->bindValue(':user', $this->_userid);
			
			$qResult = $stmt->execute();
			
		}
	}
	
     /**
      * To get all expenses for current month and year
      * as well as total amount from TotalExpenses
      *
      * @return mixed
      */
     public function getExpenses()
	{
		$dateRange = CommonUtil::dateRangeForCurrent();
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		$currentMonth = date('M');
		$currentYear = date('Y');		
		
		$getExpQuery = "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              "where e.category = ec.id ".
							  "and (e.expensedate between '" . $startDate . "' and '" . $endDate . "') ".
							  "and e.user = ". $this->_userid ." order by e.expensedate";
							  
		$getTotExpQuery = "select totalamount from TotalExpenses where ".
		              "month = '" . $currentMonth . "' and year = '" . $currentYear . "' ".
		              "and user = ".$this->_userid;
		
		//echo "sql tot exp -> ".$getExpQuery;

        /** @var $exp_rs TYPE_NAME */
        $exp_rs = $this->executeQuery($getExpQuery);
		$totexp_rs = $this->executeQuery($getTotExpQuery);
		
		$row = $totexp_rs[0];
		
		//echo "total amt -> " .$row['totalamount'];
		
		// push result set to array
		$rsArray["e"] = $exp_rs;
		$rsArray["totamt"] = $row['totalamount'];
		
		return $rsArray;			
		
	}
	
	/**
	 * Calculate sum of amounts for current month
	 * and year and populate total amount in 
	 * total expenses
	 * 
	 */
	private function populateAmtInTotExpenses($date)
	{
		$dateRange = CommonUtil::getStartAndEndDate($date);
		$startDate = $dateRange['start'];
		$endDate = $dateRange['end'];
		
		//echo "<br>date sent ->".$date;
		//echo "<br>start ->".$startDate." end date ".$endDate;
		
		$MonYYYY = CommonUtil::getMonthAndYYYY($date);
		
		$currentMonth = $MonYYYY['Mon'];
		$currentYear = $MonYYYY['YYYY'];

		$sumAmtQuery = "select sum(amount) as tamt from Expense where ".
		               "(expensedate between '" . $startDate . "' and '" . $endDate . "') and user = ".$this->_userid;
		
		//echo "<br>sql in populate total -> ".$sumAmtQuery;
		
		$sumAmtResult = $this->executeQuery($sumAmtQuery);
		$row = $sumAmtResult[0];
		
		$totalAmount = $row['tamt'];
		
		//echo "tot amt : ".$totalAmount;
		
		$updateTExpQuery = "update TotalExpenses set totalamount=:totamt where month=:month and year=:year and user=:user";
		$updStmt = $this->_conn->prepare($updateTExpQuery);
		$updStmt->bindValue(':totamt', $totalAmount);
		$updStmt->bindValue(':month', $currentMonth);
		$updStmt->bindValue(':year', $currentYear);
		$updStmt->bindValue(':user', $this->_userid);			
	
		$updateResult = $updStmt->execute();	
	}

	/**
	 * Delete selected expenses and 
	 * update total expenses
     *
	 */
	public function deleteExpenses()
	{
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		$expenseDateArray = $this->generateDateArrayFromIDs();
		
		foreach ($deleteIDs as &$id) {
			
			//echo "id : ".$id."<br>";
			//echo "query : ".$query;
			
			$query = "delete from ".$this->_tableName." where id=".$id;
			$result = $this->executeQuery($query);			

		}
		
	    for ($i = 0; $i <  count($expenseDateArray); $i++) {
    		$key=key($expenseDateArray);
    		$val=$expenseDateArray[$key];
    		
    		if ($val<> ' ') {
       			//echo $key ." = ".  $val ." <br> ";
       			$this->populateAmtInTotExpenses($val);
       		}
     		next($expenseDateArray);
    	}		
		
		return $result;
	}
	
	/**
	 * 
	 * Unique dates will be inserted into array
	 * as per given deletion ids, which is used 
	 * to calculate total amount at the end after 
	 * deleting records from expense table.
	 * 
	 * @return array of unique dates
	 */
	private function generateDateArrayFromIDs()
	{
		$deleteIDs = $this->_formInputs['deleteObject'];
		//echo "in delete base dao : count : ".count($deleteIDs)."<br>";
		
		$i = 1;
		
		foreach ($deleteIDs as &$id) {	

			$expDateQuery = "select expensedate from expense where id = ".$id;
			$expdate_rs = $this->executeQuery($expDateQuery);
			$row = $expdate_rs[0];
			
			//echo "<br>";
			//echo "<br>expensedate -> ".$row['expensedate'];
			
			$dateArray = explode("-", $row['expensedate']);
			$tmpDate = $dateArray['1']."/1/".$dateArray['0'];	

			$expenseDateArray[$i] = $tmpDate;
			
			$i++;
		}
		
		//echo "<br> size before -> ".sizeof($expenseDateArray);
		
		// Removing duplicate values set above
		$expenseDateArray = array_unique($expenseDateArray);
		
		//print_r($expenseDateArray);
		
		//echo "<br> size after -> ".sizeof($expenseDateArray);
		
		return $expenseDateArray;

	}

     /**
      * searches as per search str supplied
      *
      * @param $searchStr
      * @return mixed
      *
      */
     public function search($searchStr)
	{
		//$searchQ = $this->generateSearchQuery($_formValues);
		
		//echo "search query in main -> ".$searchQ."<br>";
		
		$getEQuery = "select e.id, e.expensedate, ec.name as cname, ".
							  "e.amount, e.notes from Expense e, ECategory ec ".
	      		              "where e.category = ec.id ". $searchStr . "and e.user = ". $this->_userid .
							  " order by e.expensedate";
							  
		//echo "whole query in main -> ".$getEQuery."<br>";	
		
		if ($searchStr == '')	
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e";
		}	
		else
		{
			$getTEQuery = "select sum(e.amount) as totalamount from Expense e where ".substr($searchStr, 3);
		}
		
		//echo "amount query in main -> ".$getTEQuery."<br>";	
		
		$exp_rs = $this->executeQuery($getEQuery);
		$totexp_rs = $this->executeQuery($getTEQuery);
		
		$row = $totexp_rs[0];
		
		// push result set to array
		$rsArray["e"] = $exp_rs;
		$rsArray["totamt"] = $row['totalamount'];
		
		return $rsArray;		
	}

     /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQuery($_formValues)
	{
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['fromdate'] == '' and $_formValues['todate'] == '' and $_formValues['category'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['fromdate'] != '')
			{
				$fromDate = CommonUtil::convertToSQLiteDateFormat($_formValues['fromdate']);
			}
			
			if ($_formValues['todate'] != '')
			{
				$toDate = CommonUtil::convertToSQLiteDateFormat($_formValues['todate']);
			}
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			
			if ($_formValues['fromdate'] != '')
			{
				// only if fromdate is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ";
				}
				
				// both fromdate & todate is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ";
				}				
				
				// fromdate and category is selected
				if ($_formValues['todate'] == '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $fromDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}	

				// fromdate, todate and category is selected
				if ($_formValues['todate'] != '' and $_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $fromDate . "' and '" . $toDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}					
				
				
			}
			elseif ($_formValues['category'] != '' and $_formValues['todate'] == '')
			{
				$searchQuery = "and e.category in (".$categoryIDs.")";
			}
		}

		return 	$searchQuery;
		
	}
	
      /**
      * Generates a search query based on inputs
      *
      * @param $_formValues
      * @return string - search query str
      *
      */
     public function generateSearchQueryByMonth($_formValues)
	{
		// if category is not selected setting it to default
		if(array_key_exists('category' , $_formValues))
		{
			//echo "category exists<br>";
		}
		else
		{
			//echo "category does not exist<br>";
			$_formValues['category'] = "";
		}

		if ($_formValues['month'] == '' and $_formValues['year'] == '' and $_formValues['category'] == '')
		{
			//echo "no value is sent<br>";
			$searchQuery = "";
		}
		else
		{
			if ($_formValues['month'] != '')
			{
				$mon = $_formValues['month'];
			}
			
			if ($_formValues['year'] != '')
			{
				$year = $_formValues['year'];
			}			
			
			if ($_formValues['category'] != '')
			{			
				$categoryIDs = CommonUtil::generateStringWithCommas($_formValues['category']);
			}	
			
			$dateRange = CommonUtil::dateRangeFromMonthAndYear($mon, $year);
			$startDate = $dateRange['start'];
			$endDate = $dateRange['end'];			
			
			
			if ($_formValues['month'] != '' and $_formValues['year'] != '')
			{
				// only if month is selected
				if ($_formValues['category'] == '')
				{
					$searchQuery = "and (e.expensedate between '". $startDate . "' and '" . $endDate . "') ";
				}
				
				// month and category is selected
				if ($_formValues['category'] != '')
				{
					$searchQuery = "and (e.expensedate between '". $startDate . "' and '" . $endDate . "') ".
					               "and e.category in (".$categoryIDs.")";
				}	
				
				
			}
			elseif ($_formValues['category'] != '')
			{
				$searchQuery = "and e.category in (".$categoryIDs.")";
			}
		}

		return 	$searchQuery;
		
	}	
	
 }