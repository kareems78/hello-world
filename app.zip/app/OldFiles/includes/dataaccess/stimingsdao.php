<?php
 include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';
 
 require_once DATAACCESS . 'basedao.php';
 
 require_once COMMON . 'util.php';
 
/**
 * Data Access for Salah Timings
 *
 */ 
 class STimingsDAO extends BaseDAO
 {
 	/**
	 * Object to hold table associated with 
	 * this DAO
	 *
	 */
	protected $tableName = 'salahtimings';
	
	/**
	 * Object to hold get all records query
	 *
	 */
	public $_getAllRecords = null;
	
	/**
	 * Object to hold get all Magrib Salah records query
	 *
	 */
	public $_getAllMSTRecords = null;	
	
	/**
	 *
	 */
	public static $_formValues = null;
	
	/**
	 * Contructor for STimingsDAO
	 * Calls BaseDAO construction and sets the table name.
	 * 
	 * 
	 */
 	public function __construct()
	{
		parent::__construct($this->tableName, 0);
		
		$queries = $this->getQueries();
		
		// sets the query to get all records
		$this->_getAllRecords = $queries['getAllRecordsQuery'];	
		
		$this->_getAllMSTRecords = $queries['getAllMSTRecordsQuery'];	
	
	}

	/**
	 * All the queries required
	 *
	 * return of array of all queries
	 */
	protected function getQueries()
	{
		$queriesArray = array(
		"getAllRecordsQuery" => "select * from salahtimings order by id asc",
		"getAllMSTRecordsQuery" => "select * from maghribsalahtimings order by id asc",
		);
		
		return $queriesArray;
	}
	
 }