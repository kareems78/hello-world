<?php

class CommonUtil
{
	
    /**
     * Converts date to MySQL format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function convertToMySQLDateFormat($date)
	{
		$formattedMySQLDate = date("Y-m-d H:i:s", strtotime($date));
		
		return $formattedMySQLDate;
	}
	
    /**
     * Converts date to SQLite3 format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function convertToSQLiteDateFormat($date)
	{
		$formattedMySQLDate = date("Y-m-d", strtotime($date));
		
		return $formattedMySQLDate;
	}	

    /**
     * Converts date into MMDDYYYY format
     *
     * @param $date
     * @return bool|string
     *
     */
    public static function dateInMMDDYYYY($date)
	{
		
		/**
		 * Added below in php.ini file
		 * date.timezone = "America/New_York"
		 */
		//date_default_timezone_set('UTC');
		
		$formattedDate = date("m/d/Y", strtotime($date));
		
		return $formattedDate;
	}

    /**
     * Returns current or today's date
     *
     * @return bool|string
     *
     */
    public static function getCurrentDate()
	{
		date_default_timezone_set('America/New_York');
		$currentDate = date("Y-m-d H:i:s");
		
		return $currentDate;
	}

    /**
     * Generates date range for today's date
     *
     * @return array of start and end date
     *
     */
    public static function dateRangeForCurrent()
	{
		$today = getdate();
		$startDate = $today['year']."-".$today['mon']."-01";
		$endDate = $today['year']."-".$today['mon']."-31";
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
		
	}
	
    /**
     * Generates date range from month and year
     *
     * @return array of start and end date
     *
     */
    public static function dateRangeFromMonthAndYear($mon, $year)
	{
		$today = getdate();
		$startDate = $year."-".$mon."-01";
		$endDate = $year."-".$mon."-31";
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
		
	}	
	
	public static function getStartAndEndDate($date)
	{
		$dateArray = explode("/", $date);
		
		$mon = self::getMonth();
		
		$startDate = $dateArray['2']."-".$dateArray['0']."-01";
		$endDate = $dateArray['2']."-".$dateArray['0']."-31";
		
		//echo "<br>start date -> ".$startDate;
		//echo "<br>end date -> ".$endDate;
		
		$dateRange = array(
		"start" => $startDate,
		"end" => $endDate,
		);
		
		return $dateRange;		
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	private function getMonth()
	{
		$monthArray = array(
			"01" => "Jan",
			"02" => "Feb",
			"03" => "Mar",
			"04" => "Apr",
			"05" => "May",
			"06" => "Jun",
			"07" => "Jul",
			"08" => "Aug",
			"09" => "Sept",
			"10" => "Oct",
			"11" => "Nov",
			"12" => "Dec",
		);
		
		return $monthArray;
			
	}
	
	/**
	 * 
	 * Enter description here ...
	 */
	public static function getMonthAndYYYY($date)
	{
		$dateArray = explode("/", $date);
		
		$mon = self::getMonth();
		
		$startDate = $dateArray['2']."-".$mon[$dateArray['0']]."-01";
		$endDate = $dateArray['2']."-".$mon[$dateArray['0']]."-31";
		
		$MonYYYY = array(
		"Mon" => $mon[$dateArray['0']],
		"YYYY" => $dateArray['2'],
		);
		
		return $MonYYYY;		
	}

    /**
     * Checks result set
     *
     * @param $result
     * @return bool
     *
     */
    public static function validateResultSet($result)
	{
		if ($result !=null and sizeof($result)>=1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

    /**
     * Generate given list with commas
     *
     * @param $items
     * @return string
     *
     */
    public static function generateStringWithCommas($items)
	{
		$count = count($items);

		if($count === 0) {
			return '';
		} else if($count === 1) {
			return $items[0];
		} else {
			return implode(', ', array_slice($items, 0, $count));
		}		
	}	
	
	/**
	 * Find day of week like Monday, Tuesday etc
	 * 
	 * @param $date
	 * @return dayofWeek
	 * 
	 */
	public static function dayOfWeek($date)
	{
		return date('l', strtotime($date));
	}
	
	/**
	 * 
	 * @param $rows
	 * 
	 */
	public static function displayPageSettingColumns($rows)
	{
		for ($i = 0; $i < sizeof($rows); $i++) 
		{ 
		  //echo "<br>rows[$i] : ".$rows[$i]."<br>";
		  $cols = explode(":", $rows[$i]);
		  //echo sizeof($cols)."<br>";
		 // print_r($cols);
		 
		  echo"<label>".$cols['2']."</label><br>";
		  
		  echo"<div class='container'>";
          
		  if ($cols['3'] != 'yes')
		  {
		  	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='yes'/>";
		  }	
		  else 
		  {
		  	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='yes' checked='checked'/>";	
		  }
          echo"&nbsp;&nbsp;&nbsp;<label for='".$cols['0']."'>yes</label>&nbsp;&nbsp;&nbsp;"; 
          
          
          if ($cols['3'] != 'no')
          {
          	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='no'/>";
          }
          else
          {
          	echo"<input type='radio' name='".$cols['1']."' id='".$cols['0']."' value='no' checked='checked'/>";
          }
          echo"&nbsp;&nbsp;&nbsp;<label for='".$cols['0']."'>no</label><br>";

          echo"</div>";									  
		  
		  //echo"columnname : ".$cols['1']."<br>";
		} 
	}	
	
	/**
	 * Enter description here ...
	 * 
	 * @param $timeStr
	 */
	public static function performTimeConversation($timeStr)
	{
		$formattedTime = null;
		echo "in ComonUtil::performTimeConversation : ".$timeStr;
		
	  	$strarray = explode(" ", $timeStr);
	  	//echo "<br>".sizeof($strarray)."<br>";
	 	//print_r($strarray);	

	 	if (strtolower($strarray[1]) == 'am')
	 	{
	 		if ($tmpArray[0] != '12')
	 		{
	 			$formattedTime = $strarray[0];
	 		}
	 		else 
	 		{
	 			$formattedTime = strval(intval($tmpArray[0])+12).":".$tmpArray[1];
	 		}	
	 	}
	 	elseif (strtolower($strarray[1]) == 'pm')
	 	{
	 		$tmpArray = explode(":", $strarray[0]);
	 		
	 		if ($tmpArray[0] != '12')
	 		{
	 			$formattedTime = strval(intval($tmpArray[0])+12).":".$tmpArray[1];	
	 		}
	 		else
	 		{
	 			$formattedTime = $strarray[0];
	 		}
	 		
	 	}
	 	
	 	return $formattedTime;
	}
	
	/**
	 * Enter description here ...
	 * 
	 * @param $timeStr
	 */
	public static function validateTaskTime($timeStrArray)
	{
		//echo "<br>in ComonUtil::validateTaskTime : Array Count : ".count($timeStrArray)."<br>";
		
		$timeFlag = true;
		
		foreach ($timeStrArray as &$timeStr) {
			
			$strArray = explode(" ", $timeStr);
			
			//print_r($strArray);
			
			if (strtolower($strArray[1]) != 'am' and strtolower($strArray[1]) != 'pm')
		 	{
		 		$timeFlag = false;
		 		break;
		 	}
		}
		
		return $timeFlag;
	}	
}