<?php

/**
 *	Controller - controls the flow
 *
 */ 
 class ProcessFormInputs
 {
 	
 	
 }
