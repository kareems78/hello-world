<?php
// Inialize session
//session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['username'])) {
$_SESSION['errorMsg'] = 'Your session might have been invalid. Please login ...';
header("Location: ".BASE_PATH."index.php");
}

if (isset($_SESSION['userdetails']))
{
	$userDetails = $_SESSION['userdetails'];
} 

if (isset($_SESSION['userrole']))
{
	$userRole = $_SESSION['userrole'];
} 