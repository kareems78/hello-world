<?php

  define("HTTP", ($_SERVER["HTTP_HOST"] == "127.0.0.1:54007") ? "http://127.0.0.1:54007/" : "http://homeapps.com/");
  define("BASE_PATH",	HTTP);

  //define("JPG",  BASE_PATH."jpgraph/");


  //define("PCHART",  BASE_PATH."pChart/");
  
  define("USERS",  BASE_PATH."aapps/users/");
  define("ROLES",  BASE_PATH."aapps/roles/");
  define("MODULES",  BASE_PATH."aapps/modules/");
  define("MENUS",  BASE_PATH."aapps/modules/menu/");
  define("CATEGORIES",  BASE_PATH."aapps/categories/");
  
  define("DBOPERS",  BASE_PATH."aapps/dbopers/");
  
  define("TASK",  BASE_PATH."papps/task/");
  define("CREDENTIAL",  BASE_PATH."papps/credential/"); 
  define("EXPENSE",  BASE_PATH."papps/expense/");  
  define("URLSTORE",  BASE_PATH."papps/urlstore/");
  define("PROJECTIONS",  BASE_PATH."papps/expense/projections/");
   
  define("PMISC",  BASE_PATH."papps/misc/");
  define("DTASKS",  BASE_PATH."papps/misc/d-tasks/"); 
  define("DPLAN",  BASE_PATH."papps/misc/dietplan/");
  define("PDETAILS",  BASE_PATH."papps/misc/plotdetails/"); 

  define("STIMINGS",  BASE_PATH."iapps/stimings/"); 
  define("STRACKER",  BASE_PATH."iapps/stracker/");  
  define("ZCALC",  BASE_PATH."iapps/zcalc/"); 
  define("DUAS",  BASE_PATH."iapps/duas/");
 
  define("REMAINDERS",  BASE_PATH."mapps/remainder/"); 
  define("BIOMETRICS",  BASE_PATH."mapps/biometrics/");   
  define("WEIGHTRECORDER",  BASE_PATH."mapps/weightrecorder/"); 
  define("CREDITPAYMENT",  BASE_PATH."mapps/creditpayment/"); 
  define("FUNDSTRANSFER",  BASE_PATH."mapps/fundstransfer/"); 
  define("ONLINEORDERS",  BASE_PATH."mapps/onlineorders/"); 
  define("HAPPSCAL",  BASE_PATH."mapps/happscal/");   
  
  define("CSS", BASE_PATH."css/"); 
  define("IMAGES", BASE_PATH."images/"); 
  define("SCRIPTS", BASE_PATH."scripts/");  
 
  //define("ROOT", dirname(__FILE__).'../../' ); 
  
  define("DS", DIRECTORY_SEPARATOR);
  define("ROOT", realpath(dirname(__FILE__)));  
  
  define("USERS_LEFTNAV", ROOT."aapps/users/leftnav.php" );  
  define("ROLES_LEFTNAV", ROOT."aapps/roles/leftnav.php" );  
  define("MODULES_LEFTNAV", ROOT."aapps/modules/leftnav.php" );  
  define("CATEGORIES_LEFTNAV", ROOT."aapps/categories/leftnav.php" );
  define("DBOPERS_LEFTNAV", ROOT."aapps/dbopers/leftnav.php" );
  
  define("TASKS_LEFTNAV", ROOT."papps/task/leftnav.php" );  
  define("CREDS_LEFTNAV", ROOT."papps/credential/leftnav.php" ); 
  define("EXP_LEFTNAV", ROOT."papps/expense/leftnav.php" );
  define("URLS_LEFTNAV", ROOT."papps/urlstore/leftnav.php" );
  define("PMISC_LEFTNAV", ROOT."papps/misc/leftnav.php" ); 
  
  define("STM_LEFTNAV", ROOT."iapps/stimings/leftnav.php" );
  define("ST_LEFTNAV", ROOT."iapps/stracker/leftnav.php" );
  define("DUAS_LEFTNAV", ROOT."iapps/duas/leftnav.php" );
  
  define("REM_LEFTNAV", ROOT."mapps/remainder/leftnav.php" );
  define("BIO_LEFTNAV", ROOT."mapps/biometrics/leftnav.php" );
  define("WR_LEFTNAV", ROOT."mapps/weightrecorder/leftnav.php" );
  define("CP_LEFTNAV", ROOT."mapps/creditpayment/leftnav.php" );
  define("FT_LEFTNAV", ROOT."mapps/fundstransfer/leftnav.php" );
  define("OO_LEFTNAV", ROOT."mapps/onlineorders/leftnav.php" );
  
  define("HEADER_CSS", ROOT."css/header.css" );
  
  define("INCLUDES",  ROOT."includes/");  
  define("CONTROLLER",     INCLUDES. "controller/"); 
  define("COMMON",     INCLUDES. "common/"); 
  define("DATAACCESS",     INCLUDES. "dataaccess/"); 
  define("DATABASE",     INCLUDES. "database/");

  define("JPG",  $_SERVER["HTTP_HOST"]."/jpgraph");
  define("PCHART",  ROOT."pChart/");
  
  //require_once ROOT . "includes/common/session.php";
  
  //!isset($_SESSION) ? session::init(): '';
  
  //require_once ROOT . "views/usersession.php";
  
  
  ?>