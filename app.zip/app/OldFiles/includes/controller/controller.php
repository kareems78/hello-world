<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once CONTROLLER . 'menucontroller.php';
require_once CONTROLLER . 'modulecontroller.php';
require_once CONTROLLER . 'taskcontroller.php';
require_once CONTROLLER . 'credcontroller.php';
require_once CONTROLLER . 'logincontroller.php';
require_once CONTROLLER . 'allcatcontroller.php';
require_once CONTROLLER . 'expcontroller.php';
require_once CONTROLLER . 'remcontroller.php';
require_once CONTROLLER . 'biocontroller.php';
require_once CONTROLLER . 'wrcontroller.php';
require_once CONTROLLER . 'cpcontroller.php';
require_once CONTROLLER . 'ftcontroller.php';
require_once CONTROLLER . 'oocontroller.php';
require_once CONTROLLER . 'pmisccontroller.php';
require_once CONTROLLER . 'stcontroller.php';
require_once CONTROLLER . 'stmcontroller.php';
require_once CONTROLLER . 'usercontroller.php';
require_once CONTROLLER . 'dtaskscontroller.php';
require_once CONTROLLER . 'projexpcontroller.php';
require_once CONTROLLER . 'urlstorecontroller.php';
require_once CONTROLLER . 'dplancontroller.php';
require_once CONTROLLER . 'pdetailscontroller.php';
require_once CONTROLLER . 'dboperscontroller.php';
require_once CONTROLLER . 'dbenvdetailscontroller.php';
 
/**
 *	Controller - controls the flow
 *
 */ 
 class Controller
 {
	protected static $_oper = null;

	public static $_formValues = null;
	
	protected static $_controller = null;
	
	public static $_id = null;
	
	public static $_userid = null;
	
	public static $_strVar = null;


     /**
      * Finds the controller and process operation requested
      *
      * @param $subModName
      * @param $oper
      * @return bool|list|null|void
      *
      */
     public static function findAndProcess($subModName,$oper)
	{
		self::$_oper = $oper;
		$result = null;
		
		if (!isset(self::$_controller))
		{
			$result = self::initiateController($subModName)->process();
		}
		
		return $result;
	}
	
      /**
      * Finds the controller and process operation requested
      *
      * @param $subModName
      * @param $oper
      * @param $userid
      * @return bool|list|null|void
      *
      */
     public static function findAndProcessWithUserID($subModName,$oper, $userid)
	{
		self::$_oper = $oper;
		self::$_userid = $userid;
		$result = null;
		
		if (!isset(self::$_controller))
		{
			$result = self::initiateController($subModName)->process();
		}
		
		return $result;
	}	

     /**
      * Processes form input values and calls
      * find and process function
      *
      * @param array $formInputs
      * @return bool|list|null|void
      *
      */
     public static function processForm($formInputs = array())
	{
		self::$_formValues = $formInputs;
		
		$result = null;
		
		if (isset($formInputs))
		{
			$smod = $formInputs['submodule'];
			$op = $formInputs['oper'];
			$result = self::findAndProcess($smod,$op);
		}
		
		return $result;
	}

     /**
      * Initiates controller
      *
      * @param $submodule
      * @return instance of controller requested
      */
     private static function initiateController($submodule)
	{
		switch (strtolower($submodule))
		{
			case (strtolower('menu')):
				self::$_controller = new MenuController();
				break;			
			
			case (strtolower('module')):
				self::$_controller = new ModuleController();
				break;
				
			case (strtolower('task')):
				self::$_controller = new TaskController();
				break;
				
			case (strtolower('credential')):
				self::$_controller = new CredController();
				break;		

			case (strtolower('login')):
				self::$_controller = new LoginController();
				break;			

			case (strtolower('allcat')):
				self::$_controller = new AllCatController();
				break;	

			case (strtolower('expense')):
				self::$_controller = new ExpController();
				break;		

			case (strtolower('remainder')):
				self::$_controller = new RemController();
				break;	

			case (strtolower('biometrics')):
				self::$_controller = new BioController();
				break;	

			case (strtolower('weightrecorder')):
				self::$_controller = new WRController();
				break;	

			case (strtolower('creditpayment')):
				self::$_controller = new CPController();
				break;	

			case (strtolower('fundstransfer')):
				self::$_controller = new FTController();
				break;		

			case (strtolower('pmisc')):
				self::$_controller = new PMiscController();
				break;	

			case (strtolower('stracker')):
				self::$_controller = new STrackerController();
				break;	

			case (strtolower('stimings')):
				self::$_controller = new STimingsController();
				break;	

			case (strtolower('onlineorders')):
				self::$_controller = new OOController();
				break;	

			case (strtolower('users')):
				self::$_controller = new UserController();
				break;	

			case (strtolower('dtasks')):
				self::$_controller = new DTasksController();
				break;	

			case (strtolower('projections')):
				self::$_controller = new ProjExpController();
				break;	

			case (strtolower('urlstore')):
				self::$_controller = new UrlStoreController();
				break;	

			case (strtolower('dplan')):
				self::$_controller = new DPlanController();
				break;				
				
			case (strtolower('plotdetails')):
				self::$_controller = new PDetailsController();
				break;	

			case (strtolower('dbopers')):
				self::$_controller = new DBOperationsController();
				break;		

            case (strtolower('dbenvdetails')):
                self::$_controller = new DBEnvDetailsController();
                break; 				
				
			default:
				die("<b>Error occurred : </b><font color='red'>Controller : ".$submodule." not found.</font>");
				//echo "Controller not found.";		
		}	

		return self::$_controller;	
		
	}

 }