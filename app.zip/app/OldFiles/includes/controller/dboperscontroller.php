<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once DATAACCESS . 'dbopersdao.php';
 
/**
 *	STimingsController - controls the flow
 *
 */ 
 class DBOperationsController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new DBOperationsDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			case strtolower('getUpdateIdDropDownValues'):
				$result = $dao->getUpdateIdDropDownValues();	
				break;				
			
			// update ids		
			case strtolower('updateids'):
				$result = $dao->updateIDs(parent::$_formValues);
				break;
				
			case strtolower('getCSVTableDropDownValues'):
				$result = $dao->getCSVTableDropDownValues();	
				break;	

			case strtolower('generatecsv'):
				$result = $dao->generateCSVFile(parent::$_formValues);
				break;				
				
			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }