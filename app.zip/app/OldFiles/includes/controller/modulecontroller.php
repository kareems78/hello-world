<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once DATAACCESS . 'moduledao.php';
 
/**
 *	STimingsController - controls the flow
 *
 */ 
 class ModuleController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new ModuleDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('getAll'):
				$result = $dao->executeQuery($dao->_getAllRecords);
				break;

			// add a record		
			case strtolower('add'):
				$result = $dao->insert(parent::$_formValues);
				break;
				
			case strtolower('getDropDownValues'):
				$result = $dao->getDropDownValues();	
				break;	
			
			// delete records		
			case strtolower('delete'):
				$dao->setFormInputs(parent::$_formValues);
				$result = $dao->delete();	
				break;	

			// retrieve a record to edit	
			case strtolower('edit'):
				echo "in edit task : id : ".parent::$_id;
				$result = $dao->getByID(parent::$_id);
				break;	

			// update a record		
			case strtolower('update'):
				$result = $dao->update(parent::$_formValues);
				break;				
				
			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }