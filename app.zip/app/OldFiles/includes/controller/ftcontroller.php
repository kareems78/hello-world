<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once DATAACCESS . 'fundstransferdao.php';
 
/**
 *	FTController - controls the flow
 *
 */ 
 class FTController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$userid = parent::$_userid;
		
		//Setting userid if sent thru form values
		if (!isset($userid))
		{
			if (isset(parent::$_formValues['userid']))
			{
				$userid = parent::$_formValues['userid'];
			}
		}		
		
		$dao = new FundsTransferDAO($userid);
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('getAll'):
				$result = $dao->executeQuery($dao->_getAllRecords);
				break;

			// add a record		
			case strtolower('add'):
				$result = $dao->insert(parent::$_formValues);
				break;
				
			case strtolower('getDropDownValues'):
				$result = $dao->getDropDownValues();	
				break;	
			
			// delete records	
			case strtolower('delete'):
				$dao->setFormInputs(parent::$_formValues);
				$result = $dao->delete();	
				break;	
			
			// retrieve a record to edit
			case strtolower('edit'):
				$result = $dao->getByID(parent::$_id);
				break;	
			
			// update a record	
			case strtolower('update'):
				$result = $dao->update(parent::$_formValues);
				break;		

			// search str	
			case strtolower('searchstr'):
				$result = $dao->generateSearchQuery(parent::$_formValues);
				break;	

			// search	
			case strtolower('search'):
				$result = $dao->search(parent::$_strVar);
				break;				

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }