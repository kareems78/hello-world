<?php
 
include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once DATAACCESS . 'stimingsdao.php';
 
/**
 *	STimingsController - controls the flow
 *
 */ 
 class STimingsController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new STimingsDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('getAll'):
				$result = $dao->executeQuery($dao->_getAllRecords);
				break;

			// get maghrib salah timings		
			case strtolower('getMST'):
				$result = $dao->executeQuery($dao->_getAllMSTRecords);
				break;

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
				
		}
		
		return $result;		
	}
 }