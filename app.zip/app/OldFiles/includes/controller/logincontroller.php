<?php

include_once $_SERVER['DOCUMENT_ROOT'] . '\defines.php';

require_once DATAACCESS . 'logindao.php';
 
/**
 *	LoginController - controls the flow
 *
 */ 
 class LoginController extends Controller
 {
     /**
      * processes all operations
      *
      * @return bool|list|void
      *
      */
	public function process()
	{
		$result = null;
		
		$dao = new LoginDAO();
		
		//get stored operation
		switch (strtolower(parent::$_oper))
		{
			// get all records
			case strtolower('validate'):
				$result = $dao->validateUser(parent::$_formValues);
				break;

			default:
				die("Error occurred : <font color='red'>Operation : ".parent::$_oper." not found.</font>");
		}
		
		// Close SQLite DB Connection
		$this->_conn = null;		
		
		return $result;		
	}
 }