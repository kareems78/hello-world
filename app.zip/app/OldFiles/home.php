<?php
include_once 'defines.php';

include_once 'usersession.php';

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Welcome to Home Apps</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<link href="css/header.css" rel="stylesheet"/>
		<link href="css/menu.css" rel="stylesheet" type="text/css">
		<link href="css/index.mainbody.css" rel="stylesheet"/>
		<link href="css/footer.css" rel="stylesheet"/>
		
    </head>
    <body>
        <div class="wrapper">
		
			<!-- header starts here -->
			<?php require_once 'header.php';?>
			<!-- header ends here -->
			
			<!-- cssmenu starts here -->
			<?php require_once 'menu.php';?>
			<!-- cssmenu ends here -->
            
			<!-- main body starts here -->
            <div class="mainbody">
                
                 <div class="leftcol">
                    
                    <div class="left_navbar">
                        
                        <h3> </h3>
                        
                        <ul class="left_inner">

                        </ul> 
                    </div>
                </div> 
                
                <div class="midcol">
                    <div class="middle_holder">
					
					<table border="0">
					<tr>
					
					<!-- row :1 & col : 1 -->
					<?php 
						if ($userRole['roleid'] == 1)
						{
					?>
					<td valign="top">
					
					<div id='tbl'><table class='tbl'>
					<tr>
						<th width='175'>Admin Apps</th>
					</tr>
					<tr>
						<td><a href="aapps/users/users.php">Users</a></td>
					</tr>	
					<tr>
						<!-- <td><a href="aapps/roles/roles.php">Roles</a></td> -->
						<td><a href="#">Roles</a></td>
					</tr>
					<tr>
						<td><a href="aapps/modules/modules.php">Modules</a></td>
					</tr>
					<tr>
						<td><a href="aapps/categories/allcategories.php">Categories</a></td>
					</tr>		
					<tr>
						<td><a href="aapps/dbopers/updateids/updateids.php">DB Operations</a></td>
					</tr>								
					</table>
					</div>					
					
					</td>					
					
					<?php 
						}
					?>					
					
					<td width="20">
					&nbsp;
					</td>					
					
					<!-- row :1 & col : 2 -->
					<td valign="top">
					
					<div id='tbl'><table class='tbl'>
					<tr>
						<th width='175'>Personal Apps</th>
					</tr>
					<tr>
						<td><a href="#">Blogs</a></td>
					</tr>	
					<tr>
						<td><a href="papps/task/tasks.php">Tasks</a></td>
					</tr>	
					<tr>	
						<td><a href="papps/expense/expenses.php">Expenses</a></td>
					</tr>	
					<tr>	
						<td><a href="papps/credential/credentials.php">Credentials</a></td>
					</tr>	
					<tr>	
						<td><a href="papps/misc/cleaning.php">Misc</a></td>
					</tr>
					</table>
					</div>						
					
					</td>
					
					<td width="20">
					&nbsp;
					</td>
					
					<!-- row :1 & col : 3 -->
					<td valign="top">
					
					<div id='tbl'><table class='tbl'>
					<tr>
						<th width='175'>Islamic Apps</th>
					</tr>
					<tr>
						<td><a href="iapps/stimings/salahtimings.php">Salah Timings</a></td>
					</tr>	
					<tr>
						<td><a href="iapps/stracker/salahtracker.php">Salah Tracker</a></td>
					</tr>	
					<tr>	
						<td><a href="iapps/duas/duas.php">Duas</a></td>
					</tr>	
					</table>
					</div>						
					
					</td>
					
					<td width="20">
					&nbsp;
					</td>
					
					<!-- row :1 & col : 4 -->
					<td valign="top">
					
					<div id='tbl'><table class='tbl'>
					<tr>
						<th width='175'>Misc Apps</th>
					</tr>
					<tr>
						<td><a href="mapps/remainder/remainders.php">Remainders</a></td>
					</tr>
					<tr>
						<td><a href="mapps/biometrics/biometrics.php">Biometrics</a></td>
					</tr>
					<tr>
						<td><a href="mapps/weightrecorder/weightrecorder.php">Weight Recorder</a></td>
					</tr>					
					<tr>
						<td><a href="mapps/creditpayment/creditpayment.php">Credit Payments</a></td>
					</tr>	
					<tr>	
						<td><a href="mapps/fundstransfer/fundstransfer.php">Funds Transfer</a></td>
					</tr>	
					<tr>	
						<td><a href="mapps/onlineorders/onlineorders.php">Online Orders</a></td>
					</tr>					
					</table>
					</div>					
					
					</td>
					
					</tr>
					
					</table>
                      
                    </div>
                </div>
                
                <div class="rightcol">
                    <div class="right_holder">

                    </div>
                    
                    <div class="right_holder">

                    </div>
                </div>
                
            </div>
            <!-- main body ends here -->
			
			<!-- footer starts here -->
			<?php require_once 'footer.php';?>
            <!-- footer ends here -->
			
        </div>
    </body>
</html>
