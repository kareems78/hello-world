DROP TABLE IF EXISTS "account";
CREATE TABLE "account" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
   "description" text DEFAULT NULL
);
INSERT INTO "account" VALUES(1,'Kareem ICICI',NULL);
INSERT INTO "account" VALUES(2,'Kareem SBI',NULL);
INSERT INTO "account" VALUES(3,'Kareem Citi',NULL);
INSERT INTO "account" VALUES(4,'Jakeer Bhai',NULL);
INSERT INTO "account" VALUES(5,'Kareem NRE',NULL);
INSERT INTO "account" VALUES(6,'Kaleemullah Uncle','SBI Account');
INSERT INTO "account" VALUES(7,'Thoukhir UK Acct','');
INSERT INTO "account" VALUES(8,'Kareem Home Loan','');
DROP TABLE IF EXISTS "bioabbrevations";
CREATE TABLE "bioabbrevations" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "bioabbrevations" VALUES(1,'BMI','Body Mass Index');
INSERT INTO "bioabbrevations" VALUES(2,'WC','Waist Circumference');
INSERT INTO "bioabbrevations" VALUES(3,'BP','Blood Pressure');
INSERT INTO "bioabbrevations" VALUES(4,'GF','Glucose Fasting');
INSERT INTO "bioabbrevations" VALUES(5,'GNF','Glucose Non Fasting');
INSERT INTO "bioabbrevations" VALUES(6,'Total Chol','Total Cholestrol');
INSERT INTO "bioabbrevations" VALUES(7,'HDL Chol','HDL Cholestrol');
INSERT INTO "bioabbrevations" VALUES(8,'LDL','LDL Cholestrol');
DROP TABLE IF EXISTS "biometrics";
CREATE TABLE "biometrics" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "createddate" text NOT NULL,
  "biotestdate" text NOT NULL,
  "user" integer NOT NULL,
  "weight" text NOT NULL,
  "bmi" text DEFAULT NULL,
  "waist" text DEFAULT NULL,
  "bp" text NOT NULL,
  "glucosefasting" text DEFAULT NULL,
  "glucosenonfasting" text DEFAULT NULL,
  "totalcholestrol" text DEFAULT NULL,
  "hdlcholestrol" text DEFAULT NULL,
  "ldlcholestrol" text DEFAULT NULL,
  "riskratio" text DEFAULT NULL,
  "notes" text DEFAULT NULL,
  CONSTRAINT "FKBIO_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "biometrics" VALUES(2002001,'2012-11-19','2011-10-25',2,'132','23','32','111/74','91','','144','19','','7.5','Test notes');
INSERT INTO "biometrics" VALUES(2002002,'2012-11-19','2012-10-24',2,'129','22','30','110/70','','112','146','31','','4.8','');
DROP TABLE IF EXISTS "ccategory";
CREATE TABLE "ccategory" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "ccategory" VALUES(1,'Home',NULL);
INSERT INTO "ccategory" VALUES(2,'Work',NULL);
INSERT INTO "ccategory" VALUES(3,'Misc',NULL);
INSERT INTO "ccategory" VALUES(4,'Mail',NULL);
INSERT INTO "ccategory" VALUES(5,'Medical',NULL);
INSERT INTO "ccategory" VALUES(6,'Insurance',NULL);
INSERT INTO "ccategory" VALUES(7,'Utilities',NULL);
INSERT INTO "ccategory" VALUES(8,'Personal',NULL);
INSERT INTO "ccategory" VALUES(9,'Credit Card',NULL);
INSERT INTO "ccategory" VALUES(10,'Car','Car related links');
INSERT INTO "ccategory" VALUES(11,'S - Card','Shopping Card');
INSERT INTO "ccategory" VALUES(12,'Technical','');
DROP TABLE IF EXISTS "cleaning";
CREATE TABLE "cleaning" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "headline" text DEFAULT NULL,
  "user" integer NOT NULL,
  "text" blob,
   CONSTRAINT "FKPLOTDETAILS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
DROP TABLE IF EXISTS "component";
CREATE TABLE "component" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "component" VALUES(1,'Cramer','Cramer');
INSERT INTO "component" VALUES(2,'GCP-MV','GCP-MV');
DROP TABLE IF EXISTS "content";
CREATE TABLE "content" (
  "element_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "text" blob NOT NULL
);
INSERT INTO "content" VALUES(1,'sfdfd');
DROP TABLE IF EXISTS "credential";
CREATE TABLE "credential" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
  "createddate" text DEFAULT NULL,
  "username" text NOT NULL,
  "password" text NOT NULL,
  "user" integer NOT NULL,
  "category" integer NOT NULL,
  "url" text DEFAULT NULL,
  "notes" blob DEFAULT NULL,
  CONSTRAINT "FKCRED_CCAT" FOREIGN KEY ("category") REFERENCES "ccategory" ("id"),
  CONSTRAINT "FKCRED_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "credential" VALUES(2002001,'Yahoo Mail','2012-11-20','mailtokarims','Qwerty!@12',2,4,'','');
INSERT INTO "credential" VALUES(2002002,'Yahoo Mail','2012-11-20','kareem.shaik','ilushe**10',2,4,'','kareem.shaik@ymail.com');
INSERT INTO "credential" VALUES(2002003,'Gmail','2012-11-20','karim.shak','f10',2,4,'','');
INSERT INTO "credential" VALUES(2002004,'Hotmail','2012-11-20','kareim_s','ilusha**10',2,4,'','');
INSERT INTO "credential" VALUES(2002005,'Progressive','2012-11-20','kareems78','f10',2,6,'http://www.progressive.com/login.aspx','Policy No# 43611518-5
Custmoer Care: 1-800-876-5581

Fax: 1 800 229 1590');
INSERT INTO "credential" VALUES(2002006,'Prudential 401K','2012-11-27','kareems78','f10',2,3,'https://ssologin.prudential.com/app/retirement/Login.fcc','401K plan

877-778-2100');
INSERT INTO "credential" VALUES(2002007,'ATT Internet','2012-11-30','kareems78','f10',2,3,'','');
INSERT INTO "credential" VALUES(2002008,'ATT Composer','2012-11-30','ks589h','ks589h',2,2,'https://bistromatic.mo.sbc.com:9443/rdm/','');
INSERT INTO "credential" VALUES(2002009,'ATT Redmine','2012-11-30','ks589h','F10',2,2,'http://139.76.215.96:7225/redmine/login','');
INSERT INTO "credential" VALUES(2002010,'ATT QC','2012-11-30','ks589h','Almalik@10',2,2,'','05//12/2014 :
Old Pwd : Hafsaloo@10

07/11/2014 :
Old Pwd : Qwerty@10

09/10/2014 :
Old Pwd : Asdzxc@10

11/11/2014 :
Old Pwd : Habeebullah@10

01/08/2015 :
Old Pwd : Mudassir@10

03/09/2015 :
Old Pwd : Ataullah@10

05/14/2015 :
Old Pwd : Abdullah@10

07/13/2015 :
Old Pwd : Arrahman@10

09/01/2015
Old Pwd : Albaseer@10

11/02/2015
Old Pwd : Arrazaq@10

01/06/2016
Old Pwd : Albaari@10

06/06/2016
Old Pwd : Aljabbar@10');
INSERT INTO "credential" VALUES(2002011,'ATT Global Login','2012-11-30','ks589h','Almalik@1978',2,2,'','Your secret question is: 
Model name of my first car?

Nissan Altima GXE');
INSERT INTO "credential" VALUES(2002012,'ATT Crucible','2012-11-30','ks589h','ITServices Pwd',2,2,'http://crucible.snt.bst.bls.com:8060/','Use below url from Amdocs Ntwk
http://139.76.213.210:11175/');
INSERT INTO "credential" VALUES(2002013,'ATT FTP','2012-11-30','m45678','G0ipag!',2,2,NULL,NULL);
INSERT INTO "credential" VALUES(2002014,'Remit2India','2012-11-30','Yahoo Email ID','k10',2,8,'https://www.timesofmoney.com/remittance/secure/r2i','Customer ID : 1695742
');
INSERT INTO "credential" VALUES(2002015,'Mint','2012-11-30','Yahoo Email ID','f10',2,8,'https://wwws.mint.com/login.event','');
INSERT INTO "credential" VALUES(2002016,'Davis Vision','2012-11-30','Yahoo Email ID','f10',2,5,'http://www.davisvision.com','ID: 789000733095

Customer Care : 1 800 999 5431');
INSERT INTO "credential" VALUES(2002017,'CIGNA','2012-11-30','kareems78','f10',2,5,NULL,'ID: U40574366 01

Account - 3209216

Customer Care : 800-244-6224

www.myCigna.com

Cigna Dental PPO

Radius Network');
INSERT INTO "credential" VALUES(2002018,'Georgia Power','2012-11-30','kareems78','f10',2,7,'http://www.georgiapower.com/','Account No : 80852-13009

1-888-660-5890');
INSERT INTO "credential" VALUES(2002019,'Visa Trax','2012-11-30','kareems78','hafsa@10',2,2,'https://app01.visatrax.com/inszoom_hosted_login.aspx?org_id=Ogtree','Registered with Amdocs Email ID');
INSERT INTO "credential" VALUES(2002020,'Pure Talk USA','2012-11-30','211100014177','f10',2,8,'https://www.puretalkusa.com/','Customer Care : (877) 820-7873

Email : support@puretalkusa.com

Account No# 211100014177
Order No# 1892644
SIM# 89014102255478559752
Phone Number : 678-654-2211');
INSERT INTO "credential" VALUES(2002021,'Oracle','2012-11-30','Gmail ID','F10',2,8,NULL,NULL);
INSERT INTO "credential" VALUES(2002022,'Safari Books Online','2012-11-30','Amdocs EmailID','f10',2,8,'http://www.safaribooksonline.com/','');
INSERT INTO "credential" VALUES(2002023,'Junior Achievement','2012-11-30','Amdocs EmailID','f10',2,8,'http://jaog.convio.net/goto/TEAM1','');
INSERT INTO "credential" VALUES(2002024,'Sears Card','2012-11-30','kareems78','f10',2,11,'https://www.citibank.com/us/cards/srs/index.jsp','');
INSERT INTO "credential" VALUES(2002025,'Homes','2012-11-30','kareemshaik','f10',2,8,'http://www.homes.com','');
INSERT INTO "credential" VALUES(2002026,'ATT Manual Jira','2012-11-30','ks589h','Almalik@10',2,2,'https://itrack.web.att.com/secure/Dashboard.jspa','05/12/2014 :
Old Pwd : Hafsaloo@10

07/11/2014 :
Old Pwd : Qwerty@10

09/10/2014 :
Old Pwd : Asdzxc@10

11/11/2014 :
Old Pwd : Habeebullah@10

01/08/2015 :
Old Pwd : Mudassir@10

03/09/2015 :
Old Pwd : Ataullah@10

09/01/2015 :
Old Pwd : Albaseer@10

11/02/2015 :
Old Pwd :Arrazaq@10

01/06/2016
Old Pwd : Albaari@10

06/06/2016
Old Pwd : Aljabbar@10');
INSERT INTO "credential" VALUES(2002027,'eRenterPlan','2012-11-30','Y! Mail','f10',2,6,'http://my.erenterplan.com','Policy# 0030609238
1 888 205 8118

Auto Pay: CC ends with 8844');
INSERT INTO "credential" VALUES(2002028,'Zakat.org','2012-11-30','Yahoo Email','f10',2,8,'http://www.zakat.org','');
INSERT INTO "credential" VALUES(2002029,'Comcast','2012-11-30','kareemshaik@comcast.net','f10',2,8,'https://login.comcast.net/login','Account : 8220177050947301');
INSERT INTO "credential" VALUES(2002030,'AAA','2012-11-30','kareems78','f10',2,8,NULL,'Membership# 429-014-630180570-3');
INSERT INTO "credential" VALUES(2002031,'Evernote','2012-11-30','karimshk','Rainbow@10',2,8,'','');
INSERT INTO "credential" VALUES(2002032,'Apple ID','2012-11-30','Gmail','F10',2,8,NULL,NULL);
INSERT INTO "credential" VALUES(2002033,'Roku','2012-11-30','Y! Mail','f10',2,8,'https://owner.roku.com/Login/','');
INSERT INTO "credential" VALUES(2002034,'Cloud Acct','2012-11-30','Y!Mail','f10',2,8,'http://ksh.cloud-ide.com/cloud/ide.jsp','');
INSERT INTO "credential" VALUES(2002035,'Apple iCloud','2012-11-30','Gmail','F10',2,8,'https://www.icloud.com/','');
INSERT INTO "credential" VALUES(2002036,'DDS GA','2012-11-30','Y! Mail','f10',2,8,'https://online.dds.ga.gov/onlineservices/Account/Login.aspx','');
INSERT INTO "credential" VALUES(2002037,'Old Navy','2012-11-30','Y! Mail','f10',2,11,'https://www3.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=oldnavy&accountType=plcc&mlink=5151,5838218,11&clink=5838218','Secret questions :

In which city your father was born - Vinukonda
(V should be in CAPS)');
INSERT INTO "credential" VALUES(2002038,'American Express','2012-11-30','kareems78','f10',2,11,'https://www.americanexpress.com/','');
INSERT INTO "credential" VALUES(2002039,'JCPenny','2012-12-11','Y! Mail','f10',2,8,'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=jcpenney&accountType=generic','Challenge Question:
Q: In what city was your father born? (Enter full name of city only)?
A: vinukonda');
INSERT INTO "credential" VALUES(2002040,'Babies R Us CC','2013-05-13','Y! Mail','f10',2,11,'https://www.onlinecreditcenter6.com/consumergen2/login.do?subActionId=1000&clientId=tru&accountType=generic','');
INSERT INTO "credential" VALUES(2002041,'Honda Services','2013-05-14','kareems78','f10',2,10,'http://www.hondafinancialservices.com/','5/14
Auto Pay is setup. from next month i.e. June, it will be deducted automatically. Paid already for current month.');
INSERT INTO "credential" VALUES(2002042,'Honda Owners','2013-06-06','Y! Mail','f10',2,10,'https://owners.honda.com','');
INSERT INTO "credential" VALUES(2002043,'SBI Policy','2013-06-11','kareems78','Jannat@14',2,6,'https://mypolicy.sbilife.co.in/Home.aspx','Will be added once registration is completed

Policy No#
35011356507 (Amt : 51890)
Customer No# 27138505

Policy No#
44024676304 (Amt : 100000)
Customer No# 27138505');
INSERT INTO "credential" VALUES(2002044,'YMCA','2013-06-12','Gmail','f10',2,1,'https://spiritonline.ymcaatlanta.org/SpiritWeb/Login','ID : 962333');
INSERT INTO "credential" VALUES(2002045,'Paypal US','2013-06-19','Gmail','f10',2,8,'https://paypal.com','');
INSERT INTO "credential" VALUES(2002046,'Paypal UK','2013-06-19','Y! Mail','k10',2,8,'','');
INSERT INTO "credential" VALUES(2002047,'Ring Britain','2013-06-19','Y! Mail','f10',2,1,'http://ringbritain.com/','Access Number : 678 791 4448

PIN : 4320683709');
INSERT INTO "credential" VALUES(2002048,'SBI Online','2013-06-25','kareems78','Aljabbar@10',2,8,'https://www.onlinesbi.com/retail/login.htm','Account No# 11348672342
Branch: Mudfort

profile password : kareem@10

Kit No: C428307043

IFC Code: SBIN0007111
MICR Code: 500002051
');
INSERT INTO "credential" VALUES(2002049,'SBI NRE Online','2013-06-25','kareemsnre78','fnre@10',2,8,'https://www.onlinesbi.com/retail/login.htm#','Account No# 31801448384
Branch: Jubilee Hills
Kit No: C435807110

profile password : kareemnre@10

Future Company : my company
IFC Code: SBIN0011745

');
INSERT INTO "credential" VALUES(2002050,'State Farm','2013-06-28','kareems78','Albaseer@10',2,6,'http://www.statefarm.com/','Auto/Home Insurance - Plan Number : 1301502727

Policy Nos#
Honda Odyssey :
713 9648-F28-11

Nissan Altima:
713 9649-F28-11

Customer Care :  770 442 1440

Trey : 770 253 2055 (Agent)

');
INSERT INTO "credential" VALUES(2002051,'CI Medicine Records','2013-06-30','Gmail','F10',2,5,'https://my.patientfusion.com/','PIN : DRHBHRLC');
INSERT INTO "credential" VALUES(2002052,'HomeApps','2013-07-02','karims','karims',2,8,'http://localhost/HomeApps','');
INSERT INTO "credential" VALUES(2002053,'WorkApps','2013-07-02','kareems','f10',2,8,'http://localhost/Work','');
INSERT INTO "credential" VALUES(2002054,'Amdocs Connect','2013-07-03','kareems','F10',2,2,'https://amdocsconnect.uc.att.com/amdocsconnect/meet/?ExEventID=8780915 ','My Info :

https://amdocsconnect.uc.att.com/amdocsconnect/ASPX/UserModules/MyInformation.aspx?ICC=1&Username=76C92A1D0D7DA68BA8438D8E5D2BFC09D15EFC7F04C5B6B9C7786DEDEF686F34C32E9B7CCFA0C3CAD1153055F59915989B9B70A55BE631BC46D39E1C6FBCF619&password=B99DE2D6137DA68E4EB3C924EB01AD4D3320AE786A9250E75B48E38B72F288201AB281E66ABFA853844EBBA9075AC7820BC16499F198444A8DE920C6125F197B&sec=1&BA=1');
INSERT INTO "credential" VALUES(2002055,'ATT Connect','2013-07-03','Amdocs EmailID','2428042',2,2,'https://connect7.uc.att.com/attinc3/meet/?ExEventID=89756692','Below is the link to the 1 hour training. Once you are finished you would get email for setting up your ATT Connect account.
http://etech.it.att.com/conferencing/
ATTConnect/Pages/VideoTraining.aspx
 
attuid@itservices
');
INSERT INTO "credential" VALUES(2002056,'ATT SVN','2013-07-15','ks589h','Almalik10',2,2,'','SVN Admin : 
https://scm.it.att.com:8443/scmadmin

CIM : 
svn://scm.it.att.com:13213 - Almalik10

ML : 
svn://scm.it.att.com:13210/

Cramer : 
svn://scm.it.att.com:13320 - Almuhaymin10

');
INSERT INTO "credential" VALUES(2002057,'Vonage','2013-07-30','7707020246','F10',2,1,'http://www.vonage.com/customer','Security PIN : 1978

Old Phone# 7708818429');
INSERT INTO "credential" VALUES(2002058,'Dropbox','2013-07-30','Gmail','f10',2,8,'https://www.dropbox.com','');
INSERT INTO "credential" VALUES(2002059,'Fedex','2013-08-13','kareems10','f10',2,1,'http://fedex.com/us/','Account : 4759-3766-0');
INSERT INTO "credential" VALUES(2002060,'ADP PayCheck','2013-08-16','kshaik@amdocs','Albaseer@10',2,2,'https://ipay.adp.com/iPay/login.jsf','Amdocs PassCode - Amdocs-Amdocs
City/Town - GUNTUR
Make and Year of first car : 2001 Nissan Altima GXE
What was your favorite subject in school : Mathematics
');
INSERT INTO "credential" VALUES(2002061,'Target Credit Card','2013-09-06','kareems78','felisha10',2,11,'https://rcam.target.com/default.aspx','');
INSERT INTO "credential" VALUES(2002062,'Shahana BOA Online','2013-09-06','shameen8609','f10',2,8,'http://bankofamerica.com','Access ID : 7708818429
PIN : 670812');
INSERT INTO "credential" VALUES(2002063,'NextGen Patient Portal','2013-10-02','kareems78','f10',2,5,'https://www.nextmd.com/Login/Login.aspx','Security Token : 868-05-597

GA Urology Address:
1357 Hembree Road, Alpharetta GA
 Suite 250

Security Questions :
Q: In which city did you meet your spouse ?
A: hyderabad

Q: What is the city of honeymoon ?
A: kullu manali');
INSERT INTO "credential" VALUES(2002064,'Reward R Us','2013-10-09','Y! Mail','F10',2,1,'https://rewardsrus.toysrus.com/','Membership# 2100058690159');
INSERT INTO "credential" VALUES(2002065,'Nissan Leaf Account','2013-10-22','kareems78','Aljabbar@10',2,1,'https://www.nissanfinance.com/nmaccss/','NMAC Number : 25006904468

VIN : 1N4AZ0CP2DC414197

Bought in : 10/2013 - Check docs for correct date

PIN : 191003');
INSERT INTO "credential" VALUES(2002066,'Kohls','2013-10-22','kareems78','F10',2,11,'https://credit.kohls.com/eCustService/','Fathers Middle Name : saheb
Make of first car : nissan');
INSERT INTO "credential" VALUES(2002067,'Xoom','2013-10-22','Y! Mail','f10',2,8,'https://www.xoom.com','');
INSERT INTO "credential" VALUES(2002068,'Amli Resident Portal','2013-10-25','kareems78','f10',2,1,'https://property.onesite.realpage.com/welcomehome/?siteid=1011366#url=%23login','');
INSERT INTO "credential" VALUES(2002069,'Macys','2013-12-13','Y! Mail','f10',2,11,'https://www.macys.com/account/signin','');
INSERT INTO "credential" VALUES(2002070,'iCard Gift Card','2013-12-16','Y! Mail','f10',2,11,'https://www.icardgiftcard.com','');
INSERT INTO "credential" VALUES(2002071,'Renweb Kareem','2013-12-19','kareems78','f10',2,1,'https://www.renweb.com/Logins/ParentsWeb-Login.aspx','Person ID : 1201338

District Code : ILM-GA');
INSERT INTO "credential" VALUES(2002072,'Remember The Milk','2014-01-19','kareems78','f10',2,8,'https://www.rememberthemilk.com/login/','');
INSERT INTO "credential" VALUES(2002073,'Visual Studio Account','2014-01-28','Hotmail','ilusha****10',2,12,'https://kareems78.visualstudio.com/','');
INSERT INTO "credential" VALUES(2002074,'Motorola Router','2014-02-13','admin','F10',2,1,'http://192.168.0.1/','');
INSERT INTO "credential" VALUES(2002075,'Rally Access','2014-03-18','ks589h@att.com','Aljabbar@10',2,2,'https://rally1.rallydev.com/slm/login.op','');
INSERT INTO "credential" VALUES(2002076,'Twitter','2014-03-26','kareems78','F10',2,8,'https://twitter.com/','Y! Mail');
INSERT INTO "credential" VALUES(2002077,'Skype','2014-05-04','kareem.shahana','Mudassir@10',2,8,'http://www.skype.com','');
INSERT INTO "credential" VALUES(2002078,'To Access LS Unix Box','2014-05-12','as1300','Chan63Me!',2,2,'','');
INSERT INTO "credential" VALUES(2002080,'LS Unix Box','2014-07-03','ks589h','Ksha@10',2,2,'','');
INSERT INTO "credential" VALUES(2002081,'Ebay US','2014-07-20','Gmail','Ksha@10',2,8,'http://www.ebay.com','');
INSERT INTO "credential" VALUES(2002082,'FACTS - ILM','2014-08-15','kareems78','F10',2,1,'https://online.factsmgt.com','');
INSERT INTO "credential" VALUES(2002083,'Amdocs Connect Info','2014-11-05','na','na',2,2,'https://amdocsconnect.uc.att.com/amdocsconnect/ASPX/UserModules/MyInformation.aspx?ICC=1&Username=76C92A1D0D7DA68BA8438D8E5D2BFC09D15EFC7F04C5B6B9C7786DEDEF686F34C32E9B7CCFA0C3CAD1153055F59915989B9B70','');
INSERT INTO "credential" VALUES(2002084,'NewEgg','2014-11-07','Y! Mail','F@10',2,8,'http://www.newegg.com','');
INSERT INTO "credential" VALUES(2002085,'Food Network','2014-11-12','Y! Mail','F@10',2,1,'http://www.foodnetwork.com','');
INSERT INTO "credential" VALUES(2002086,'Skype New ID','2014-12-05','kareems100278','F@10',2,8,'http://www.skype.com','');
INSERT INTO "credential" VALUES(2002087,'Java Net','2014-12-10','kareems78','f10',2,8,'https://java.net/','Gmail ID');
INSERT INTO "credential" VALUES(2002088,'Shahana Apple ID','2014-12-28','Shahana GmailID','F@10',2,8,'http://apple.com','');
INSERT INTO "credential" VALUES(2002089,'Men''s Health UK','2015-01-06','kareems78','f10',2,8,'http://www.menshealth.co.uk/','');
INSERT INTO "credential" VALUES(2002090,'Thumbtack','2015-01-07','Y! Mail','F@10',2,8,'http://www.thumbtack.com/','');
INSERT INTO "credential" VALUES(2002091,'homepack buzz','2015-01-08','Y! Mail','f10',2,8,'http://www.homepackbuzz.com','');
INSERT INTO "credential" VALUES(2002092,'Paid ViewPoint','2015-01-28','Y! Mail','f10',2,8,'http://paidviewpoint.com/','');
INSERT INTO "credential" VALUES(2002093,'IXL ','2015-02-17','hafsak665','ilm',2,1,'http://www.ixl.com/','');
INSERT INTO "credential" VALUES(2002094,'Zenni Optical','2015-03-21','Y! Mail','f10',2,1,'https://www.zennioptical.com','');
INSERT INTO "credential" VALUES(2002095,'Walmart','2015-04-12','Y! Mail','f10',2,1,'http://www.walmart.com','');
INSERT INTO "credential" VALUES(2002096,'Bluebird ','2015-04-29','kareems78','F10',2,1,'https://secure.bluebird.com/','What is your birth place ?
Guntur');
INSERT INTO "credential" VALUES(2002097,'Facebook','2015-06-21','Y! Mail','Alkhaliq@10',2,8,'http://www.facebook.com','');
INSERT INTO "credential" VALUES(2002098,'Tenali BB','2015-06-24','smeera953','Raiyan@2014',2,1,'http://selfcare.sdc.bsnl.co.in','BSNL connection

First Car Model : santro

http://192.168.1.1/
admin/admin

Mobile : 8985966028

Wifi Pwd : 9676867938');
INSERT INTO "credential" VALUES(2002099,'IRCTC','2015-06-25','kareems78','f10',2,8,'http://www.irctc.co.in','Registered Email : Yahoo (karim.shaik@gmail.com)
Answer to secret Q : nehru niketan

Mobile : 9063223563

Your user id is kareems78     
Your Password is kbn608');
INSERT INTO "credential" VALUES(2002100,'Hyd Airtel Wifi','2015-07-05','RaiyanMd','meera_shakeela',2,1,'https://www.airtel.in/myaccount','Upgrade to 16 Mbps order details below

order no : 37591194
order id : 26863095

Online Account
https://www.airtel.in/myaccount

Username/Password : 9063775031/Raiyan@2014

Complaint No: 57419094
Order Id : 31227130
Order no# 42876190');
INSERT INTO "credential" VALUES(2002101,'Stanley Website','2015-08-26','Y! Mail','Arrazaq@10',2,8,'https://cgifederal.secure.force.com/SiteLogin?country=&language=','');
INSERT INTO "credential" VALUES(2002102,'Reliable Calling','2015-08-28','Y! Mail','f10',2,8,'https://www.reliablecalling.com/usa','');
INSERT INTO "credential" VALUES(2002103,'Summit Health','2015-10-09','kareems78','F10',2,2,'https://www.summithealth.com/AppointmentSystem/LoginAppointment.aspx?LHpqXHpTqLpS6H2fLLM1nEB3c5I7z+gMSHc9i3XUM32iTp4Gvy4lQMPr1ZPZM5B3A/g9Q/x++VWD0k67u7xGvAmNrU6g08Fih1B4snM+VeM=','');
INSERT INTO "credential" VALUES(2002104,'UPS','2015-10-09','kareems78','F@10',2,8,'https://www.ups.com/one-to-one/login?loc=en_US&returnto=http%3A%2F%2Fwww.ups.com%2Fcontent%2Fus%2Fen%2Findex.jsx%3Fcookie%26%23x3d%3Bus%26%2395%3Ben%26%2395%3Bhome%26amp%3BSite%26%23x3d%3BCorporate%26','Account ID : 111W18');
INSERT INTO "credential" VALUES(2002105,'AAA','2015-10-25','kareems78','f10',2,8,'https://autoclubsouth.aaa.com/','');
INSERT INTO "credential" VALUES(2002106,'Groupon','2015-10-28','Y! Mail','f10',2,1,'https://www.groupon.com/','');
INSERT INTO "credential" VALUES(2002107,'ATT Wireless Phone','2015-11-03','6789435398','PIN#1003',2,8,'','ATT Security PIN # 1003');
INSERT INTO "credential" VALUES(2002108,'Samsung Account','2015-11-07','Gmail','F10',2,8,'https://www.samsung.com','');
INSERT INTO "credential" VALUES(2002109,'Allstate','2015-12-02','kareems78','F10',2,6,'https://myaccount.allstate.com/anon/login/login.aspx','');
INSERT INTO "credential" VALUES(2002110,'Microsoft Account','2016-02-12','Gmail','F10',2,4,'https://login.live.com','');
INSERT INTO "credential" VALUES(2002111,'ATT RSA PIN','2016-03-10 11:50:18','ks589h','19781978',2,2,'http://notavailable.com','');
INSERT INTO "credential" VALUES(2002112,'Amdocs RSA PIN','2016-03-10 11:50:45','kareems','1003',2,2,'http://notavailable.com','');
INSERT INTO "credential" VALUES(2002113,'Linked In','2016-04-11 23:02:41','Y! Mail','f10',2,8,'https://www.linkedin.com','');
INSERT INTO "credential" VALUES(2002114,'','2016-04-27 15:49:40','','',2,'','','');
INSERT INTO "credential" VALUES(2002115,'','2016-04-27 15:50:10','','',2,'','','');
INSERT INTO "credential" VALUES(2002116,'','2016-04-27 15:55:06','','',2,'','','');
INSERT INTO "credential" VALUES(2002117,'','2016-04-27 15:55:37','','',2,'','','');
INSERT INTO "credential" VALUES(2002118,'Amazon','2016-04-29 17:33:13','Y! mail','f10',2,8,'https://www.amazon.com','');
INSERT INTO "credential" VALUES(2002119,'Shahana Microsoft Acct','2016-06-04 15:23:38','shahana.shameen@gmail.com','Almalik@10',2,1,'https://www.microsoft.com/en-us/','');
DROP TABLE IF EXISTS "creditcard";
CREATE TABLE "creditcard" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "creditcard" VALUES(1,'GAP',NULL);
INSERT INTO "creditcard" VALUES(2,'JCPenny',NULL);
INSERT INTO "creditcard" VALUES(3,'Kohls',NULL);
INSERT INTO "creditcard" VALUES(4,'Old Navy',NULL);
INSERT INTO "creditcard" VALUES(5,'Macys',NULL);
INSERT INTO "creditcard" VALUES(6,'TJX Rewards',NULL);
INSERT INTO "creditcard" VALUES(7,'BOA - 1741',NULL);
INSERT INTO "creditcard" VALUES(8,'BOA - 8844',NULL);
INSERT INTO "creditcard" VALUES(9,'Babies R Us CC','Babies R Us Credit Card');
INSERT INTO "creditcard" VALUES(10,'BOA - 9384','BOA - Better balance rewards card');
INSERT INTO "creditcard" VALUES(11,'American Express','American Express Credit Card');
INSERT INTO "creditcard" VALUES(12,'Target Credit Card','');
INSERT INTO "creditcard" VALUES(13,'BOA - 4680','1741 is replaced with 4680');
INSERT INTO "creditcard" VALUES(14,'Car Loan','');
INSERT INTO "creditcard" VALUES(15,'BOA - 8089','');
DROP TABLE IF EXISTS "creditpayment";
CREATE TABLE "creditpayment" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "referenceno" text NOT NULL,
  "creditcard" integer NOT NULL,
  "datepaid" text NOT NULL,
  "datededucted" text DEFAULT NULL,
  "user" integer NOT NULL,
  "amount" real NOT NULL,
  "notes" blob DEFAULT NULL,
  CONSTRAINT "FKCREDITPAYMENT_CC" FOREIGN KEY ("creditcard") REFERENCES "creditcard" ("id"),
  CONSTRAINT "FKCREDITPAYMENT_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "creditpayment" VALUES(2002001,'180396693',7,'2013-05-29',NULL,2,300,'');
INSERT INTO "creditpayment" VALUES(2002002,'180396692',8,'2013-05-29',NULL,2,100,'');
INSERT INTO "creditpayment" VALUES(2002003,'2783469176',10,'2013-05-29',NULL,2,13.94,'Purchase from walmart');
INSERT INTO "creditpayment" VALUES(2002004,'531675766',4,'2013-07-13',NULL,2,28.34,'Bought t-shirt & pant for myself');
INSERT INTO "creditpayment" VALUES(2002005,'2799444325',10,'2013-07-16',NULL,2,61.01,'');
INSERT INTO "creditpayment" VALUES(2002006,'4199460424',8,'2013-07-16',NULL,2,0.72,'');
INSERT INTO "creditpayment" VALUES(2002007,'540030197',4,'2013-07-30','2013-08-08',2,26.65,'');
INSERT INTO "creditpayment" VALUES(2002008,'3881185523',7,'2013-08-06',NULL,2,327.12,'');
INSERT INTO "creditpayment" VALUES(2002009,'2825694505',7,'2013-08-11','2013-09-03',2,12.51,'');
INSERT INTO "creditpayment" VALUES(2002010,'1525744897',8,'2013-08-11','2013-08-11',2,11.5,'');
INSERT INTO "creditpayment" VALUES(2002011,'225758750',7,'2013-08-11','2013-09-03',2,50.36,'');
INSERT INTO "creditpayment" VALUES(2002012,'547364900',4,'2013-08-16',NULL,2,50,'');
INSERT INTO "creditpayment" VALUES(2002013,'S1013',11,'2013-08-16',NULL,2,72.64,'');
INSERT INTO "creditpayment" VALUES(2002014,'2709091081',8,'2013-08-21',NULL,2,26.02,'');
INSERT INTO "creditpayment" VALUES(2002015,'3809099314',7,'2013-08-21',NULL,2,580.03998,'');
INSERT INTO "creditpayment" VALUES(2002016,'3809106815',10,'2013-08-21','2013-08-21',2,57.18,'');
INSERT INTO "creditpayment" VALUES(2002017,'W0856',11,'2013-08-22','2013-09-01',2,20.17,'');
INSERT INTO "creditpayment" VALUES(2002018,'554628141',4,'2013-09-04','2013-09-05',2,2.85,'');
INSERT INTO "creditpayment" VALUES(2002019,'339490878',7,'2013-09-05','2013-09-05',2,650,'');
INSERT INTO "creditpayment" VALUES(2002020,'1639512889',8,'2013-09-05','2013-09-05',2,10,'');
INSERT INTO "creditpayment" VALUES(2002021,'159132290',12,'2013-09-06','2013-09-06',2,55,'');
INSERT INTO "creditpayment" VALUES(2002022,'142890181',7,'2013-09-17','2013-09-17',2,300,'');
INSERT INTO "creditpayment" VALUES(2002023,'1522775514',7,'2013-09-26','2013-09-26',2,300,'');
INSERT INTO "creditpayment" VALUES(2002024,'1602062803',7,'2013-10-17','2013-10-17',2,500,'');
INSERT INTO "creditpayment" VALUES(2002025,'1602075248',10,'2013-10-17','2013-10-17',2,50,'');
INSERT INTO "creditpayment" VALUES(2002026,'2802084054',8,'2013-10-17','2013-10-17',2,31.28,'');
INSERT INTO "creditpayment" VALUES(2002027,'13102288457221',3,'2013-10-22','2013-10-22',2,46.39,'');
INSERT INTO "creditpayment" VALUES(2002028,'3770733805',7,'2013-10-25','2013-10-25',2,500,'');
INSERT INTO "creditpayment" VALUES(2002029,'577801941',4,'2013-10-31','2013-10-31',2,68.44,'Discount Code ;
VBZCZ7HFJJTR');
INSERT INTO "creditpayment" VALUES(2002030,'2674590830',7,'2013-11-06','2013-11-06',2,750,'');
INSERT INTO "creditpayment" VALUES(2002031,'2604747848',10,'2013-11-21','2013-11-21',2,40,'');
INSERT INTO "creditpayment" VALUES(2002032,'1604754944',8,'2013-11-21','2013-11-21',2,76,'');
INSERT INTO "creditpayment" VALUES(2002033,'1604759896',7,'2013-11-21','2013-11-21',2,400,'');
INSERT INTO "creditpayment" VALUES(2002034,'S7798',11,'2013-11-29','2013-11-29',2,90.44,'');
INSERT INTO "creditpayment" VALUES(2002035,'208964453',7,'2013-12-03','2013-12-03',2,400,'');
INSERT INTO "creditpayment" VALUES(2002036,'2673674326',7,'2013-12-10','2013-12-10',2,400,'');
INSERT INTO "creditpayment" VALUES(2002037,'W9526',11,'2013-12-13','2013-12-13',2,55.6,'Costco Membership');
INSERT INTO "creditpayment" VALUES(2002038,'600434741',9,'2013-12-19','2013-12-19',2,11.74,'');
INSERT INTO "creditpayment" VALUES(2002039,'577495886',10,'2013-12-23','2013-12-23',2,6.79,'');
INSERT INTO "creditpayment" VALUES(2002040,'577513668',8,'2013-12-23','2013-12-23',2,95.58,'');
INSERT INTO "creditpayment" VALUES(2002041,'3077525948',7,'2013-12-23','2013-12-23',2,550,'');
INSERT INTO "creditpayment" VALUES(2002042,'4179850821',7,'2014-01-15','2014-01-15',2,800,'');
INSERT INTO "creditpayment" VALUES(2002043,'4179864134',10,'2014-01-15','2014-01-15',2,28.51,'');
INSERT INTO "creditpayment" VALUES(2002044,'615456288',1,'2014-01-20','2014-01-20',2,46.5,'');
INSERT INTO "creditpayment" VALUES(2002045,'626879551',7,'2014-02-13','2014-02-13',2,150,'');
INSERT INTO "creditpayment" VALUES(2002046,'585958687',8,'2014-03-03','2014-03-03',2,47.48,'');
INSERT INTO "creditpayment" VALUES(2002047,'585981364',7,'2014-03-03','2014-03-03',2,500,'');
INSERT INTO "creditpayment" VALUES(2002048,'647139125',10,'2014-03-10','2014-03-10',2,75,'Hafsa''s North Fulton Bill');
INSERT INTO "creditpayment" VALUES(2002049,'647166140',13,'2014-03-10','2014-03-10',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002050,'4285239964',13,'2014-03-26','2014-03-26',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002051,'641319480',10,'2014-04-02','2014-04-02',2,88.9,'');
INSERT INTO "creditpayment" VALUES(2002052,'3741326901',8,'2014-04-02','2014-04-02',2,10,'');
INSERT INTO "creditpayment" VALUES(2002053,'3741341356',13,'2014-04-02','2014-04-02',2,500,'');
INSERT INTO "creditpayment" VALUES(2002054,'574551179',13,'2014-04-17','2014-04-17',2,700,'');
INSERT INTO "creditpayment" VALUES(2002055,'2808076964',13,'2014-05-14','2014-05-14',2,100,'');
INSERT INTO "creditpayment" VALUES(2002056,'3717090791',8,'2014-05-15','2014-05-15',2,32.09,'');
INSERT INTO "creditpayment" VALUES(2002057,'4217069289',10,'2014-05-15','2014-05-15',2,15.35,'');
INSERT INTO "creditpayment" VALUES(2002058,'1468280993',13,'2014-05-21','2014-05-21',2,500,'');
INSERT INTO "creditpayment" VALUES(2002059,'225074371',13,'2014-06-08','2014-06-08',2,800,'');
INSERT INTO "creditpayment" VALUES(2002060,'4125107862',10,'2014-06-08','2014-06-08',2,99.83,'');
INSERT INTO "creditpayment" VALUES(2002061,'2604520806',10,'2014-06-29','2014-06-29',2,135.50999,'');
INSERT INTO "creditpayment" VALUES(2002062,'404526548',13,'2014-06-29','2014-06-29',2,800,'');
INSERT INTO "creditpayment" VALUES(2002063,'4088418436',10,'2014-07-09','2014-07-09',2,10,'');
INSERT INTO "creditpayment" VALUES(2002064,'2626226731',13,'2014-07-13','2014-07-13',2,500,'');
INSERT INTO "creditpayment" VALUES(2002065,'2769149432',10,'2014-07-29','2014-07-29',2,37.98,'');
INSERT INTO "creditpayment" VALUES(2002066,'372969949',13,'2014-08-11','2014-08-11',2,700,'');
INSERT INTO "creditpayment" VALUES(2002067,'1729093212',10,'2014-08-29','2014-08-29',2,47.15,'');
INSERT INTO "creditpayment" VALUES(2002068,'529109173',13,'2014-08-29','2014-08-29',2,300,'');
INSERT INTO "creditpayment" VALUES(2002069,'MACYSC100',5,'2014-09-09','2014-09-09',2,200,'');
INSERT INTO "creditpayment" VALUES(2002070,'3827056955',13,'2014-09-09','2014-09-09',2,500,'');
INSERT INTO "creditpayment" VALUES(2002071,'3992434003',13,'2014-09-16','2014-09-16',2,700,'');
INSERT INTO "creditpayment" VALUES(2002072,'14100247383550',3,'2014-10-02','2014-10-02',2,47.9,'');
INSERT INTO "creditpayment" VALUES(2002073,'197481437',5,'2014-10-09','2014-10-09',2,144.99001,'');
INSERT INTO "creditpayment" VALUES(2002074,'1414293620',13,'2014-10-12','2014-10-12',2,500,'');
INSERT INTO "creditpayment" VALUES(2002075,'3090420689',10,'2014-10-21','2014-10-21',2,110.8,'');
INSERT INTO "creditpayment" VALUES(2002076,'4190436055',13,'2014-10-21','2014-10-21',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002077,'2938100555',8,'2014-11-07','2014-11-07',2,7.48,'');
INSERT INTO "creditpayment" VALUES(2002078,'338201230',13,'2014-11-07','2014-11-07',2,200,'');
INSERT INTO "creditpayment" VALUES(2002079,'219078575',10,'2014-11-16','2014-11-16',2,51.93,'');
INSERT INTO "creditpayment" VALUES(2002080,'3719116057',8,'2014-11-16','2014-11-16',2,66,'');
INSERT INTO "creditpayment" VALUES(2002081,'219127289',13,'2014-11-16','2014-11-16',2,800,'');
INSERT INTO "creditpayment" VALUES(2002082,'202677871',5,'2014-11-21','2014-12-02',2,34.2,'');
INSERT INTO "creditpayment" VALUES(2002083,'1645232534',13,'2014-12-01','2014-12-01',2,600.71002,'');
INSERT INTO "creditpayment" VALUES(2002084,'1645242228',10,'2014-12-01','2014-12-01',2,48.13,'');
INSERT INTO "creditpayment" VALUES(2002085,'2774501439',10,'2014-12-16','2014-12-16',2,16.05,'');
INSERT INTO "creditpayment" VALUES(2002086,'0274503593',8,'2014-12-16','2014-12-16',2,12.64,'');
INSERT INTO "creditpayment" VALUES(2002087,'0274505591',13,'2014-12-16','2014-12-16',2,300,'');
INSERT INTO "creditpayment" VALUES(2002088,'1664045024',13,'2015-01-07','2015-01-07',2,800,'');
INSERT INTO "creditpayment" VALUES(2002089,'2764063222',10,'2015-01-07','2015-01-07',2,123.29,'');
INSERT INTO "creditpayment" VALUES(2002090,'464071583',8,'2015-01-07','2015-01-07',2,28,'');
INSERT INTO "creditpayment" VALUES(2002091,'409940504',13,'2015-01-24','2015-01-24',2,700,'');
INSERT INTO "creditpayment" VALUES(2002092,'409940504',10,'2015-01-24','2015-01-24',2,37.96,'');
INSERT INTO "creditpayment" VALUES(2002093,'210296311',13,'2015-02-16','2015-02-16',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002094,'1610302717',10,'2015-02-16','2015-02-16',2,12.99,'');
INSERT INTO "creditpayment" VALUES(2002095,'235740578',13,'2015-03-02','2015-03-02',2,500,'');
INSERT INTO "creditpayment" VALUES(2002096,'0319168925',14,'2015-03-19','2015-03-19',2,400,'');
INSERT INTO "creditpayment" VALUES(2002097,'294708334',13,'2015-04-01','2015-04-02',2,500,'');
INSERT INTO "creditpayment" VALUES(2002098,'2594715339',10,'2015-04-01','2015-04-01',2,179.77,'');
INSERT INTO "creditpayment" VALUES(2002099,'298155683',10,'2015-04-13','2015-04-14',2,68,'');
INSERT INTO "creditpayment" VALUES(2002100,'1698164406',13,'2015-04-13','2015-04-14',2,300,'');
INSERT INTO "creditpayment" VALUES(2002101,'2958950386',13,'2015-04-21','2015-04-21',2,500,'');
INSERT INTO "creditpayment" VALUES(2002102,'2975074589',10,'2015-05-04','2015-05-04',2,37.93,'');
INSERT INTO "creditpayment" VALUES(2002103,'124193134',15,'2015-05-21','2015-05-21',2,200,'');
INSERT INTO "creditpayment" VALUES(2002104,'1534998036',10,'2015-06-03','2015-06-03',2,200,'');
INSERT INTO "creditpayment" VALUES(2002105,'2937695646',15,'2015-06-15','2015-06-15',2,700,'');
INSERT INTO "creditpayment" VALUES(2002106,'3960121064',10,'2015-06-29','2015-06-29',2,600,'');
INSERT INTO "creditpayment" VALUES(2002107,'177662033',15,'2015-07-13','2015-07-13',2,200,'');
INSERT INTO "creditpayment" VALUES(2002108,'2854202733',10,'2015-08-02','2015-08-02',2,600,'');
INSERT INTO "creditpayment" VALUES(2002109,'1649996834',15,'2015-08-13','2015-08-13',2,3000,'');
INSERT INTO "creditpayment" VALUES(2002110,'2821435855',15,'2015-08-21','2015-08-21',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002111,'1421444150',10,'2015-08-21','2015-08-21',2,500,'');
INSERT INTO "creditpayment" VALUES(2002112,'2881250492',15,'2015-09-09','2015-09-09',2,443,'');
INSERT INTO "creditpayment" VALUES(2002113,'4012529880',8,'2015-09-13','2015-09-13',2,123.04,'');
INSERT INTO "creditpayment" VALUES(2002114,'2512551922',10,'2015-09-13','2015-09-13',2,50,'');
INSERT INTO "creditpayment" VALUES(2002115,'312556835',15,'2015-09-13','2015-09-13',2,100,'');
INSERT INTO "creditpayment" VALUES(2002116,'1756821967',10,'2015-09-18','2015-09-18',2,75,'');
INSERT INTO "creditpayment" VALUES(2002117,'1448578387',15,'2015-10-21','2015-10-21',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002118,'1448588107',8,'2015-10-21','2015-10-21',2,31.28,'');
INSERT INTO "creditpayment" VALUES(2002119,'4048598335',10,'2015-10-21','2015-10-21',2,17.19,'');
INSERT INTO "creditpayment" VALUES(2002120,'694830153',15,'2015-11-19','2015-11-19',2,700,'');
INSERT INTO "creditpayment" VALUES(2002121,'694846797',10,'2015-11-19','2015-11-19',2,123,'');
INSERT INTO "creditpayment" VALUES(2002122,'2594858215',8,'2015-11-19','2015-11-19',2,66,'');
INSERT INTO "creditpayment" VALUES(2002123,'4090305975',8,'2015-11-30','2015-11-30',2,100,'');
INSERT INTO "creditpayment" VALUES(2002124,'4090311752',15,'2015-11-30','2015-11-30',2,2000,'');
INSERT INTO "creditpayment" VALUES(2002125,'111870856303080 ',5,'2015-12-02','2015-12-02',2,19.07,'');
INSERT INTO "creditpayment" VALUES(2002126,'653186753',15,'2015-12-19 00:00:00','2015-12-19 00:00:00',2,2000,'');
INSERT INTO "creditpayment" VALUES(2002127,'653213971',8,'2015-12-19 00:00:00','2015-12-19 00:00:00',2,100,'');
INSERT INTO "creditpayment" VALUES(2002128,'4053220834',10,'2015-12-19 00:00:00','2015-12-19 00:00:00',2,100,'');
INSERT INTO "creditpayment" VALUES(2002129,'2834610579',15,'2016-01-20 00:00:00','2016-01-20 00:00:00',2,800,'');
INSERT INTO "creditpayment" VALUES(2002130,'0428',8,'2016-01-16 00:00:00','2016-01-16 00:00:00',2,25,'');
INSERT INTO "creditpayment" VALUES(2002131,'1434644611',10,'2016-01-20 00:00:00','2016-01-20 00:00:00',2,150,'');
INSERT INTO "creditpayment" VALUES(2002132,'1480771141',15,'2016-02-18','2016-02-18',2,500,'');
INSERT INTO "creditpayment" VALUES(2002133,'2980796493',10,'2016-02-18','2016-02-18',2,50,'');
INSERT INTO "creditpayment" VALUES(2002134,'4180803063',10,'2016-02-18','2016-02-18',2,59.57,'');
INSERT INTO "creditpayment" VALUES(2002135,'121942692456812',5,'2016-02-22','2016-02-22',2,12.78,'');
INSERT INTO "creditpayment" VALUES(2002136,'16030754978492',3,'2016-03-07','2016-03-07',2,2.56,'');
INSERT INTO "creditpayment" VALUES(2002137,'0514366786',15,'2016-03-16','2016-03-16',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002138,'0514411619',8,'2016-03-16','2016-03-16',2,2.83,'');
INSERT INTO "creditpayment" VALUES(2002139,'4145018056',10,'2016-03-20','2016-03-20',2,75,'');
INSERT INTO "creditpayment" VALUES(2002140,'4145068849',15,'2016-03-20','2016-03-20',2,1000,'Transfered from 9574 - deposit it back in few days');
INSERT INTO "creditpayment" VALUES(2002141,'0575152675',15,'2016-03-23','2016-03-23',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002142,'0665477595',15,'2016-04-02','2016-04-02',2,700,'');
INSERT INTO "creditpayment" VALUES(2002143,'1408398693',10,'2016-04-19','2016-04-19',2,165.51,'');
INSERT INTO "creditpayment" VALUES(2002144,'3908403068',15,'2016-04-19','2016-04-19',2,700,'');
INSERT INTO "creditpayment" VALUES(2002145,'3981139044',15,'2016-05-09','2016-05-09',2,350,'');
INSERT INTO "creditpayment" VALUES(2002146,'0581150862',10,'2016-05-09','2016-05-09',2,56.75,'');
INSERT INTO "creditpayment" VALUES(2002147,'0515667180',15,'2016-05-13','2016-05-13',2,1000,'');
INSERT INTO "creditpayment" VALUES(2002148,'3915699668',8,'2016-05-13','2016-05-13',2,46.94,'');
INSERT INTO "creditpayment" VALUES(2002149,'0696138107',15,'2016-06-03','2016-06-03',2,400,'');
DROP TABLE IF EXISTS "csvtables";
CREATE TABLE "csvtables" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "csvtables" VALUES(1,'EXPENSE',NULL);
INSERT INTO "csvtables" VALUES(2,'ECATEGORY',NULL);
DROP TABLE IF EXISTS "dailyfikr";
CREATE TABLE "dailyfikr" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
   "user" integer NOT NULL,
  "createddate" text NOT NULL,
  "display" text NOT NULL,
   CONSTRAINT "FKDFIKR_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "dailyfikr" VALUES(2002001,'Pray atleast fazr and Isha Salah with Jamah in Masjid',2,'2016-03-06','yes');
INSERT INTO "dailyfikr" VALUES(2002002,'Recite Quran everyday',2,'2016-03-07','yes');
INSERT INTO "dailyfikr" VALUES(2002003,'Taleem at home',2,'2016-03-07','yes');
INSERT INTO "dailyfikr" VALUES(2002004,'Muzakira of 6 qualities',2,'2016-03-07','yes');
DROP TABLE IF EXISTS "datatables";
CREATE TABLE "datatables" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "datatables" VALUES(1,'BIOMETRICS',NULL);
INSERT INTO "datatables" VALUES(2,'CLEANING',NULL);
INSERT INTO "datatables" VALUES(3,'CONTENT',NULL);
INSERT INTO "datatables" VALUES(4,'CREDENTIAL',NULL);
INSERT INTO "datatables" VALUES(5,'CREDITPAYMENT',NULL);
INSERT INTO "datatables" VALUES(6,'DPLAN',NULL);
INSERT INTO "datatables" VALUES(7,'DTASKS',NULL);
INSERT INTO "datatables" VALUES(8,'EXPENSE',NULL);
INSERT INTO "datatables" VALUES(9,'FUNDSTRANSFER',NULL);
INSERT INTO "datatables" VALUES(10,'ONLINEORDERS',NULL);
INSERT INTO "datatables" VALUES(11,'PLOTDETAILS',NULL);
INSERT INTO "datatables" VALUES(12,'PROJECTIONS',NULL);
INSERT INTO "datatables" VALUES(13,'REMAINDER',NULL);
INSERT INTO "datatables" VALUES(14,'SALAHTRACKER',NULL);
INSERT INTO "datatables" VALUES(15,'TASK',NULL);
INSERT INTO "datatables" VALUES(16,'TOTALEXPENSES',NULL);
INSERT INTO "datatables" VALUES(17,'URLSTORE',NULL);
INSERT INTO "datatables" VALUES(18,'WEIGHTRECORDER',NULL);
DROP TABLE IF EXISTS "datracker";
CREATE TABLE "datracker" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "datdate" text NOT NULL UNIQUE,
  "createddate" text NOT NULL,
  "updateddate" text DEFAULT NULL,
  "user" integer NOT NULL,
  "morningdhikr" text DEFAULT NULL,
  "ishraq" text DEFAULT NULL,
  "eveningdhikr" text DEFAULT NULL,
  "taleem" text DEFAULT NULL,
  "muzakira" text DEFAULT NULL,
  "recitequran" text DEFAULT NULL,
  "notes" blob,
  CONSTRAINT "FKSTRACKER_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "datracker" VALUES(2002001,'2016-03-01','2016-03-07','2016-03-07',2,'No','Yes','No','No','No','No','');
DROP TABLE IF EXISTS "dbconndetails";
CREATE TABLE "dbconndetails" (
"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE , 
"envname" TEXT NOT NULL , 
"user" INTEGER NOT NULL , 
"username" INTEGER NOT NULL , 
"password" INTEGER NOT NULL , 
"dbhost" INTEGER NOT NULL, 
"dbport" INTEGER NOT NULL, 
"sid" INTEGER NOT NULL,
CONSTRAINT "FKDBCONNDETAILS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "dbconndetails" VALUES(2002001,'ST9_AMD',2,'Cramer','att4t2015','139.76.213.209',11200,'lci9t1');
INSERT INTO "dbconndetails" VALUES(2002002,'ST9_ATT',2,'Cramer','att4t2015','nmsis9d1.snt.bst.bls.com',1521,'lci9t1');
INSERT INTO "dbconndetails" VALUES(2002003,'IT7_AMD',2,'Cramer','att4i2015','139.76.213.210',10181,'lci7i1');
INSERT INTO "dbconndetails" VALUES(2002004,'IT7_ATT',2,'Cramer','att4i2015','nmsii7d1.snt.bst.bls.com',1521,'lci7i1');
INSERT INTO "dbconndetails" VALUES(2002005,'IT9_AMD',2,'Cramer','att4i2015','139.76.213.210',11166,'lci9i1.snt.bst.bls.com');
INSERT INTO "dbconndetails" VALUES(2002006,'CRM_AM_GG(Prod)',2,'Cramer','att4g2015','139.76.213.209',12054,'ipag2pdb.db.att.com');
INSERT INTO "dbconndetails" VALUES(2002007,'GCP_AM_GG(Prod)',2,'GCP_USER','m1rr0rdb','139.76.213.209',12054,'ipag2pdb.db.att.com');
INSERT INTO "dbconndetails" VALUES(2002008,'GCP_AT_GG(Prod)',2,'GCP_USER','m1rr0rdb','mlpd367db.sfdc.sbc.com',1524,'ipag2pdb.db.att.com');
DROP TABLE IF EXISTS "dbenvdetails";
CREATE TABLE "dbenvdetails" (
"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE , 
"envname" TEXT NOT NULL , 
"dbenvdetails" BLOB NOT NULL , 
"user" INTEGER NOT NULL , 
"description" BLOB, 
CONSTRAINT "FKDBENVDETAILS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "dbenvdetails" VALUES(2002001,'LS Prod GG','IPAG2PDB_DG2.DB.ATT.COM =  (DESCRIPTION =    (ADDRESS = (PROTOCOL = TCP)(HOST = mlpd367db.sfdc.sbc.com)(PORT = 1524))    (ADDRESS = (PROTOCOL = TCP)(HOST = mlpd368db.sfdc.sbc.com)(PORT = 1524))    (ADDRESS = (PROTOCOL = TCP)(HOST = mlpd369db.sfdc.sbc.com)(PORT = 1524))    (ADDRESS = (PROTOCOL = TCP)(HOST = mlpd370db.sfdc.sbc.com)(PORT = 1524))    (LOAD_BALANCE = yes)    (CONNECT_DATA =      (SERVER = DEDICATED)      (SERVICE_NAME = ipag2pdb.db.att.com)))',2,' ');
INSERT INTO "dbenvdetails" VALUES(2002002,'SIT3','t1bbn1d2.db.att.com = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP) (HOST = t1bbn1d2.vci.att.com) (PORT = 1524)) (CONNECT_DATA = (service_name = t1bbn1d2.db.att.com)) )',2,' DB Host : t1bbn1d2.vci.att.com(135.213.47.217)

App Host : t1c1m218.vci.att.com');
INSERT INTO "dbenvdetails" VALUES(2002003,'SIT3GG','t1can1d3.db.att.com = (DESCRIPTION =  (ADDRESS = (PROTOCOL = TCP) (HOST = t1can1d3.vci.att.com) (PORT = 1524)) (CONNECT_DATA = (SERVICE_NAME = t1can1d3.db.att.com)) )',2,' ');
INSERT INTO "dbenvdetails" VALUES(2002004,'LS Prod',' P1BBN1D9.db.att.com =  (DESCRIPTION =    (ADDRESS = (PROTOCOL = TCP)(HOST = p1bbn1c3.ffdc.sbc.com)(PORT = 1521))    (CONNECT_DATA =      (SERVER = DEDICATED)      (SERVICE_NAME = p1bbn1d9.db.att.com)    )  )',2,' ');
INSERT INTO "dbenvdetails" VALUES(2002005,'SIT6','t1can1d1.db.att.com = (DESCRIPTION =  (ADDRESS = (PROTOCOL = TCP) (HOST = t1can1d1.vci.att.com) (PORT = 1524)) (CONNECT_DATA = (SERVICE_NAME = t1can1d1.db.att.com)) )',2,' ');
INSERT INTO "dbenvdetails" VALUES(2002006,'ST8GG','ipagt8g1.snt.bst.bls.com=
  (DESCRIPTION =
    (ADDRESS = 
    (PROTOCOL = TCP)
    (HOST =
ipagt8g1db.snt.bst.bls.com)
    (PORT = 1521))
  (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ipagt8g.snt.bst.bls.com))
  )',2,'NAT IP : 139.76.215.102

NAT Port : 1521

SID : ipagt8g_1
');
INSERT INTO "dbenvdetails" VALUES(2002007,'SIT7GG','t1c3d829.db.att.com =
  (DESCRIPTION =
      (ADDRESS = (PROTOCOL=TCP)(HOST= zlt06459.vci.att.com)(Port=1524))
      (CONNECT_DATA = (SERVICE_NAME = t1c3d829.db.att.com)))',2,' ');
INSERT INTO "dbenvdetails" VALUES(2002008,'ST9GG','ipagt9g1.snt.bst.bls.com = (DESCRIPTION =
 (ADDRESS_LIST = 
   (ADDRESS = (PROTOCOL = TCP) 
   (HOST = ipagt9g1.snt.bst.bls.com)
   (PORT = 1521)) ) (CONNECT_DATA = 
   (SID = ipagt9g1) ) )
',2,' ');
DROP TABLE IF EXISTS "dplan";
CREATE TABLE "dplan" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "day" text NOT NULL,
  "breakfast" blob NOT NULL,
  "lunch" blob NOT NULL,
  "snacks" blob NOT NULL,
  "dinner" blob NOT NULL,
  "workouts" blob NOT NULL,
  "user" integer NOT NULL,
  CONSTRAINT "FKDPLAN_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "dplan" VALUES(2002001,'Monday','Oats & tea','Salad + Buttermilk','Fruits, Coffee/Green Tea','1 Roti','Treadmill : 22 mins
Push Ups : 1-10 mins',2);
INSERT INTO "dplan" VALUES(2002002,'Tuesday','Scrambled Egg + Tea','Rice (Dal) + Chicken','Fruits, Green Tea','1 Roti','Treadmill : 10 mins
RIng : 10 mins',2);
INSERT INTO "dplan" VALUES(2002003,'Wednesday','Oats & Coffee','Salad, Baked Fish','Fruits, Green Tea','1 Roti','None',2);
INSERT INTO "dplan" VALUES(2002004,'Thursday','Oats, Fruit Juice/Tea','2 Rotis','Fruits, Green Tea','No','Treadmill : 25 mins
Ring : 5 mins
Push Ups : 5 mins',2);
INSERT INTO "dplan" VALUES(2002005,'Friday','Scrambled Egg, Coffee','Roti & Chicken','Fruits, Green Tea','Salad','Treadmill: 15 mins
Ring : 5 min
Push ups: 15 mins',2);
INSERT INTO "dplan" VALUES(2002006,'Saturday','Indian Breakfast','No Choice','Fruits, Green Tea','Roti','None',2);
INSERT INTO "dplan" VALUES(2002007,'Sunday','Oats, Green Tea','No Choice','Fruits, Green Tea','Baked Fish, 1/2 Roti','Treadmill : 10 mins
Ring : 10 mins',2);
DROP TABLE IF EXISTS "dtasks";
CREATE TABLE "dtasks" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "tasktimetext" text NOT NULL,
  "tasktime" text DEFAULT NULL,
  "createddate" text NOT NULL,
  "updateddate" text DEFAULT NULL,
  "task" blob NOT NULL,
  "user" integer NOT NULL,
  "notes" blob,
  CONSTRAINT "FKDTASKS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "dtasks" VALUES(2002001,'5:30 AM','5:30','2013-09-11','2015-12-21 14:14:15','Wake Up',2,'');
INSERT INTO "dtasks" VALUES(2002002,'5:45 AM','5:45','2013-09-11','2015-12-21 14:14:15','Read Surah Yaseen',2,'');
INSERT INTO "dtasks" VALUES(2002003,'6:15 AM','6:15','2013-09-11','2015-12-21 14:14:15','Prayer',2,'');
INSERT INTO "dtasks" VALUES(2002004,'6:30 AM','6:30','2013-09-11','2015-12-21 14:14:15','Wake Up Hafsa',2,'');
INSERT INTO "dtasks" VALUES(2002005,'6:50 AM','6:50','2013-09-11','2015-12-21 14:14:15','Start feeding Hafsa',2,'');
INSERT INTO "dtasks" VALUES(2002006,'7:20 AM','7:20','2013-09-11','2015-12-21 14:14:15','Leave for School',2,'');
INSERT INTO "dtasks" VALUES(2002007,'8:30 AM','8:30','2013-09-11','2015-12-21 14:14:15','Pray Ishraaq and Recite Quran',2,'');
INSERT INTO "dtasks" VALUES(2002009,'9:20 AM','9:20','2013-09-11','2015-12-21 14:14:15','Take bath',2,'');
INSERT INTO "dtasks" VALUES(2002010,'9:30 AM','9:30','2013-09-11','2015-12-21 14:14:15','Breakfast',2,'');
INSERT INTO "dtasks" VALUES(2002011,'12:00 PM','12:00','2013-09-11','2015-12-21 14:14:15','Lunch',2,'');
INSERT INTO "dtasks" VALUES(2002012,'12:15 PM','12:15','2013-09-11','2015-12-21 14:14:15','Leave to pick Hafsa',2,'');
INSERT INTO "dtasks" VALUES(2002013,'12:45 PM','12:45','2013-09-11','2015-12-21 14:14:15','Leave for office',2,'');
INSERT INTO "dtasks" VALUES(2002014,'9:00 PM','21:00','2013-09-11','2015-12-21 14:14:15','Dinner',2,'try to finish before Isha');
DROP TABLE IF EXISTS "ecategory";
CREATE TABLE "ecategory" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "emaincategory" integer NOT NULL,
  "description" text DEFAULT NULL,
    CONSTRAINT "FKECATEGORY_EMCAT" FOREIGN KEY ("emaincategory") REFERENCES "emaincategory" ("id")
);
INSERT INTO "ecategory" VALUES(1,'Bath/Misc',1,'');
INSERT INTO "ecategory" VALUES(2,'Bath/Necessities',1,'');
INSERT INTO "ecategory" VALUES(3,'Bills/Electricity',2,'');
INSERT INTO "ecategory" VALUES(4,'Bills/Rent',2,'');
INSERT INTO "ecategory" VALUES(5,'Bills/Utilities',2,'');
INSERT INTO "ecategory" VALUES(6,'Bills/Vonage',2,'');
INSERT INTO "ecategory" VALUES(7,'Bills/Wireless',2,'');
INSERT INTO "ecategory" VALUES(8,'Car/Gas',3,'');
INSERT INTO "ecategory" VALUES(9,'Car/Misc',3,'');
INSERT INTO "ecategory" VALUES(10,'Car/Oil Change',3,'');
INSERT INTO "ecategory" VALUES(11,'Car/Repairs',3,'');
INSERT INTO "ecategory" VALUES(12,'Clothes/Aalia',4,'');
INSERT INTO "ecategory" VALUES(13,'Clothes/Hafsa',4,'');
INSERT INTO "ecategory" VALUES(14,'Clothes/Kareem',4,'');
INSERT INTO "ecategory" VALUES(15,'Clothes/Shahana',4,'');
INSERT INTO "ecategory" VALUES(16,'Food/Fruits',5,'');
INSERT INTO "ecategory" VALUES(17,'Food/Grocery',5,'');
INSERT INTO "ecategory" VALUES(18,'Food/Meat',5,'');
INSERT INTO "ecategory" VALUES(19,'Food/Misc',5,'');
INSERT INTO "ecategory" VALUES(20,'Food/Restaurants',5,'');
INSERT INTO "ecategory" VALUES(21,'Food/Snacks',5,'');
INSERT INTO "ecategory" VALUES(22,'Home/Decor',7,'');
INSERT INTO "ecategory" VALUES(23,'Home/Electronics',7,'');
INSERT INTO "ecategory" VALUES(24,'Home/Misc',7,'');
INSERT INTO "ecategory" VALUES(25,'Home/Necessities',7,'');
INSERT INTO "ecategory" VALUES(26,'KitchenWare',8,'');
INSERT INTO "ecategory" VALUES(27,'Medical/Aalia',9,'');
INSERT INTO "ecategory" VALUES(28,'Medical/Hafsa',9,'');
INSERT INTO "ecategory" VALUES(29,'Medical/Kareem',9,'');
INSERT INTO "ecategory" VALUES(30,'Medical/Shahana',9,'');
INSERT INTO "ecategory" VALUES(31,'Misc',11,'');
INSERT INTO "ecategory" VALUES(32,'Personal Care',12,'');
INSERT INTO "ecategory" VALUES(33,'School/Misc',13,'');
INSERT INTO "ecategory" VALUES(34,'School/Tution',13,'');
INSERT INTO "ecategory" VALUES(35,'Transport',14,'');
INSERT INTO "ecategory" VALUES(36,'Food/Sea Food',5,'Fish, Shrimp');
INSERT INTO "ecategory" VALUES(37,'Baby Expenses',11,'Food, Diapers etc');
INSERT INTO "ecategory" VALUES(38,'Gift',6,'');
INSERT INTO "ecategory" VALUES(39,'Medicines',10,'');
INSERT INTO "ecategory" VALUES(40,'Car/Service',3,'');
INSERT INTO "ecategory" VALUES(41,'Food/Milk',5,'');
INSERT INTO "ecategory" VALUES(42,'Trip Expenses',15,'');
INSERT INTO "ecategory" VALUES(43,'Clothes/Misc',4,'');
INSERT INTO "ecategory" VALUES(44,'Medical/General',9,'');
INSERT INTO "ecategory" VALUES(45,'Medical/Misc',9,'');
INSERT INTO "ecategory" VALUES(46,'Home/Laundry',7,'');
DROP TABLE IF EXISTS "emaincategory";
CREATE TABLE "emaincategory" ("id" INTEGER PRIMARY KEY  NOT NULL  UNIQUE , "name" TEXT, "description" BLOB);
INSERT INTO "emaincategory" VALUES(1,'Bath','Bath related');
INSERT INTO "emaincategory" VALUES(2,'Bills','Electricity, Rent, Wireless, Vonage');
INSERT INTO "emaincategory" VALUES(3,'Car','Gas, Oil Change, Repairs, Service, Misc');
INSERT INTO "emaincategory" VALUES(4,'Clothes','Kareem, Shahana, Hafsa, Aalia, Misc');
INSERT INTO "emaincategory" VALUES(5,'Food','Fish, Meat, Grocery, Fruits, Misc, Snacks, Milk, Restaurant');
INSERT INTO "emaincategory" VALUES(6,'Gift','Gift');
INSERT INTO "emaincategory" VALUES(7,'Home','Decor, Electronics, Laundry,Misc, Necessities');
INSERT INTO "emaincategory" VALUES(8,'Kitchenware','Kitchenware');
INSERT INTO "emaincategory" VALUES(9,'Medical','Kareem, Shahana, Hafsa, Aalia, Misc');
INSERT INTO "emaincategory" VALUES(10,'Medicines','Medicines');
INSERT INTO "emaincategory" VALUES(11,'Misc','Misc');
INSERT INTO "emaincategory" VALUES(12,'PersonalCare','Personal Care');
INSERT INTO "emaincategory" VALUES(13,'School','Tution, Misc');
INSERT INTO "emaincategory" VALUES(14,'Transport','Transport');
INSERT INTO "emaincategory" VALUES(15,'Trip Expenses','Trip Expenses');
DROP TABLE IF EXISTS "expense";
CREATE TABLE "expense" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "expensedate" text NOT NULL,
  "category" integer NOT NULL,
  "user" integer NOT NULL,
  "amount" real NOT NULL,
  "notes" blob DEFAULT NULL,
  CONSTRAINT "FKEXPENSE_ECAT" FOREIGN KEY ("category") REFERENCES "ecategory" ("id"),
  CONSTRAINT "FKEXPENSE_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "expense" VALUES(2002001,'2014-03-01',31,2,16,'Hair Cut');
INSERT INTO "expense" VALUES(2002002,'2014-03-01',17,2,3.07,'Vanilla Essence, Garlic');
INSERT INTO "expense" VALUES(2002003,'2014-03-01',17,2,5.57,'Nutella, Cinnamon Powder, Butter');
INSERT INTO "expense" VALUES(2002004,'2014-03-02',18,2,34.38,'');
INSERT INTO "expense" VALUES(2002005,'2014-03-02',19,2,7.52,'Bread, Milk');
INSERT INTO "expense" VALUES(2002006,'2014-03-02',8,2,63.19,'');
INSERT INTO "expense" VALUES(2002007,'2014-03-02',17,2,50.52,'Patel Brothers');
INSERT INTO "expense" VALUES(2002008,'2014-03-02',17,2,35.41,'Dekalbs Farmers Market');
INSERT INTO "expense" VALUES(2002009,'2014-03-02',36,2,37,'Dekalbs');
INSERT INTO "expense" VALUES(2002010,'2014-03-03',30,2,2.73,'');
INSERT INTO "expense" VALUES(2002011,'2014-03-03',19,2,6.17,'Milk');
INSERT INTO "expense" VALUES(2002012,'2014-03-03',31,2,5.48,'Coffee in Dunkin Donuts with friends');
INSERT INTO "expense" VALUES(2002013,'2014-03-05',31,2,105,'Aalia Passport');
INSERT INTO "expense" VALUES(2002014,'2014-03-06',31,2,2,'Shab-e-Jummah');
INSERT INTO "expense" VALUES(2002015,'2014-03-07',19,2,7.2,'Milk');
INSERT INTO "expense" VALUES(2002016,'2014-03-07',17,2,16.5,'Basmati Rice');
INSERT INTO "expense" VALUES(2002017,'2014-03-07',19,2,1.09,'Samosa');
INSERT INTO "expense" VALUES(2002018,'2014-03-07',32,2,4.27,'');
INSERT INTO "expense" VALUES(2002019,'2014-03-07',19,2,2,'Soda');
INSERT INTO "expense" VALUES(2002020,'2014-03-07',25,2,23.32,'Dixie Plates, bowls, cups, tide');
INSERT INTO "expense" VALUES(2002021,'2014-03-07',37,2,4.84,'Cereal for Aalia');
INSERT INTO "expense" VALUES(2002022,'2014-03-07',31,2,12.79,'Decorating items from Party City');
INSERT INTO "expense" VALUES(2002023,'2014-03-08',17,2,4.11,'');
INSERT INTO "expense" VALUES(2002024,'2014-03-08',25,2,11.55,'To Go boxes from Costco');
INSERT INTO "expense" VALUES(2002025,'2014-03-13',15,2,38.5,'');
INSERT INTO "expense" VALUES(2002026,'2014-03-13',19,2,6.17,'Milk');
INSERT INTO "expense" VALUES(2002027,'2014-03-14',29,2,7.73,'Vitamin-D, Prep Medicine');
INSERT INTO "expense" VALUES(2002028,'2014-03-13',17,2,1,'Cabbage');
INSERT INTO "expense" VALUES(2002029,'2014-03-15',16,2,7.3027,'banana, avocado, strawberries');
INSERT INTO "expense" VALUES(2002030,'2014-03-15',21,2,4.0994,'funny onion rings');
INSERT INTO "expense" VALUES(2002031,'2014-03-15',19,2,1.7922,'eggs');
INSERT INTO "expense" VALUES(2002032,'2014-03-15',20,2,25.1,'Royal Bamboo');
INSERT INTO "expense" VALUES(2002033,'2014-03-15',19,2,7.66,'yoghurt, milk chocolate, choco chips');
INSERT INTO "expense" VALUES(2002034,'2014-03-15',21,2,9.15,'Nutro wafers, cookies, mango juice');
INSERT INTO "expense" VALUES(2002035,'2014-03-16',19,2,8.3,'Milk & Garlic bread');
INSERT INTO "expense" VALUES(2002036,'2014-03-16',19,2,3.08,'Gatorade');
INSERT INTO "expense" VALUES(2002037,'2014-03-06',27,2,20,'');
INSERT INTO "expense" VALUES(2002038,'2014-03-18',19,2,6.17,'');
INSERT INTO "expense" VALUES(2002039,'2014-03-18',25,2,17.4303,'');
INSERT INTO "expense" VALUES(2002040,'2014-03-18',37,2,36.3693,'');
INSERT INTO "expense" VALUES(2002041,'2014-03-19',19,2,6.03,'Yoghurt, Cilantro, MInt leaves');
INSERT INTO "expense" VALUES(2002042,'2014-03-19',31,2,5.35,'Car Charger');
INSERT INTO "expense" VALUES(2002043,'2014-03-19',19,2,7.81,'Milk');
INSERT INTO "expense" VALUES(2002044,'2014-03-21',16,2,5.9431,'');
INSERT INTO "expense" VALUES(2002045,'2014-03-21',19,2,15.4912,'Shrimp, Carrot');
INSERT INTO "expense" VALUES(2002046,'2014-03-25',31,2,7.99,'cdms');
INSERT INTO "expense" VALUES(2002047,'2014-03-26',19,2,6.17,'Milk');
INSERT INTO "expense" VALUES(2002048,'2014-03-21',8,2,66.56,'');
INSERT INTO "expense" VALUES(2002049,'2014-03-26',2,2,5.33,'Shampoo');
INSERT INTO "expense" VALUES(2002050,'2014-03-27',31,2,8.22,'Coconut Water');
INSERT INTO "expense" VALUES(2002051,'2014-03-29',19,2,5.99,'');
INSERT INTO "expense" VALUES(2002052,'2014-03-29',16,2,2.87,'');
INSERT INTO "expense" VALUES(2002053,'2014-03-29',17,2,55.07,'');
INSERT INTO "expense" VALUES(2002054,'2014-03-30',18,2,73.66,'');
INSERT INTO "expense" VALUES(2002055,'2014-03-30',17,2,1.59,'Rice flour');
INSERT INTO "expense" VALUES(2002056,'2014-03-30',31,2,1.99,'Mehendi cone');
INSERT INTO "expense" VALUES(2002057,'2014-03-31',16,2,5.6547,'water melon');
INSERT INTO "expense" VALUES(2002058,'2014-03-31',37,2,21.1753,'Wipes');
INSERT INTO "expense" VALUES(2002059,'2014-03-31',21,2,5.1397,'');
INSERT INTO "expense" VALUES(2002060,'2014-03-31',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002061,'2014-03-31',17,2,23.45,'Sona Masoori Rice, Bay Leaves, Nesacafe');
INSERT INTO "expense" VALUES(2002062,'2014-04-01',29,2,20,'');
INSERT INTO "expense" VALUES(2002063,'2014-04-02',37,2,2.36,'Whole wheat cereal');
INSERT INTO "expense" VALUES(2002064,'2014-04-03',8,2,68.67,'');
INSERT INTO "expense" VALUES(2002065,'2014-04-03',29,2,80,'');
INSERT INTO "expense" VALUES(2002066,'2014-04-03',16,2,3.84,'');
INSERT INTO "expense" VALUES(2002067,'2014-04-03',19,2,4.74,'');
INSERT INTO "expense" VALUES(2002068,'2014-04-03',31,2,18.9,'Citrucel, Miralax');
INSERT INTO "expense" VALUES(2002069,'2014-04-04',20,2,25.54,'');
INSERT INTO "expense" VALUES(2002070,'2014-04-04',19,2,6.06,'');
INSERT INTO "expense" VALUES(2002071,'2014-04-05',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002072,'2014-04-05',2,2,4.14,'Soaps');
INSERT INTO "expense" VALUES(2002073,'2014-04-05',19,2,8.23,'Kaju Katli sweet');
INSERT INTO "expense" VALUES(2002074,'2014-04-05',31,2,17.47,'');
INSERT INTO "expense" VALUES(2002075,'2014-04-05',24,2,14.88,'Plants');
INSERT INTO "expense" VALUES(2002076,'2014-04-07',2,2,3.09,'tooth paste');
INSERT INTO "expense" VALUES(2002077,'2014-04-07',19,2,3.42,'Bread');
INSERT INTO "expense" VALUES(2002078,'2014-04-07',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002079,'2014-04-07',29,2,2.9,'Vitamin D');
INSERT INTO "expense" VALUES(2002080,'2014-04-07',30,2,2.9,'Vitamin D');
INSERT INTO "expense" VALUES(2002081,'2014-04-08',16,2,0.8549,'');
INSERT INTO "expense" VALUES(2002082,'2014-04-08',37,2,4.841,'Cereal');
INSERT INTO "expense" VALUES(2002083,'2014-04-05',10,2,120.89,'Oil change and Wheel alignment');
INSERT INTO "expense" VALUES(2002084,'2014-04-11',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002085,'2014-04-12',25,2,70.58,'IKEA');
INSERT INTO "expense" VALUES(2002086,'2014-04-13',31,2,5.47,'Always');
INSERT INTO "expense" VALUES(2002087,'2014-04-13',19,2,12,'Almonds & Parachute Oil');
INSERT INTO "expense" VALUES(2002088,'2014-04-14',29,2,5,'Cytra Solution');
INSERT INTO "expense" VALUES(2002089,'2014-04-16',24,2,18.49,'Milk, Eggs, Carrots, Grean Peas');
INSERT INTO "expense" VALUES(2002090,'2014-04-16',19,2,11.79,'Fruits, Bread, Sugar');
INSERT INTO "expense" VALUES(2002091,'2014-04-18',31,2,5.48,'');
INSERT INTO "expense" VALUES(2002092,'2014-04-20',19,2,5.98,'');
INSERT INTO "expense" VALUES(2002093,'2014-04-22',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002094,'2014-04-22',20,2,21.4,'Jerusalem Bakery');
INSERT INTO "expense" VALUES(2002095,'2014-04-13',25,2,4.45,'Home Depot (Screws)');
INSERT INTO "expense" VALUES(2002096,'2014-04-13',21,2,3.8,'Publix');
INSERT INTO "expense" VALUES(2002097,'2014-04-11',17,2,20.13,'Curry Leaves, Garlic, Mint, Tomatoes, Cilantro, Potatoes');
INSERT INTO "expense" VALUES(2002098,'2014-04-13',16,2,2.4931,'');
INSERT INTO "expense" VALUES(2002099,'2014-04-13',25,2,0.9991,'cup hook');
INSERT INTO "expense" VALUES(2002100,'2014-04-13',31,2,1.88,'Plant plastic holder');
INSERT INTO "expense" VALUES(2002101,'2014-04-11',19,2,8.24,'');
INSERT INTO "expense" VALUES(2002102,'2014-04-22',19,2,5.9328,'Hereshey, lindt');
INSERT INTO "expense" VALUES(2002103,'2014-04-22',32,2,2.1186,'Nail Polish from walgreens');
INSERT INTO "expense" VALUES(2002104,'2014-04-22',2,2,3.21,'Soap');
INSERT INTO "expense" VALUES(2002105,'2014-04-23',17,2,15.84,'Cilantro, Basmati Rice');
INSERT INTO "expense" VALUES(2002106,'2014-04-23',19,2,9.16,'Choclate, Eggs, Butter Sticks');
INSERT INTO "expense" VALUES(2002107,'2014-04-23',17,2,42.82,'Mazola, Onions, Sona Masoori');
INSERT INTO "expense" VALUES(2002108,'2014-04-24',8,2,73.36,'');
INSERT INTO "expense" VALUES(2002109,'2014-04-25',16,2,5.0161,'');
INSERT INTO "expense" VALUES(2002110,'2014-04-25',37,2,2.0188,'');
INSERT INTO "expense" VALUES(2002111,'2014-04-25',17,2,2.3587,'Walmart:
- Tomato
- Salad');
INSERT INTO "expense" VALUES(2002112,'2014-04-25',36,2,8.2194,'');
INSERT INTO "expense" VALUES(2002113,'2014-04-25',21,2,9.9189,'Walmart:
- Ice Cream cones
- Lays
- Cookies
');
INSERT INTO "expense" VALUES(2002114,'2014-04-26',17,2,78.17,'');
INSERT INTO "expense" VALUES(2002115,'2014-04-26',16,2,4.15,'');
INSERT INTO "expense" VALUES(2002116,'2014-04-26',19,2,6.29,'Milk');
INSERT INTO "expense" VALUES(2002117,'2014-04-29',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002118,'2014-04-30',37,2,3.08,'Cereal');
INSERT INTO "expense" VALUES(2002119,'2014-04-25',38,2,26.51,'Clothes');
INSERT INTO "expense" VALUES(2002120,'2014-04-30',16,2,4.8616,'');
INSERT INTO "expense" VALUES(2002121,'2014-04-30',19,2,3.0694,'');
INSERT INTO "expense" VALUES(2002122,'2014-05-01',25,2,3.57,'');
INSERT INTO "expense" VALUES(2002123,'2014-05-03',14,2,5.32,'JCPenny');
INSERT INTO "expense" VALUES(2002124,'2014-05-04',20,2,14.98,'Amma Kitchen');
INSERT INTO "expense" VALUES(2002125,'2014-05-04',16,2,0.4944,'banana');
INSERT INTO "expense" VALUES(2002126,'2014-05-04',25,2,43.2066,'Coconut Water, Brush, Miralax, Tide, Yoghurt

(Total - 43.26 -- Need to adjust - check Banana on same day -- 3%, 7%)');
INSERT INTO "expense" VALUES(2002127,'2014-05-05',29,2,5,'Parking');
INSERT INTO "expense" VALUES(2002128,'2014-05-05',19,2,3.7,'bread');
INSERT INTO "expense" VALUES(2002129,'2014-05-05',16,2,4.7,'apples');
INSERT INTO "expense" VALUES(2002130,'2014-05-06',19,2,16.2637,'coconut water');
INSERT INTO "expense" VALUES(2002131,'2014-05-06',17,2,7.1997,'onions');
INSERT INTO "expense" VALUES(2002132,'2014-05-06',16,2,5.6547,'watermelon');
INSERT INTO "expense" VALUES(2002133,'2014-05-06',17,2,13.6,'india plaza');
INSERT INTO "expense" VALUES(2002134,'2014-05-07',29,2,44.75,'');
INSERT INTO "expense" VALUES(2002135,'2014-05-08',16,2,0.66,'Banana');
INSERT INTO "expense" VALUES(2002136,'2014-05-08',26,2,2.2,'Plates to eat');
INSERT INTO "expense" VALUES(2002137,'2014-05-08',37,2,2.8222,'Cereal');
INSERT INTO "expense" VALUES(2002138,'2014-05-08',17,2,1.1124,'brocoli');
INSERT INTO "expense" VALUES(2002139,'2014-05-10',31,2,10.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002140,'2014-05-10',17,2,2.48,'');
INSERT INTO "expense" VALUES(2002141,'2014-04-26',39,2,11.44,'Advil');
INSERT INTO "expense" VALUES(2002142,'2014-05-11',19,2,6.09,'Milk');
INSERT INTO "expense" VALUES(2002143,'2014-05-11',17,2,0.76,'Cucumber');
INSERT INTO "expense" VALUES(2002144,'2014-05-12',19,2,2.35,'Bread');
INSERT INTO "expense" VALUES(2002145,'2014-05-12',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002146,'2014-05-12',17,2,16.13,'Batura, Rotis, Imli, Lemons');
INSERT INTO "expense" VALUES(2002147,'2014-05-13',19,2,12.2,'Milk');
INSERT INTO "expense" VALUES(2002148,'2014-05-13',17,2,2.71,'Eggs');
INSERT INTO "expense" VALUES(2002149,'2014-05-09',31,2,32.09,'Travel Bag from amazon');
INSERT INTO "expense" VALUES(2002150,'2014-05-15',8,2,38.22,'');
INSERT INTO "expense" VALUES(2002151,'2014-05-15',20,2,16.46,'Cake World');
INSERT INTO "expense" VALUES(2002152,'2014-05-15',21,2,6.49,'salt cookies');
INSERT INTO "expense" VALUES(2002153,'2014-05-15',37,2,2.74,'cereal');
INSERT INTO "expense" VALUES(2002154,'2014-05-15',16,2,1.26,'Banana');
INSERT INTO "expense" VALUES(2002155,'2014-05-17',17,2,3.93,'Salt & tomatoes');
INSERT INTO "expense" VALUES(2002156,'2014-05-17',16,2,3.0591,'mango');
INSERT INTO "expense" VALUES(2002157,'2014-05-17',17,2,1.7201,'Cilantro & mint');
INSERT INTO "expense" VALUES(2002158,'2014-05-17',25,2,4.35,'multi-purpose spray, boxes');
INSERT INTO "expense" VALUES(2002159,'2014-05-17',32,2,1,'Dental Floss');
INSERT INTO "expense" VALUES(2002160,'2014-05-17',25,2,7.36,'SOS, Foam bowls, Foil');
INSERT INTO "expense" VALUES(2002161,'2014-05-17',16,2,1.78,'Strawberries');
INSERT INTO "expense" VALUES(2002162,'2014-05-18',19,2,15.94,'Pita breads & meat pockets');
INSERT INTO "expense" VALUES(2002163,'2014-05-19',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002164,'2014-05-20',17,2,2.05,'cucumber');
INSERT INTO "expense" VALUES(2002165,'2014-05-20',40,2,22.6,'Nissan Leaf Tire rotation');
INSERT INTO "expense" VALUES(2002166,'2014-05-20',17,2,8.49,'');
INSERT INTO "expense" VALUES(2002167,'2014-05-19',37,2,12.66,'Cereal, Baby food');
INSERT INTO "expense" VALUES(2002168,'2014-05-21',19,2,6.9,'Kellogs, Bread');
INSERT INTO "expense" VALUES(2002169,'2014-05-23',31,2,95,'Swimming');
INSERT INTO "expense" VALUES(2002170,'2014-05-23',8,2,31.31,'');
INSERT INTO "expense" VALUES(2002171,'2014-05-24',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002172,'2014-05-26',8,2,18.96,'');
INSERT INTO "expense" VALUES(2002173,'2014-05-26',13,2,19.2,'Childrens place');
INSERT INTO "expense" VALUES(2002174,'2014-05-26',20,2,12.7,'Asma Cuisine');
INSERT INTO "expense" VALUES(2002175,'2014-05-26',13,2,2.24,'Childrens place');
INSERT INTO "expense" VALUES(2002176,'2014-05-26',15,2,15.73,'hand bag');
INSERT INTO "expense" VALUES(2002177,'2014-05-26',13,2,13.64,'Pant');
INSERT INTO "expense" VALUES(2002178,'2014-05-26',25,2,11.69,'Neon Straws, Laundry basket, moth bar, Scent sheets');
INSERT INTO "expense" VALUES(2002179,'2014-05-26',37,2,2.74,'Cereal');
INSERT INTO "expense" VALUES(2002180,'2014-05-26',16,2,1.76,'Banana + tax of others');
INSERT INTO "expense" VALUES(2002181,'2014-05-26',17,2,46.6,'');
INSERT INTO "expense" VALUES(2002182,'2014-05-26',25,2,4.38,'Kalonji oil');
INSERT INTO "expense" VALUES(2002183,'2014-05-26',18,2,42.21,'Chicken');
INSERT INTO "expense" VALUES(2002184,'2014-05-26',25,2,56.91,'Blankets, Wallet(13.99)');
INSERT INTO "expense" VALUES(2002185,'2014-05-28',19,2,6.56,'Croisant');
INSERT INTO "expense" VALUES(2002186,'2014-05-28',16,2,4.99,'Watermelon');
INSERT INTO "expense" VALUES(2002187,'2014-05-28',37,2,2.48,'Cereal');
INSERT INTO "expense" VALUES(2002188,'2014-05-28',16,2,1,'Banana');
INSERT INTO "expense" VALUES(2002189,'2014-05-28',19,2,5.73,'Lays, eggs');
INSERT INTO "expense" VALUES(2002190,'2014-05-30',8,2,78.69,'');
INSERT INTO "expense" VALUES(2002191,'2014-05-30',19,2,12.34,'Milk');
INSERT INTO "expense" VALUES(2002192,'2014-05-31',17,2,2.69,'Cucumber, Yoghurt');
INSERT INTO "expense" VALUES(2002193,'2014-05-31',38,2,56.77,'Mustaq''s family');
INSERT INTO "expense" VALUES(2002194,'2014-05-31',27,2,50,'');
INSERT INTO "expense" VALUES(2002195,'2014-06-01',31,2,11.99,'Hafsa Haircut');
INSERT INTO "expense" VALUES(2002196,'2014-06-01',16,2,1.09,'');
INSERT INTO "expense" VALUES(2002197,'2014-06-01',27,2,7.97,'Tylenol');
INSERT INTO "expense" VALUES(2002198,'2014-06-01',17,2,17.2,'Tooth paste, Pasta, Onions, Sugar, Dawn');
INSERT INTO "expense" VALUES(2002199,'2014-06-02',29,2,10.16,'Vitamin D');
INSERT INTO "expense" VALUES(2002200,'2014-06-02',30,2,10.15,'Vitamin D');
INSERT INTO "expense" VALUES(2002201,'2014-06-03',27,2,20,'');
INSERT INTO "expense" VALUES(2002202,'2014-06-04',29,2,24.75,'Parking Fee - 4.75');
INSERT INTO "expense" VALUES(2002203,'2014-06-04',16,2,7.61,'Banana, Pears, Canteloupe, Plums');
INSERT INTO "expense" VALUES(2002204,'2014-06-04',27,2,5.67,'Motrin');
INSERT INTO "expense" VALUES(2002205,'2014-06-04',19,2,18.86,'Metamucil, Horizon Milk, Unidentified food item');
INSERT INTO "expense" VALUES(2002206,'2014-06-05',27,2,20,'');
INSERT INTO "expense" VALUES(2002207,'2014-06-06',2,2,23.1013,'Bath tissue rolls');
INSERT INTO "expense" VALUES(2002208,'2014-06-06',17,2,7.1997,'Onions');
INSERT INTO "expense" VALUES(2002209,'2014-06-06',17,2,12.3,'');
INSERT INTO "expense" VALUES(2002210,'2014-06-06',36,2,7.98,'');
INSERT INTO "expense" VALUES(2002211,'2014-06-06',31,2,3.58,'Mint Plant');
INSERT INTO "expense" VALUES(2002212,'2014-06-06',19,2,2.28,'Bread');
INSERT INTO "expense" VALUES(2002213,'2014-06-06',37,2,4.6,'Baby Food');
INSERT INTO "expense" VALUES(2002214,'2014-06-07',19,2,12.82,'Pizza from Jerusalem Bakery');
INSERT INTO "expense" VALUES(2002215,'2014-06-07',17,2,21.22,'');
INSERT INTO "expense" VALUES(2002216,'2014-06-07',38,2,20.24,'Hassan''s Son');
INSERT INTO "expense" VALUES(2002217,'2014-06-08',21,2,1.84,'Cookies');
INSERT INTO "expense" VALUES(2002218,'2014-06-08',17,2,4.7,'Peanuts');
INSERT INTO "expense" VALUES(2002219,'2014-09-25',41,2,13.17,'');
INSERT INTO "expense" VALUES(2002220,'2014-09-24',31,2,10.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002221,'2014-09-24',17,2,42.68,'');
INSERT INTO "expense" VALUES(2002222,'2014-09-25',16,2,1.57,'');
INSERT INTO "expense" VALUES(2002223,'2014-09-25',17,2,7.9,'Walmart
Condensed Milk
Yoghurt
Bathroom Cleaner');
INSERT INTO "expense" VALUES(2002224,'2014-09-29',23,2,4.37,'Battery for Car DVD Remote Control');
INSERT INTO "expense" VALUES(2002225,'2014-09-29',16,2,4,'');
INSERT INTO "expense" VALUES(2002226,'2014-09-28',17,2,9.35,'Green Tea - 2 (Small & Big)
Falooda');
INSERT INTO "expense" VALUES(2002227,'2014-09-28',18,2,87.58,'8 lbs Meat
4 lbs Paya');
INSERT INTO "expense" VALUES(2002228,'2014-09-28',17,2,17.23,'Baakhar Khani, Sindh Biryani Masala, Maza 24 pack');
INSERT INTO "expense" VALUES(2002229,'2014-09-29',17,2,5.08,'Tomatoes, Mint, Cilantro, Lemons');
INSERT INTO "expense" VALUES(2002230,'2014-09-29',21,2,3.13,'Kroger
Wafers, Muffin, Biscoti');
INSERT INTO "expense" VALUES(2002231,'2014-09-29',37,2,41.72,'Diapers');
INSERT INTO "expense" VALUES(2002232,'2014-09-29',37,2,2.08,'Cereal');
INSERT INTO "expense" VALUES(2002233,'2014-09-29',2,2,3.28,'Chlorox Bathroom cleaner');
INSERT INTO "expense" VALUES(2002234,'2014-09-29',25,2,13.1,'Tide');
INSERT INTO "expense" VALUES(2002235,'2014-09-29',31,2,12.99,'Booster Seat from Target');
INSERT INTO "expense" VALUES(2002236,'2014-09-29',41,2,7.59,'');
INSERT INTO "expense" VALUES(2002237,'2014-10-01',17,2,1.69,'Condensed milk');
INSERT INTO "expense" VALUES(2002238,'2014-10-02',8,2,53.36,'');
INSERT INTO "expense" VALUES(2002239,'2014-10-02',19,2,11.22,'Pizza for Hafsa School EID Party');
INSERT INTO "expense" VALUES(2002240,'2014-10-02',28,2,5,'');
INSERT INTO "expense" VALUES(2002241,'2014-10-01',17,2,6.3,'');
INSERT INTO "expense" VALUES(2002242,'2014-10-03',42,2,11.44,'');
INSERT INTO "expense" VALUES(2002243,'2014-10-06',42,2,61.78,'Gas');
INSERT INTO "expense" VALUES(2002244,'2014-10-03',42,2,53.97,'Gas');
INSERT INTO "expense" VALUES(2002245,'2014-10-05',42,2,17,'Sea World Car Parking');
INSERT INTO "expense" VALUES(2002246,'2014-10-07',42,2,55.41,'Gas');
INSERT INTO "expense" VALUES(2002247,'2014-10-07',16,2,1.46,'Banana');
INSERT INTO "expense" VALUES(2002248,'2014-10-07',17,2,5.07,'');
INSERT INTO "expense" VALUES(2002249,'2014-10-08',41,2,6.59,'');
INSERT INTO "expense" VALUES(2002250,'2014-10-08',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002251,'2014-10-08',17,2,50.01,'');
INSERT INTO "expense" VALUES(2002252,'2014-10-09',2,2,4.98,'Shampoo');
INSERT INTO "expense" VALUES(2002253,'2014-10-09',17,2,4.14,'Yoghurt, Cucumber');
INSERT INTO "expense" VALUES(2002254,'2014-10-09',13,2,4.27,'T-shirt for painting');
INSERT INTO "expense" VALUES(2002255,'2014-10-11',17,2,3.8,'curry leaves
turai');
INSERT INTO "expense" VALUES(2002256,'2014-10-11',41,2,6.39,'');
INSERT INTO "expense" VALUES(2002257,'2014-10-11',17,2,6.61,'');
INSERT INTO "expense" VALUES(2002258,'2014-10-11',20,2,31.69,'');
INSERT INTO "expense" VALUES(2002259,'2014-10-14',17,2,4.77,'Salad
Cilantro
Yoghurt');
INSERT INTO "expense" VALUES(2002260,'2014-10-14',2,2,3.28,'Clorox bleach');
INSERT INTO "expense" VALUES(2002261,'2014-10-15',29,2,11.42,'bandage
tape
cream
');
INSERT INTO "expense" VALUES(2002262,'2014-10-16',17,2,37.09,'Aata
tomatoes
onions
cumin seeds
dhania seeds
ghee
chapathi');
INSERT INTO "expense" VALUES(2002263,'2014-10-16',41,2,5.56,'');
INSERT INTO "expense" VALUES(2002264,'2014-10-21',41,2,7.99,'');
INSERT INTO "expense" VALUES(2002265,'2014-10-21',16,2,4.99,'Apple
Parsemon');
INSERT INTO "expense" VALUES(2002266,'2014-10-21',19,2,3.47,'soda');
INSERT INTO "expense" VALUES(2002267,'2014-10-23',20,2,28.25,'Jerusalem Bakery');
INSERT INTO "expense" VALUES(2002268,'2014-10-19',41,2,2.39,'');
INSERT INTO "expense" VALUES(2002269,'2014-10-05',42,2,3.18,'Sprite');
INSERT INTO "expense" VALUES(2002270,'2014-10-02',42,2,4.12,'Ice bags');
INSERT INTO "expense" VALUES(2002271,'2014-10-18',16,2,2.2,'Avacado, Banana');
INSERT INTO "expense" VALUES(2002272,'2014-10-18',17,2,0.99,'Sugar');
INSERT INTO "expense" VALUES(2002273,'2014-10-18',21,2,7.71,'Waffles');
INSERT INTO "expense" VALUES(2002274,'2014-10-23',16,2,5.97,'Oranges');
INSERT INTO "expense" VALUES(2002275,'2014-10-23',41,2,2.4,'');
INSERT INTO "expense" VALUES(2002276,'2014-10-23',17,2,7.23,'Bread, Cilantro, Tomatoes');
INSERT INTO "expense" VALUES(2002277,'2014-10-25',41,2,6.17,'');
INSERT INTO "expense" VALUES(2002278,'2014-10-25',21,2,9.46,'Sweets');
INSERT INTO "expense" VALUES(2002279,'2014-10-26',17,2,22.11,'Mint
Peeled Garlic
Curry leaves
Tamarind
Okra
Methi
Sambar Powder
Shredded Coconut');
INSERT INTO "expense" VALUES(2002280,'2014-10-26',37,2,21.1753,'Wipes');
INSERT INTO "expense" VALUES(2002281,'2014-10-26',31,2,12.49,'For Shahana');
INSERT INTO "expense" VALUES(2002282,'2014-10-26',25,2,25.98,'Bounty
Cascade Diswasher liquid');
INSERT INTO "expense" VALUES(2002283,'2014-10-26',17,2,21.77,'Mazola Pil');
INSERT INTO "expense" VALUES(2002284,'2014-10-25',18,2,4.82,'Chicken');
INSERT INTO "expense" VALUES(2002285,'2014-10-25',17,2,14.37,'Basmati Rice');
INSERT INTO "expense" VALUES(2002286,'2014-10-19',8,2,59.13,'');
INSERT INTO "expense" VALUES(2002287,'2014-10-05',42,2,7.4,'Magnet');
INSERT INTO "expense" VALUES(2002288,'2014-10-25',17,2,54.95,'');
INSERT INTO "expense" VALUES(2002289,'2014-10-17',17,2,10.4,'Mixed vegetables
Trays
Sandies');
INSERT INTO "expense" VALUES(2002290,'2014-10-17',37,2,2.08,'Cereal');
INSERT INTO "expense" VALUES(2002291,'2014-10-25',36,2,16.21,'');
INSERT INTO "expense" VALUES(2002292,'2014-10-29',41,2,10,'');
INSERT INTO "expense" VALUES(2002293,'2014-10-29',17,2,3.06,'Oats');
INSERT INTO "expense" VALUES(2002294,'2014-10-29',17,2,3.13,'Cookies
Chillies
Mint');
INSERT INTO "expense" VALUES(2002295,'2014-10-30',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002296,'2014-10-29',37,2,2.56,'Cereal');
INSERT INTO "expense" VALUES(2002297,'2014-11-05',21,2,2.98,'Nila Wafers');
INSERT INTO "expense" VALUES(2002298,'2014-11-05',27,2,7.97,'Tylenol');
INSERT INTO "expense" VALUES(2002299,'2014-11-05',25,2,3.69,'Stain remover');
INSERT INTO "expense" VALUES(2002300,'2014-11-05',41,2,6.17,'');
INSERT INTO "expense" VALUES(2002301,'2014-11-06',37,2,2.08,'Cereal');
INSERT INTO "expense" VALUES(2002302,'2014-11-06',28,2,10.67,'Clariton');
INSERT INTO "expense" VALUES(2002303,'2014-11-06',27,2,20,'Checkup for Cold');
INSERT INTO "expense" VALUES(2002304,'2014-11-07',29,2,13.85,'Allegra for sore throat');
INSERT INTO "expense" VALUES(2002305,'2014-11-08',28,2,5,'Cingular tablets');
INSERT INTO "expense" VALUES(2002306,'2014-11-08',31,2,33.17,'Gifts from walgreens');
INSERT INTO "expense" VALUES(2002307,'2014-11-08',21,2,1.58,'cookies');
INSERT INTO "expense" VALUES(2002308,'2014-11-08',17,2,16.68,'onions
ginger
paratha');
INSERT INTO "expense" VALUES(2002309,'2014-11-02',16,2,1.05,'');
INSERT INTO "expense" VALUES(2002310,'2014-11-02',17,2,15.87,'');
INSERT INTO "expense" VALUES(2002311,'2014-11-02',37,2,5.34,'baby cream');
INSERT INTO "expense" VALUES(2002312,'2014-11-01',41,2,6.17,'');
INSERT INTO "expense" VALUES(2002313,'2014-11-01',21,2,3.49,'');
INSERT INTO "expense" VALUES(2002314,'2014-11-01',18,2,13.28,'Chicken');
INSERT INTO "expense" VALUES(2002315,'2014-11-02',8,2,21.61,'');
INSERT INTO "expense" VALUES(2002316,'2014-11-08',41,2,6.17,'');
INSERT INTO "expense" VALUES(2002317,'2014-11-02',17,2,30.39,'');
INSERT INTO "expense" VALUES(2002318,'2014-11-10',18,2,43.24,'');
INSERT INTO "expense" VALUES(2002319,'2014-11-10',24,2,2.66,'Vicks');
INSERT INTO "expense" VALUES(2002320,'2014-11-10',21,2,1,'chatpat snacks');
INSERT INTO "expense" VALUES(2002321,'2014-11-10',8,2,57.91,'');
INSERT INTO "expense" VALUES(2002322,'2014-11-12',27,2,5.42,'');
INSERT INTO "expense" VALUES(2002323,'2014-11-12',17,2,6.91,'Tomatoes
Potatoes');
INSERT INTO "expense" VALUES(2002324,'2014-11-12',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002325,'2014-11-11',29,2,10,'');
INSERT INTO "expense" VALUES(2002326,'2014-11-11',32,2,3.2,'lip balm');
INSERT INTO "expense" VALUES(2002327,'2014-10-05',42,2,3.8,'toll');
INSERT INTO "expense" VALUES(2002328,'2014-11-11',29,2,20,'cold and cough check up');
INSERT INTO "expense" VALUES(2002329,'2014-11-11',17,2,1.94,'bread');
INSERT INTO "expense" VALUES(2002330,'2014-11-15',17,2,17.43,'Dosa Batter
Onions
Almonds');
INSERT INTO "expense" VALUES(2002331,'2014-11-14',37,2,4.16,'Cereal');
INSERT INTO "expense" VALUES(2002332,'2014-11-14',16,2,1.27,'Banana');
INSERT INTO "expense" VALUES(2002333,'2014-11-14',17,2,0.5,'Tomato Sauce');
INSERT INTO "expense" VALUES(2002334,'2014-11-13',17,2,11.07,'Cabbage
Gawar Beans
Curry leaves
Mint
Yoghurt');
INSERT INTO "expense" VALUES(2002335,'2014-11-16',17,2,7.68,'Pani Puri
Cilantro
Mint');
INSERT INTO "expense" VALUES(2002336,'2014-11-16',37,2,41.7193,'Diapers');
INSERT INTO "expense" VALUES(2002337,'2014-11-16',17,2,8.23,'Rice');
INSERT INTO "expense" VALUES(2002338,'2014-11-17',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002339,'2014-10-23',31,2,7.48,'Card reader');
INSERT INTO "expense" VALUES(2002340,'2014-11-18',16,2,1.35,'Banana');
INSERT INTO "expense" VALUES(2002341,'2014-11-18',17,2,20.8,'Tide
Butter
Eggs');
INSERT INTO "expense" VALUES(2002342,'2014-12-01',27,2,25,'Check up - 20
Medicine - 5');
INSERT INTO "expense" VALUES(2002343,'2014-12-01',31,2,12,'Hair Cut');
INSERT INTO "expense" VALUES(2002344,'2014-12-01',16,2,1.35,'banana');
INSERT INTO "expense" VALUES(2002345,'2014-12-01',17,2,10.66,'croissant
buns
shrimp
');
INSERT INTO "expense" VALUES(2002346,'2014-11-27',31,2,1.07,'Nail Cutter');
INSERT INTO "expense" VALUES(2002347,'2014-12-03',17,2,63.79,'');
INSERT INTO "expense" VALUES(2002348,'2014-12-10',35,2,6,'Underground ATL Parking - 2
Paking near office - 4');
INSERT INTO "expense" VALUES(2002349,'2014-11-21',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002350,'2014-12-05',41,2,7.6,'');
INSERT INTO "expense" VALUES(2002351,'2014-12-05',37,2,2.97,'');
INSERT INTO "expense" VALUES(2002352,'2014-12-05',17,2,1.64,'Tomatoes');
INSERT INTO "expense" VALUES(2002353,'2014-12-05',24,2,62.13,'Trash Can
Trash bags
Sleapwear for Hafsa
Mug
iPhone cover
Foil
Fragrance
Chocolate
Belt');
INSERT INTO "expense" VALUES(2002354,'2014-12-03',8,2,16.27,'');
INSERT INTO "expense" VALUES(2002355,'2014-12-09',8,2,13.61,'');
INSERT INTO "expense" VALUES(2002356,'2014-12-07',20,2,12.84,'Papa Johns Pizza');
INSERT INTO "expense" VALUES(2002357,'2014-11-21',17,2,3.95,'Salt');
INSERT INTO "expense" VALUES(2002358,'2014-12-10',20,2,6.75,'Willys Mexican Grill');
INSERT INTO "expense" VALUES(2002359,'2014-12-12',32,2,2.02,'dental floss');
INSERT INTO "expense" VALUES(2002360,'2014-12-12',41,2,6.16,'');
INSERT INTO "expense" VALUES(2002361,'2014-12-17',16,2,2.69,'banana');
INSERT INTO "expense" VALUES(2002362,'2014-12-17',17,2,10.93,'Faultless Spray
Nutella
Potatoes
Eggs');
INSERT INTO "expense" VALUES(2002363,'2014-12-17',2,2,1.98,'Bucket');
INSERT INTO "expense" VALUES(2002364,'2014-12-17',18,2,57,'');
INSERT INTO "expense" VALUES(2002365,'2014-12-17',17,2,22.84,'');
INSERT INTO "expense" VALUES(2002366,'2014-12-17',32,2,9.62,'foot cream');
INSERT INTO "expense" VALUES(2002367,'2014-12-17',41,2,6.16,'');
INSERT INTO "expense" VALUES(2002368,'2014-12-14',24,2,7.44,'Pouches');
INSERT INTO "expense" VALUES(2002369,'2014-12-13',20,2,3.91,'Starbucks coffee');
INSERT INTO "expense" VALUES(2002370,'2014-12-13',16,2,1.38,'banana');
INSERT INTO "expense" VALUES(2002371,'2014-12-13',17,2,2.23,'sugar');
INSERT INTO "expense" VALUES(2002372,'2014-12-14',14,2,50.08,'aeropostale - tshirts');
INSERT INTO "expense" VALUES(2002373,'2014-12-13',14,2,16.91,'track pant from Aeropostale');
INSERT INTO "expense" VALUES(2002374,'2014-12-14',31,2,4.27,'notebook');
INSERT INTO "expense" VALUES(2002375,'2014-12-10',16,2,1.29,'banana');
INSERT INTO "expense" VALUES(2002376,'2014-12-10',19,2,8.32,'');
INSERT INTO "expense" VALUES(2002377,'2014-12-13',31,2,14.41,'Watch');
INSERT INTO "expense" VALUES(2002378,'2014-12-13',14,2,16.54,'');
INSERT INTO "expense" VALUES(2002379,'2014-12-13',31,2,6.95,'Glasses');
INSERT INTO "expense" VALUES(2002380,'2014-08-29',16,2,1.48,'banana');
INSERT INTO "expense" VALUES(2002381,'2014-08-29',24,2,5.33,'febreze
hot iron cleaner
');
INSERT INTO "expense" VALUES(2002382,'2014-09-01',38,2,16.85,'Frock(Rafa)');
INSERT INTO "expense" VALUES(2002383,'2014-08-21',31,2,0.66,'Water bottle');
INSERT INTO "expense" VALUES(2002384,'2014-08-29',19,2,4.68,'Pita Bread from Jerusalem Bakery');
INSERT INTO "expense" VALUES(2002385,'2014-08-21',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002386,'2014-08-27',43,2,65.05,'Covered Girl');
INSERT INTO "expense" VALUES(2002387,'2014-09-06',17,2,1.42,'Mac N Cheese');
INSERT INTO "expense" VALUES(2002388,'2014-08-28',24,2,10.7,'Dumbbell from Five Below');
INSERT INTO "expense" VALUES(2002389,'2014-09-04',16,2,3.29,'');
INSERT INTO "expense" VALUES(2002390,'2014-09-04',17,2,4.03,'Eggs
Honey Oat');
INSERT INTO "expense" VALUES(2002391,'2014-09-07',17,2,3.14,'Olives
Red Onion
Jalapeno');
INSERT INTO "expense" VALUES(2002392,'2014-09-06',17,2,93.08,'');
INSERT INTO "expense" VALUES(2002393,'2014-09-07',8,2,18.88,'');
INSERT INTO "expense" VALUES(2002394,'2014-09-07',19,2,7.82,'Cake
Pepsi
');
INSERT INTO "expense" VALUES(2002395,'2014-09-06',31,2,11.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002396,'2014-08-16',37,2,41.7193,'Diapers');
INSERT INTO "expense" VALUES(2002397,'2014-08-16',2,2,15.8253,'bath tissue');
INSERT INTO "expense" VALUES(2002398,'2014-08-16',16,2,4.1097,'');
INSERT INTO "expense" VALUES(2002399,'2014-08-16',17,2,6.9937,'onions');
INSERT INTO "expense" VALUES(2002400,'2014-08-16',17,2,42.77,'');
INSERT INTO "expense" VALUES(2002401,'2014-08-11',41,2,5.99,'');
INSERT INTO "expense" VALUES(2002402,'2014-08-11',19,2,4.28,'coconut water');
INSERT INTO "expense" VALUES(2002403,'2014-08-02',8,2,65.23,'');
INSERT INTO "expense" VALUES(2002404,'2014-08-29',8,2,53.44,'');
INSERT INTO "expense" VALUES(2002405,'2014-08-24',2,2,3.21,'');
INSERT INTO "expense" VALUES(2002406,'2014-08-24',19,2,2.1293,'');
INSERT INTO "expense" VALUES(2002407,'2014-08-22',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002408,'2014-08-23',31,2,5,'Zoo Atlanta');
INSERT INTO "expense" VALUES(2002409,'2014-08-29',17,2,12.26,'');
INSERT INTO "expense" VALUES(2002410,'2014-08-25',18,2,6.34,'');
INSERT INTO "expense" VALUES(2002411,'2014-08-25',17,2,17.95,'Rice
Bakhar Khani
cilantro');
INSERT INTO "expense" VALUES(2002412,'2014-08-14',29,2,20,'GA Urology');
INSERT INTO "expense" VALUES(2002413,'2014-08-23',17,2,17.93,'');
INSERT INTO "expense" VALUES(2002414,'2014-08-17',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002415,'2014-08-27',41,2,12.34,'');
INSERT INTO "expense" VALUES(2002416,'2014-08-22',16,2,1.18,'Banana');
INSERT INTO "expense" VALUES(2002417,'2014-08-22',17,2,1.44,'Canned Beans');
INSERT INTO "expense" VALUES(2002418,'2014-08-17',2,2,1.97,'Clorox Gel
Tide');
INSERT INTO "expense" VALUES(2002419,'2014-08-17',25,2,10.7,'Tide');
INSERT INTO "expense" VALUES(2002420,'2014-12-24',8,2,44.49,'');
INSERT INTO "expense" VALUES(2002421,'2014-12-24',17,2,19.69,'');
INSERT INTO "expense" VALUES(2002422,'2014-12-24',17,2,43.14,'');
INSERT INTO "expense" VALUES(2002423,'2014-12-24',13,2,9.97,'');
INSERT INTO "expense" VALUES(2002424,'2014-12-23',37,2,25.1,'Milk bottles
Cereal');
INSERT INTO "expense" VALUES(2002425,'2014-12-15',37,2,41.7193,'diapers');
INSERT INTO "expense" VALUES(2002426,'2014-12-15',2,2,23.1013,'Bath tissues');
INSERT INTO "expense" VALUES(2002427,'2014-12-22',32,2,7.48,'Hair Gel and Hair Spray');
INSERT INTO "expense" VALUES(2002428,'2014-12-15',25,2,6.82,'Duracell batteries');
INSERT INTO "expense" VALUES(2002429,'2014-12-09',43,2,8.55,'');
INSERT INTO "expense" VALUES(2002430,'2014-12-23',41,2,9.3,'');
INSERT INTO "expense" VALUES(2002431,'2014-12-10',37,2,3.97,'Orajel paste');
INSERT INTO "expense" VALUES(2002432,'2014-12-10',31,2,8.57,'');
INSERT INTO "expense" VALUES(2002433,'2014-12-11',17,2,4.53,'lemons
carrots
salad');
INSERT INTO "expense" VALUES(2002434,'2014-12-15',17,2,84.81,'');
INSERT INTO "expense" VALUES(2002435,'2014-12-09',43,2,9.6,'');
INSERT INTO "expense" VALUES(2002436,'2015-01-07',8,2,47.38,'');
INSERT INTO "expense" VALUES(2002437,'2015-01-07',30,2,284,'Wisdom Tooth Extraction');
INSERT INTO "expense" VALUES(2002438,'2015-01-07',30,2,16.99,'Motrin
Liquid to rinse');
INSERT INTO "expense" VALUES(2002439,'2014-12-18',30,2,173,'Dental Consultation');
INSERT INTO "expense" VALUES(2002440,'2015-01-08',21,2,5.01,'');
INSERT INTO "expense" VALUES(2002441,'2015-01-08',17,2,13.1,'');
INSERT INTO "expense" VALUES(2002442,'2015-01-08',19,2,23.12,'Cakes Meeting Stuff');
INSERT INTO "expense" VALUES(2002443,'2015-01-10',15,2,43.36,'');
INSERT INTO "expense" VALUES(2002444,'2015-01-10',17,2,21.6,'Rice
Onions
curry leaves');
INSERT INTO "expense" VALUES(2002445,'2015-01-09',19,2,10.05,'Pastry Sheets');
INSERT INTO "expense" VALUES(2002446,'2015-01-12',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002447,'2015-01-04',21,2,2.43,'Cookies');
INSERT INTO "expense" VALUES(2002448,'2015-01-04',17,2,0.57,'Chillies
');
INSERT INTO "expense" VALUES(2002449,'2015-01-06',16,2,1.09,'banana');
INSERT INTO "expense" VALUES(2002450,'2015-01-06',2,2,3.31,'toilet bowl cleaner
bowl freshner');
INSERT INTO "expense" VALUES(2002451,'2015-01-06',37,2,4.75,'');
INSERT INTO "expense" VALUES(2002452,'2015-01-06',17,2,19,'');
INSERT INTO "expense" VALUES(2002453,'2015-01-02',41,2,7.19,'');
INSERT INTO "expense" VALUES(2002454,'2015-01-02',24,2,10.69,'Bounty paper towels
');
INSERT INTO "expense" VALUES(2002455,'2015-01-02',17,2,4.97,'Tomatoes
');
INSERT INTO "expense" VALUES(2002456,'2015-01-02',2,2,8.56,'Shampoo and Mouth Wash');
INSERT INTO "expense" VALUES(2002457,'2014-12-25',18,2,171,'Goat - 124.87
Rest Chicken');
INSERT INTO "expense" VALUES(2002458,'2014-12-27',19,2,10.7,'Sweets');
INSERT INTO "expense" VALUES(2002459,'2014-12-27',41,2,7.19,'');
INSERT INTO "expense" VALUES(2002460,'2014-12-27',17,2,19.17,'');
INSERT INTO "expense" VALUES(2002461,'2014-12-26',43,2,9.58,'For Rehan');
INSERT INTO "expense" VALUES(2002462,'2014-12-26',12,2,7.08,'');
INSERT INTO "expense" VALUES(2002463,'2014-12-24',13,2,9.97,'');
INSERT INTO "expense" VALUES(2002464,'2014-12-25',21,2,5.29,'');
INSERT INTO "expense" VALUES(2002465,'2014-12-25',43,2,26.5,'Shahana''s Cousin');
INSERT INTO "expense" VALUES(2002466,'2015-01-03',31,2,6.78,'Parer cups, bowls for Halqa Mushwara');
INSERT INTO "expense" VALUES(2002467,'2015-01-14',17,2,8.06,'tomatoes
yoghurt');
INSERT INTO "expense" VALUES(2002468,'2015-01-14',17,2,3.2,'Bread');
INSERT INTO "expense" VALUES(2002469,'2015-01-14',41,2,7.19,'');
INSERT INTO "expense" VALUES(2002470,'2015-01-13',16,2,2.13,'Papaya
Oranges');
INSERT INTO "expense" VALUES(2002471,'2015-01-13',17,2,1.74,'Cabbage
Cookies');
INSERT INTO "expense" VALUES(2002472,'2015-01-13',20,2,12.7,'');
INSERT INTO "expense" VALUES(2002473,'2015-01-12',37,2,41.7193,'');
INSERT INTO "expense" VALUES(2002474,'2015-01-12',17,2,19.5597,'Mazola Oil');
INSERT INTO "expense" VALUES(2002475,'2015-01-12',25,2,10.1543,'');
INSERT INTO "expense" VALUES(2002476,'2015-01-20',41,2,6.16,'');
INSERT INTO "expense" VALUES(2002477,'2015-01-20',43,2,1.9153,'Aeropostle polo t-shirt');
INSERT INTO "expense" VALUES(2002478,'2015-01-20',15,2,2.5573,'');
INSERT INTO "expense" VALUES(2002479,'2015-01-20',13,2,7.06,'');
INSERT INTO "expense" VALUES(2002480,'2015-01-20',14,2,13.9,'');
INSERT INTO "expense" VALUES(2002481,'2015-01-20',43,2,1.92,'');
INSERT INTO "expense" VALUES(2002482,'2015-01-19',31,2,7.47,'Rose & Card');
INSERT INTO "expense" VALUES(2002483,'2015-01-24',8,2,17.36,'');
INSERT INTO "expense" VALUES(2002484,'2015-01-26',16,2,1.67,'');
INSERT INTO "expense" VALUES(2002485,'2015-01-26',41,2,6.98,'');
INSERT INTO "expense" VALUES(2002486,'2015-01-26',17,2,4.36,'Butter');
INSERT INTO "expense" VALUES(2002487,'2015-01-27',17,2,29.51,'');
INSERT INTO "expense" VALUES(2002488,'2015-01-30',8,2,44.82,'');
INSERT INTO "expense" VALUES(2002489,'2015-01-30',17,2,14.64,'');
INSERT INTO "expense" VALUES(2002490,'2015-02-02',28,2,20,'');
INSERT INTO "expense" VALUES(2002491,'2015-02-02',44,2,18,'Yearly fee');
INSERT INTO "expense" VALUES(2002492,'2015-02-02',28,2,12.99,'');
INSERT INTO "expense" VALUES(2002493,'2015-02-02',38,2,2.51,'makeup set');
INSERT INTO "expense" VALUES(2002494,'2015-01-30',16,2,0.8,'');
INSERT INTO "expense" VALUES(2002495,'2015-01-30',17,2,2.06,'Eggs');
INSERT INTO "expense" VALUES(2002496,'2015-02-04',44,2,14.28,'Both for Hafsa and Aalia

Motrin, Tylenol and Pedialite');
INSERT INTO "expense" VALUES(2002497,'2015-02-04',19,2,2.34,'Gatorade');
INSERT INTO "expense" VALUES(2002498,'2015-02-03',28,2,20,'');
INSERT INTO "expense" VALUES(2002499,'2015-02-03',27,2,38,'Admin Fee - 18');
INSERT INTO "expense" VALUES(2002500,'2015-02-03',27,2,5,'Zofran');
INSERT INTO "expense" VALUES(2002501,'2015-02-03',19,2,2.26,'Gatorade');
INSERT INTO "expense" VALUES(2002502,'2015-02-01',16,2,1.05,'');
INSERT INTO "expense" VALUES(2002503,'2015-02-01',17,2,4.19,'Tomatoes');
INSERT INTO "expense" VALUES(2002504,'2015-02-01',2,2,3.24,'flush bar');
INSERT INTO "expense" VALUES(2002505,'2015-02-02',9,2,16.0393,'Car Mats');
INSERT INTO "expense" VALUES(2002506,'2015-02-02',24,2,6.9443,'Trays');
INSERT INTO "expense" VALUES(2002507,'2015-02-02',19,2,8.858,'Naan - For Daawat');
INSERT INTO "expense" VALUES(2002508,'2015-02-01',17,2,20.53,'Rice
Lemon
Mint');
INSERT INTO "expense" VALUES(2002509,'2015-01-31',17,2,8.9,'Batura
Henna');
INSERT INTO "expense" VALUES(2002510,'2015-01-31',32,2,11.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002511,'2015-02-01',18,2,36.59,'Chicken');
INSERT INTO "expense" VALUES(2002512,'2015-02-01',17,2,4.98,'Sindh Biryani Masala
Basil drink');
INSERT INTO "expense" VALUES(2002513,'2015-02-01',41,2,6.78,'');
INSERT INTO "expense" VALUES(2002514,'2015-02-01',31,2,15,'Pendant from Shamas collection');
INSERT INTO "expense" VALUES(2002515,'2015-02-11',17,2,1,'Rotini');
INSERT INTO "expense" VALUES(2002516,'2015-02-11',25,2,2.47,'Air Fresners');
INSERT INTO "expense" VALUES(2002517,'2015-02-11',31,2,3.74,'Food drive');
INSERT INTO "expense" VALUES(2002518,'2015-02-11',17,2,18.91,'');
INSERT INTO "expense" VALUES(2002519,'2015-02-11',40,2,403.42001,'Honda Oil Chane + Rotors change');
INSERT INTO "expense" VALUES(2002520,'2015-02-09',35,2,42.5,'');
INSERT INTO "expense" VALUES(2002522,'2015-02-08',17,2,4.5217,'Nann');
INSERT INTO "expense" VALUES(2002523,'2015-02-08',16,2,6.1697,'');
INSERT INTO "expense" VALUES(2002524,'2015-02-08',37,2,41.7193,'');
INSERT INTO "expense" VALUES(2002525,'2015-02-08',41,2,6.78,'');
INSERT INTO "expense" VALUES(2002526,'2015-01-12',16,2,1.66,'');
INSERT INTO "expense" VALUES(2002527,'2015-01-12',21,2,1.85,'Cookies');
INSERT INTO "expense" VALUES(2002528,'2015-02-08',21,2,10.94,'Tostitos
Salsa
Wafles
Bugles
');
INSERT INTO "expense" VALUES(2002529,'2015-02-08',16,2,1.08,'Banana');
INSERT INTO "expense" VALUES(2002530,'2015-02-08',36,2,5,'Shrimp');
INSERT INTO "expense" VALUES(2002531,'2015-02-08',46,2,9.94,'Tide');
INSERT INTO "expense" VALUES(2002532,'2015-02-08',2,2,7.83,'');
INSERT INTO "expense" VALUES(2002533,'2015-02-08',32,2,7.06,'Moisturizer cream');
INSERT INTO "expense" VALUES(2002534,'2015-01-17',16,2,1.2,'');
INSERT INTO "expense" VALUES(2002535,'2015-01-17',32,2,7.97,'Oral B Brushes');
INSERT INTO "expense" VALUES(2002536,'2015-01-17',17,2,1.67,'Rotini');
INSERT INTO "expense" VALUES(2002537,'2015-02-12',16,2,4.99,'');
INSERT INTO "expense" VALUES(2002538,'2015-02-12',17,2,2.98,'coleslaw
pineapple chunks');
INSERT INTO "expense" VALUES(2002539,'2015-02-12',13,2,4.8,'t-shirt for school');
INSERT INTO "expense" VALUES(2002540,'2015-02-15',41,2,6.16,'');
INSERT INTO "expense" VALUES(2002541,'2015-02-11',32,2,1.07,'face mask');
INSERT INTO "expense" VALUES(2002542,'2015-02-14',17,2,5.73,'Mayo
Canberries');
INSERT INTO "expense" VALUES(2002543,'2015-02-16',16,2,1.93,'Banana');
INSERT INTO "expense" VALUES(2002544,'2015-02-17',37,2,2.08,'');
INSERT INTO "expense" VALUES(2002545,'2015-02-17',17,2,9.37,'Onions
Gatorade
Yoghurt
Eggs');
INSERT INTO "expense" VALUES(2002546,'2015-02-14',8,2,18.36,'');
INSERT INTO "expense" VALUES(2002547,'2015-02-19',41,2,6.78,'');
INSERT INTO "expense" VALUES(2002548,'2015-02-23',17,2,28.61,'');
INSERT INTO "expense" VALUES(2002549,'2015-02-23',41,2,6.58,'');
INSERT INTO "expense" VALUES(2002550,'2015-02-23',20,2,14.98,'Naan');
INSERT INTO "expense" VALUES(2002551,'2015-02-22',17,2,5.15,'Yoghurt');
INSERT INTO "expense" VALUES(2002552,'2015-02-22',17,2,2.28,'');
INSERT INTO "expense" VALUES(2002553,'2015-02-22',16,2,1.41,'');
INSERT INTO "expense" VALUES(2002554,'2015-02-23',13,2,4.15,'');
INSERT INTO "expense" VALUES(2002555,'2015-02-24',16,2,3.64,'Pears');
INSERT INTO "expense" VALUES(2002556,'2015-02-24',17,2,3.68,'Yoghurt');
INSERT INTO "expense" VALUES(2002557,'2015-02-27',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002558,'2015-03-05',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002559,'2015-03-03',17,2,16.45,'');
INSERT INTO "expense" VALUES(2002560,'2015-03-03',16,2,5.5414,'');
INSERT INTO "expense" VALUES(2002561,'2015-03-03',41,2,12.2467,'');
INSERT INTO "expense" VALUES(2002562,'2015-02-27',8,2,20,'');
INSERT INTO "expense" VALUES(2002563,'2015-03-09',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002564,'2015-03-08',17,2,58.84,'');
INSERT INTO "expense" VALUES(2002565,'2015-03-07',38,2,21.39,'Toaster');
INSERT INTO "expense" VALUES(2002566,'2015-03-08',16,2,4.42,'');
INSERT INTO "expense" VALUES(2002567,'2015-03-08',17,2,2.58,'Choco Chips');
INSERT INTO "expense" VALUES(2002568,'2015-03-10',8,2,47.71,'');
INSERT INTO "expense" VALUES(2002569,'2015-03-14',17,2,25.65,'');
INSERT INTO "expense" VALUES(2002570,'2015-03-13',41,2,5.45,'');
INSERT INTO "expense" VALUES(2002571,'2015-03-13',20,2,12.84,'');
INSERT INTO "expense" VALUES(2002572,'2015-03-14',13,2,5.45,'');
INSERT INTO "expense" VALUES(2002573,'2015-03-14',38,2,6.39,'Frock for basarath kid');
INSERT INTO "expense" VALUES(2002574,'2015-03-15',37,2,62.8946,'Diapers
Wipes');
INSERT INTO "expense" VALUES(2002575,'2015-03-15',17,2,31.84,'Soft Soap
Always
Biscoff
Cascade Gel');
INSERT INTO "expense" VALUES(2002576,'2015-03-15',25,2,17.36,'Fabulsco
Toothpaste
Mouthwash
Air Freshner
Shampoo
Ball');
INSERT INTO "expense" VALUES(2002577,'2015-03-15',25,2,1.07,'Spray Bottle');
INSERT INTO "expense" VALUES(2002578,'2015-03-15',20,2,9.6,'Cake World');
INSERT INTO "expense" VALUES(2002579,'2015-03-15',25,2,5.79,'wipes
tongue cleaner');
INSERT INTO "expense" VALUES(2002580,'2015-03-17',41,2,2.5,'');
INSERT INTO "expense" VALUES(2002581,'2015-03-17',17,2,5,'yoghurt');
INSERT INTO "expense" VALUES(2002582,'2015-03-17',16,2,2.09,'Banana');
INSERT INTO "expense" VALUES(2002583,'2015-03-17',28,2,15,'Eye Exam - 10
Cingular - 5');
INSERT INTO "expense" VALUES(2002584,'2015-03-17',38,2,5.87,'Gift for Basarat daughter');
INSERT INTO "expense" VALUES(2002585,'2015-03-17',33,2,12.84,'Hafsa School bag');
INSERT INTO "expense" VALUES(2002586,'2015-03-20',16,2,3.03,'');
INSERT INTO "expense" VALUES(2002587,'2015-03-20',41,2,2.3,'');
INSERT INTO "expense" VALUES(2002588,'2015-03-20',17,2,5.25,'Tomatoes
Salt');
INSERT INTO "expense" VALUES(2002589,'2015-03-20',25,2,2.96,'Scrub');
INSERT INTO "expense" VALUES(2002590,'2015-03-20',32,2,5.74,'Tongue Cleaner
Toothbrush');
INSERT INTO "expense" VALUES(2002591,'2015-03-19',31,2,16.93,'Eye glasses for Hafsa');
INSERT INTO "expense" VALUES(2002592,'2015-03-02',27,2,20,'');
INSERT INTO "expense" VALUES(2002593,'2015-03-14',13,2,4.23,'');
INSERT INTO "expense" VALUES(2002594,'2015-03-20',32,2,27.82,'Mac Compact powder');
INSERT INTO "expense" VALUES(2002595,'2015-03-21',17,2,7.97,'');
INSERT INTO "expense" VALUES(2002596,'2015-03-22',41,2,5.64,'');
INSERT INTO "expense" VALUES(2002598,'2015-03-30',17,2,46.07,'');
INSERT INTO "expense" VALUES(2002599,'2015-03-25',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002600,'2015-03-30',41,2,6.78,'');
INSERT INTO "expense" VALUES(2002601,'2015-03-24',37,2,5.05,'');
INSERT INTO "expense" VALUES(2002602,'2015-03-24',16,2,1.07,'');
INSERT INTO "expense" VALUES(2002603,'2015-03-24',17,2,6.56,'Tomatoes
Bread
Eggs');
INSERT INTO "expense" VALUES(2002604,'2015-03-27',41,2,2.18,'2%');
INSERT INTO "expense" VALUES(2002605,'2015-03-27',44,2,7.94,'Pepcid');
INSERT INTO "expense" VALUES(2002606,'2015-03-27',17,2,3.59,'Eggs + Tax');
INSERT INTO "expense" VALUES(2002607,'2015-03-30',16,2,4.72,'Banana
Water Melon');
INSERT INTO "expense" VALUES(2002608,'2015-03-30',21,2,3.11,'Tostitos');
INSERT INTO "expense" VALUES(2002609,'2015-04-05',41,2,3.6,'');
INSERT INTO "expense" VALUES(2002610,'2015-04-04',31,2,5.34,'Passport photos for Aalia from costco');
INSERT INTO "expense" VALUES(2002611,'2015-04-04',18,2,49.48,'');
INSERT INTO "expense" VALUES(2002612,'2015-04-04',17,2,21.78,'');
INSERT INTO "expense" VALUES(2002613,'2015-04-06',32,2,10.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002614,'2015-04-06',16,2,1.19,'Banana');
INSERT INTO "expense" VALUES(2002615,'2015-04-06',17,2,12.56,'Oil
Tomatoes');
INSERT INTO "expense" VALUES(2002616,'2015-04-09',8,2,48.15,'');
INSERT INTO "expense" VALUES(2002617,'2015-04-09',28,2,10.51,'clariton');
INSERT INTO "expense" VALUES(2002618,'2015-04-09',36,2,6.96,'');
INSERT INTO "expense" VALUES(2002619,'2015-04-09',46,2,11.97,'Tide');
INSERT INTO "expense" VALUES(2002620,'2015-04-09',21,2,3.11,'French Fries');
INSERT INTO "expense" VALUES(2002621,'2015-04-12',17,2,6.63,'Bread and Butter');
INSERT INTO "expense" VALUES(2002622,'2015-04-11',17,2,17.78,'');
INSERT INTO "expense" VALUES(2002623,'2015-04-13',41,2,3.6,'');
INSERT INTO "expense" VALUES(2002624,'2015-04-13',17,2,5.29,'');
INSERT INTO "expense" VALUES(2002625,'2015-04-13',16,2,1.24,'Banana');
INSERT INTO "expense" VALUES(2002626,'2015-04-13',21,2,10,'Tostitos
Cookies
Choclate');
INSERT INTO "expense" VALUES(2002627,'2015-04-16',37,2,41.72,'Diapers');
INSERT INTO "expense" VALUES(2002628,'2015-04-16',37,2,5.05,'Cereal');
INSERT INTO "expense" VALUES(2002629,'2015-04-16',2,2,11.89,'Bath Tissues');
INSERT INTO "expense" VALUES(2002630,'2015-04-16',17,2,9.87,'Onions
Tomatoes');
INSERT INTO "expense" VALUES(2002631,'2015-04-16',41,2,2.58,'');
INSERT INTO "expense" VALUES(2002632,'2015-04-16',44,2,6.07,'Motrin');
INSERT INTO "expense" VALUES(2002633,'2015-04-15',27,2,20,'');
INSERT INTO "expense" VALUES(2002634,'2015-04-15',41,2,1.96,'2%');
INSERT INTO "expense" VALUES(2002635,'2015-04-15',17,2,21.44,'Paapad
Basmati Rice
Toor Dal
Laddu');
INSERT INTO "expense" VALUES(2002636,'2015-04-15',18,2,17.97,'');
INSERT INTO "expense" VALUES(2002637,'2015-04-15',25,2,5.33,'Loctite Glue');
INSERT INTO "expense" VALUES(2002638,'2015-04-20',41,2,2.58,'');
INSERT INTO "expense" VALUES(2002639,'2015-04-20',41,2,1.9,'');
INSERT INTO "expense" VALUES(2002640,'2015-04-20',16,2,1.98,'');
INSERT INTO "expense" VALUES(2002641,'2015-04-20',17,2,3.19,'Honey Oats Cereal');
INSERT INTO "expense" VALUES(2002642,'2015-04-16',25,2,3.08,'toothpaste');
INSERT INTO "expense" VALUES(2002643,'2015-04-21',16,2,1.96,'');
INSERT INTO "expense" VALUES(2002644,'2015-04-21',17,2,8.77,'Dishwashing liquid
eggs
tomatoes');
INSERT INTO "expense" VALUES(2002645,'2015-04-21',20,2,20,'Madras chettinad');
INSERT INTO "expense" VALUES(2002646,'2015-04-21',31,2,241.25999,'Tourist Visa');
INSERT INTO "expense" VALUES(2002647,'2015-04-27',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002648,'2015-04-24',41,2,3.37,'');
INSERT INTO "expense" VALUES(2002649,'2015-04-24',21,2,2.07,'Cookies');
INSERT INTO "expense" VALUES(2002650,'2015-04-23',17,2,31.3,'');
INSERT INTO "expense" VALUES(2002651,'2015-04-25',2,2,2,'');
INSERT INTO "expense" VALUES(2002652,'2015-04-25',16,2,1.4,'');
INSERT INTO "expense" VALUES(2002653,'2015-04-25',17,2,11.84,'');
INSERT INTO "expense" VALUES(2002654,'2015-04-29',31,2,150,'Subhani & Subhani');
INSERT INTO "expense" VALUES(2002655,'2015-04-30',41,2,3.39,'');
INSERT INTO "expense" VALUES(2002656,'2015-05-02',16,2,7.55,'Banana
Apples
Pears');
INSERT INTO "expense" VALUES(2002657,'2015-04-30',16,2,1.33,'Banana');
INSERT INTO "expense" VALUES(2002658,'2015-04-30',41,2,1.9,'');
INSERT INTO "expense" VALUES(2002659,'2015-04-30',17,2,4.05,'Tomatoes + Tax');
INSERT INTO "expense" VALUES(2002660,'2015-05-04',41,2,5.48,'');
INSERT INTO "expense" VALUES(2002661,'2015-05-04',17,2,2.82,'');
INSERT INTO "expense" VALUES(2002662,'2015-05-04',33,2,0.47,'Sharpener from walmart');
INSERT INTO "expense" VALUES(2002663,'2015-05-04',19,2,3.1,'Humus');
INSERT INTO "expense" VALUES(2002664,'2015-05-02',17,2,67.38,'');
INSERT INTO "expense" VALUES(2002665,'2015-05-05',33,2,11.84,'Summer learning stuff');
INSERT INTO "expense" VALUES(2002666,'2015-05-05',2,2,1,'Comet from Dollar Tree');
INSERT INTO "expense" VALUES(2002667,'2015-05-05',17,2,17.41,'');
INSERT INTO "expense" VALUES(2002668,'2015-05-06',8,2,26.75,'');
INSERT INTO "expense" VALUES(2002669,'2015-05-04',13,2,18.81,'');
INSERT INTO "expense" VALUES(2002670,'2015-05-06',18,2,52.73,'');
INSERT INTO "expense" VALUES(2002671,'2015-05-06',17,2,4.48,'Banne Nawab
Rice crackers');
INSERT INTO "expense" VALUES(2002672,'2015-05-07',16,2,1.39,'');
INSERT INTO "expense" VALUES(2002673,'2015-05-07',46,2,11.97,'');
INSERT INTO "expense" VALUES(2002674,'2015-05-07',17,2,7.34,'');
INSERT INTO "expense" VALUES(2002675,'2015-05-07',28,2,5,'');
INSERT INTO "expense" VALUES(2002676,'2015-05-07',2,2,3.21,'Soap');
INSERT INTO "expense" VALUES(2002677,'2015-05-07',41,2,3.29,'');
INSERT INTO "expense" VALUES(2002678,'2015-05-04',17,2,1.69,'');
INSERT INTO "expense" VALUES(2002679,'2015-05-04',21,2,2.22,'');
INSERT INTO "expense" VALUES(2002680,'2015-05-04',19,2,4,'Cake');
INSERT INTO "expense" VALUES(2002681,'2015-11-03',8,2,47.35,'');
INSERT INTO "expense" VALUES(2002682,'2015-11-02',21,2,2.36,'Spring roll sheets');
INSERT INTO "expense" VALUES(2002683,'2015-11-01',17,2,5.28,'Al-Madina
Falooda
Couscous');
INSERT INTO "expense" VALUES(2002684,'2015-11-01',8,2,11.41,'');
INSERT INTO "expense" VALUES(2002685,'2015-11-05',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002686,'2015-11-23',18,2,22.44,'');
INSERT INTO "expense" VALUES(2002687,'2015-11-24',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002688,'2015-11-23',18,2,14.22,'');
INSERT INTO "expense" VALUES(2002689,'2015-11-23',17,2,42.67,'');
INSERT INTO "expense" VALUES(2002690,'2015-11-24',17,2,35.47,'');
INSERT INTO "expense" VALUES(2002691,'2015-12-02',8,2,47,'');
INSERT INTO "expense" VALUES(2002692,'2015-11-26',21,2,10.56,'lighter oil
chips
ranch');
INSERT INTO "expense" VALUES(2002693,'2015-12-01',16,2,3.31,'');
INSERT INTO "expense" VALUES(2002694,'2015-11-30',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002695,'2015-11-23',31,2,3500,'Honda Fit Advance');
INSERT INTO "expense" VALUES(2002696,'2015-11-28',41,2,1.74,'');
INSERT INTO "expense" VALUES(2002697,'2015-11-28',16,2,0.91,'');
INSERT INTO "expense" VALUES(2002698,'2015-11-28',17,2,1.71,'Onions');
INSERT INTO "expense" VALUES(2002699,'2015-11-24',41,2,3.59,'');
INSERT INTO "expense" VALUES(2002700,'2015-11-24',31,2,0.88,'Mug');
INSERT INTO "expense" VALUES(2002701,'2015-11-24',17,2,2.72,'Eggs');
INSERT INTO "expense" VALUES(2002702,'2015-12-02',17,2,11,'');
INSERT INTO "expense" VALUES(2002703,'2015-12-02',17,2,7.71,'');
INSERT INTO "expense" VALUES(2002704,'2015-12-04',17,2,25.48,'Oil from Costco');
INSERT INTO "expense" VALUES(2002705,'2015-12-04',21,2,6,'pirouline from costco');
INSERT INTO "expense" VALUES(2002706,'2015-12-04',31,2,32.49,'Always, Shoes');
INSERT INTO "expense" VALUES(2002707,'2015-12-05',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002708,'2015-12-06',17,2,16.89,'');
INSERT INTO "expense" VALUES(2002709,'2015-12-06',17,2,11.88,'');
INSERT INTO "expense" VALUES(2002710,'2015-12-06',9,2,1,'Car Perfume');
INSERT INTO "expense" VALUES(2002711,'2015-12-06',46,2,12,'');
INSERT INTO "expense" VALUES(2002712,'2015-12-05',31,2,10.99,'Hair cut');
INSERT INTO "expense" VALUES(2002713,'2015-12-06',8,2,17.75,'');
INSERT INTO "expense" VALUES(2002714,'2015-11-17',27,2,20,'');
INSERT INTO "expense" VALUES(2002715,'2015-11-10',41,2,2.09,'');
INSERT INTO "expense" VALUES(2002716,'2015-11-10',17,2,10.35,'');
INSERT INTO "expense" VALUES(2002717,'2015-11-16',22,2,27.8,'curtain rods');
INSERT INTO "expense" VALUES(2002718,'2015-11-16',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002719,'2015-11-22',8,2,43.29,'');
INSERT INTO "expense" VALUES(2002720,'2015-11-16',17,2,1.03,'Waffle mix from Kroger');
INSERT INTO "expense" VALUES(2002721,'2015-11-14',36,2,9.38,'');
INSERT INTO "expense" VALUES(2002722,'2015-11-06',20,2,10.7,'Pizza');
INSERT INTO "expense" VALUES(2002723,'2015-11-19',41,2,3.49,'');
INSERT INTO "expense" VALUES(2002724,'2015-11-19',16,2,1.09,'Banana');
INSERT INTO "expense" VALUES(2002725,'2015-11-19',17,2,10.71,'');
INSERT INTO "expense" VALUES(2002726,'2015-11-11',25,2,19.07,'Towels');
INSERT INTO "expense" VALUES(2002727,'2015-11-13',41,2,2.09,'');
INSERT INTO "expense" VALUES(2002728,'2015-11-13',25,2,4.24,'foil');
INSERT INTO "expense" VALUES(2002729,'2015-11-13',31,2,16.7,'Trojan');
INSERT INTO "expense" VALUES(2002730,'2015-11-06',17,2,4.09,'');
INSERT INTO "expense" VALUES(2002731,'2015-11-07',32,2,1.29,'Nupur Mehandi');
INSERT INTO "expense" VALUES(2002732,'2015-11-14',20,2,16.05,'');
INSERT INTO "expense" VALUES(2002733,'2015-12-08',41,2,7.61,'');
INSERT INTO "expense" VALUES(2002734,'2015-12-09',16,2,3.43,'');
INSERT INTO "expense" VALUES(2002735,'2015-12-12',17,2,1.98,'Sugar');
INSERT INTO "expense" VALUES(2002736,'2015-12-12',32,2,19.37,'Olay, foot cream');
INSERT INTO "expense" VALUES(2002737,'2015-12-12',13,2,2.46,'Night dress from walmart - Hello Kitty');
INSERT INTO "expense" VALUES(2002738,'2015-12-12',26,2,0.88,'wooden spoons');
INSERT INTO "expense" VALUES(2002739,'2015-12-12',17,2,27.21,'');
INSERT INTO "expense" VALUES(2002740,'2015-12-12',13,2,4.8,'');
INSERT INTO "expense" VALUES(2002741,'2015-12-14',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002742,'2015-12-15',16,2,1.86,'');
INSERT INTO "expense" VALUES(2002743,'2015-12-15',8,2,16.99,'');
INSERT INTO "expense" VALUES(2002744,'2015-12-15',17,2,2.03,'Bread');
INSERT INTO "expense" VALUES(2002745,'2015-12-17',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002746,'2015-12-19',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002747,'2015-12-19',17,2,34.49,'Rice - 16.99');
INSERT INTO "expense" VALUES(2002748,'2015-12-19',20,2,4.06,'Auntie Anne''s');
INSERT INTO "expense" VALUES(2002749,'2015-12-19',16,2,7.57,'');
INSERT INTO "expense" VALUES(2002750,'2015-12-16',29,2,15,'Georgia Urology');
INSERT INTO "expense" VALUES(2002751,'2015-12-17',30,2,33.55,'Co-Pay : 20');
INSERT INTO "expense" VALUES(2002752,'2015-12-16',18,2,44.61,'Chicken');
INSERT INTO "expense" VALUES(2002754,'2015-12-12',36,2,6.98,'Tilapia from walmart');
INSERT INTO "expense" VALUES(2002755,'2015-12-12',17,2,2.96,'Eggs');
INSERT INTO "expense" VALUES(2002756,'2015-12-20',32,2,10.92,'Mouthwash
Floss');
INSERT INTO "expense" VALUES(2002757,'2015-12-21',21,2,1.59,'Butter Cookies');
INSERT INTO "expense" VALUES(2002758,'2015-12-26',8,2,17.29,'');
INSERT INTO "expense" VALUES(2002759,'2015-12-24',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002760,'2015-12-24',21,2,12.99,'Tostitos, Salsa, Syrup, Cake');
INSERT INTO "expense" VALUES(2002761,'2015-12-24',17,2,4.26,'Mac and Cheese, Elbows');
INSERT INTO "expense" VALUES(2002762,'2015-12-24',21,2,2.89,'Good Day Cookies');
INSERT INTO "expense" VALUES(2002763,'2015-12-24',17,2,2.5,'Cilantro, Chillies');
INSERT INTO "expense" VALUES(2002764,'2015-12-20',32,2,24.66,'Elizabeth Arden from Macys');
INSERT INTO "expense" VALUES(2002765,'2015-12-27',17,2,36.05,'Patel Brothers');
INSERT INTO "expense" VALUES(2002766,'2015-12-27',21,2,8.4,'Sweets from Gokul');
INSERT INTO "expense" VALUES(2002767,'2016-01-03',17,2,2.66,'French Bread');
INSERT INTO "expense" VALUES(2002768,'2015-12-29',41,2,7.61,'');
INSERT INTO "expense" VALUES(2002769,'2016-01-01',16,2,0.72,'Banana');
INSERT INTO "expense" VALUES(2002770,'2016-01-01',19,2,0.91,'Water');
INSERT INTO "expense" VALUES(2002771,'2015-12-27',20,2,26.03,'Zyka');
INSERT INTO "expense" VALUES(2002772,'2015-12-31',17,2,10.43,'Spices Hut');
INSERT INTO "expense" VALUES(2002773,'2016-01-03',14,2,10.59,'Jeans from Aeropostle');
INSERT INTO "expense" VALUES(2002774,'2015-12-19',13,2,7.48,'Childerns place');
INSERT INTO "expense" VALUES(2002776,'2016-01-03',32,2,2,'Bath and Body Works');
INSERT INTO "expense" VALUES(2002777,'2016-01-03',38,2,8.7,'Bath and Body Works - for teachers');
INSERT INTO "expense" VALUES(2002778,'2016-01-06',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002781,'2016-01-08',16,2,1.42,'Banana');
INSERT INTO "expense" VALUES(2002782,'2016-01-08',17,2,4.16,'Salt, Eggs');
INSERT INTO "expense" VALUES(2002783,'2016-01-09',17,2,22.35,'Spices Hut');
INSERT INTO "expense" VALUES(2002784,'2016-01-09',46,2,11.99,'');
INSERT INTO "expense" VALUES(2002785,'2016-01-09',25,2,4.58,'Dish Washing Liquid, Toothpaste');
INSERT INTO "expense" VALUES(2002786,'2016-01-09',17,2,7.02,'Olives, All purpose flour');
INSERT INTO "expense" VALUES(2002787,'2016-01-09',16,2,2.39,'Papaya from Spices Hut');
INSERT INTO "expense" VALUES(2002788,'2016-01-10',32,2,11.99,'Aalia HairCut');
INSERT INTO "expense" VALUES(2002789,'2016-01-10',8,2,18.6,'');
INSERT INTO "expense" VALUES(2002790,'2016-01-10',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002791,'2016-01-10',39,2,5.63,'Benagay, Back ache patch');
INSERT INTO "expense" VALUES(2002792,'2016-01-12',9,2,15.99,'Emission Test');
INSERT INTO "expense" VALUES(2002793,'2016-01-14',9,2,22,'Car Tag Renewal');
INSERT INTO "expense" VALUES(2002794,'2016-01-12',17,2,2.7604,'Hamburger Buns');
INSERT INTO "expense" VALUES(2002795,'2016-01-12',23,2,6.2916,'Tube Light');
INSERT INTO "expense" VALUES(2002796,'2016-01-16',2,2,3.0816,'Shampoo');
INSERT INTO "expense" VALUES(2002797,'2016-01-16',17,2,2.9458,'Eggs');
INSERT INTO "expense" VALUES(2002798,'2016-01-16',16,2,5.9431,'Banana, Apples, Oranges');
INSERT INTO "expense" VALUES(2002799,'2016-01-10',17,2,16.1813,'Cocoa Powder, Puff Pastry Sheets, Cheddar Cheese');
INSERT INTO "expense" VALUES(2002800,'2016-01-10',39,2,6.0241,'Bengay, Backache Strip');
INSERT INTO "expense" VALUES(2002801,'2016-01-16',41,2,3.42,'');
INSERT INTO "expense" VALUES(2002802,'2016-01-16',8,2,20.06,'Oddyssey');
INSERT INTO "expense" VALUES(2002803,'2016-01-16',17,2,33.57,'Dates - 5.99
Sweet -  5.99');
INSERT INTO "expense" VALUES(2002804,'2016-01-18',33,2,16.25,'2nd grade book - 8.47
Brownies for school - 6.98');
INSERT INTO "expense" VALUES(2002805,'2016-01-19',8,2,16.6,'Fit');
INSERT INTO "expense" VALUES(2002806,'2016-01-19',17,2,10.58,'Mint, Onions, Malaysian Paratha');
INSERT INTO "expense" VALUES(2002807,'2016-01-18',17,2,2.06,'Kraft Cheese Strings');
INSERT INTO "expense" VALUES(2002808,'2016-01-20',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002809,'2016-01-25',41,2,3.69,'');
INSERT INTO "expense" VALUES(2002810,'2016-01-25',16,2,0.6,'Grapefruit');
INSERT INTO "expense" VALUES(2002811,'2016-01-25',32,2,5.57,'Waxelene (4.99) plus other items tax');
INSERT INTO "expense" VALUES(2002812,'2016-01-26',46,2,0.97,'Starch for cloth ironing');
INSERT INTO "expense" VALUES(2002813,'2016-01-26',32,2,5.22,'St Ives Body Lotion (4.78)');
INSERT INTO "expense" VALUES(2002814,'2016-01-26',16,2,1.44,'Banana');
INSERT INTO "expense" VALUES(2002815,'2016-01-29',17,2,2.04,'Eggs');
INSERT INTO "expense" VALUES(2002816,'2016-02-02',8,2,19.06,'Odyssey');
INSERT INTO "expense" VALUES(2002817,'2016-02-02',18,2,41.57,'5 Chicken
3.5 lbs Boneless Chicken');
INSERT INTO "expense" VALUES(2002818,'2016-02-02',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002819,'2016-02-02',16,2,6.23,'Kiwi, Oranges');
INSERT INTO "expense" VALUES(2002820,'2016-02-02',17,2,10.84,'Almonds');
INSERT INTO "expense" VALUES(2002821,'2016-01-31',8,2,16.31,'Honda Fit');
INSERT INTO "expense" VALUES(2002822,'2016-01-29',32,2,10.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002823,'2016-01-28',21,2,14.05,'Bakhlava from Al Madina');
INSERT INTO "expense" VALUES(2002824,'2016-01-27',17,2,23.18,'Basmati Rice - 14.41
Cilantro, Mint, Chillies
Milk Rusk');
INSERT INTO "expense" VALUES(2002825,'2016-02-02',25,2,10.68,'Toothbrush');
INSERT INTO "expense" VALUES(2002826,'2016-01-29',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002827,'2016-01-31',13,2,5.35,'');
INSERT INTO "expense" VALUES(2002828,'2016-01-31',16,2,1.99,'banana, avacado');
INSERT INTO "expense" VALUES(2002829,'2016-01-31',17,2,26.02,'Rice - 15.99
Chillies
Red Onions - 7.79');
INSERT INTO "expense" VALUES(2002830,'2016-01-30',17,2,65,'From Cherians');
INSERT INTO "expense" VALUES(2002831,'2016-01-30',36,2,5.99,'Anchovies (frozen) from Cherians');
INSERT INTO "expense" VALUES(2002832,'2016-01-31',25,2,1.84,'Sponge, Glass tumblers');
INSERT INTO "expense" VALUES(2002833,'2016-01-31',17,2,12.78,'Fruit Loops, Butter, Funny Onions, Vanilla Essense');
INSERT INTO "expense" VALUES(2002834,'2016-02-03',31,2,35,'BOA charge for overlimit (less available balance)');
INSERT INTO "expense" VALUES(2002835,'2016-02-09',8,2,16.23,'Fit');
INSERT INTO "expense" VALUES(2002836,'2016-02-10',8,2,37.43,'Odyssey');
INSERT INTO "expense" VALUES(2002837,'2016-02-10',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002838,'2016-02-10',16,2,1.11,'Banana');
INSERT INTO "expense" VALUES(2002839,'2016-02-10',2,2,6.32,'Chlorox Bathroom Cleaner, Toliet Bowl Cleaner');
INSERT INTO "expense" VALUES(2002840,'2016-02-10',17,2,9.67,'Eggs, Yeast, Olive Oil');
INSERT INTO "expense" VALUES(2002841,'2016-02-07',18,2,105,'Baby Goat');
INSERT INTO "expense" VALUES(2002842,'2016-02-07',17,2,6.29,'Shaan, Dhania seeds');
INSERT INTO "expense" VALUES(2002843,'2016-02-09',38,2,16.85,'Frock for Manha');
INSERT INTO "expense" VALUES(2002844,'2016-02-07',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002845,'2016-02-05',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002846,'2016-02-05',2,2,21.9136,'Bathroom Tissue rolls');
INSERT INTO "expense" VALUES(2002847,'2016-02-05',25,2,15.4936,'Kitchen tissue rolls');
INSERT INTO "expense" VALUES(2002848,'2016-02-10',17,2,6.17,'Bournvita');
INSERT INTO "expense" VALUES(2002849,'2016-02-10',17,2,6.38,'Pita Bread, Zatara');
INSERT INTO "expense" VALUES(2002850,'2016-02-10',17,2,15.03,'Vatika Hair oil, cilantro, pudina, tomato, garlic, ginger, lemon, thai chillies, big chillies, Shaan Nihari');
INSERT INTO "expense" VALUES(2002851,'2015-11-27',23,2,32.09,'Samsumg wireless headphones');
INSERT INTO "expense" VALUES(2002852,'2016-02-06',33,2,2.92,'Black beans, Pine apple chunks');
INSERT INTO "expense" VALUES(2002853,'2016-02-06',17,2,2.7,'Yeast - 1.48
Taco Shells - 1');
INSERT INTO "expense" VALUES(2002854,'2016-02-06',21,2,2,'Chips Ahoy');
INSERT INTO "expense" VALUES(2002855,'2016-02-02',38,2,10.68,'Gift to Ali Bhai''s Dawat');
INSERT INTO "expense" VALUES(2002856,'2016-02-12',17,2,2.55,'Bread for Shahi Tukda (Dawat)');
INSERT INTO "expense" VALUES(2002857,'2016-02-12',33,2,15,'Bake Sale');
INSERT INTO "expense" VALUES(2002858,'2016-02-12',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002859,'2016-02-12',17,2,4.59,'Sugar, Coconut flakes');
INSERT INTO "expense" VALUES(2002860,'2016-02-12',17,2,7.19,'Shredded Coconut
Cardamom');
INSERT INTO "expense" VALUES(2002861,'2016-02-16',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002862,'2016-02-16',16,2,0.96,'Banana');
INSERT INTO "expense" VALUES(2002863,'2016-02-16',17,2,4.93,'Eggs, Green Peas');
INSERT INTO "expense" VALUES(2002864,'2016-02-16',21,2,4.48,'Rice Crackers, Andhra Mix');
INSERT INTO "expense" VALUES(2002865,'2016-02-16',17,2,29.75,'Wheat Flour - 8.99
egg plant, turai, Guvar phalli, tomatoes, carrots, chillies, Beans, Bell pepper, Potatoes, onions');
INSERT INTO "expense" VALUES(2002866,'2016-02-13',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002867,'2016-02-13',17,2,6.4,'Roti for Daawat');
INSERT INTO "expense" VALUES(2002868,'2016-02-13',17,2,1.67,'Foam cups (0.98) + tax');
INSERT INTO "expense" VALUES(2002869,'2016-02-13',31,2,6.29,'Bread and Milk (Hamid family)');
INSERT INTO "expense" VALUES(2002870,'2016-02-15',13,2,2.97,'t shirt');
INSERT INTO "expense" VALUES(2002871,'2016-02-15',31,2,5,'chuck e cheese');
INSERT INTO "expense" VALUES(2002872,'2016-02-18',8,2,14.31,'Honda Fit');
INSERT INTO "expense" VALUES(2002873,'2016-02-21',41,2,3.8,'');
INSERT INTO "expense" VALUES(2002874,'2016-02-21',31,2,11.08,'For Hamid''s family
Milk, Bhendi, Squash, Yoghurt');
INSERT INTO "expense" VALUES(2002875,'2016-02-21',17,2,3.36,'Onions');
INSERT INTO "expense" VALUES(2002876,'2016-02-21',2,2,3.87,'Soaps');
INSERT INTO "expense" VALUES(2002877,'2016-02-20',17,2,10.28,'Dates, Lady fingers');
INSERT INTO "expense" VALUES(2002878,'2016-02-19',13,2,17.84,'2 from Macys, 1 from Childern place');
INSERT INTO "expense" VALUES(2002879,'2016-02-19',12,2,4.84,'Macys');
INSERT INTO "expense" VALUES(2002880,'2016-02-19',17,2,22,'Mint, Dosakai, Cookies, Moong, Peeled garlic, ginger, jalebi');
INSERT INTO "expense" VALUES(2002881,'2016-02-19',16,2,0.66,'Avacado');
INSERT INTO "expense" VALUES(2002882,'2016-02-20',12,2,4,'');
INSERT INTO "expense" VALUES(2002883,'2016-02-20',13,2,5,'');
INSERT INTO "expense" VALUES(2002884,'2016-02-20',25,2,0.97,'Flour sack towel');
INSERT INTO "expense" VALUES(2002885,'2016-02-25',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002886,'2016-02-25',21,2,3.08,'Potato Chips');
INSERT INTO "expense" VALUES(2002887,'2016-02-22',15,2,10.7,'Cardigan');
INSERT INTO "expense" VALUES(2002888,'2016-02-24',20,2,10.69,'Pizza from Papa Johns');
INSERT INTO "expense" VALUES(2002889,'2016-02-20',21,2,2.48,'Animal Crackers');
INSERT INTO "expense" VALUES(2002890,'2016-02-22',17,2,4.46,'Tomatoes
Spring roll');
INSERT INTO "expense" VALUES(2002891,'2016-02-22',31,2,16.04,'Games');
INSERT INTO "expense" VALUES(2002892,'2016-02-22',46,2,10.77,'Tide');
INSERT INTO "expense" VALUES(2002893,'2016-02-22',25,2,1.67,'Tooth Paste');
INSERT INTO "expense" VALUES(2002894,'2016-02-22',22,2,7.57,'2 Cafe Rods (2.97 each) + Other items Tax');
INSERT INTO "expense" VALUES(2002895,'2016-02-22',31,2,4.97,'Clue Game');
INSERT INTO "expense" VALUES(2002896,'2016-02-26',38,2,10,'Sharone for her delivery (Office)');
INSERT INTO "expense" VALUES(2002897,'2015-11-25',10,2,34.11,'');
INSERT INTO "expense" VALUES(2002898,'2016-03-05',17,2,23.69,'Lemon(4) - 0.24
Potatoes(0.95lb) - 0.94
Beet Root - 0.63
Tomatoes - 1.97
Guava - 1.32
Karela - 0.86
Methi - 1.39
Mint - 0.99
Chilli - 0.95
Spinach bag - 1.79
Cilantro - 0.69
Bhendi - 3.04
Upma - 2.49
Cake Rusk - 4.99');
INSERT INTO "expense" VALUES(2002899,'2016-03-05',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002900,'2016-02-29',16,2,6.1491,'Oranges');
INSERT INTO "expense" VALUES(2002901,'2016-02-29',17,2,1.9364,'Eggs');
INSERT INTO "expense" VALUES(2002902,'2016-02-29',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002903,'2016-02-29',17,2,0.7,'Broccoli');
INSERT INTO "expense" VALUES(2002904,'2016-02-26',8,2,7.9,'Honda Fit');
INSERT INTO "expense" VALUES(2002905,'2016-02-27',17,2,38.66,'');
INSERT INTO "expense" VALUES(2002906,'2016-02-26',16,2,1.33,'Banana');
INSERT INTO "expense" VALUES(2002907,'2016-02-26',30,2,2.83,'Vitamin D');
INSERT INTO "expense" VALUES(2002908,'2016-03-05',12,2,2.56,'T-Shirt');
INSERT INTO "expense" VALUES(2002909,'2016-03-06',20,2,30.04,'Mughals');
INSERT INTO "expense" VALUES(2002910,'2016-03-05',17,2,18.52,'Paratha - 8.99
Red Onions - 8.99');
INSERT INTO "expense" VALUES(2002911,'2016-03-07',33,2,310,'Quran Classes');
INSERT INTO "expense" VALUES(2002912,'2016-03-07',16,2,2.22,'Banana, Avocado');
INSERT INTO "expense" VALUES(2002913,'2016-03-07',17,2,2.8222,'Vegetable Oil');
INSERT INTO "expense" VALUES(2002914,'2016-03-07',17,2,2.06,'Oats');
INSERT INTO "expense" VALUES(2002915,'2016-03-10',8,2,17.55,'Honda Fit');
INSERT INTO "expense" VALUES(2002916,'2016-03-10',27,2,38,'Copay - 20 (3 year check up )
Admin Fees - 18');
INSERT INTO "expense" VALUES(2002917,'2016-02-10',27,2,20,'');
INSERT INTO "expense" VALUES(2002918,'2016-02-10',28,2,20,'');
INSERT INTO "expense" VALUES(2002919,'2016-03-11',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002920,'2016-03-12',13,2,0.52,'jacket (after discount)');
INSERT INTO "expense" VALUES(2002921,'2016-03-12',19,2,7.98,'');
INSERT INTO "expense" VALUES(2002922,'2016-03-12',31,2,10.7,'Sun glasses
Sandals');
INSERT INTO "expense" VALUES(2002923,'2016-03-14',35,2,42.5,'MARTA');
INSERT INTO "expense" VALUES(2002924,'2016-03-08',32,2,6.2,'Pedicure Kit from Walgreens');
INSERT INTO "expense" VALUES(2002925,'2016-03-16',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002926,'2016-03-08',30,2,16.88,'Iron and B12');
INSERT INTO "expense" VALUES(2002927,'2016-03-09',44,2,39.58,'Thermometer');
INSERT INTO "expense" VALUES(2002928,'2016-03-11',17,2,4.1,'Bread from global market');
INSERT INTO "expense" VALUES(2002929,'2016-03-12',21,2,1.89,'Tortilla Chips');
INSERT INTO "expense" VALUES(2002930,'2016-03-12',17,2,14.42,'Kroger
=====
Mac and Cheese
Elbows
Nutela
Salt
Eggs');
INSERT INTO "expense" VALUES(2002931,'2016-03-12',16,2,1.68,'Strawberry from Kroger');
INSERT INTO "expense" VALUES(2002932,'2016-03-12',17,2,6.95,'Red Whip Cream from Sams Club');
INSERT INTO "expense" VALUES(2002933,'2016-03-13',17,2,68,'Cherians');
INSERT INTO "expense" VALUES(2002934,'2016-03-11',8,2,41.27,'Honda Odyssey (19.6 G/$2.09)');
INSERT INTO "expense" VALUES(2002935,'2016-03-19',8,2,18.43,'Honda Fit (8.3 G / $ 2.19)');
INSERT INTO "expense" VALUES(2002936,'2016-03-19',32,2,11.99,'Hair Cut');
INSERT INTO "expense" VALUES(2002937,'2016-03-19',17,2,10.61,'Lemon, Cilantro, tomatoes, brocoli, potatoes, curry leaves, mint, tindora');
INSERT INTO "expense" VALUES(2002938,'2016-03-19',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002939,'2016-03-19',17,2,3.48,'Natures Own Butter Bread from Whole Foods Market');
INSERT INTO "expense" VALUES(2002940,'2016-03-19',12,2,5.3393,'Hoody Jacket');
INSERT INTO "expense" VALUES(2002941,'2016-03-19',13,2,16.03,'Pant and Shoes');
INSERT INTO "expense" VALUES(2002942,'2016-03-20',31,2,25.68,'hand bag for shahana');
INSERT INTO "expense" VALUES(2002943,'2016-03-20',25,2,9.62,'Water bottle, lunch storage boxes ');
INSERT INTO "expense" VALUES(2002944,'2016-03-20',16,2,4.61,'banana, cantaloupe, apples');
INSERT INTO "expense" VALUES(2002945,'2016-03-20',2,2,4.82,'Shampoo (Dandruff and Normal)');
INSERT INTO "expense" VALUES(2002946,'2016-03-20',17,2,12.89,'Fruit Loops, Ceddar Cheese, Ovaltine Malt, Cucumber, Salad and tax of other items');
INSERT INTO "expense" VALUES(2002947,'2016-03-20',36,2,5.46,'Salmon Frozen from walmart');
INSERT INTO "expense" VALUES(2002948,'2016-03-24',27,2,20,'Nose Bleeding');
INSERT INTO "expense" VALUES(2002949,'2016-03-24',39,2,7.48,'NeilMed Naso Gel for both Aalia and Hafsa');
INSERT INTO "expense" VALUES(2002950,'2016-03-24',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002951,'2016-03-24',16,2,4.67,'Oranges');
INSERT INTO "expense" VALUES(2002952,'2016-03-24',17,2,6.27,'Butter, Eggs');
INSERT INTO "expense" VALUES(2002953,'2016-03-23',30,2,2.7,'Vit D from walgreens');
INSERT INTO "expense" VALUES(2002954,'2016-03-29',41,2,7.61,'');
INSERT INTO "expense" VALUES(2002955,'2016-03-30',17,2,6.34,'Ice Cream, Cilantro, Black Beans');
INSERT INTO "expense" VALUES(2002956,'2016-03-31',17,2,4.46,'Sour Cream, Jalapenos, Salsa');
INSERT INTO "expense" VALUES(2002957,'2016-03-30',17,2,24.47,'From Spices Hut');
INSERT INTO "expense" VALUES(2002958,'2016-03-29',32,2,4.97,'Aveeno Baby Cream');
INSERT INTO "expense" VALUES(2002959,'2016-03-29',17,2,1.98,'Eggs');
INSERT INTO "expense" VALUES(2002960,'2016-03-29',16,2,8.54,'Kiwi, avacado, Banana, Water Melon');
INSERT INTO "expense" VALUES(2002961,'2016-04-02',20,2,21.37,'Karachi Broast');
INSERT INTO "expense" VALUES(2002962,'2016-04-06',17,2,3.7236,'Eggs, Sugar');
INSERT INTO "expense" VALUES(2002963,'2016-04-06',46,2,11.44,'Tide');
INSERT INTO "expense" VALUES(2002964,'2016-04-06',9,2,1.0094,'Perfume for car');
INSERT INTO "expense" VALUES(2002965,'2016-04-01',38,2,25,'Gift for Zaheer Bhai Daawat');
INSERT INTO "expense" VALUES(2002966,'2016-04-02',18,2,119.9149,'Full goat, Keema');
INSERT INTO "expense" VALUES(2002967,'2016-04-02',17,2,5.4249,'Mash Mallons, Seek Kabab, Sindh Biryani');
INSERT INTO "expense" VALUES(2002968,'2016-04-02',18,2,52.5156,'Chicken');
INSERT INTO "expense" VALUES(2002969,'2016-04-02',17,2,25.6586,'Basmati Rics, Samosas');
INSERT INTO "expense" VALUES(2002970,'2016-04-06',41,2,7.61,'');
INSERT INTO "expense" VALUES(2002971,'2016-04-06',17,2,22.47,'Rice, Tomatoes');
INSERT INTO "expense" VALUES(2002972,'2016-04-06',17,2,5.11,'Pita Bread');
INSERT INTO "expense" VALUES(2002973,'2016-04-06',8,2,16.96,'Honda Fit');
INSERT INTO "expense" VALUES(2002974,'2016-04-05',17,2,49.35,'Cherians');
INSERT INTO "expense" VALUES(2002975,'2016-04-05',8,2,44.91,'Honda Oddysey');
INSERT INTO "expense" VALUES(2002976,'2016-04-06',2,2,5.21,'Tooth paste');
INSERT INTO "expense" VALUES(2002977,'2016-04-16',17,2,31.66,'');
INSERT INTO "expense" VALUES(2002978,'2016-04-16',16,2,11.07,'Pears, Nectarine, Apple, Grape, Kiwi');
INSERT INTO "expense" VALUES(2002979,'2016-04-16',17,2,1.42,'lettuce, taro');
INSERT INTO "expense" VALUES(2002980,'2016-04-16',21,2,3.45,'Rusk, Quaker Capn Crunch');
INSERT INTO "expense" VALUES(2002981,'2016-04-06',33,2,40,'Yearly Book - 20
Field Trip - 20');
INSERT INTO "expense" VALUES(2002982,'2016-04-19',28,2,38,'Admin Fees : 20
Co Pay : 20');
INSERT INTO "expense" VALUES(2002983,'2016-04-19',17,2,5.44,'Curry Leaves
Chilli Powder');
INSERT INTO "expense" VALUES(2002984,'2016-04-19',20,2,18.18,'Papa Johns Pizza');
INSERT INTO "expense" VALUES(2002985,'2016-04-19',30,2,5,'Vitamin D');
INSERT INTO "expense" VALUES(2002986,'2016-04-19',28,2,2.7,'Ointment  for Nose ');
INSERT INTO "expense" VALUES(2002987,'2016-04-20',17,2,8.88,'Bread, Eggs, Honey');
INSERT INTO "expense" VALUES(2002988,'2016-04-17',41,2,3.81,'');
INSERT INTO "expense" VALUES(2002989,'2016-04-13',41,2,7.61,'');
INSERT INTO "expense" VALUES(2002990,'2016-04-10',17,2,7.16,'Garlic, Coconut Oil');
INSERT INTO "expense" VALUES(2002991,'2016-04-09',16,2,1,'Tangerines');
INSERT INTO "expense" VALUES(2002992,'2016-04-09',36,2,10.75,'Shrimp & Fish');
INSERT INTO "expense" VALUES(2002993,'2016-04-09',21,2,3.43,'Lychee Je;;y for kids');
INSERT INTO "expense" VALUES(2002994,'2016-04-10',31,2,0.7107,'Double Mint Gum');
INSERT INTO "expense" VALUES(2002995,'2016-04-10',25,2,1.391,'Dish Washing Liquid');
INSERT INTO "expense" VALUES(2002996,'2016-04-10',17,2,6.15,'Pancake Mix, Elbows, Bread');
INSERT INTO "expense" VALUES(2002997,'2016-04-10',21,2,5.1294,'Nature Valley Bars');
INSERT INTO "expense" VALUES(2002998,'2016-04-10',25,2,4.2586,'Trash Can covers');
INSERT INTO "expense" VALUES(2002999,'2016-04-17',16,2,1.4008,'Banana');
INSERT INTO "expense" VALUES(2003000,'2016-04-17',17,2,0.5871,'Tomato paste');
INSERT INTO "expense" VALUES(2003001,'2016-04-17',32,2,6.9336,'ACT Mouth Wash');
INSERT INTO "expense" VALUES(2003002,'2016-04-16',21,2,2.6574,'Sugar Free Cookies');
INSERT INTO "expense" VALUES(2003003,'2016-04-16',17,2,3.0591,'Potatoes');
INSERT INTO "expense" VALUES(2003004,'2016-04-12',16,2,2.61,'Banana, Cantelope');
INSERT INTO "expense" VALUES(2003005,'2016-04-12',32,2,5,'Moisturizer');
INSERT INTO "expense" VALUES(2003006,'2016-04-09',36,2,7.67,'Dekalb Farmers Market');
INSERT INTO "expense" VALUES(2003007,'2016-04-09',16,2,5.36,'Guava, Apples, Papaya');
INSERT INTO "expense" VALUES(2003008,'2016-04-09',17,2,14.53,'Snap Beans, Corn, Egg Plant, green onions, onions, radish');
INSERT INTO "expense" VALUES(2003009,'2016-04-09',17,2,23.4,'Patel Brothers');
INSERT INTO "expense" VALUES(2003010,'2016-04-07',16,2,6.9,'Kiwi, Avacado, Apples');
INSERT INTO "expense" VALUES(2003011,'2016-04-07',31,2,10.19,'Purchase for India - Candle, Slippers, Bracelet, Straws');
INSERT INTO "expense" VALUES(2003012,'2016-04-07',2,2,0.88,'Mug');
INSERT INTO "expense" VALUES(2003013,'2016-04-23',21,2,7.88,'Chips, Donuts, Starbucks coffee');
INSERT INTO "expense" VALUES(2003014,'2016-04-24',17,2,17.5,'rice');
INSERT INTO "expense" VALUES(2003015,'2016-04-23',16,2,10.9,'Plums, Papaya, Pear, Peach, Cantalope');
INSERT INTO "expense" VALUES(2003016,'2016-04-24',41,2,7.61,'');
INSERT INTO "expense" VALUES(2003017,'2016-04-23',8,2,42.94,'Honda Odyssey');
INSERT INTO "expense" VALUES(2003018,'2016-04-24',17,2,34.02,'Cherians');
INSERT INTO "expense" VALUES(2003019,'2016-04-26',16,2,1.5,'Banana');
INSERT INTO "expense" VALUES(2003020,'2016-04-26',39,2,8.96,'Equate, Vicks (4.98)');
INSERT INTO "expense" VALUES(2003021,'2016-04-26',17,2,5.06,'Salt, Oats');
INSERT INTO "expense" VALUES(2003022,'2016-04-26',31,2,4.93,'For India - Kadai');
INSERT INTO "expense" VALUES(2003023,'2016-04-24',31,2,22.76,'For India - Hanger, Clips, Sink Set, Glass, liner');
INSERT INTO "expense" VALUES(2003024,'2016-04-26',8,2,20.14,'Honda Fit');
INSERT INTO "expense" VALUES(2003025,'2016-05-05',17,2,4.99,'Tomatoes, Bell pepper, Curry leaves, cilantro');
INSERT INTO "expense" VALUES(2003026,'2016-05-03',41,2,7.41,'');
INSERT INTO "expense" VALUES(2003027,'2016-05-02',30,2,22.84,'Co pay and Medicines');
INSERT INTO "expense" VALUES(2003028,'2016-05-02',31,2,2,'Skittles for India');
INSERT INTO "expense" VALUES(2003029,'2016-04-30',20,2,8.22,'Fries, Hummus Falafel roll (northpoint Mall)');
INSERT INTO "expense" VALUES(2003030,'2016-04-29',41,2,3.08,'');
INSERT INTO "expense" VALUES(2003031,'2016-04-29',17,2,24.61,'Kawan Paratha, Sher-e-punjab naan, tindora, cauliflower, karela, gongura, gawar ki phalli');
INSERT INTO "expense" VALUES(2003032,'2016-05-01',8,2,24.19,'Honda Odyssey');
INSERT INTO "expense" VALUES(2003033,'2016-05-01',19,2,21.23,'Ranch, Cooking Spray, Corn, Bread, Charcoal, cake');
INSERT INTO "expense" VALUES(2003034,'2016-05-04',36,2,5.15,'Shrimp from walmart');
INSERT INTO "expense" VALUES(2003035,'2016-05-04',21,2,8.1576,'Graham Crackers, Belvita');
INSERT INTO "expense" VALUES(2003036,'2016-05-04',17,2,1.545,'Eggs');
INSERT INTO "expense" VALUES(2003037,'2016-05-04',16,2,8.24,'Oranges, Kiwi, Avacado, Apples');
INSERT INTO "expense" VALUES(2003038,'2016-05-03',2,2,19.1102,'Bathroom tissues');
INSERT INTO "expense" VALUES(2003039,'2016-05-03',21,2,6.1594,'Humus Crisps from Sams club');
INSERT INTO "expense" VALUES(2003040,'2016-05-08',32,2,22.98,'Hair Cut for me and Aalia');
INSERT INTO "expense" VALUES(2003041,'2016-05-07',31,2,33.48,'For India from Walmart');
INSERT INTO "expense" VALUES(2003042,'2016-05-07',46,2,9.97,'Tide');
INSERT INTO "expense" VALUES(2003043,'2016-05-07',31,2,20.33,'for India from Dollar Tree');
INSERT INTO "expense" VALUES(2003044,'2016-05-08',17,2,55.69,'Spices Hut');
INSERT INTO "expense" VALUES(2003045,'2016-05-08',20,2,48.65,'Mughals');
INSERT INTO "expense" VALUES(2003046,'2016-05-08',8,2,46.14,'Honda Odyssey');
INSERT INTO "expense" VALUES(2003047,'2016-05-07',31,2,63.13,'for India - Ring for Ammi');
INSERT INTO "expense" VALUES(2003048,'2016-04-29',31,2,46.94,'HP Screen from Amazon');
INSERT INTO "expense" VALUES(2003049,'2016-05-11',17,2,10.96,'Flour, Condensed Milk, Yeat, Eggs, Coconut flakes');
INSERT INTO "expense" VALUES(2003050,'2016-05-13',33,2,20,'For PTO');
INSERT INTO "expense" VALUES(2003051,'2016-05-04',33,2,25,'Teacher Appreciation');
INSERT INTO "expense" VALUES(2003052,'2016-05-15',17,2,51.44,'from Cherians');
INSERT INTO "expense" VALUES(2003053,'2016-05-15',36,2,8.4,'Tilapia');
INSERT INTO "expense" VALUES(2003054,'2016-05-15',19,2,4.99,'Lychee for India');
INSERT INTO "expense" VALUES(2003055,'2016-05-15',16,2,13.66,'Cherries, Kiwi, Water melon, Green Apples, Black berries');
INSERT INTO "expense" VALUES(2003056,'2016-05-15',17,2,0.48,'Raddish');
INSERT INTO "expense" VALUES(2003057,'2016-05-15',17,2,6.15,'Sheermal from Global market');
INSERT INTO "expense" VALUES(2003058,'2016-05-14',8,2,20.45,'Honda Fit');
INSERT INTO "expense" VALUES(2003059,'2016-05-14',18,2,39.29,'Goat Paya (2lbs) - 18.31
Chicken (4) - 20.98');
INSERT INTO "expense" VALUES(2003060,'2016-05-14',17,2,4.45,'Basil Drink, Cilantro for Achaar');
INSERT INTO "expense" VALUES(2003061,'2016-05-10',41,2,7.61,'');
INSERT INTO "expense" VALUES(2003062,'2016-05-13',31,2,10.6893,'mesh to drain rice for india');
INSERT INTO "expense" VALUES(2003063,'2016-05-13',38,2,8.5493,'Gift for Hamid Daawat');
INSERT INTO "expense" VALUES(2003064,'2016-05-13',22,2,6.4093,'Storage bin for prayer mats');
INSERT INTO "expense" VALUES(2003065,'2016-05-16',17,2,3.09,'Oats from publix');
INSERT INTO "expense" VALUES(2003066,'2016-05-10',31,2,5.34,'Water bottle for India');
INSERT INTO "expense" VALUES(2003067,'2016-05-16',16,2,2.4102,'Banana');
INSERT INTO "expense" VALUES(2003068,'2016-05-16',17,2,1.1124,'Salt');
INSERT INTO "expense" VALUES(2003069,'2016-05-06',31,2,11.72,'Sandals, Clothing for India');
INSERT INTO "expense" VALUES(2003070,'2016-05-10',16,2,1.0197,'Banana');
INSERT INTO "expense" VALUES(2003071,'2016-05-11',17,2,7.46,'Walnut halves');
INSERT INTO "expense" VALUES(2003072,'2016-05-10',25,2,3.1672,'');
INSERT INTO "expense" VALUES(2003073,'2016-05-10',2,2,5.3286,'Shampoo');
INSERT INTO "expense" VALUES(2003074,'2016-05-16',33,2,12,'Field Day Contribution');
INSERT INTO "expense" VALUES(2003075,'2016-05-11',29,2,27.25,'Co Pay - 20 for Urologist visit and rest medicines');
INSERT INTO "expense" VALUES(2003076,'2016-05-11',25,2,4.28,'Glasses for home');
INSERT INTO "expense" VALUES(2003077,'2016-05-16',45,2,45,'Medicines for Abba');
INSERT INTO "expense" VALUES(2003078,'2016-04-24',31,2,70.25,'For India - bouncer, bottle, etc');
INSERT INTO "expense" VALUES(2003079,'2016-04-24',31,2,10.99,'Belt for me');
INSERT INTO "expense" VALUES(2003080,'2016-04-24',31,2,38.47,'For India from Marshals - storage, Spoon holder, blanket for baby');
INSERT INTO "expense" VALUES(2003081,'2016-05-17',41,2,7.61,'');
INSERT INTO "expense" VALUES(2003082,'2016-05-17',17,2,7.72,'Onions, tomatoes, cookies');
INSERT INTO "expense" VALUES(2003083,'2016-05-14',20,2,16.85,'Bagel Boys');
INSERT INTO "expense" VALUES(2003084,'2016-05-23',35,2,42.5,'Transport');
INSERT INTO "expense" VALUES(2003085,'2016-05-25',20,2,7.02,'Missed to bring lunch box');
INSERT INTO "expense" VALUES(2003086,'2016-05-26',8,2,48.64,'Honda Odyssey');
INSERT INTO "expense" VALUES(2003087,'2016-05-25',17,2,21.79,'Lemon ,tomotoes, tindora, eggplant, toor daal, moong daal, cilantro, turai');
INSERT INTO "expense" VALUES(2003088,'2016-05-24',41,2,7.61,'');
INSERT INTO "expense" VALUES(2003089,'2016-05-27',8,2,17.99,'Honda Fit');
INSERT INTO "expense" VALUES(2003090,'2016-05-26',31,2,5.34,'Moisturizer for India');
INSERT INTO "expense" VALUES(2003091,'2016-05-21',31,2,16.05,'for India from Dollar Tree');
INSERT INTO "expense" VALUES(2003092,'2016-05-30',42,2,95,'Smoky Mountains
Parking - 5
Tram - 36
Scenic chair lift - 21
Earthquake Ride - 18
Star bucks coffee - 8
Magnets - 7
');
INSERT INTO "expense" VALUES(2003093,'2016-06-01',41,2,7.61,'');
INSERT INTO "expense" VALUES(2003094,'2016-05-29',16,2,2.79,'Banana, Kiwi, Peaches');
INSERT INTO "expense" VALUES(2003095,'2016-05-29',31,2,16.89,'Baby lotion, Choclates for India, balloons');
INSERT INTO "expense" VALUES(2003096,'2016-05-29',17,2,2.5,'egss');
INSERT INTO "expense" VALUES(2003097,'2016-05-29',21,2,2.73,'Lays');
INSERT INTO "expense" VALUES(2003098,'2016-05-21',31,2,7.81,'for India - Pan cake syrup, pan cake mix, Ranch');
INSERT INTO "expense" VALUES(2003099,'2016-05-21',19,2,3.99,'Cake');
INSERT INTO "expense" VALUES(2003100,'2016-06-02',8,2,18.99,'Honda Odyssey');
INSERT INTO "expense" VALUES(2003101,'2016-05-29',17,2,42.28,'spices hut');
INSERT INTO "expense" VALUES(2003102,'2016-05-21',19,2,12.78,'cup cakes for school, greek yogurt, ');
INSERT INTO "expense" VALUES(2003103,'2016-06-02',31,2,1.2,'Page Markers for India');
INSERT INTO "expense" VALUES(2003104,'2016-06-02',24,2,1.2,'Duck tape');
INSERT INTO "expense" VALUES(2003105,'2016-05-31',39,2,6.36,'Advil tablets');
INSERT INTO "expense" VALUES(2003106,'2016-05-23',38,2,9.26,'Cake for Zaheer bhai');
INSERT INTO "expense" VALUES(2003107,'2016-05-27',38,2,9.26,'Cake for Br Kamal (Kerala)');
INSERT INTO "expense" VALUES(2003108,'2016-05-31',31,2,14.11,'Shopping Cart for India');
INSERT INTO "expense" VALUES(2003109,'2016-05-15',31,2,9.61,'Storage for India');
INSERT INTO "expense" VALUES(2003110,'2016-05-29',31,2,11.77,'from Dollar Tree for India');
INSERT INTO "expense" VALUES(2003111,'2016-05-19',19,2,7,'Cup cake for school, cheese');
INSERT INTO "expense" VALUES(2003112,'2016-05-19',25,2,1.99,'plastic wrap');
INSERT INTO "expense" VALUES(2003113,'2016-05-21',31,2,45.42,'for India from walmrt');
INSERT INTO "expense" VALUES(2003114,'2016-05-29',19,2,7.5,'Bread for Smoky Trip');
INSERT INTO "expense" VALUES(2003115,'2016-05-29',17,2,2.27,'Pan cake syrup');
INSERT INTO "expense" VALUES(2003116,'2016-06-06',8,2,17.54,'Honda Odyssey');
DROP TABLE IF EXISTS "exportmodules";
CREATE TABLE "exportmodules" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "exportmodules" VALUES(1,'Fund Transfers',NULL);
INSERT INTO "exportmodules" VALUES(2,'Contacts',NULL);
INSERT INTO "exportmodules" VALUES(3,'Credentials',NULL);
DROP TABLE IF EXISTS "fundstransfer";
CREATE TABLE "fundstransfer" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "referenceno" text NOT NULL,
  "datesent" text NOT NULL,
  "transferredto" integer NOT NULL,
  "user" integer NOT NULL,
  "amount"integer NOT NULL,
  "destamount" integer DEFAULT NULL,
  "notes" blob DEFAULT NULL,
  CONSTRAINT "FKFUNDSTRANSFER_ACCT" FOREIGN KEY ("transferredto") REFERENCES "account" ("id"),
  CONSTRAINT "FKFUNDSTRANSFER_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "fundstransfer" VALUES(2002001,'1695742001','2008-11-17',3,2,1200,59709,'');
INSERT INTO "fundstransfer" VALUES(2002002,'1695742002','2008-11-21',3,2,1500,73950,NULL);
INSERT INTO "fundstransfer" VALUES(2002003,'1695742003','2008-12-07',3,2,1500,72195,NULL);
INSERT INTO "fundstransfer" VALUES(2002004,'1695742004','2008-12-22',2,2,1000,46909,NULL);
INSERT INTO "fundstransfer" VALUES(2002005,'1695742005','2008-12-29',3,2,500,23955,NULL);
INSERT INTO "fundstransfer" VALUES(2002006,'1695742006','2009-01-06',2,2,1001,48313,NULL);
INSERT INTO "fundstransfer" VALUES(2002007,'1695742007','2009-01-19',3,2,1001,48463,NULL);
INSERT INTO "fundstransfer" VALUES(2002008,'1695742008','2009-01-21',2,2,1001,48233,NULL);
INSERT INTO "fundstransfer" VALUES(2002009,'1695742009','2009-02-20',3,2,1001,49292,NULL);
INSERT INTO "fundstransfer" VALUES(2002010,'1695742010','2009-03-06',2,2,1001,50926,NULL);
INSERT INTO "fundstransfer" VALUES(2002011,'1695742011','2009-03-24',2,2,1001,50215,NULL);
INSERT INTO "fundstransfer" VALUES(2002012,'1695742012','2009-03-24',3,2,1100,55189,NULL);
INSERT INTO "fundstransfer" VALUES(2002013,'1695742013','2009-04-24',3,2,1001,49555,NULL);
INSERT INTO "fundstransfer" VALUES(2002014,'1695742014','2009-05-12',2,2,1100,53693,NULL);
INSERT INTO "fundstransfer" VALUES(2002015,'1695742015','2009-05-20',3,2,1001,46882,NULL);
INSERT INTO "fundstransfer" VALUES(2002016,'1695742016','2009-06-08',2,2,1100,51460,NULL);
INSERT INTO "fundstransfer" VALUES(2002017,'1695742017','2009-06-08',3,2,1000,46571,NULL);
INSERT INTO "fundstransfer" VALUES(2002018,'1695742018','2009-07-11',3,2,1000,47705,NULL);
INSERT INTO "fundstransfer" VALUES(2002019,'1695742019','2009-08-24',3,2,1150,55482,NULL);
INSERT INTO "fundstransfer" VALUES(2002020,'1695742020','2009-09-19',3,2,1100,52274,NULL);
INSERT INTO "fundstransfer" VALUES(2002021,'1695742021','2009-10-16',3,2,1100,50316,NULL);
INSERT INTO "fundstransfer" VALUES(2002022,'1695742022','2009-11-10',3,2,1500,68295,NULL);
INSERT INTO "fundstransfer" VALUES(2002023,'1695742023','2009-12-15',3,2,1150,53124,NULL);
INSERT INTO "fundstransfer" VALUES(2002024,'1695742024','2010-01-05',2,2,1500,67905,NULL);
INSERT INTO "fundstransfer" VALUES(2002025,'1695742025','2010-01-19',3,2,1100,50129,NULL);
INSERT INTO "fundstransfer" VALUES(2002026,'1695742026','2010-02-22',3,2,1100,50294,NULL);
INSERT INTO "fundstransfer" VALUES(2002027,'1695742027','2010-02-25',2,2,1500,68310,NULL);
INSERT INTO "fundstransfer" VALUES(2002028,'1695742028','2010-03-22',3,2,1100,49535,NULL);
INSERT INTO "fundstransfer" VALUES(2002029,'1695742029','2010-03-29',2,2,2000,88705,NULL);
INSERT INTO "fundstransfer" VALUES(2002030,'1695742030','2010-04-26',2,2,2001,88269,NULL);
INSERT INTO "fundstransfer" VALUES(2002031,'1695742031','2010-04-26',3,2,1001,43999,NULL);
INSERT INTO "fundstransfer" VALUES(2002032,'1695742032','2010-05-17',2,2,1010,46244,NULL);
INSERT INTO "fundstransfer" VALUES(2002033,'1695742033','2010-05-17',3,2,1100,50371,NULL);
INSERT INTO "fundstransfer" VALUES(2002034,'1695742034','2010-06-21',2,2,2001,91551,NULL);
INSERT INTO "fundstransfer" VALUES(2002035,'1695742035','2010-06-21',3,2,1100,50162,NULL);
INSERT INTO "fundstransfer" VALUES(2002036,'1695742036','2010-07-19',2,2,1010,47092,NULL);
INSERT INTO "fundstransfer" VALUES(2002037,'1695742037','2010-07-19',3,2,1100,51295,NULL);
INSERT INTO "fundstransfer" VALUES(2002038,'1695742038','2010-08-24',2,2,2100,97239,NULL);
INSERT INTO "fundstransfer" VALUES(2002039,'1695742039','2010-09-21',3,2,1050,47123,NULL);
INSERT INTO "fundstransfer" VALUES(2002040,'1695742040','2010-10-18',3,2,1001,43768,NULL);
INSERT INTO "fundstransfer" VALUES(2002041,'1695742041','2010-10-18',2,2,2001,87799,NULL);
INSERT INTO "fundstransfer" VALUES(2002042,'1695742042','2010-11-24',3,2,1261,57069,NULL);
INSERT INTO "fundstransfer" VALUES(2002043,'1695742043','2010-12-20',2,2,1100,48893,NULL);
INSERT INTO "fundstransfer" VALUES(2002044,'1695742044','2011-01-13',2,2,2300,103379,NULL);
INSERT INTO "fundstransfer" VALUES(2002045,'1695742045','2011-01-26',2,2,2300,104791,NULL);
INSERT INTO "fundstransfer" VALUES(2002046,'1695742046','2011-02-15',2,2,1100,49089,NULL);
INSERT INTO "fundstransfer" VALUES(2002047,'1695742047','2011-02-15',3,2,2200,98357,NULL);
INSERT INTO "fundstransfer" VALUES(2002048,'1695742048','2011-02-23',2,2,3500,156695,NULL);
INSERT INTO "fundstransfer" VALUES(2002049,'1695742049','2011-03-28',4,2,1400,61345,NULL);
INSERT INTO "fundstransfer" VALUES(2002050,'1695742050','2011-03-28',2,2,2100,92760,NULL);
INSERT INTO "fundstransfer" VALUES(2002051,'1695742051','2011-04-04',3,2,3100,135616,NULL);
INSERT INTO "fundstransfer" VALUES(2002052,'1695742052','2011-04-18',3,2,2100,92002,NULL);
INSERT INTO "fundstransfer" VALUES(2002053,'1695742053','2011-05-18',2,2,1100,48990,NULL);
INSERT INTO "fundstransfer" VALUES(2002054,'1695742054','2011-05-18',3,2,1100,48990,NULL);
INSERT INTO "fundstransfer" VALUES(2002055,'1695742055','2011-06-06',3,2,1500,66273,NULL);
INSERT INTO "fundstransfer" VALUES(2002056,'1695742056','2011-06-20',3,2,1100,48664,NULL);
INSERT INTO "fundstransfer" VALUES(2002057,'1695742057','2011-06-30',2,2,1600,70150,NULL);
INSERT INTO "fundstransfer" VALUES(2002058,'1695742058','2011-07-11',5,2,1100,48189,NULL);
INSERT INTO "fundstransfer" VALUES(2002059,'1695742059','2011-07-18',2,2,1600,70277,NULL);
INSERT INTO "fundstransfer" VALUES(2002060,'1695742060','2011-08-05',2,2,1600,71156,NULL);
INSERT INTO "fundstransfer" VALUES(2002061,'1695742061','2011-09-19',2,2,1100,52782,NULL);
INSERT INTO "fundstransfer" VALUES(2002062,'1695742062','2011-09-27',2,2,2100,102296,NULL);
INSERT INTO "fundstransfer" VALUES(2002063,'1695742063','2011-10-18',1,2,1300,64437,NULL);
INSERT INTO "fundstransfer" VALUES(2002064,'1695742064','2011-11-09',1,2,1300,65145,NULL);
INSERT INTO "fundstransfer" VALUES(2002065,'1695742065','2011-11-29',5,2,1300,66097,NULL);
INSERT INTO "fundstransfer" VALUES(2002066,'1695742066','2011-12-13',1,2,1300,67667,NULL);
INSERT INTO "fundstransfer" VALUES(2002067,'1695742067','2012-01-19',1,2,1300,67343,NULL);
INSERT INTO "fundstransfer" VALUES(2002068,'1695742068','2012-02-08',4,2,6100,0,'Closed');
INSERT INTO "fundstransfer" VALUES(2002069,'1695742069','2012-02-16',4,2,6100,295488,NULL);
INSERT INTO "fundstransfer" VALUES(2002070,'1695742070','2012-03-12',4,2,1300,64397,NULL);
INSERT INTO "fundstransfer" VALUES(2002071,'1695742071','2012-04-09',4,2,1600,81552,NULL);
INSERT INTO "fundstransfer" VALUES(2002072,'1695742072','2012-04-16',1,2,1300,66832,NULL);
INSERT INTO "fundstransfer" VALUES(2002073,'1695742073','2012-05-06',2,2,2600,137594,'SBI Life Insurance');
INSERT INTO "fundstransfer" VALUES(2002074,'1695742074','2012-05-21',2,2,1300,71262,NULL);
INSERT INTO "fundstransfer" VALUES(2002075,'1695742075','2012-06-04',4,2,1300,70786,NULL);
INSERT INTO "fundstransfer" VALUES(2002076,'1695742076','2012-06-04',1,2,1600,87138,NULL);
INSERT INTO "fundstransfer" VALUES(2002077,'1695742077','2012-06-25',4,2,1200,65809,NULL);
INSERT INTO "fundstransfer" VALUES(2002078,'1695742078','2012-07-25',1,2,1600,87598,NULL);
INSERT INTO "fundstransfer" VALUES(2002079,'1695742079','2012-08-03',1,2,1300,71066,NULL);
INSERT INTO "fundstransfer" VALUES(2002080,'1695742080','2012-08-10',1,2,2100,115431,NULL);
INSERT INTO "fundstransfer" VALUES(2002081,'1695742081','2012-09-12',2,2,1300,69752,NULL);
INSERT INTO "fundstransfer" VALUES(2002082,'1695742082','2012-10-20',1,2,1300,69044,NULL);
INSERT INTO "fundstransfer" VALUES(2002083,'1695742083','2012-11-09',2,2,1300,70124,'');
INSERT INTO "fundstransfer" VALUES(2002084,'1695742084','2012-12-15',2,2,1300,NULL,'');
INSERT INTO "fundstransfer" VALUES(2002085,'X061897859282994','2013-08-21',2,2,650,40641,'');
INSERT INTO "fundstransfer" VALUES(2002086,'X061895073730255','2013-08-21',6,2,500,31505,'');
INSERT INTO "fundstransfer" VALUES(2002087,'X061862428712637','2013-09-13',7,2,355,216,'To UK : 216 pounds');
INSERT INTO "fundstransfer" VALUES(2002088,'X061826285974043','2013-09-26',2,2,670,40764,'');
INSERT INTO "fundstransfer" VALUES(2002089,'X061899553080381','2013-10-22',2,2,1050,63945,'');
INSERT INTO "fundstransfer" VALUES(2002090,'X061886394188367','2013-11-25',2,2,655,40105,'');
INSERT INTO "fundstransfer" VALUES(2002091,'X061867101885812','2013-11-25',6,2,830,50902,'');
INSERT INTO "fundstransfer" VALUES(2002092,'X061892293885097','2013-12-23',2,2,655,39871,'');
INSERT INTO "fundstransfer" VALUES(2002093,'X061846548751427','2013-12-23',6,2,830,50606,'');
INSERT INTO "fundstransfer" VALUES(2002094,'X061806857532445 ','2014-01-20',2,2,655,39455,'');
INSERT INTO "fundstransfer" VALUES(2002095,'X061839509961919','2014-01-20',6,2,830,50078,'');
INSERT INTO "fundstransfer" VALUES(2002096,'X061840707299065','2014-04-02',2,2,685,39977,'');
INSERT INTO "fundstransfer" VALUES(2002097,'X061836539195925','2014-04-07',2,2,655,38545,'');
INSERT INTO "fundstransfer" VALUES(2002098,'X061824138006108','2014-05-05',2,2,855,50405,'');
INSERT INTO "fundstransfer" VALUES(2002099,'X061891633297038','2014-05-05',4,2,855,50405,'');
INSERT INTO "fundstransfer" VALUES(2002100,'X061810240291856','2014-06-11',2,2,525,30368,'');
INSERT INTO "fundstransfer" VALUES(2002101,'X061887362754255','2014-06-20',2,2,2550,151292,'');
INSERT INTO "fundstransfer" VALUES(2002102,'X061876492617158','2014-07-09',2,2,1200,70800,'');
INSERT INTO "fundstransfer" VALUES(2002103,'X061847651366854','2014-07-21',2,2,605,35670,'Zakat');
INSERT INTO "fundstransfer" VALUES(2002104,'X061869877383670','2014-07-22',4,2,258,15152,'Zakat');
INSERT INTO "fundstransfer" VALUES(2002105,'X061815769900277','2014-08-29',2,2,503,29825,'');
INSERT INTO "fundstransfer" VALUES(2002106,'X061832317747774','2014-09-16',6,2,845,50526,'');
INSERT INTO "fundstransfer" VALUES(2002107,'X061852384844959','2014-09-23',2,2,715,42600,'Loan + Qurbani');
INSERT INTO "fundstransfer" VALUES(2002108,'X061839416809221','2014-10-26',2,2,453,27135,'Loan');
INSERT INTO "fundstransfer" VALUES(2002109,'X061826286245203','2014-11-07',6,2,845,51156,'');
INSERT INTO "fundstransfer" VALUES(2002110,'X061819307184973 ','2014-11-21',2,2,453,27428,'');
INSERT INTO "fundstransfer" VALUES(2002111,'X061849339294662','2015-01-29',2,2,605,36396,'');
INSERT INTO "fundstransfer" VALUES(2002112,'X061828926048195','2014-12-23',2,2,605,37440,'');
INSERT INTO "fundstransfer" VALUES(2002113,'X061883364814065 ','2015-02-08',2,2,303,18246,'');
INSERT INTO "fundstransfer" VALUES(2002114,'X061826253179502 ','2015-02-09',4,2,825,50151,'');
INSERT INTO "fundstransfer" VALUES(2002115,'X061876589413455 ','2015-03-02',2,2,662,40077,'');
INSERT INTO "fundstransfer" VALUES(2002116,'X061890886405480','2015-04-01',2,2,632,38560,'');
INSERT INTO "fundstransfer" VALUES(2002117,'X061837298302498','2015-05-05',2,2,503,31270,'');
INSERT INTO "fundstransfer" VALUES(2002118,'X061806502593280','2015-05-13',2,2,503,31600,'');
INSERT INTO "fundstransfer" VALUES(2002119,'X061877525533563','2015-06-06',2,2,353,22050,'');
INSERT INTO "fundstransfer" VALUES(2002120,'X061874016154270','2015-06-10',2,2,1500,94500,'');
INSERT INTO "fundstransfer" VALUES(2002121,'X061884693966432','2015-06-30',2,2,805,50536,'800
400 - Loan
400 - Zakat');
INSERT INTO "fundstransfer" VALUES(2002122,'X061806725111659','2015-07-08',6,2,163,10064,'Zakat amt');
INSERT INTO "fundstransfer" VALUES(2002123,'X061869163847309','2015-07-17',2,2,1800,88312,'50000 - Shubh Nivesh
2500 - Fitra
');
INSERT INTO "fundstransfer" VALUES(2002124,'X061876710102262','2015-07-29',2,2,403,25416,'');
INSERT INTO "fundstransfer" VALUES(2002125,'X061843676696156 ','2015-08-02',2,2,1001,63744,'');
INSERT INTO "fundstransfer" VALUES(2002126,'X061811475479563','2015-09-03',2,2,1001,65866,'');
INSERT INTO "fundstransfer" VALUES(2002127,'X061870526113773','2015-09-08',8,2,53,3310,'');
INSERT INTO "fundstransfer" VALUES(2002128,'X061864941749540','2015-09-18',2,2,1200,78744,'');
INSERT INTO "fundstransfer" VALUES(2002129,'X061828441685501 ','2015-10-01',2,2,104,6585,'');
INSERT INTO "fundstransfer" VALUES(2002130,'X061879298290175','2015-10-27',2,2,503,32150,'');
INSERT INTO "fundstransfer" VALUES(2002131,'X061899214052144 ','2015-11-30',2,2,458,30030,'');
INSERT INTO "fundstransfer" VALUES(2002132,'X061883520363163 ','2015-12-19 00:00:00',2,2,503,32875,'');
INSERT INTO "fundstransfer" VALUES(2002133,'X061877996230711 ','2015-12-31 00:00:00',2,2,695,45223,'Loan Amount & Remaining amount (20000) for bore');
INSERT INTO "fundstransfer" VALUES(2002134,'X061832177588093','2016-01-29 00:00:00',2,2,625,41664,'10000 for Anis');
INSERT INTO "fundstransfer" VALUES(2002135,'X061875941849459','2016-01-29 00:00:00',6,2,227,15053,'');
INSERT INTO "fundstransfer" VALUES(2002136,'X061883434788320 ','2016-03-01',2,2,453,30420,'');
INSERT INTO "fundstransfer" VALUES(2002137,'X061862074465561','2016-03-20',2,2,253,16480,'Preethi Mixer and for other stuff');
INSERT INTO "fundstransfer" VALUES(2002138,'X061806350976598','2016-04-02',2,2,403,26200,'');
INSERT INTO "fundstransfer" VALUES(2002139,'X061883636029028','2016-05-03',2,2,503,32850,'');
INSERT INTO "fundstransfer" VALUES(2002140,'X061859838495711','2016-06-03',2,2,555,36580,'');
DROP TABLE IF EXISTS "maghribsalahtimings";
CREATE TABLE "maghribsalahtimings" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "dayno" integer NOT NULL,
  "jan" text NOT NULL,
  "feb" text NOT NULL,
  "mar" text NOT NULL,
  "apr" text NOT NULL,
  "may" text NOT NULL,
  "jun" text NOT NULL,
  "jul" text NOT NULL,
  "aug" text NOT NULL,
  "sept" text NOT NULL,
  "oct" text NOT NULL,
  "nov" text NOT NULL,
  "dec" text NOT NULL
);
INSERT INTO "maghribsalahtimings" VALUES(1,1,'5:46','6:13','6:40','8:04','8:27','8:49','8:58','8:43','8:08','7:27','6:50','5:34');
INSERT INTO "maghribsalahtimings" VALUES(2,2,'5:46','6:15','6:40','8:05','8:27','8:49','8:58','8:42','8:07','7:26','6:50','5:34');
INSERT INTO "maghribsalahtimings" VALUES(3,3,'5:46','6:16','6:42','8:05','8:28','8:50','8:57','8:41','8:06','7:24','6:49','5:34');
INSERT INTO "maghribsalahtimings" VALUES(4,4,'5:47','6:17','6:42','8:06','8:29','8:50','8:57','8:40','8:04','7:23','6:48','5:34');
INSERT INTO "maghribsalahtimings" VALUES(5,5,'5:48','6:18','6:43','8:07','8:30','8:51','8:57','8:40','8:03','7:22','6:47','5:34');
INSERT INTO "maghribsalahtimings" VALUES(6,6,'5:49','6:19','6:44','8:08','8:30','8:51','8:57','8:39','8:02','7:20','6:46','5:34');
INSERT INTO "maghribsalahtimings" VALUES(7,7,'5:50','6:19','6:45','8:08','8:31','8:52','8:57','8:38','8:00','7:19','6:46','5:34');
INSERT INTO "maghribsalahtimings" VALUES(8,8,'5:51','6:20','7:46','8:09','8:32','8:52','8:57','8:37','7:59','7:18','5:45','5:34');
INSERT INTO "maghribsalahtimings" VALUES(9,9,'5:52','6:22','7:46','8:10','8:33','8:53','8:56','8:36','7:58','7:16','5:44','5:35');
INSERT INTO "maghribsalahtimings" VALUES(10,10,'5:52','6:23','7:47','8:11','8:34','8:53','8:56','8:35','7:56','7:15','5:43','5:35');
INSERT INTO "maghribsalahtimings" VALUES(11,11,'5:54','6:24','7:48','8:11','8:34','8:54','8:56','8:34','7:55','7:14','5:42','5:35');
INSERT INTO "maghribsalahtimings" VALUES(12,12,'5:55','6:25','7:49','8:12','8:35','8:54','8:55','8:33','7:53','7:13','5:42','5:35');
INSERT INTO "maghribsalahtimings" VALUES(13,13,'5:56','6:26','7:50','8:13','8:36','8:55','8:55','8:31','7:52','7:11','5:41','5:35');
INSERT INTO "maghribsalahtimings" VALUES(14,14,'5:57','6:27','7:50','8:14','8:37','8:55','8:55','8:30','7:51','7:10','5:41','5:35');
INSERT INTO "maghribsalahtimings" VALUES(15,15,'5:58','6:27','7:51','8:14','8:37','8:55','8:54','8:29','7:49','7:09','5:40','5:36');
INSERT INTO "maghribsalahtimings" VALUES(16,16,'5:58','6:29','7:52','8:15','8:38','8:56','8:54','8:28','7:48','7:08','5:39','5:36');
INSERT INTO "maghribsalahtimings" VALUES(17,17,'5:59','6:29','7:53','8:16','8:39','8:56','8:53','8:27','7:46','7:07','5:39','5:37');
INSERT INTO "maghribsalahtimings" VALUES(18,18,'6:01','6:30','7:53','8:17','8:39','8:56','8:53','8:26','7:45','7:05','5:38','5:37');
INSERT INTO "maghribsalahtimings" VALUES(19,19,'6:02','6:31','7:54','8:17','8:40','8:56','8:52','8:25','7:44','7:04','5:38','5:38');
INSERT INTO "maghribsalahtimings" VALUES(20,20,'6:03','6:32','7:55','8:18','8:41','8:57','8:52','8:23','7:42','7:03','5:37','5:38');
INSERT INTO "maghribsalahtimings" VALUES(21,21,'6:04','6:32','7:56','8:19','8:42','8:57','8:51','8:22','7:41','7:02','5:37','5:38');
INSERT INTO "maghribsalahtimings" VALUES(22,22,'6:05','6:33','7:56','8:20','8:42','8:57','8:51','8:21','7:39','7:01','5:37','5:39');
INSERT INTO "maghribsalahtimings" VALUES(23,23,'6:06','6:34','7:57','8:20','8:43','8:57','8:50','8:20','7:38','7:00','5:36','5:40');
INSERT INTO "maghribsalahtimings" VALUES(24,24,'6:06','6:36','7:58','8:21','8:44','8:57','8:49','8:19','7:37','6:59','5:36','5:40');
INSERT INTO "maghribsalahtimings" VALUES(25,25,'6:07','6:36','7:59','8:22','8:44','8:58','8:49','8:17','7:35','6:57','5:36','5:41');
INSERT INTO "maghribsalahtimings" VALUES(26,26,'6:08','6:37','7:59','8:23','8:45','8:58','8:48','8:16','7:34','6:56','5:35','5:41');
INSERT INTO "maghribsalahtimings" VALUES(27,27,'6:09','6:38','8:00','8:24','8:46','8:58','8:47','8:15','7:33','6:55','5:35','5:42');
INSERT INTO "maghribsalahtimings" VALUES(28,28,'6:10','6:39','8:01','8:24','8:46','8:58','8:46','8:14','7:31','6:54','5:35','5:42');
INSERT INTO "maghribsalahtimings" VALUES(29,29,'6:11','6:39','8:02','8:25','8:47','8:58','8:46','8:12','7:30','6:53','5:35','5:43');
INSERT INTO "maghribsalahtimings" VALUES(30,30,'6:12','','8:02','8:26','8:48','8:58','8:45','8:11','7:28','6:52','5:34','5:44');
INSERT INTO "maghribsalahtimings" VALUES(31,31,'6:12','','8:03','','8:48','','8:44','8:10','','6:51','','5:45');
DROP TABLE IF EXISTS "member";
CREATE TABLE "member" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "member" VALUES(1,'Kareem',NULL);
INSERT INTO "member" VALUES(2,'Shahana',NULL);
INSERT INTO "member" VALUES(3,'Hafsa',NULL);
INSERT INTO "member" VALUES(4,'Aalia',NULL);
DROP TABLE IF EXISTS "module";
CREATE TABLE "module" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL,
  "createddate" text DEFAULT NULL,
  "updateddate" text DEFAULT NUL
);
INSERT INTO "module" VALUES(2,'Personal Apps','Tasks, Expenses, Credentials, URL Store, Misc etc','2012-10-04','2016-05-25 13:50:32');
INSERT INTO "module" VALUES(3,'Islamic Apps','Salah Timings & Tracker, Duas etc','2012-10-04','2016-05-25 13:50:32');
INSERT INTO "module" VALUES(4,'Misc Apps','Weight Recorder, Biometrics, Online Orders, Credit Payments, Funds Transfer etc','2012-10-04','2016-05-25 13:50:32');
INSERT INTO "module" VALUES(6,'Admin Apps','Users, Modules, Categories, DBOpers','2013-10-08','2016-05-25 13:50:32');
INSERT INTO "module" VALUES(8,'Work Apps','DBEnvDetails','2016-01-04 15:03:31','2016-05-25 13:50:32');
INSERT INTO "module" VALUES(9,'DR Apps','Data Retrieve Apps','2016-05-25 13:50:11','2016-05-25 13:50:32');
DROP TABLE IF EXISTS "month";
CREATE TABLE "month" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "month" VALUES(1,'January','Jan');
INSERT INTO "month" VALUES(2,'February','Feb');
INSERT INTO "month" VALUES(3,'March','Mar');
INSERT INTO "month" VALUES(4,'April','Apr');
INSERT INTO "month" VALUES(5,'May','May');
INSERT INTO "month" VALUES(6,'June','Jun');
INSERT INTO "month" VALUES(7,'July','Jul');
INSERT INTO "month" VALUES(8,'August','Aug');
INSERT INTO "month" VALUES(9,'September','Sept');
INSERT INTO "month" VALUES(10,'October','Oct');
INSERT INTO "month" VALUES(11,'November','Nov');
INSERT INTO "month" VALUES(12,'December','Dec');
DROP TABLE IF EXISTS "objecttypes";
CREATE TABLE "objecttypes" (
"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE , 
"typeid" TEXT NOT NULL , 
"name" TEXT NOT NULL , 
"objecttype" TEXT NOT NULL , 
"user" INTEGER NOT NULL , 
"tablename" INTEGER NOT NULL , 
CONSTRAINT "FKOBJECTTYPES_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "objecttypes" VALUES(2002002,'150000063','Ethernet Connection (QoS)','circuit',2,'EXT_CIRCUIT_ETH_CONN');
INSERT INTO "objecttypes" VALUES(2002003,'150000059','VLAN Segment_IDIS','circuit',2,'EXT_CIRCUIT_VLAN_SEGMENT');
INSERT INTO "objecttypes" VALUES(2002004,'1761020016','LAG','circuit',2,'EXT_CIRCUIT_LAG');
INSERT INTO "objecttypes" VALUES(2002005,'1761020002','TIRKS Bearer','circuit',2,'EXT_CIRCUIT_TIRKS_BEARER');
INSERT INTO "objecttypes" VALUES(2002006,'150000064','Ethernet Bearer_IDIS','circuit',2,'EXT_CIRCUIT_ETH_BEARER');
INSERT INTO "objecttypes" VALUES(2002007,'1761020004','LGX','node',2,'EXT_NODE_LGX');
INSERT INTO "objecttypes" VALUES(2002008,'1761020038','MDF_LGX','node',2,'EXT_NODE_LGX');
INSERT INTO "objecttypes" VALUES(2002009,'1761020032','Generic','node',2,'EXT_NODE_GENERIC');
INSERT INTO "objecttypes" VALUES(2002010,'1761020027','Cisco 2800 Series','node',2,'EXT_NODE_CISCO_2800_SERIES');
INSERT INTO "objecttypes" VALUES(2002011,'1921003012','ADTRAN LPU','node',2,'EXT_NODE_ADTRAN_LPU');
INSERT INTO "objecttypes" VALUES(2002012,'1761020017','ADTRAN 800 Series','node',2,'EXT_NODE_ADTRAN_800_SERIES');
INSERT INTO "objecttypes" VALUES(2002013,'1761020018','ADTRAN 5000 series','node',2,'EXT_NODE_ADTRAN_5000_Series');
INSERT INTO "objecttypes" VALUES(2002014,'1921003015','CIENA EGS','node',2,'EXT_NODE_CIENA_EGS');
INSERT INTO "objecttypes" VALUES(2002015,'1761020041','CIENA EMUX','node',2,'EXT_NODE_CIENA_EMUX');
INSERT INTO "objecttypes" VALUES(2002016,'1761020020','Ciena 3900 Series','node',2,'EXT_NODE_CIENA_NTE_SERIES');
INSERT INTO "objecttypes" VALUES(2002017,'1921003014','JUNIPER UCPE','node',2,'EXT_NODE_UCPE');
INSERT INTO "objecttypes" VALUES(2002018,'1761020000','Juniper MX Series','node',2,'EXT_NODE_JUNIPER_MX_SERIES');
INSERT INTO "objecttypes" VALUES(2002019,'1761020020','10 Gigabit Ethernet_Tx','port',2,'EXT_PORT_JUNIPER_MX');
INSERT INTO "objecttypes" VALUES(2002020,'1761020021','10 Gigabit Ethernet_Rx','port',2,'EXT_PORT_JUNIPER_MX');
INSERT INTO "objecttypes" VALUES(2002021,'1921000000','100 Gigabit Ethernet_Rx','port',2,'EXT_PORT_JUNIPER_MX');
INSERT INTO "objecttypes" VALUES(2002022,'1921000001','100 Gigabit Ethernet_Tx','port',2,'EXT_PORT_JUNIPER_MX');
INSERT INTO "objecttypes" VALUES(2002023,'1900000001','OpticalMultiRate_Rx','port',2,'EXT_PORT');
INSERT INTO "objecttypes" VALUES(2002024,'1761020040','UNI Service','service',2,'EXT_SERVICE_IPAG_UNI');
INSERT INTO "objecttypes" VALUES(2002025,'1761020056','Leg EVC Service','service',2,'EXT_SERVICE_ACCESS_LEG_EVC');
INSERT INTO "objecttypes" VALUES(2002026,'1761020050','SCP EVC Service','service',2,'EXT_SERVICE_SCP_EVC');
INSERT INTO "objecttypes" VALUES(2002027,'1761020042','EVC Service','service',2,'EXT_SERVICE_EVC');
INSERT INTO "objecttypes" VALUES(2002028,'1761020057','CFM Domain','service',2,'EXT_SERVICE_CFM_DOMAIN');
INSERT INTO "objecttypes" VALUES(2002029,'1761020036','INL Service','service',2,'EXT_SERVICE_IPAG_INL');
INSERT INTO "objecttypes" VALUES(2002030,'1761020055','LAG Service Type','service',2,'EXT_SERVICE_IPAG_LAG');
INSERT INTO "objecttypes" VALUES(2002031,'1900000001','OpticalMultiRate_Rx','port',2,'EXT_PORT');
INSERT INTO "objecttypes" VALUES(2002033,'26','Number','dimobject',2,'DimNumber');
INSERT INTO "objecttypes" VALUES(2002034,'23','Topology','dimobject',2,'Topology');
INSERT INTO "objecttypes" VALUES(2002035,'21','Project','dimobject',2,'Project');
INSERT INTO "objecttypes" VALUES(2002036,'11','Shelf','dimobject',2,'Shelf');
INSERT INTO "objecttypes" VALUES(2002037,'10','Slot','dimobject',2,'Slot');
INSERT INTO "objecttypes" VALUES(2002038,'8','Service','dimobject',2,'Service');
INSERT INTO "objecttypes" VALUES(2002039,'7','Subscriber','dimobject',2,'Subscriber');
INSERT INTO "objecttypes" VALUES(2002040,'6','Location','dimobject',2,'Location');
INSERT INTO "objecttypes" VALUES(2002041,'5','Card','dimobject',2,'Card');
INSERT INTO "objecttypes" VALUES(2002042,'4','Port','dimobject',2,'Port');
INSERT INTO "objecttypes" VALUES(2002043,'3','Circuit','dimobject',2,'Circuit');
INSERT INTO "objecttypes" VALUES(2002044,'2','Link','dimobject',2,'Link');
INSERT INTO "objecttypes" VALUES(2002045,'1','Node','dimobject',2,'Node');
INSERT INTO "objecttypes" VALUES(2002046,'1761020017','Unrouted Ethernet Bearer','circuit',2,'EXT_CIRCUIT_ETH_BEARER');
INSERT INTO "objecttypes" VALUES(2002047,'11111','DURATION','mvconfig',2,'Set Extension Table');
INSERT INTO "objecttypes" VALUES(2002048,'22222','JOBMANAGEMENT','mvconfig',2,'Set Extension Table');
INSERT INTO "objecttypes" VALUES(2002049,'33333','JOB_MONITOR','mvconfig',2,'Set Extension Table');
INSERT INTO "objecttypes" VALUES(2002050,'44444','LOG_KEEPING','mvconfig',2,'Set Extension Table');
INSERT INTO "objecttypes" VALUES(2002051,'55555','PERCENTAGE','mvconfig',2,'Set Extension Table');
DROP TABLE IF EXISTS "onlineorders";
CREATE TABLE "onlineorders" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "orderno" text NOT NULL,
  "ordername" text NOT NULL,
  "orderdate" text NOT NULL,
  "user" integer NOT NULL,
  "orderamount" real NOT NULL,
  "notes" blob,
  CONSTRAINT "UKOORDERS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "onlineorders" VALUES(2002001,'130729446','Twin Duvet Cover','2013-12-16',2,27.94,'12/16 - Ordered from overstock');
INSERT INTO "onlineorders" VALUES(2002002,'11-8905985','Nissan Blower Motor Resistor','2013-07-10',2,41.2,'Ordered from partsgeek.com');
INSERT INTO "onlineorders" VALUES(2002003,'108-0838122-7813048','Deva Vegan Capsules','2013-08-15',2,26.02,'From Amazon

Estimated Delivery (8/22 - 8/26)');
INSERT INTO "onlineorders" VALUES(2002004,'2677176-965090','Wireless Keyboard','2013-10-01',2,21.28,'');
INSERT INTO "onlineorders" VALUES(2002005,'VIB Card','7776755469','2013-10-03',2,50,'');
INSERT INTO "onlineorders" VALUES(2002006,'295284','Nissan EMI','2013-10-22',2,311.95001,'10/22 - Amount is due on 11/1');
INSERT INTO "onlineorders" VALUES(2002007,'625998400','Lip Balm','2014-01-24',2,25.1,'');
INSERT INTO "onlineorders" VALUES(2002008,'TUD4U','North Fulton Emergency Bill for Hafsa','2014-02-24',2,75,'2/24 - Used CC ending with 9384');
DROP TABLE IF EXISTS "otwhours";
CREATE TABLE "otwhours" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "otwhdate" text NOT NULL,
   "otwhdesc" text NOT NULL,
  "noofhours" integer NOT NULL,
  "user" integer NOT NULL,
  "used" text NOT NULL,
  "utiliseddate" text NULL,
  "notes" blob,
  CONSTRAINT "FKTASK_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "otwhours" VALUES(2002001,'2015-02-22','Weekend Support',17,2,'Yes','','');
INSERT INTO "otwhours" VALUES(2002002,'2015-03-08','Weekend Support',8,2,'Yes','','');
INSERT INTO "otwhours" VALUES(2002003,'2015-03-22','Weekend Support',14,2,'Yes','2015-08-05','');
INSERT INTO "otwhours" VALUES(2002004,'2015-10-10','PM Label Updates',5,2,'Yes','2015-11-20','PM Label Updates');
INSERT INTO "otwhours" VALUES(2002005,'2015-10-11','PM Label Updates',3,2,'Yes','2015-11-20','PM Label Updates');
INSERT INTO "otwhours" VALUES(2002006,'2015-10-25','1510 Deployment Support',8,2,'Yes','','1510 Deployment Support');
INSERT INTO "otwhours" VALUES(2002007,'2015-12-13','1512 Deployment Support',10,2,'Yes','2016-01-22','1512 Deployment Support');
INSERT INTO "otwhours" VALUES(2002008,'2016-01-09','Prod GG Service, Number, Circuit Issue',10,2,'Yes','2016-04-05','Prod GG Service, Number, Circuit Issue');
INSERT INTO "otwhours" VALUES(2002009,'2016-02-21','1602 Deployment Support',12,2,'No','','1602 Deployment Support');
INSERT INTO "otwhours" VALUES(2002010,'2016-04-17','1604 Deployment Support',10,2,'No','','GCP-MV jobs started at 10:20 PM

Created GCP_USER jobs first and then Cramer jobs');
INSERT INTO "otwhours" VALUES(2002011,'2016-05-22','1605 Deployment Support',5,2,'no',NULL,'');
INSERT INTO "otwhours" VALUES(2002012,'2016-06-12','1606 production deployment',4,2,'no',NULL,'');
DROP TABLE IF EXISTS "pagesettings";
CREATE TABLE "pagesettings" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "tablename" text NOT NULL,
  "page" text NOT NULL,
  "columnname" text NOT NULL,
  "coldisplay" text NOT NULL,
  "visible" text NOT NULL,
  "user" integer NOT NULL,
  CONSTRAINT "FKPAGESETTINGS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "pagesettings" VALUES(1,'salahtracker','View','createddate','Created Date','yes',2);
INSERT INTO "pagesettings" VALUES(2,'salahtracker','View','updateddate','Updated Date','yes',2);
INSERT INTO "pagesettings" VALUES(3,'salahtracker','Search','createddate','Created Date','yes',2);
INSERT INTO "pagesettings" VALUES(4,'salahtracker','Search','updateddate','Updated Date','yes',2);
DROP TABLE IF EXISTS "plotdetails";
CREATE TABLE "plotdetails" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "datesent" text NOT NULL,
  "amount" real NOT NULL,
  "user" integer NOT NULL,
  "notes" blob,
  CONSTRAINT "FKPLOTDETAILS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "plotdetails" VALUES(2002001,'2013-08-21',31505,2,'');
INSERT INTO "plotdetails" VALUES(2002002,'2012-02-16',295488,2,'');
INSERT INTO "plotdetails" VALUES(2002003,'2012-03-12',64397,2,'');
INSERT INTO "plotdetails" VALUES(2002004,'2012-04-16',81552,2,'');
INSERT INTO "plotdetails" VALUES(2002005,'2012-06-04',70786,2,'');
INSERT INTO "plotdetails" VALUES(2002006,'2012-06-25',65809,2,'');
INSERT INTO "plotdetails" VALUES(2002007,'2012-08-11',30000,2,'');
INSERT INTO "plotdetails" VALUES(2002008,'2012-08-18',50000,2,'');
INSERT INTO "plotdetails" VALUES(2002009,'2013-05-29',60775,2,'');
INSERT INTO "plotdetails" VALUES(2002010,'2013-11-25',50902,2,'');
INSERT INTO "plotdetails" VALUES(2002011,'2013-12-23',50606,2,'');
INSERT INTO "plotdetails" VALUES(2002012,'2014-01-20',50078,2,'');
DROP TABLE IF EXISTS "priority";
CREATE TABLE "priority" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "priority" VALUES(1,'Highest','Should be completed with in a day');
INSERT INTO "priority" VALUES(2,'High','Should be completed in 2 days');
INSERT INTO "priority" VALUES(3,'Medium','Should be completed in 4 days');
INSERT INTO "priority" VALUES(4,'Low','Should be completed in a week');
DROP TABLE IF EXISTS "projections";
CREATE TABLE "projections" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
  "user" integer NOT NULL,
  "estimatedcost" real NOT NULL,
  "actualcost" real NOT NULL,
  "notes" blob,
  CONSTRAINT "FKPROJECTIONS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "projections" VALUES(2002001,'House Rent',2,1160,1160,'');
INSERT INTO "projections" VALUES(2002002,'MARTA',2,42.5,42.5,'');
DROP TABLE IF EXISTS "release";
CREATE TABLE "release" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "release" VALUES(1,'1504','1504');
INSERT INTO "release" VALUES(2,'1505','1505');
INSERT INTO "release" VALUES(4,'1507','1507');
INSERT INTO "release" VALUES(5,'1510','1510');
INSERT INTO "release" VALUES(6,'1607','1607');
INSERT INTO "release" VALUES(7,'1608','1608');
INSERT INTO "release" VALUES(8,'1610','1610');
INSERT INTO "release" VALUES(9,'1702','1702');
INSERT INTO "release" VALUES(10,'1604','1604');
DROP TABLE IF EXISTS "remainder";
CREATE TABLE "remainder" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "remainder" text NOT NULL,
  "createddate" text NOT NULL,
  "lastremainder" text NOT NULL,
  "nextremainder" text NOT NULL,
  "user" integer NOT NULL,
  "daysafter" integer DEFAULT NULL,
  "daysbefore" integer DEFAULT NULL,
  "notes" blob DEFAULT NULL,
  CONSTRAINT "FKREMAINDER_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "remainder" VALUES(2002003,'Hair Cut','2012-11-12','2014-07-25','2014-08-30',2,30,40,'History:
=====
07302014
LR - 05/10/2014 NR - 06/21/2014 (Actual -> 07/25/2014)

05/11/2014
LR - 03/01/2013 NR - 04/12/2014  (Actual -> 05/10/2014)

03/03/2014
LR - 1/11/2014 NR - 02/08/2014');
INSERT INTO "remainder" VALUES(2002004,'TV Subscription','2012-11-19','2013-09-18','2014-01-20',2,0,0,'');
INSERT INTO "remainder" VALUES(2002005,'Honda Oil Change','2013-06-20','2016-03-09','2016-07-08',2,240,250,'');
INSERT INTO "remainder" VALUES(2002006,'Stove top cleaning','2013-07-27','2013-10-10','2013-11-30',2,25,30,'');
INSERT INTO "remainder" VALUES(2002007,'Oven cleaning','2013-07-27','2013-08-27','2013-09-30',2,25,30,'');
INSERT INTO "remainder" VALUES(2002008,'Comcast 12 Months Promotion','2016-04-19 13:26:00','2016-04-19','2017-03-17',2,330,240,'');
DROP TABLE IF EXISTS "reqmnts";
CREATE TABLE "reqmnts" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "projectdesc" text NOT NULL,
  "release" integer NOT NULL,
  "component" integer NOT NULL,
  "user" integer NOT NULL,
  "createddate" text NOT NULL,
  "pid" text NULL,
  "cr" text NULL,
  "jira" text NULL,
  "estimate" text NULL,
  "notes" blob,
  CONSTRAINT "FKREQMNTS_RELEASE" FOREIGN KEY ("release") REFERENCES "release" ("id"),
  CONSTRAINT "FKREQMNTS_COMPONENT" FOREIGN KEY ("component") REFERENCES "component" ("id"),
  CONSTRAINT "FKREQMNTS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "reqmnts" VALUES(2002001,'OnStar Europe Alarm correlations and Performance Enhancements',1,2,2,'2016-03-03','271687c','','1210','','PMT : 432930
No Impact');
INSERT INTO "reqmnts" VALUES(2002002,'2013 INSIGHT - Planned Data',1,2,2,'2016-03-04','274545','','1121','1 Week','PMT : 430305
EMUXACD - Col needs to be added to Node procedure');
INSERT INTO "reqmnts" VALUES(2002003,'ASEoLS Bonded Pair Support',2,2,2,'2016-03-04','261565N','','1568','1 Week','RelationshipType
3 New attributes for Service Extn table');
INSERT INTO "reqmnts" VALUES(2002004,'EoCU as a Replacement for TDM DS1 s - Automation (ID: 271236a)',4,2,2,'2016-03-04','271236a','','1233','2.5 Weeks','PMT : 433540');
INSERT INTO "reqmnts" VALUES(2002005,'ASE OOR Phase 3 (ID: 280406) MDE score 3',4,2,2,'2016-03-04','280406','','1386','1 Week','PMT : 437719
GCP MV DCUT(1 week) - assuming Cramer model ''CS-NAME'' attribute at UNI Service level');
INSERT INTO "reqmnts" VALUES(2002006,'CR # 121946 PID: 274707B OSP Fiber Info to GCP for SA',4,'',2,'2016-03-04','274707B','','1517','2 Weeks','PMT : 439086
Attributes will be added to service extn table');
INSERT INTO "reqmnts" VALUES(2002007,'CR # 121946 PID: 274707B OSP Fiber Info to GCP for SA',4,2,2,'2016-03-04','274707B','','1517','2 Weeks','PMT : 439086
Attributes will be added to service extn table');
INSERT INTO "reqmnts" VALUES(2002008,'Cisco 2941 to ASR901 GSMoE (ID: 277645)',5,2,2,'2016-03-04','277645','','1274','','PMT : 441626

No Impact');
INSERT INTO "reqmnts" VALUES(2002009,'Network Functions on Demand - 1607 Release (ID: 289116) ',6,2,2,'2016-03-04','289116','','2088','3 days','2 new attributes to be added to Node uCPE device extension table');
INSERT INTO "reqmnts" VALUES(2002010,'MP Core Part 3: HSIA By-Pass Feature (ID: 283878)',6,2,2,'2016-03-04','283878','','1923','1 Week','1 Week is given because we need to add new LGX device type and new attribute

03/01 : 
As per discussion - GCP-MV should support LAG, INL - In that case there will be no
impact to MV. Test Support is required.
US623514 - Created by Dave Castro - Need to add task');
INSERT INTO "reqmnts" VALUES(2002011,'ASE InterLATA Phase 2 - July release (ID: 289450) ',8,2,2,'2016-03-04','289450','','2076','1 Week','We learnt that we are storing the OOR domain n domain object also for UNI, EVC, CNl, EVC access, INL and LAG svc/ckt.
We need to figure out how is it being populated for parent EVC, CNL and INL(access/Core) and LAG (core/Access). Alok to let me know.
With this project introduction its for sure that parent EVC, INL and CNL can no longer have a clean determining on domain being IR or OOR.
UNI and EVC access leg by extension rule def from Node can still have a concept of IR or OOR.

In MV staging tables, DomainIndicator is in Location, Node, Circuit, and Service - Ambrin wants circuit and all service except UNI to not have indicator');
INSERT INTO "reqmnts" VALUES(2002012,'ASE on Demand Wholesale ENNI Port (ID: 288901) 1610',8,2,2,'2016-03-04','288901','','2099','2 days','We need to send an indicator to GCP if UNI is ENNI UNI Service

We have to either get the info from UNI Service name or Projectname which is there in  EXT_SERVICE_IPAG_UNI ext table');
INSERT INTO "reqmnts" VALUES(2002013,'2016 SD&E GCP/SXP Transformation (Non-IBM Activities) (ID: 289639)1610',8,2,2,'2016-03-04','289639','','2120','3 days','Test only support

MV Option 1: Add additional GG Replication so MV staging tables feed DMaaP in addition to GCP.
MV Option 2: Remove GG replication to GCP and just feed DMaaP.');
INSERT INTO "reqmnts" VALUES(2002014,'vASE L2 VPN Metro NTD (ID-288485) CANOPI Piece - 1702 ',9,2,2,'2016-03-04','288485','','2054','2 days','Test only support
 
Assumption :
If PID 288382 needs to be approved and MV should complete tasks');
INSERT INTO "reqmnts" VALUES(2002015,'SAREA Rel 2c (ID: 283912c) 1607',6,2,2,'2016-03-07','283912c','','2153','3 days','Might be test only for now');
INSERT INTO "reqmnts" VALUES(2002016,'AGILE #372 - SD-731d AT&T Telco Functional Automation (ID: 284655) (CR 133686) 1604',6,2,2,'2016-03-07','284655','','1696','1 Week','Estimate given on 9/18 - test only support - need to check release whether it is 1604 or 1607');
INSERT INTO "reqmnts" VALUES(2002017,'ASEoD - MPP, E-rate 10GE and Sell and deploy enhancements - (ID: 288715)',6,2,2,'2016-03-07','288715','','2085','3 days','F16210 ASEoD Deploy and Sell Phase 2 CANOPI impacted ');
INSERT INTO "reqmnts" VALUES(2002018,'290711 MPC5E card and telco MX series devices',8,2,2,'2016-03-18 16:24:38','290711','','2174','4 days','New card type is being added

US682240 - US-CANOPI-290711-SVD-F1-3500: CANOPI MV interface support for PID 290711');
INSERT INTO "reqmnts" VALUES(2002019,'Increase ASE bandwidth to 100 Gbps (ID: 289385) 1610',8,2,2,'2016-04-04 14:42:06','289385','','2199','1 Week','Node type and card

US682244 - US-CANOPI-289385-SVD-Item1-3600: Provide Cramer data thru MV interface to GCP in support of Ciena CN8700');
INSERT INTO "reqmnts" VALUES(2002020,'289646 1610 changes',8,2,2,'2016-04-04 15:39:57','289646','','9999','3 days','2 new attributes will be added to service');
INSERT INTO "reqmnts" VALUES(2002021,'ASE Ordering Enhancements (ID: 289184)1607',6,2,2,'2016-04-10 23:03:46','289184','','2061','3 days','NOSHARING - new attribute needs to be added to NTE devices');
INSERT INTO "reqmnts" VALUES(2002022,'CR 141333 - 289116 1607 provide required NFoD inventory (288255a) 1607',6,2,2,'2016-04-26 17:09:24','288255a','','2254','3 days','Test Only Support - we need to provide data to Action (like DMap)');
INSERT INTO "reqmnts" VALUES(2002023,'SAREA Rel 2d (ID:283912d) 1610',8,2,2,'2016-05-05 19:03:12','283912d','','2280','4 days','High Level estimates given');
INSERT INTO "reqmnts" VALUES(2002024,'CR 145850 - EoCu MACD Failure Due to Address Mis-match (PID 289592a) 1702',9,2,2,'2016-06-14 18:26:35','289592a','','1234','3 days','address_id is added to service mv table - comes from UNI Service extension table');
DROP TABLE IF EXISTS "role";
CREATE TABLE "role" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
  "createddate" text NOT NULL,
  "updateddate" text NOT NULL,
  "notes" blob
);
INSERT INTO "role" VALUES(1,'admin','2012-09-26 16:52:45','2012-09-26 16:52:56',NULL);
INSERT INTO "role" VALUES(2,'normal','2012-09-26 16:53:16','2012-09-26 16:53:18',NULL);
DROP TABLE IF EXISTS "salahtimings";
CREATE TABLE "salahtimings" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "dayrange" text NOT NULL,
  "month" text NOT NULL,
  "Fazr Begin" text NOT NULL,
  "Fazr Iqama" text NOT NULL,
  "Fazr Ends" text NOT NULL,
  "Dhuhr Begin" text NOT NULL,
  "Asr Begin" text NOT NULL,
  "Asr Iqama" text NOT NULL,
  "Isha Begin" text NOT NULL,
  "Isha Iqama" text NOT NULL,
  "notes" blob
);
INSERT INTO "salahtimings" VALUES(1,'1-7','Jan','6:15','6:45','7:42','12:43','3:28','4:30','7:13','7:45',NULL);
INSERT INTO "salahtimings" VALUES(2,'8-14','Jan','6:15','6:45','7:42','12:46','3:31','4:30','7:18','7:45',NULL);
INSERT INTO "salahtimings" VALUES(3,'15-21','Jan','6:15','6:45','7:40','12:49','3:37','4:30','7:24','7:45',NULL);
INSERT INTO "salahtimings" VALUES(4,'22-31','Jan','6:13','6:45','7:35','12:51','3:46','4:45','7:32','8:00',NULL);
INSERT INTO "salahtimings" VALUES(5,'1-7','Feb','6:08','6:30','7:30','12:52','3:51','4:45','7:38','8:00',NULL);
INSERT INTO "salahtimings" VALUES(6,'8-14','Feb','6:04','6:30','7:23','12:52','3:56','5:00','7:44','8:10',NULL);
INSERT INTO "salahtimings" VALUES(7,'15-21','Feb','5:58','6:20','7:16','12:52','4:00','5:00','7:49','8:10',NULL);
INSERT INTO "salahtimings" VALUES(8,'22-END','Feb','5:50','6:20','7:07','12:51','4:05','5:15','7:56','8:20',NULL);
INSERT INTO "salahtimings" VALUES(9,'1-7','Mar','5:42','6:15','6:58','12:50','4:08','5:15','8:01','8:20',NULL);
INSERT INTO "salahtimings" VALUES(10,'8-DST','Mar','5:34','6:15','6:50','12:48','4:10','5:30','8:07','8:30',NULL);
INSERT INTO "salahtimings" VALUES(11,'DST-21','Mar','6:25','6:45','7:39','1:47','4:12','6:15','9:12','9:30',NULL);
INSERT INTO "salahtimings" VALUES(12,'22-31','Mar','6:14','6:45','7:25','1:44','4:14','6:30','9:21','9:40',NULL);
INSERT INTO "salahtimings" VALUES(13,'1-7','Apr','5:59','6:30','7:16','1:41','5:15','6:30','9:28','9:45',NULL);
INSERT INTO "salahtimings" VALUES(14,'8-14','Apr','5:48','6:15','7:07','1:39','5:16','6:30','9:34','9:50',NULL);
INSERT INTO "salahtimings" VALUES(15,'15-21','Apr','5:38','6:15','6:58','1:37','5:17','6:30','9:42','10:00',NULL);
INSERT INTO "salahtimings" VALUES(16,'22-30','Apr','5:28','6:00','6:48','1:36','5:17','6:45','9:52','10:05',NULL);
INSERT INTO "salahtimings" VALUES(17,'1-7','May','5:15','6:00','6:42','1:35','5:18','6:45','9:59','10:15',NULL);
INSERT INTO "salahtimings" VALUES(18,'8-14','May','5:06','5:50','6:36','1:34','5:18','6:45','10:06','10:20',NULL);
INSERT INTO "salahtimings" VALUES(19,'15-21','May','4:58','5:50','6:31','1:34','5:19','6:45','10:10','10:25',NULL);
INSERT INTO "salahtimings" VALUES(20,'22-31','May','4:52','5:45','6:27','1:35','5:20','7:00','10:15','10:30',NULL);
INSERT INTO "salahtimings" VALUES(21,'1-7','Jun','4:45','5:45','6:25','1:36','5:21','7:00','10:19','10:35',NULL);
INSERT INTO "salahtimings" VALUES(22,'8-14','Jun','4:42','5:40','6:25','1:38','5:23','7:00','10:22','10:35',NULL);
INSERT INTO "salahtimings" VALUES(23,'15-21','Jun','4:41','5:40','6:26','1:39','5:24','7:00','10:24','10:40',NULL);
INSERT INTO "salahtimings" VALUES(24,'22-30','Jun','4:42','5:45','6:28','1:41','5:26','7:00','10:25','10:40',NULL);
INSERT INTO "salahtimings" VALUES(25,'1-7','Jul','4:50','5:45','6:30','1:42','5:28','7:00','10:25','10:40',NULL);
INSERT INTO "salahtimings" VALUES(26,'8-14','Jul','4:56','5:50','6:33','1:43','5:29','7:00','10:24','10:40',NULL);
INSERT INTO "salahtimings" VALUES(27,'15-21','Jul','5:03','5:50','6:37','1:44','5:29','7:00','10:22','10:35',NULL);
INSERT INTO "salahtimings" VALUES(28,'22-31','Jul','5:13','6:00','6:41','1:44','5:28','7:00','10:18','10:35',NULL);
INSERT INTO "salahtimings" VALUES(29,'1-7','Aug','5:20','6:00','6:48','1:44','5:27','6:45','10:11','10:25',NULL);
INSERT INTO "salahtimings" VALUES(30,'8-14','Aug','5:28','6:10','6:53','1:43','5:26','6:45','10:05','10:15',NULL);
INSERT INTO "salahtimings" VALUES(31,'15-21','Aug','5:35','6:10','6:58','1:42','5:24','6:45','9:56','10:15',NULL);
INSERT INTO "salahtimings" VALUES(32,'22-31','Aug','5:44','6:15','7:03','1:40','5:20','6:30','9:45','10:00',NULL);
INSERT INTO "salahtimings" VALUES(33,'1-7','Sept','5:50','6:15','7:10','1:37','5:14','6:30','9:30','9:45',NULL);
INSERT INTO "salahtimings" VALUES(34,'8-14','Sept','5:56','6:30','7:15','1:35','5:09','6:15','9:19','9:30',NULL);
INSERT INTO "salahtimings" VALUES(35,'15-21','Sept','6:02','6:30','7:20','1:32','5:04','6:15','9:08','9:20',NULL);
INSERT INTO "salahtimings" VALUES(36,'22-30','Sept','6:09','6:40','7:25','1:30','4:57','6:00','8:57','9:15',NULL);
INSERT INTO "salahtimings" VALUES(37,'1-7','Oct','6:14','6:40','7:31','1:27','4:49','6:00','8:45','9:00',NULL);
INSERT INTO "salahtimings" VALUES(38,'8-14','Oct','6:19','6:50','7:36','1:25','4:42','5:45','8:35','8:45',NULL);
INSERT INTO "salahtimings" VALUES(39,'15-21','Oct','6:25','6:50','7:43','1:23','4:36','5:45','8:27','8:45',NULL);
INSERT INTO "salahtimings" VALUES(40,'22-31','Oct','6:32','7:00','7:50','1:22','4:30','5:30','8:19','8:30',NULL);
INSERT INTO "salahtimings" VALUES(41,'1-DST','Nov','6:37','7:00','7:56','1:21','4:22','5:30','8:09','8:30',NULL);
INSERT INTO "salahtimings" VALUES(42,'DST-14','Nov','5:43','6:15','7:03','12:22','3:18','4:25','7:05','7:45',NULL);
INSERT INTO "salahtimings" VALUES(43,'15-21','Nov','5:49','6:15','7:10','12:23','3:13','4:25','7:00','7:45',NULL);
INSERT INTO "salahtimings" VALUES(44,'22-30','Nov','5:56','6:30','7:16','12:26','3:11','4:25','6:58','7:45',NULL);
INSERT INTO "salahtimings" VALUES(45,'1-7','Dec','6:01','6:30','7:24','12:29','3:10','4:15','6:57','7:45',NULL);
INSERT INTO "salahtimings" VALUES(46,'8-14','Dec','6:06','6:40','7:30','12:32','3:11','4:15','6:59','7:45',NULL);
INSERT INTO "salahtimings" VALUES(47,'15-21','Dec','6:10','6:40','7:35','12:36','3:14','4:25','7:02','7:45',NULL);
INSERT INTO "salahtimings" VALUES(48,'22-31','Dec','6:13','6:40','7:39','12:40','3:10','4:25','7:07','7:45',NULL);
DROP TABLE IF EXISTS "salahtracker";
CREATE TABLE "salahtracker" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "sdate" text NOT NULL UNIQUE,
  "createddate" text NOT NULL,
  "updateddate" text DEFAULT NULL,
  "user" integer NOT NULL,
  "fazr" text DEFAULT NULL,
  "dhuhr" text DEFAULT NULL,
  "asr" text DEFAULT NULL,
  "maghrib" text DEFAULT NULL,
  "isha" text DEFAULT NULL,
  "notes" blob,
  CONSTRAINT "FKSTRACKER_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "salahtracker" VALUES(2002001,'2013-05-28','2013-05-28 16:56:09','2013-05-28 16:56:09',2,'No','Yes','Yes','No','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002002,'2013-05-29','2013-05-29 00:00:00','2013-05-29 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002003,'2013-05-30','2013-05-30 00:00:00','2013-05-30 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002004,'2013-05-31','2013-05-31 00:00:00','2013-05-31 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002005,'2013-06-01','2013-06-01 00:00:00','2013-06-01 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002006,'2013-06-02','2013-06-02 00:00:00','2013-06-02 00:00:00',2,'Yes','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002007,'2013-06-03','2013-06-03 00:00:00','2013-06-03 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002008,'2013-06-04','2013-06-04 00:00:00','2013-06-04 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002009,'2013-06-05','2013-06-05 00:00:00','2013-06-05 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002010,'2013-06-06','2013-06-06 00:00:00','2013-06-06 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002011,'2013-06-07','2013-06-07 00:00:00','2013-06-07 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002012,'2013-06-08','2013-06-08 00:00:00','2013-06-08 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002013,'2013-06-09','2013-06-09 00:00:00','2013-06-09 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002014,'2013-06-10','2013-06-10 00:00:00','2013-06-10 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002015,'2013-06-11','2013-06-11 00:00:00','2013-06-11 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002016,'2013-06-12','2013-06-12 00:00:00','2013-06-12 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002017,'2013-06-13','2013-06-13 00:00:00','2013-06-13 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002018,'2013-06-14','2013-06-14 00:00:00','2013-06-14 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002019,'2013-06-15','2013-06-15 00:00:00','2013-06-15 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002020,'2013-06-16','2013-06-16 00:00:00','2013-06-16 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002021,'2013-06-17','2013-06-17 00:00:00','2013-06-17 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002022,'2013-06-18','2013-06-18 00:00:00','2013-06-18 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002023,'2013-06-19','2013-06-19 00:00:00','2013-06-19 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002024,'2013-06-20','2013-06-20 00:00:00','2013-06-20 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002025,'2013-06-21','2013-06-21 00:00:00','2013-06-21 00:00:00',2,'No','Yes','Yes','No','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002026,'2013-06-22','2013-06-22 00:00:00','2013-06-22 00:00:00',2,'Yes','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002027,'2013-06-23','2013-06-23 00:00:00','2013-06-23 00:00:00',2,'No','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002028,'2013-06-24','2013-06-24 00:00:00','2013-06-24 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002029,'2013-06-25','2013-06-25 00:00:00','2013-06-25 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002030,'2013-06-26','2013-06-26 00:00:00','2013-06-26 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002031,'2013-06-27','2013-06-27 00:00:00','2013-06-27 00:00:00',2,'No','Yes','No','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002032,'2013-06-29','2013-06-29 00:00:00','2013-06-29 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002033,'2013-06-30','2013-06-30 00:00:00','2013-06-30 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002034,'2013-07-01','2013-07-01 00:00:00','2013-07-01 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002035,'2013-07-02','2013-07-02 00:00:00','2013-07-02 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002036,'2013-07-03','2013-07-03 00:00:00','2013-07-03 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002037,'2013-07-04','2013-07-04 00:00:00','2013-07-04 00:00:00',2,'No','Yes','No','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002038,'2013-07-05','2013-07-05 00:00:00','2013-07-05 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002039,'2013-07-06','2013-07-06 00:00:00','2013-07-06 00:00:00',2,'No','Yes','Yes','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002040,'2013-07-07','2013-07-07 00:00:00','2013-07-07 00:00:00',2,'No','Yes','Yes','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002041,'2013-07-08','2013-07-08 00:00:00','2013-07-08 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002042,'2013-07-09','2013-07-09 00:00:00','2013-07-09 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002043,'2013-07-10','2013-07-10 00:00:00','2013-07-10 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002044,'2013-07-11','2013-07-11 00:00:00','2013-07-11 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002045,'2013-07-12','2013-07-12 00:00:00','2013-07-12 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002046,'2013-07-13','2013-07-13 00:00:00','2013-07-13 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002047,'2013-07-14','2013-07-14 00:00:00','2013-07-14 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002048,'2013-07-15','2013-07-15 00:00:00','2013-07-15 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002049,'2013-07-16','2013-07-16 00:00:00','2013-07-16 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002050,'2013-07-17','2013-07-17 00:00:00','2013-07-17 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002051,'2013-07-18','2013-07-18 00:00:00','2013-07-18 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002052,'2013-07-19','2013-07-19 00:00:00','2013-07-19 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002053,'2013-07-20','2013-07-20 00:00:00','2013-07-20 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002054,'2013-07-21','2013-07-21 00:00:00','2013-07-21 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002055,'2013-07-22','2013-07-22 00:00:00','2013-07-22 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002056,'2013-07-23','2013-07-23 00:00:00','2013-07-23 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002057,'2013-07-24','2013-07-24 00:00:00','2013-07-24 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002058,'2013-07-25','2013-07-25 00:00:00','2013-07-25 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002059,'2013-07-26','2013-07-26 00:00:00','2013-07-26 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002060,'2013-07-27','2013-07-27 00:00:00','2013-07-27 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002061,'2013-07-28','2013-07-28 00:00:00','2013-07-28 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002062,'2013-07-29','2013-07-29 00:00:00','2013-07-29 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002063,'2013-07-30','2013-07-30 00:00:00','2013-07-30 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002064,'2013-07-31','2013-07-31 00:00:00','2013-07-31 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002065,'2013-08-01','2013-08-01 00:00:00','2013-08-01 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002066,'2013-08-02','2013-08-02 00:00:00','2013-08-02 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002067,'2013-08-03','2013-08-03 00:00:00','2013-08-03 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002068,'2013-08-04','2013-08-04 00:00:00','2013-08-04 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002069,'2013-08-05','2013-08-05 00:00:00','2013-08-05 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002070,'2013-08-06','2013-08-06 00:00:00','2013-08-06 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002071,'2013-08-07','2013-08-07 00:00:00','2013-08-07 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002072,'2013-08-08','2013-08-08 00:00:00','2013-08-08 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002073,'2013-08-09','2013-08-09 00:00:00','2013-08-09 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002074,'2013-08-10','2013-08-10 00:00:00','2013-08-10 00:00:00',2,'Yes','No','No','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002075,'2013-08-12','2013-08-12 00:00:00','2013-08-12 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002076,'2013-08-13','2013-08-13 00:00:00','2013-08-13 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002077,'2013-08-11','2013-08-11 00:00:00','2013-08-11 00:00:00',2,'No','No','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002078,'2013-08-14','2013-08-14 00:00:00','2013-08-14 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002079,'2013-08-15','2013-08-15 00:00:00','2013-08-15 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002080,'2013-08-16','2013-08-16 00:00:00','2013-08-16 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002081,'2013-08-17','2013-08-17 00:00:00','2013-08-17 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002082,'2013-08-18','2013-08-18 00:00:00','2013-08-18 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002083,'2013-08-19','2013-08-19 00:00:00','2013-08-19 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002084,'2013-08-20','2013-08-20 00:00:00','2013-08-20 00:00:00',2,'Yes','No','No','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002085,'2013-08-21','2013-08-21 00:00:00','2013-08-21 00:00:00',2,'No','Yes','No','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002086,'2013-08-22','2013-08-22 00:00:00','2013-08-22 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002087,'2013-08-23','2013-08-23 00:00:00','2013-08-23 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002088,'2013-08-24','2013-08-24 00:00:00','2013-08-24 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002089,'2013-08-25','2013-08-25 00:00:00','2013-08-25 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002090,'2013-08-26','2013-08-26 00:00:00','2013-08-26 00:00:00',2,'No','Yes','Yes','No','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002091,'2013-08-27','2013-08-27 00:00:00','2013-08-27 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002092,'2013-08-28','2013-08-28 00:00:00','2013-08-28 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002093,'2013-08-29','2013-08-29 00:00:00','2013-08-29 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002094,'2013-08-30','2013-08-30 00:00:00','2013-08-30 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002095,'2013-08-31','2013-08-31 00:00:00','2013-08-31 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002096,'2013-09-01','2013-09-01 00:00:00','2013-09-01 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002097,'2013-09-02','2013-09-02 00:00:00','2013-09-02 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002098,'2013-09-03','2013-09-03 00:00:00','2013-09-03 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002099,'2013-09-04','2013-09-04 00:00:00','2013-09-04 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002100,'2013-09-05','2013-09-05 00:00:00','2013-09-05 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002101,'2013-09-06','2013-09-06 00:00:00','2013-09-06 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002102,'2013-09-07','2013-09-07 00:00:00','2013-09-07 00:00:00',2,'No','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002103,'2013-09-08','2013-09-08 00:00:00','2013-09-08 00:00:00',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002104,'2013-09-09','2013-09-09 00:00:00','2013-09-10 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002105,'2013-09-10','2013-09-10 00:00:00','2013-09-11 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002106,'2013-09-11','2013-09-11 00:00:00','2013-09-12 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002107,'2013-09-12','2013-09-12 00:00:00','2013-09-13 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002108,'2013-09-13','2013-09-13 00:00:00','2013-09-16 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002109,'2013-09-14','2013-09-16 00:00:00',NULL,2,'No','No','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002111,'2013-09-16','2013-09-16 00:00:00','2013-09-17 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002112,'2013-09-15','2013-09-16 00:00:00',NULL,2,'No','Yes','No','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002113,'2013-09-17','2013-09-17 00:00:00','2013-09-18 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002114,'2013-09-18','2013-09-18 00:00:00','2013-09-19 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002115,'2013-09-19','2013-09-19 00:00:00','2013-09-23 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002116,'2013-09-20','2013-09-23 00:00:00',NULL,2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002117,'2013-09-21','2013-09-23 00:00:00',NULL,2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002118,'2013-09-22','2013-09-23 00:00:00',NULL,2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002119,'2013-09-23','2013-09-23 00:00:00','2013-09-24 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002120,'2013-09-24','2013-09-24 00:00:00','2013-09-25 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002121,'2013-09-25','2013-09-25 00:00:00','2013-09-25 00:00:00',2,'Yes','Yes','Yes','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002122,'2013-09-26','2013-09-26 00:00:00','2013-09-27 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002123,'2013-09-27','2013-09-27 00:00:00','2013-09-28 00:00:00',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002124,'2013-09-28','2013-09-28 00:00:00','2013-10-01 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002125,'2013-09-29','2013-10-01 00:00:00',NULL,2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002126,'2013-09-30','2013-10-01 00:00:00',NULL,2,'No','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002127,'2013-10-01','2013-10-01 00:00:00','2013-10-02 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002128,'2013-10-02','2013-10-02 00:00:00','2013-10-03 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002129,'2013-10-03','2013-10-03 00:00:00','2013-10-04 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002130,'2013-10-04','2013-10-04 00:00:00','2013-10-05 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002131,'2013-10-05','2013-10-06 00:00:00',NULL,2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002132,'2013-10-06','2013-10-06 00:00:00','2013-10-07 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002133,'2013-10-07','2013-10-07 00:00:00','2013-10-07 00:00:00',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002134,'2013-10-08','2013-10-08 00:00:00','2013-10-08 21:57:35',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002135,'2013-10-09','2013-10-09 18:32:25','2013-10-10 13:45:37',2,'Yes','No','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002136,'2013-10-10','2013-10-10 13:45:47','2013-10-11 10:31:43',2,'Yes','Yes','Yes','No','No',NULL);
INSERT INTO "salahtracker" VALUES(2002137,'2013-10-11','2013-10-11 10:31:55','2013-10-12 20:44:25',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002138,'2013-10-12','2013-10-12 20:44:34','2013-10-16 09:53:12',2,'No','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002139,'2013-10-13','2013-10-16 09:53:26','2013-10-16 09:53:26',2,'No','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002140,'2013-10-14','2013-10-16 09:53:40','2013-10-16 09:53:40',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002141,'2013-10-15','2013-10-16 09:53:55','2013-10-16 09:53:55',2,'Yes','No','No','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002142,'2013-10-16','2013-10-16 09:54:02','2013-10-17 10:09:24',2,'No','No','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002143,'2013-10-17','2013-10-17 10:09:31','2013-10-18 11:31:42',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002144,'2013-10-18','2013-10-18 11:31:48','2013-10-20 23:12:40',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002145,'2013-10-19','2013-10-20 23:12:55','2013-10-20 23:12:55',2,'No','Yes','Yes','No','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002146,'2013-10-20','2013-10-20 23:13:06','2013-10-20 23:13:06',2,'Yes','No','No','No','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002147,'2013-10-21','2013-10-21 10:38:55','2013-10-22 11:58:17',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002148,'2013-10-22','2013-10-22 11:58:46','2013-10-23 15:07:19',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002149,'2013-10-23','2013-10-23 15:07:25','2013-10-24 17:28:54',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002150,'2013-10-24','2013-10-24 17:29:04','2013-10-24 23:55:17',2,'Yes','Yes','Yes','Yes','Yes',NULL);
INSERT INTO "salahtracker" VALUES(2002151,'2013-10-25','2013-10-25 12:11:41','2013-10-26 10:07:46',2,'Yes','Yes','Yes','Yes','No',NULL);
INSERT INTO "salahtracker" VALUES(2002152,'2013-10-26','2013-10-26 10:08:40','2013-10-28 08:45:16',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002153,'2013-10-27','2013-10-28 08:45:42','2013-10-28 08:45:42',2,'No','Yes','Yes','Yes','No','Missed Fazr & Isha');
INSERT INTO "salahtracker" VALUES(2002154,'2013-10-28','2013-10-28 08:46:14','2013-10-31 00:05:07',2,'No','Yes','No','Yes','Yes','Missed Fazr
Missed Asr');
INSERT INTO "salahtracker" VALUES(2002155,'2013-10-29','2013-10-31 00:05:47','2013-10-31 00:05:47',2,'Yes','Yes','Yes','Yes','No','Missed Isha');
INSERT INTO "salahtracker" VALUES(2002156,'2013-10-30','2013-10-31 00:06:16','2013-10-31 00:06:16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002157,'2013-10-31','2013-10-31 17:33:27','2013-11-01 00:43:27',2,'Yes','No','Yes','Yes','Yes','Missed Dhuhr');
INSERT INTO "salahtracker" VALUES(2002158,'2013-11-01','2013-11-01 23:08:00','2013-11-01 23:08:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002159,'2013-11-02','2013-11-03 01:47:08','2013-11-03 01:47:18',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002160,'2013-11-03','2013-11-03 22:17:07','2013-11-03 22:17:07',2,'Yes','No','Yes','Yes','Yes','Missed Dhuhr');
INSERT INTO "salahtracker" VALUES(2002161,'2013-11-04','2013-11-05 10:41:43','2013-11-05 10:41:43',2,'No','Yes','No','No','No','Missed Fazr, Asr, Maghrib, Isha');
INSERT INTO "salahtracker" VALUES(2002162,'2013-11-05','2013-11-05 10:41:51','2013-11-06 07:29:21',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002163,'2013-11-06','2013-11-06 07:29:27','2013-11-07 09:30:45',2,'Yes','Yes','Yes','Yes','No','Missed Isha');
INSERT INTO "salahtracker" VALUES(2002164,'2013-11-07','2013-11-07 09:30:57','2013-11-08 22:53:47',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002165,'2013-11-08','2013-11-08 22:54:04','2013-11-08 22:54:04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002166,'2013-11-09','2013-11-10 14:21:28','2013-11-10 14:21:28',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002167,'2013-11-10','2013-11-10 14:21:38','2013-11-11 23:43:57',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002168,'2013-11-11','2013-11-11 23:44:12','2013-11-11 23:44:12',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002169,'2013-11-12','2013-11-12 15:59:22','2013-11-13 00:36:15',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002170,'2013-11-13','2013-11-13 23:52:49','2013-11-13 23:52:49',2,'No','Yes','No','Yes','Yes','Missed Fazr
Missed Asr');
INSERT INTO "salahtracker" VALUES(2002171,'2013-11-14','2013-11-14 11:53:36','2013-11-18 23:11:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002172,'2013-11-15','2013-11-18 23:12:21','2013-11-18 23:12:21',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002173,'2013-11-16','2013-11-18 23:12:46','2013-11-18 23:12:46',2,'Yes','Yes','Yes','Yes','No','Missed Isha');
INSERT INTO "salahtracker" VALUES(2002174,'2013-11-18','2013-11-18 23:13:05','2013-11-18 23:13:05',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002175,'2013-11-17','2013-11-18 23:13:42','2013-11-18 23:13:42',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002176,'2013-11-19','2013-11-19 17:57:59','2013-11-21 23:55:03',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002177,'2013-11-20','2013-11-21 23:55:19','2013-11-21 23:55:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002178,'2013-11-21','2013-11-21 23:55:32','2013-11-25 10:57:37',2,'Yes','Yes','Yes','Yes','No','Missed Isha');
INSERT INTO "salahtracker" VALUES(2002179,'2013-11-22','2013-11-25 10:57:50','2013-11-25 10:57:50',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002180,'2013-11-23','2013-11-25 10:58:05','2013-11-25 10:58:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002181,'2013-11-24','2013-11-25 10:58:16','2013-11-25 10:58:16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002182,'2013-11-25','2013-11-25 10:58:28','2013-11-26 10:09:38',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002183,'2013-11-26','2013-11-26 10:09:49','2013-11-28 22:45:01',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002184,'2013-11-27','2013-11-28 22:45:22','2013-11-28 22:45:22',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002185,'2013-11-28','2013-11-28 22:45:41','2013-11-28 22:45:41',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002186,'2013-11-29','2013-12-03 11:46:52','2013-12-03 11:46:52',2,'Yes','No','No','No','No','Missed all prayers except Fazr');
INSERT INTO "salahtracker" VALUES(2002187,'2013-11-30','2013-12-03 11:47:10','2013-12-03 11:47:10',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002188,'2013-12-01','2013-12-03 11:47:34','2013-12-03 11:47:34',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002189,'2013-12-02','2013-12-03 11:47:45','2013-12-03 11:47:45',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002190,'2013-12-03','2013-12-03 11:47:54','2013-12-04 08:52:03',2,'No','Yes','Yes','Yes','No','Missed Fazr
Missed Isha');
INSERT INTO "salahtracker" VALUES(2002191,'2013-12-04','2013-12-04 08:52:12','2013-12-04 22:09:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002192,'2013-12-05','2013-12-05 13:07:44','2013-12-06 16:12:21',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002193,'2013-12-06','2013-12-06 16:12:31','2013-12-07 15:16:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002194,'2013-12-07','2013-12-07 15:21:33','2013-12-08 22:27:42',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002195,'2013-12-08','2013-12-08 22:31:14','2013-12-08 22:31:14',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002196,'2013-12-09','2013-12-09 18:08:09','2013-12-09 18:08:09',2,'No','Yes','Yes','Yes','No','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002197,'2013-12-10','2013-12-10 23:40:45','2013-12-10 23:40:45',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002198,'2013-12-11','2013-12-11 15:24:49','2013-12-12 13:28:18',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002199,'2013-12-12','2013-12-12 13:28:29','2013-12-13 16:43:27',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002200,'2013-12-13','2013-12-13 16:43:38','2013-12-16 18:31:28',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002201,'2013-12-14','2013-12-16 18:31:59','2013-12-16 18:31:59',2,'Yes','Yes','No','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002202,'2013-12-15','2013-12-16 18:33:16','2013-12-17 10:23:47',2,'Yes','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002203,'2013-12-16','2013-12-16 18:33:28','2013-12-16 18:33:28',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002204,'2013-12-17','2013-12-17 10:23:59','2013-12-18 12:47:36',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002205,'2013-12-18','2013-12-18 12:47:49','2013-12-19 00:24:03',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002206,'2013-12-19','2013-12-19 23:01:06','2013-12-19 23:01:06',2,'No','Yes','Yes','Yes','Yes','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002207,'2013-12-20','2013-12-22 23:56:11','2013-12-22 23:56:11',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002208,'2013-12-21','2013-12-22 23:56:31','2013-12-22 23:56:31',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002209,'2013-12-22','2013-12-22 23:56:43','2013-12-22 23:56:43',2,'No','No','No','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002210,'2013-12-23','2013-12-23 17:55:20','2013-12-23 17:55:20',2,'No','Yes','No','Yes','Yes','Missed Fazr
Missed Asr');
INSERT INTO "salahtracker" VALUES(2002211,'2013-12-24','2013-12-26 17:24:02','2013-12-26 17:24:02',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002212,'2013-12-25','2013-12-26 17:24:35','2013-12-26 17:24:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002213,'2013-12-26','2013-12-26 17:24:59','2013-12-27 18:01:35',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002214,'2013-12-27','2013-12-30 08:50:09','2013-12-30 08:50:09',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002215,'2013-12-28','2013-12-30 08:50:22','2013-12-30 08:50:22',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002216,'2013-12-29','2013-12-30 08:50:35','2013-12-30 08:50:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002217,'2013-12-30','2013-12-30 08:51:36','2013-12-31 16:49:34',2,'No','Yes','Yes','Yes','No','Missed Fazr');
INSERT INTO "salahtracker" VALUES(2002218,'2013-12-31','2014-01-03 01:20:54','2014-01-03 01:20:54',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002219,'2014-01-01','2014-01-03 01:22:29','2014-01-03 01:22:29',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002220,'2014-01-02','2014-01-03 01:22:59','2014-01-03 01:22:59',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002221,'2014-01-03','2014-01-05 00:34:09','2014-01-05 00:34:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002222,'2014-01-04','2014-01-05 00:36:28','2014-01-05 00:36:28',2,'No','No','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002223,'2014-01-05','2014-01-06 16:30:14','2014-01-06 16:30:14',2,'No','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002224,'2014-01-06','2014-01-06 16:30:24','2014-01-07 00:29:01',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002225,'2014-01-07','2014-01-07 16:04:05','2014-01-07 23:26:05',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002226,'2014-01-08','2014-01-08 21:02:55','2014-01-08 21:02:55',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002227,'2014-01-09','2014-01-09 08:13:53','2014-01-10 00:31:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002228,'2014-01-10','2014-01-10 16:05:44','2014-01-12 02:03:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002229,'2014-01-11','2014-01-12 02:04:10','2014-01-12 02:04:10',2,'No','No','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002230,'2014-01-12','2014-01-12 23:51:21','2014-01-12 23:51:21',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002231,'2014-01-13','2014-01-13 08:27:42','2014-01-14 00:24:15',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002232,'2014-01-14','2014-01-14 17:39:56','2014-01-15 10:16:02',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002233,'2014-01-15','2014-01-15 10:16:07','2014-01-15 22:18:13',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002234,'2014-01-16','2014-01-16 08:42:50','2014-01-16 23:56:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002235,'2014-01-17','2014-01-17 10:07:21','2014-01-19 23:30:38',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002236,'2014-01-18','2014-01-19 23:30:49','2014-01-19 23:30:49',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002237,'2014-01-19','2014-01-19 23:31:01','2014-01-19 23:31:01',2,'No','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002238,'2014-01-20','2014-01-20 23:04:58','2014-01-20 23:04:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002239,'2014-01-21','2014-01-22 12:05:23','2014-01-22 12:05:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002240,'2014-01-22','2014-01-22 12:05:29','2014-01-24 12:31:03',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002241,'2014-01-24','2014-01-24 12:31:10','2014-01-26 22:20:25',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002242,'2014-01-25','2014-01-26 22:20:38','2014-01-26 22:20:38',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002243,'2014-01-26','2014-01-26 22:20:51','2014-01-26 22:20:51',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002244,'2014-01-23','2014-01-26 22:21:22','2014-01-26 22:21:22',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002245,'2014-01-27','2014-01-27 17:52:23','2014-01-28 08:48:15',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002246,'2014-01-28','2014-01-28 08:48:28','2014-01-28 22:35:16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002247,'2014-01-29','2014-01-29 22:23:09','2014-01-29 22:23:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002248,'2014-01-30','2014-01-30 22:12:09','2014-01-30 22:12:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002249,'2014-01-31','2014-01-31 17:31:19','2014-01-31 17:31:19',2,'No','Yes','','','','');
INSERT INTO "salahtracker" VALUES(2002250,'2014-02-01','2014-02-02 23:36:40','2014-02-02 23:36:40',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002251,'2014-02-02','2014-02-02 23:36:50','2014-02-02 23:36:50',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002252,'2014-02-03','2014-02-05 23:03:21','2014-02-05 23:03:37',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002253,'2014-02-04','2014-02-05 23:03:54','2014-02-05 23:03:54',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002254,'2014-02-05','2014-02-05 23:04:12','2014-02-05 23:04:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002255,'2014-02-06','2014-02-07 00:31:14','2014-02-07 00:31:14',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002256,'2014-02-07','2014-02-07 23:21:00','2014-02-07 23:21:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002257,'2014-02-08','2014-02-09 12:43:56','2014-02-09 12:43:56',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002258,'2014-02-09','2014-02-09 12:44:03','2014-02-10 11:46:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002259,'2014-02-10','2014-02-10 11:46:55','2014-02-11 00:17:32',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002260,'2014-02-11','2014-02-12 09:06:20','2014-02-12 09:06:20',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002261,'2014-02-12','2014-02-12 09:06:28','2014-02-13 00:21:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002262,'2014-02-13','2014-02-16 07:12:48','2014-02-16 07:12:48',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002263,'2014-02-14','2014-02-16 07:13:05','2014-02-16 07:13:05',2,'Yes','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002264,'2014-02-15','2014-02-16 07:13:24','2014-02-16 07:13:24',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002265,'2014-02-16','2014-02-16 07:13:32','2014-02-18 16:29:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002266,'2014-02-17','2014-02-18 16:29:40','2014-02-18 16:29:40',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002267,'2014-02-18','2014-02-18 16:29:47','2014-02-19 16:52:48',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002268,'2014-02-19','2014-02-19 16:52:56','2014-02-20 16:38:21',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002269,'2014-02-20','2014-02-20 16:38:33','2014-02-21 00:56:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002270,'2014-02-21','2014-02-23 12:02:54','2014-02-23 12:02:54',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002271,'2014-02-22','2014-02-23 12:03:06','2014-02-23 12:03:06',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002272,'2014-02-23','2014-02-23 12:03:12','2014-02-24 11:42:59',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002273,'2014-02-24','2014-02-24 11:43:05','2014-02-24 23:22:36',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002274,'2014-02-25','2014-02-25 09:42:37','2014-02-25 22:56:31',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002275,'2014-02-26','2014-02-27 11:19:18','2014-02-27 11:19:18',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002276,'2014-02-27','2014-02-27 11:19:24','2014-02-27 22:33:12',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002277,'2014-02-28','2014-02-28 22:18:42','2014-02-28 22:18:42',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002278,'2014-03-01','2014-03-03 08:35:49','2014-03-03 08:35:49',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002279,'2014-03-02','2014-03-03 08:36:04','2014-03-03 08:36:04',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002280,'2014-03-03','2014-03-03 08:36:15','2014-03-03 22:47:25',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002281,'2014-03-04','2014-03-04 09:39:58','2014-03-04 22:45:41',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002282,'2014-03-05','2014-03-06 08:38:17','2014-03-06 08:38:17',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002283,'2014-03-06','2014-03-06 08:38:25','2014-03-08 03:38:04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002284,'2014-03-07','2014-03-08 03:38:19','2014-03-08 03:38:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002285,'2014-03-08','2014-03-10 00:07:27','2014-03-10 00:07:27',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002286,'2014-03-09','2014-03-10 00:07:44','2014-03-10 09:25:17',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002287,'2014-03-10','2014-03-10 09:25:26','2014-03-11 13:10:56',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002288,'2014-03-11','2014-03-11 13:11:57','2014-03-11 22:59:36',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002289,'2014-03-12','2014-03-13 00:07:08','2014-03-13 00:07:08',2,'Yes','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002290,'2014-03-13','2014-03-13 23:51:02','2014-03-13 23:51:02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002291,'2014-03-14','2014-03-16 00:01:38','2014-03-16 00:01:38',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002292,'2014-03-15','2014-03-16 00:01:55','2014-03-16 00:01:55',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002293,'2014-03-16','2014-03-16 20:37:53','2014-03-16 20:37:53',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002294,'2014-03-17','2014-03-18 10:12:13','2014-03-18 10:12:13',2,'Yes','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002295,'2014-03-18','2014-03-18 10:12:20','2014-03-19 12:58:21',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002296,'2014-03-19','2014-03-19 12:58:26','2014-03-20 17:59:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002297,'2014-03-20','2014-03-20 17:59:16','2014-03-21 00:32:01',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002298,'2014-03-21','2014-03-25 14:37:23','2014-03-25 14:37:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002299,'2014-03-22','2014-03-25 14:37:36','2014-03-25 14:37:36',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002300,'2014-03-23','2014-03-25 14:37:52','2014-03-25 14:37:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002301,'2014-03-24','2014-03-25 14:38:09','2014-03-25 14:38:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002302,'2014-03-25','2014-03-25 14:38:20','2014-03-26 23:09:22',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002303,'2014-03-26','2014-03-26 23:09:06','2014-03-26 23:09:06',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002304,'2014-03-27','2014-03-27 17:35:55','2014-03-28 00:17:36',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002305,'2014-03-28','2014-03-29 08:32:40','2014-03-29 08:32:40',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002306,'2014-03-29','2014-03-29 08:32:49','2014-03-31 13:44:19',2,'No','No','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002307,'2014-03-30','2014-03-31 13:44:35','2014-03-31 13:44:35',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002308,'2014-03-31','2014-03-31 13:44:41','2014-04-01 20:06:41',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002309,'2014-04-01','2014-04-01 20:06:49','2014-04-02 00:26:46',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002310,'2014-04-02','2014-04-04 15:24:22','2014-04-04 15:24:22',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002311,'2014-04-03','2014-04-04 15:24:36','2014-04-04 15:24:36',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002312,'2014-04-04','2014-04-04 15:24:47','2014-04-07 14:06:52',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002313,'2014-04-05','2014-04-07 14:07:03','2014-04-07 14:07:03',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002314,'2014-04-06','2014-04-07 14:07:11','2014-04-07 14:07:11',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002315,'2014-04-07','2014-04-07 14:07:16','2014-04-08 13:01:32',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002316,'2014-04-08','2014-04-08 13:14:22','2014-04-09 11:18:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002317,'2014-04-09','2014-04-09 11:19:02','2014-04-09 22:37:27',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002318,'2014-04-10','2014-04-11 16:23:07','2014-04-11 16:23:45',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002319,'2014-04-11','2014-04-11 16:23:30','2014-04-13 12:57:44',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002320,'2014-04-12','2014-04-13 12:57:56','2014-04-13 12:57:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002321,'2014-04-13','2014-04-13 12:58:05','2014-04-14 16:39:19',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002322,'2014-04-14','2014-04-14 16:39:25','2014-04-16 09:36:22',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002323,'2014-04-15','2014-04-16 09:36:35','2014-04-16 09:36:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002324,'2014-04-16','2014-04-16 09:36:43','2014-04-17 16:00:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002325,'2014-04-17','2014-04-17 16:00:56','2014-04-18 12:36:37',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002326,'2014-04-18','2014-04-18 12:36:45','2014-04-21 16:12:42',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002327,'2014-04-19','2014-04-21 16:13:00','2014-04-21 16:13:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002328,'2014-04-20','2014-04-21 16:13:12','2014-04-21 16:13:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002329,'2014-04-21','2014-04-21 16:13:21','2014-04-24 08:25:02',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002330,'2014-04-22','2014-04-22 15:41:33','2014-04-24 08:23:31',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002331,'2014-04-23','2014-04-24 08:23:49','2014-04-24 08:23:49',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002332,'2014-04-24','2014-04-24 08:24:00','2014-04-25 11:45:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002333,'2014-04-25','2014-04-26 12:13:10','2014-04-26 12:13:10',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002334,'2014-04-26','2014-04-26 12:13:17','2014-04-27 09:21:34',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002335,'2014-04-27','2014-04-27 09:21:47','2014-04-29 10:35:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002336,'2014-04-28','2014-04-29 10:35:55','2014-04-29 10:35:55',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002337,'2014-04-29','2014-04-29 10:36:01','2014-04-30 00:38:53',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002338,'2014-04-30','2014-05-01 00:05:01','2014-05-01 00:05:01',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002339,'2014-05-01','2014-05-02 15:42:04','2014-05-02 15:42:04',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002340,'2014-05-02','2014-05-02 15:42:11','2014-05-04 09:55:41',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002341,'2014-05-03','2014-05-04 09:56:00','2014-05-04 09:56:00',2,'No','No','Yes','No','No','');
INSERT INTO "salahtracker" VALUES(2002342,'2014-05-04','2014-05-04 09:56:18','2014-05-06 00:00:01',2,'No','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002343,'2014-05-05','2014-05-06 00:00:14','2014-05-06 00:00:14',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002344,'2014-05-06','2014-05-09 11:43:11','2014-05-09 11:43:11',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002345,'2014-05-07','2014-05-09 11:43:28','2014-05-09 11:43:28',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002346,'2014-05-08','2014-05-09 11:43:42','2014-05-09 11:43:42',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002347,'2014-05-09','2014-05-09 11:43:52','2014-05-11 13:00:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002348,'2014-05-10','2014-05-11 13:01:37','2014-05-11 13:01:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002349,'2014-05-11','2014-05-11 13:01:44','2014-05-12 11:19:01',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002350,'2014-05-12','2014-05-12 11:19:07','2014-05-13 00:10:16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002351,'2014-05-13','2014-05-13 16:15:08','2014-05-14 12:06:20',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002352,'2014-05-14','2014-05-14 12:06:12','2014-05-15 12:03:15',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002353,'2014-05-15','2014-05-15 12:03:20','2014-05-17 03:13:31',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002354,'2014-05-16','2014-05-17 03:13:44','2014-05-17 03:13:44',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002355,'2014-05-17','2014-05-19 09:07:24','2014-05-19 09:07:24',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002356,'2014-05-18','2014-05-19 09:07:35','2014-05-19 09:07:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002357,'2014-05-19','2014-05-19 09:07:43','2014-05-20 07:53:26',2,'No','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002358,'2014-05-20','2014-05-21 12:41:25','2014-05-21 12:41:25',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002359,'2014-05-21','2014-05-21 12:41:30','2014-05-22 22:43:03',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002360,'2014-05-22','2014-05-22 22:43:15','2014-05-22 22:43:15',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002361,'2014-05-23','2014-05-27 12:27:47','2014-05-27 12:27:47',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002362,'2014-05-24','2014-05-27 12:27:57','2014-05-27 12:27:57',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002363,'2014-05-25','2014-05-27 12:28:12','2014-05-27 12:28:12',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002364,'2014-05-26','2014-05-27 12:28:31','2014-05-27 12:28:31',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002365,'2014-05-27','2014-05-27 12:28:40','2014-05-28 15:57:57',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002366,'2014-05-28','2014-05-28 15:58:03','2014-05-29 16:35:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002367,'2014-05-29','2014-05-29 16:35:15','2014-05-31 13:42:25',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002368,'2014-05-30','2014-05-31 13:42:43','2014-05-31 13:42:43',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002369,'2014-05-31','2014-05-31 13:42:50','2014-06-02 11:16:39',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002370,'2014-06-01','2014-06-02 11:17:25','2014-06-02 11:17:25',2,'No','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002371,'2014-06-02','2014-06-02 11:17:31','2014-06-04 23:41:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002372,'2014-06-03','2014-06-04 23:41:26','2014-06-04 23:41:26',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002373,'2014-06-04','2014-06-04 23:41:41','2014-06-04 23:41:41',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002374,'2014-06-05','2014-06-10 10:18:25','2014-06-10 10:18:25',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002375,'2014-06-06','2014-06-10 10:18:37','2014-06-10 10:18:37',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002376,'2014-06-07','2014-06-10 10:18:49','2014-06-10 10:18:49',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002377,'2014-06-08','2014-06-10 10:19:02','2014-06-10 10:19:02',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002378,'2014-06-09','2014-06-10 10:19:14','2014-06-10 10:19:14',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002379,'2014-06-10','2014-06-10 10:19:20','2014-06-16 12:22:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002380,'2014-06-11','2014-06-16 12:28:10','2014-06-16 12:28:10',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002381,'2014-06-12','2014-06-16 12:28:18','2014-06-16 12:28:18',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002382,'2014-06-13','2014-06-16 12:28:35','2014-06-16 12:28:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002383,'2014-06-14','2014-06-16 12:28:48','2014-06-16 12:28:48',2,'No','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002384,'2014-06-15','2014-06-16 12:28:57','2014-06-16 12:28:57',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002385,'2014-06-16','2014-06-16 12:29:04','2014-06-19 11:16:20',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002386,'2014-06-17','2014-06-19 11:16:36','2014-06-19 11:16:36',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002387,'2014-06-18','2014-06-19 11:16:49','2014-06-19 11:16:49',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002388,'2014-06-19','2014-06-19 11:16:56','2014-06-23 12:24:46',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002389,'2014-06-20','2014-06-23 12:24:56','2014-06-23 12:24:56',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002390,'2014-06-21','2014-06-23 12:25:08','2014-06-23 12:25:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002391,'2014-06-22','2014-06-23 12:25:24','2014-06-23 12:25:24',2,'No','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002392,'2014-06-23','2014-06-23 12:25:29','2014-07-02 13:21:16',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002393,'2014-06-24','2014-07-02 13:21:31','2014-07-02 13:21:31',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002394,'2014-06-25','2014-07-02 13:22:11','2014-07-02 13:22:11',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002395,'2014-06-26','2014-07-02 13:22:37','2014-07-02 13:22:37',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002396,'2014-06-27','2014-07-02 13:22:58','2014-07-02 13:22:58',2,'No','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002397,'2014-06-28','2014-07-02 13:23:31','2014-07-02 13:23:31',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002398,'2014-06-29','2014-07-02 13:23:45','2014-07-02 13:23:45',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002399,'2014-06-30','2014-07-02 13:24:05','2014-07-02 13:24:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002400,'2014-07-01','2014-07-02 13:24:28','2014-07-02 13:24:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002401,'2014-07-02','2014-07-02 13:24:34','2014-07-08 16:20:51',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002402,'2014-07-03','2014-07-08 16:21:05','2014-07-08 16:21:05',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002403,'2014-07-04','2014-07-08 16:21:17','2014-07-08 16:21:17',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002404,'2014-07-05','2014-07-08 16:21:31','2014-07-08 16:21:31',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002405,'2014-07-06','2014-07-08 16:21:44','2014-07-08 16:21:44',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002406,'2014-07-07','2014-07-08 16:22:01','2014-07-08 16:22:01',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002407,'2014-07-08','2014-07-08 16:22:09','2014-07-09 16:03:09',2,'Yes','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002408,'2014-07-09','2014-07-09 16:03:17','2014-07-11 16:16:44',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002409,'2014-07-10','2014-07-11 16:16:54','2014-07-11 16:16:54',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002410,'2014-07-11','2014-07-11 16:17:01','2014-07-24 15:27:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002411,'2014-07-12','2014-07-24 15:28:11','2014-07-24 15:28:11',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002412,'2014-07-13','2014-07-24 15:28:23','2014-07-24 15:28:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002413,'2014-07-14','2014-07-24 15:28:38','2014-07-24 15:28:38',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002414,'2014-07-15','2014-07-24 15:28:47','2014-07-24 15:28:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002415,'2014-07-16','2014-07-24 15:28:56','2014-07-24 15:28:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002416,'2014-07-17','2014-07-24 15:29:05','2014-07-24 15:29:05',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002417,'2014-07-18','2014-07-24 15:29:14','2014-07-24 15:29:14',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002418,'2014-07-19','2014-07-24 15:29:30','2014-07-24 15:29:30',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002419,'2014-07-20','2014-07-24 15:29:58','2014-07-24 15:29:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002420,'2014-07-21','2014-07-24 15:30:36','2014-07-24 15:30:36',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002421,'2014-07-22','2014-07-24 15:30:46','2014-07-24 15:30:46',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002422,'2014-07-23','2014-07-24 15:30:55','2014-07-24 15:30:55',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002423,'2014-07-24','2014-07-24 15:31:03','2014-07-24 15:31:03',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002424,'2014-07-25','2014-07-30 15:58:17','2014-07-30 15:58:17',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002425,'2014-07-26','2014-07-30 15:58:25','2014-07-30 15:58:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002426,'2014-07-27','2014-07-30 15:58:35','2014-07-30 15:58:35',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002427,'2014-07-28','2014-07-30 15:58:45','2014-07-30 15:58:45',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002428,'2014-07-29','2014-07-30 15:58:53','2014-07-30 15:58:53',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002429,'2014-07-30','2014-07-30 15:58:59','2014-08-04 06:21:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002430,'2014-07-31','2014-08-04 06:21:34','2014-08-04 06:21:34',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002431,'2014-08-01','2014-08-04 06:21:46','2014-08-04 06:21:46',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002432,'2014-08-02','2014-08-04 06:22:04','2014-08-04 06:22:04',2,'No','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002433,'2014-08-03','2014-08-04 06:22:22','2014-08-04 06:22:22',2,'No','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002434,'2014-08-04','2014-08-04 06:22:32','2014-08-04 23:46:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002435,'2014-08-05','2014-08-06 02:09:36','2014-08-06 02:09:36',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002436,'2014-08-06','2014-08-11 00:02:25','2014-08-11 00:02:25',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002437,'2014-08-07','2014-08-11 00:02:38','2014-08-11 00:02:38',2,'No','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002438,'2014-08-08','2014-08-11 00:02:51','2014-08-11 00:02:51',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002439,'2014-08-09','2014-08-11 00:03:08','2014-08-11 00:03:08',2,'No','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002440,'2014-08-10','2014-08-11 00:03:30','2014-08-11 00:03:30',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002441,'2014-08-11','2014-08-13 21:30:35','2014-08-13 21:30:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002442,'2014-08-12','2014-08-13 21:30:49','2014-08-13 21:30:49',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002443,'2014-08-13','2014-08-13 21:31:03','2014-08-13 21:31:03',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002444,'2014-09-11','2014-09-11 22:48:42','2014-09-11 22:48:42',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002445,'2014-09-10','2014-09-11 22:48:56','2014-09-11 22:48:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002446,'2014-09-09','2014-09-11 22:49:09','2014-09-11 22:49:09',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002447,'2014-09-08','2014-09-11 22:49:23','2014-09-11 22:49:23',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002448,'2014-09-07','2014-09-11 22:49:37','2014-09-11 22:49:37',2,'No','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002449,'2014-09-06','2014-09-11 22:49:53','2014-09-11 22:49:53',2,'No','Yes','Yes','No','No','');
INSERT INTO "salahtracker" VALUES(2002450,'2014-09-05','2014-09-11 22:50:16','2014-09-11 22:50:16',2,'No','Yes','Yes','No','No','');
INSERT INTO "salahtracker" VALUES(2002451,'2014-09-04','2014-09-11 22:50:28','2014-09-11 22:50:28',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002452,'2014-09-03','2014-09-11 22:50:44','2014-09-11 22:50:44',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002453,'2014-09-02','2014-09-11 22:50:57','2014-09-11 22:50:57',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002454,'2014-09-01','2014-09-11 22:51:10','2014-09-11 22:51:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002455,'2014-08-14','2014-09-11 22:52:09','2014-09-11 22:52:09',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002456,'2014-08-15','2014-09-11 22:53:05','2014-09-11 22:53:05',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002457,'2014-08-16','2014-09-11 22:53:23','2014-09-11 22:53:23',2,'No','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002458,'2014-08-17','2014-09-11 22:53:40','2014-09-11 22:53:40',2,'No','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002459,'2014-08-18','2014-09-11 22:54:07','2014-09-11 22:54:07',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002460,'2014-08-19','2014-09-11 22:54:20','2014-09-11 22:54:20',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002461,'2014-08-20','2014-09-11 22:54:36','2014-09-11 22:54:36',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002462,'2014-08-21','2014-09-11 22:59:40','2014-09-11 22:59:40',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002463,'2014-08-22','2014-09-11 22:59:57','2014-09-11 22:59:57',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002464,'2014-08-23','2014-09-11 23:00:13','2014-09-11 23:00:13',2,'No','Yes','No','No','No','');
INSERT INTO "salahtracker" VALUES(2002465,'2014-08-24','2014-09-11 23:00:26','2014-09-11 23:00:26',2,'No','No','Yes','No','No','');
INSERT INTO "salahtracker" VALUES(2002466,'2014-08-25','2014-09-11 23:00:38','2014-09-11 23:00:38',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002467,'2014-08-26','2014-09-11 23:00:57','2014-09-11 23:00:57',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002468,'2014-08-27','2014-09-11 23:01:12','2014-09-11 23:01:12',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002469,'2014-08-28','2014-09-11 23:01:26','2014-09-11 23:01:26',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002470,'2014-08-29','2014-09-11 23:01:46','2014-09-11 23:01:46',2,'No','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002471,'2014-08-30','2014-09-11 23:02:03','2014-09-11 23:03:06',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002472,'2014-08-31','2014-09-11 23:02:19','2014-09-11 23:02:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002473,'2014-09-12','2014-09-15 13:02:23','2014-09-15 13:02:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002474,'2014-09-13','2014-09-15 13:02:33','2014-09-15 13:02:33',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002475,'2014-09-14','2014-09-15 13:02:41','2014-09-15 13:02:41',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002476,'2014-09-15','2014-09-15 13:02:47','2014-09-16 23:29:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002477,'2014-09-16','2014-09-16 23:29:17','2014-09-16 23:29:17',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002478,'2014-09-17','2014-09-22 12:10:58','2014-09-22 12:10:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002479,'2014-09-18','2014-09-22 12:11:29','2014-09-22 12:11:45',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002480,'2014-09-19','2014-09-22 12:11:58','2014-09-22 12:11:58',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002481,'2014-09-20','2014-09-22 12:12:15','2014-09-22 12:12:15',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002482,'2014-09-21','2014-09-22 12:12:28','2014-09-22 12:12:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002483,'2014-09-22','2014-09-22 12:12:34','2014-09-22 22:38:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002484,'2014-09-23','2014-09-25 18:07:28','2014-09-25 18:07:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002485,'2014-09-24','2014-09-25 18:07:46','2014-09-25 18:07:46',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002486,'2014-09-25','2014-09-25 18:08:10','2014-09-29 12:55:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002487,'2014-09-26','2014-09-29 12:55:18','2014-09-29 12:55:18',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002488,'2014-09-27','2014-09-29 12:55:29','2014-09-29 12:55:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002489,'2014-09-28','2014-09-29 12:55:38','2014-09-29 12:55:38',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002490,'2014-09-29','2014-09-29 12:55:43','2014-09-30 09:36:04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002491,'2014-09-30','2014-09-30 09:36:11','2014-09-30 09:36:11',2,'Yes','','','','','');
INSERT INTO "salahtracker" VALUES(2002492,'2014-10-01','2014-10-02 12:40:55','2014-10-02 12:40:55',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002493,'2014-10-02','2014-10-06 07:28:00','2014-10-06 07:28:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002494,'2014-10-03','2014-10-06 07:28:14','2014-10-06 07:28:14',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002495,'2014-10-04','2014-10-06 07:29:09','2014-10-06 07:29:09',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002496,'2014-10-05','2014-10-06 07:31:11','2014-10-06 07:31:11',2,'Yes','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002497,'2014-10-06','2014-10-06 07:31:25','2014-10-07 07:31:08',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002498,'2014-10-07','2014-10-07 07:31:16','2014-10-08 11:00:04',2,'Yes','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002499,'2014-10-08','2014-10-08 11:00:12','2014-10-09 10:02:05',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002500,'2014-10-09','2014-10-09 10:02:17','2014-10-12 15:43:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002501,'2014-10-10','2014-10-12 15:43:43','2014-10-12 15:43:43',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002502,'2014-10-11','2014-10-12 15:44:12','2014-10-12 15:44:12',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002503,'2014-10-12','2014-10-12 15:44:42','2014-10-15 12:22:14',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002504,'2014-10-13','2014-10-15 12:22:24','2014-10-15 12:22:24',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002505,'2014-10-14','2014-10-15 12:22:33','2014-10-15 12:22:33',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002506,'2014-10-15','2014-10-15 12:22:40','2014-10-16 23:02:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002507,'2014-10-16','2014-10-16 23:03:03','2014-10-16 23:03:03',2,'Yes','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002508,'2014-10-17','2014-10-21 11:13:49','2014-10-21 11:13:49',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002509,'2014-10-18','2014-10-21 11:14:02','2014-10-21 11:14:02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002510,'2014-10-19','2014-10-21 11:14:14','2014-10-21 11:14:14',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002511,'2014-10-20','2014-10-21 11:14:35','2014-10-21 11:14:35',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002512,'2014-10-21','2014-10-22 11:16:22','2014-10-22 11:16:22',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002513,'2014-10-22','2014-10-22 11:16:29','2014-10-24 10:53:27',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002514,'2014-10-23','2014-10-24 10:53:44','2014-10-24 10:53:44',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002515,'2014-10-24','2014-10-24 10:53:50','2014-10-27 14:11:50',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002516,'2014-10-25','2014-10-27 14:11:59','2014-10-27 14:11:59',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002517,'2014-10-26','2014-10-27 14:12:06','2014-10-27 14:12:06',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002518,'2014-10-27','2014-10-27 14:12:13','2014-10-29 15:09:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002519,'2014-10-28','2014-10-29 15:09:19','2014-10-29 15:09:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002520,'2014-10-29','2014-10-29 15:09:30','2014-11-05 18:00:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002521,'2014-10-30','2014-11-05 18:01:15','2014-11-05 18:01:15',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002522,'2014-10-31','2014-11-05 18:01:24','2014-11-05 18:01:24',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002523,'2014-11-01','2014-11-05 18:01:43','2014-11-05 18:01:43',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002524,'2014-11-02','2014-11-05 18:01:51','2014-11-05 18:01:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002525,'2014-11-03','2014-11-05 18:01:58','2014-11-05 18:01:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002526,'2014-11-04','2014-11-05 18:02:05','2014-11-05 18:02:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002527,'2014-11-05','2014-11-05 18:02:12','2014-11-05 18:02:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002528,'2014-11-06','2014-11-10 15:18:25','2014-11-10 15:18:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002529,'2014-11-07','2014-11-10 15:18:41','2014-11-10 15:18:41',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002530,'2014-11-08','2014-11-10 15:18:56','2014-11-10 15:18:56',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002531,'2014-11-09','2014-11-10 15:19:08','2014-11-10 15:19:08',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002532,'2014-11-10','2014-11-10 15:19:18','2014-11-11 08:16:44',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002533,'2014-11-11','2014-11-11 08:16:53','2014-11-13 10:42:48',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002534,'2014-11-12','2014-11-13 10:43:01','2014-11-13 10:43:01',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002535,'2014-11-13','2014-11-13 10:43:13','2014-11-13 10:43:13',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002536,'2014-11-14','2014-11-16 12:27:56','2014-11-16 12:27:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002537,'2014-11-15','2014-11-16 12:28:09','2014-11-16 12:28:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002538,'2014-11-16','2014-11-16 12:28:15','2014-11-20 12:21:15',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002539,'2014-11-17','2014-11-20 12:21:39','2014-11-20 12:21:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002540,'2014-11-18','2014-11-20 12:21:47','2014-11-20 12:21:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002541,'2014-11-19','2014-11-20 12:21:56','2014-11-20 12:21:56',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002542,'2014-11-20','2014-11-20 12:22:00','2014-12-01 11:14:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002543,'2014-11-21','2014-12-01 11:15:12','2014-12-01 11:15:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002544,'2014-11-22','2014-12-01 11:15:27','2014-12-01 11:15:27',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002545,'2014-11-23','2014-12-01 11:15:40','2014-12-01 11:15:40',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002546,'2014-11-24','2014-12-01 11:15:55','2014-12-01 11:15:55',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002547,'2014-11-25','2014-12-01 11:16:09','2014-12-01 11:16:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002548,'2014-11-26','2014-12-01 11:16:25','2014-12-01 11:16:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002549,'2014-11-27','2014-12-01 11:16:40','2014-12-01 11:16:40',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002550,'2014-11-28','2014-12-01 11:16:56','2014-12-01 11:16:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002551,'2014-11-30','2014-12-01 11:17:12','2014-12-01 11:17:12',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002552,'2014-11-29','2014-12-01 11:17:39','2014-12-01 11:17:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002553,'2014-12-01','2014-12-01 11:18:20','2014-12-05 07:24:50',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002554,'2014-12-02','2014-12-05 07:25:01','2014-12-05 07:25:01',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002555,'2014-12-03','2014-12-05 07:25:13','2014-12-05 07:25:13',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002556,'2014-12-04','2014-12-05 07:25:26','2014-12-05 07:25:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002557,'2014-12-05','2014-12-05 07:25:35','2014-12-08 10:28:03',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002558,'2014-12-06','2014-12-08 10:28:26','2014-12-08 10:28:26',2,'No','No','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002559,'2014-12-07','2014-12-08 10:28:45','2014-12-08 10:28:45',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002560,'2014-12-08','2014-12-08 10:29:10','2014-12-14 22:54:02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002561,'2014-12-09','2014-12-14 22:54:14','2014-12-14 22:54:14',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002562,'2014-12-10','2014-12-14 22:54:25','2014-12-14 22:54:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002563,'2014-12-11','2014-12-14 22:54:37','2014-12-14 22:54:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002564,'2014-12-12','2014-12-14 22:54:52','2014-12-14 22:54:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002565,'2014-12-13','2014-12-14 22:55:14','2014-12-14 22:55:14',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002566,'2014-12-14','2014-12-14 22:55:26','2014-12-14 22:55:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002567,'2014-12-15','2014-12-15 16:26:46','2014-12-16 15:40:51',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002568,'2014-12-16','2014-12-16 15:40:56','2014-12-17 23:19:11',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002569,'2014-12-17','2014-12-17 23:19:25','2014-12-17 23:19:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002570,'2014-12-18','2014-12-18 08:42:44','2014-12-22 15:58:46',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002571,'2014-12-19','2014-12-22 15:59:01','2014-12-22 15:59:01',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002572,'2014-12-20','2014-12-22 15:59:13','2014-12-22 15:59:13',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002573,'2014-12-21','2014-12-22 16:05:19','2014-12-22 16:05:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002574,'2014-12-22','2014-12-22 16:05:31','2014-12-24 10:08:38',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002575,'2014-12-23','2014-12-24 10:08:49','2014-12-24 10:08:49',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002576,'2014-12-24','2014-12-24 10:08:55','2014-12-26 00:17:40',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002577,'2014-12-25','2014-12-26 00:17:53','2014-12-26 00:17:53',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002578,'2014-12-26','2014-12-28 07:49:45','2014-12-28 07:49:45',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002579,'2014-12-27','2014-12-28 07:49:56','2014-12-28 07:49:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002580,'2014-12-28','2014-12-28 07:50:06','2014-12-29 12:40:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002581,'2014-12-29','2014-12-29 12:40:52','2014-12-31 10:57:18',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002582,'2014-12-30','2014-12-31 10:57:27','2014-12-31 10:57:27',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002583,'2014-12-31','2014-12-31 10:57:34','2015-01-02 13:24:16',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002584,'2015-01-01','2015-01-02 13:24:30','2015-01-02 13:24:30',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002585,'2015-01-02','2015-01-02 13:24:38','2015-01-05 11:17:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002586,'2015-01-03','2015-01-05 11:17:21','2015-01-05 11:17:21',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002587,'2015-01-04','2015-01-05 11:17:32','2015-01-05 11:17:32',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002588,'2015-01-05','2015-01-05 11:17:37','2015-01-05 22:17:47',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002589,'2015-01-06','2015-01-07 12:24:02','2015-01-07 12:24:02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002590,'2015-01-07','2015-01-07 12:24:09','2015-01-07 23:53:54',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002591,'2015-01-08','2015-01-08 22:41:06','2015-01-08 22:41:06',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002592,'2015-01-09','2015-01-10 07:41:33','2015-01-10 07:41:33',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002593,'2015-01-10','2015-01-10 07:41:41','2015-01-13 16:16:57',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002594,'2015-01-11','2015-01-13 16:17:10','2015-01-13 16:17:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002595,'2015-01-12','2015-01-13 16:17:21','2015-01-13 16:17:21',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002596,'2015-01-13','2015-01-17 07:57:27','2015-01-17 07:57:27',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002597,'2015-01-14','2015-01-17 07:57:52','2015-01-17 07:57:52',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002598,'2015-01-15','2015-01-17 07:58:34','2015-01-17 07:58:34',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002599,'2015-01-16','2015-01-17 07:58:46','2015-01-17 07:58:46',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002600,'2015-01-17','2015-01-17 07:58:57','2015-01-19 10:55:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002601,'2015-01-18','2015-01-19 10:55:28','2015-01-19 10:55:28',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002602,'2015-01-19','2015-01-19 10:55:35','2015-01-22 22:20:42',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002603,'2015-01-20','2015-01-22 22:21:20','2015-01-22 22:21:20',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002604,'2015-01-21','2015-01-22 22:21:32','2015-01-22 22:21:32',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002605,'2015-01-22','2015-01-22 22:21:45','2015-01-22 22:21:45',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002606,'2015-01-23','2015-01-27 23:36:14','2015-01-27 23:36:14',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002607,'2015-01-24','2015-01-27 23:36:27','2015-01-27 23:36:27',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002608,'2015-01-25','2015-01-27 23:37:18','2015-01-27 23:37:18',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002609,'2015-01-26','2015-01-27 23:37:33','2015-01-27 23:37:33',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002610,'2015-01-27','2015-01-27 23:37:48','2015-01-27 23:37:48',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002611,'2015-01-28','2015-01-31 08:06:46','2015-01-31 08:06:46',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002612,'2015-01-29','2015-01-31 08:07:00','2015-01-31 08:07:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002613,'2015-01-30','2015-01-31 08:07:13','2015-01-31 08:07:13',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002614,'2015-01-31','2015-01-31 08:07:23','2015-02-04 12:03:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002615,'2015-02-01','2015-02-04 12:03:56','2015-02-04 12:03:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002616,'2015-02-02','2015-02-04 12:04:04','2015-02-04 12:04:04',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002617,'2015-02-03','2015-02-04 12:04:11','2015-02-04 12:04:11',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002618,'2015-02-04','2015-02-04 12:04:16','2015-02-08 22:24:17',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002619,'2015-02-05','2015-02-08 22:24:34','2015-02-08 22:25:24',2,'Yes','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002620,'2015-02-06','2015-02-08 22:25:09','2015-02-08 22:25:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002621,'2015-02-07','2015-02-08 22:25:39','2015-02-08 22:25:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002622,'2015-02-08','2015-02-08 22:25:51','2015-02-08 22:25:51',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002623,'2015-02-09','2015-02-12 22:51:09','2015-02-12 22:51:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002624,'2015-02-10','2015-02-12 22:51:21','2015-02-12 22:51:21',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002625,'2015-02-11','2015-02-12 22:51:33','2015-02-12 22:51:33',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002626,'2015-02-12','2015-02-12 22:51:47','2015-02-12 22:51:47',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002627,'2015-02-13','2015-02-17 23:46:41','2015-02-17 23:46:41',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002628,'2015-02-14','2015-02-17 23:46:55','2015-02-17 23:46:55',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002629,'2015-02-15','2015-02-17 23:47:08','2015-02-17 23:47:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002630,'2015-02-16','2015-02-17 23:47:20','2015-02-17 23:47:20',2,'No','No','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002631,'2015-02-17','2015-02-17 23:47:31','2015-02-19 13:04:07',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002632,'2015-02-18','2015-02-19 13:03:51','2015-02-19 13:03:51',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002633,'2015-02-19','2015-02-22 06:31:04','2015-02-22 06:31:04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002634,'2015-02-20','2015-02-22 06:31:17','2015-02-22 06:31:17',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002635,'2015-02-21','2015-02-22 06:31:29','2015-02-22 06:31:29',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002636,'2015-02-22','2015-02-22 06:31:35','2015-02-24 08:48:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002637,'2015-02-23','2015-02-24 08:48:44','2015-02-24 08:49:01',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002638,'2015-02-24','2015-02-24 08:49:10','2015-03-02 19:07:54',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002639,'2015-02-25','2015-03-02 19:08:08','2015-03-02 19:08:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002640,'2015-02-26','2015-03-02 19:08:19','2015-03-02 19:08:19',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002641,'2015-02-27','2015-03-02 19:08:28','2015-03-02 19:08:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002642,'2015-02-28','2015-03-02 19:08:37','2015-03-02 19:08:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002643,'2015-03-01','2015-03-02 19:08:53','2015-03-02 19:08:53',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002644,'2015-03-02','2015-03-02 19:08:59','2015-03-05 15:52:04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002645,'2015-03-04','2015-03-05 15:51:39','2015-03-05 15:51:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002646,'2015-03-03','2015-03-05 15:51:51','2015-03-05 15:52:17',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002647,'2015-03-05','2015-03-05 18:40:09','2015-03-06 08:55:38',2,'Yes','Yes','No','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002648,'2015-03-09','2015-03-10 10:30:37','2015-03-10 10:30:37',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002649,'2015-03-06','2015-03-10 10:30:55','2015-03-10 10:30:55',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002650,'2015-03-07','2015-03-10 10:31:03','2015-03-10 10:31:03',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002651,'2015-03-08','2015-03-10 10:31:10','2015-03-10 10:31:10',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002652,'2015-03-10','2015-03-10 10:31:17','2015-03-12 11:50:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002653,'2015-03-11','2015-03-12 11:50:49','2015-03-12 11:50:49',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002654,'2015-03-12','2015-03-12 11:50:58','2015-03-13 23:35:32',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002655,'2015-03-13','2015-03-13 23:35:21','2015-03-15 23:34:44',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002656,'2015-03-15','2015-03-15 23:34:21','2015-03-15 23:34:21',2,'No','Yes','Yes','Yes','','');
INSERT INTO "salahtracker" VALUES(2002657,'2015-03-14','2015-03-15 23:34:35','2015-03-15 23:34:35',2,'No','Yes','','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002658,'2015-03-19','2015-03-20 11:47:11','2015-03-20 11:47:11',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002659,'2015-03-20','2015-03-20 11:47:14','2015-03-30 14:58:35',2,'No','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002660,'2015-03-16','2015-03-20 11:47:29','2015-03-20 11:47:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002661,'2015-03-17','2015-03-20 11:47:39','2015-03-20 11:47:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002662,'2015-03-18','2015-03-20 11:47:48','2015-03-20 11:47:48',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002663,'2015-03-30','2015-03-30 14:55:21','2015-03-31 09:20:07',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002664,'2015-03-29','2015-03-30 14:55:30','2015-03-30 14:55:30',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002665,'2015-03-28','2015-03-30 14:55:39','2015-03-30 14:55:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002666,'2015-03-24','2015-03-30 14:56:05','2015-03-30 14:56:05',2,'No','No','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002667,'2015-03-25','2015-03-30 14:56:13','2015-03-30 14:56:13',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002668,'2015-03-26','2015-03-30 14:56:23','2015-03-30 14:56:23',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002669,'2015-03-27','2015-03-30 14:56:30','2015-03-30 14:57:04',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002670,'2015-03-21','2015-03-30 14:56:52','2015-03-30 14:58:48',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002671,'2015-03-22','2015-03-30 14:57:27','2015-03-30 14:57:27',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002672,'2015-03-23','2015-03-30 14:58:02','2015-03-30 14:58:02',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002673,'2015-03-31','2015-03-31 09:19:53','2015-04-02 11:55:14',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002674,'2015-04-01','2015-04-02 11:54:45','2015-04-02 11:54:45',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002675,'2015-04-02','2015-04-02 11:54:51','2015-04-04 06:54:42',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002676,'2015-04-03','2015-04-04 06:54:54','2015-04-04 06:54:54',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002677,'2015-04-04','2015-04-04 06:55:01','2015-04-10 15:35:50',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002678,'2015-04-10','2015-04-10 15:35:44','2015-04-13 00:06:57',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002679,'2015-04-05','2015-04-10 15:36:00','2015-04-10 15:36:00',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002680,'2015-04-06','2015-04-10 15:36:07','2015-04-10 15:36:07',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002681,'2015-04-07','2015-04-10 15:36:15','2015-04-10 15:36:15',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002682,'2015-04-08','2015-04-10 15:36:25','2015-04-10 15:36:25',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002683,'2015-04-09','2015-04-10 15:36:34','2015-04-10 15:36:34',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002684,'2015-04-12','2015-04-13 00:07:08','2015-04-13 00:07:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002685,'2015-04-11','2015-04-13 00:07:23','2015-04-13 00:07:23',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002686,'2015-04-13','2015-04-13 23:24:37','2015-04-14 16:28:58',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002687,'2015-04-14','2015-04-16 12:33:30','2015-04-16 12:33:30',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002688,'2015-04-15','2015-04-16 12:33:43','2015-04-16 12:33:43',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002689,'2015-04-16','2015-04-16 12:33:53','2015-04-22 13:41:44',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002690,'2015-04-17','2015-04-22 13:42:26','2015-04-22 13:42:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002691,'2015-04-18','2015-04-22 13:42:51','2015-04-22 13:42:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002692,'2015-04-19','2015-04-22 13:43:09','2015-04-22 13:43:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002693,'2015-04-20','2015-04-22 13:43:20','2015-04-22 13:43:20',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002694,'2015-04-21','2015-04-22 13:43:36','2015-04-22 13:43:36',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002695,'2015-04-22','2015-04-22 13:43:48','2015-04-24 07:10:13',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002696,'2015-04-23','2015-04-24 07:10:25','2015-04-24 07:10:25',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002697,'2015-04-24','2015-04-24 07:10:31','2015-04-26 06:28:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002698,'2015-04-25','2015-04-26 06:29:08','2015-04-26 06:29:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002699,'2015-04-26','2015-04-26 06:29:15','2015-04-30 12:11:28',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002700,'2015-04-27','2015-04-30 12:11:40','2015-04-30 12:11:40',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002701,'2015-04-28','2015-04-30 12:11:51','2015-04-30 12:11:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002702,'2015-04-29','2015-04-30 12:12:01','2015-04-30 12:12:01',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002703,'2015-04-30','2015-04-30 12:12:25','2015-05-04 10:27:32',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002704,'2015-05-01','2015-05-04 10:26:19','2015-05-04 10:26:19',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002705,'2015-05-02','2015-05-04 10:26:29','2015-05-04 10:26:29',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002706,'2015-05-03','2015-05-04 10:26:40','2015-05-04 10:26:40',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002707,'2015-05-04','2015-05-04 10:26:47','2015-05-05 12:08:58',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002708,'2015-05-05','2015-05-05 12:09:06','2015-05-05 12:09:06',2,'Yes','','','','','');
INSERT INTO "salahtracker" VALUES(2002709,'2015-12-20','2015-12-20 23:01:17','2015-12-20 23:01:17',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002710,'2016-01-01','2016-01-08 14:47:46','2016-01-08 14:47:46',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002711,'2016-01-02','2016-01-08 14:47:58','2016-01-08 14:47:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002712,'2016-01-03','2016-01-08 14:48:09','2016-01-08 14:48:09',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002713,'2016-01-04','2016-01-08 22:17:26','2016-01-08 22:17:26',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002714,'2016-01-05','2016-01-08 22:17:39','2016-01-08 22:17:39',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002715,'2016-01-06','2016-01-08 22:18:17','2016-01-08 22:18:17',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002716,'2016-01-07','2016-01-08 22:18:31','2016-01-08 22:18:31',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002717,'2016-01-08','2016-01-08 22:18:45','2016-01-08 22:18:45',2,'Yes','Yes','No','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002718,'2016-01-30','2016-02-01 16:44:06','2016-02-01 16:44:06',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002719,'2016-01-31','2016-02-01 16:44:36','2016-02-01 16:44:36',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002720,'2016-01-29','2016-02-01 16:44:49','2016-02-01 16:44:49',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002721,'2016-02-07','2016-02-08 16:13:35','2016-02-08 16:13:35',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002722,'2016-02-08','2016-02-12','2016-02-12',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002723,'2016-02-14','2016-02-16','2016-02-16',2,'No','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002724,'2016-02-15','2016-02-16','2016-02-16',2,'No','Yes','Yes','No','No','');
INSERT INTO "salahtracker" VALUES(2002725,'2016-02-16','2016-02-16','2016-03-02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002726,'2016-02-01','2016-02-16','2016-02-16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002727,'2016-02-02','2016-02-16','2016-02-16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002728,'2016-02-03','2016-02-16','2016-02-16',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002729,'2016-03-01','2016-03-02','2016-03-07',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002730,'2016-03-02','2016-03-02','2016-03-04',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002731,'2016-02-04','2016-03-02','2016-03-02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002732,'2016-02-05','2016-03-02','2016-03-02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002733,'2016-02-06','2016-03-02','2016-03-02',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002734,'2016-03-03','2016-03-04','2016-03-04',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002735,'2016-03-04','2016-03-04','2016-03-04',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002736,'2016-03-05','2016-03-07','2016-03-07',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002737,'2016-03-06','2016-03-07','2016-03-07',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002738,'2016-03-07','2016-03-08','2016-03-08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002739,'2016-03-08','2016-03-08','2016-03-09 17:04:58',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002740,'2016-03-09','2016-03-09 17:01:48','2016-03-13 13:40:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002741,'2016-03-13','2016-03-13 13:39:56','2016-03-15 15:24:01',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002742,'2016-03-10','2016-03-15 15:24:51','2016-03-15 15:24:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002743,'2016-03-11','2016-03-15 15:24:51','2016-03-15 15:24:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002744,'2016-03-12','2016-03-15 15:24:51','2016-03-15 15:24:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002745,'2016-03-14','2016-03-15 15:24:51','2016-03-15 15:24:51',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002746,'2016-03-15','2016-03-15 15:24:51','2016-03-19 07:32:08',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002747,'2016-03-18','2016-03-19 07:31:50','2016-03-19 07:31:50',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002748,'2016-03-16','2016-03-19 07:32:50','2016-03-19 07:32:50',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002749,'2016-03-17','2016-03-19 07:32:50','2016-03-19 07:32:50',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002750,'2016-03-28','2016-04-03 10:56:36','2016-04-03 10:56:36',2,'Yes','Yes','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002751,'2016-03-29','2016-04-03 10:56:37','2016-04-03 10:56:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002752,'2016-03-30','2016-04-03 10:56:37','2016-04-03 10:56:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002753,'2016-03-31','2016-04-03 10:56:37','2016-04-03 10:56:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002754,'2016-04-01','2016-04-03 10:56:37','2016-04-03 10:56:37',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002755,'2016-04-02','2016-04-03 10:56:58','2016-04-03 10:56:58',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002756,'2016-04-03','2016-04-03 10:56:58','2016-04-07 10:52:29',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002757,'2016-04-07','2016-04-07 10:50:55','2016-04-17 11:19:50',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002758,'2016-04-06','2016-04-07 10:50:55','2016-04-07 10:50:55',2,'Yes','Yes','Yes','No','Yes','');
INSERT INTO "salahtracker" VALUES(2002759,'2016-04-04','2016-04-07 10:51:51','2016-04-07 10:51:51',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002760,'2016-04-05','2016-04-07 10:51:51','2016-04-07 10:51:51',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002761,'2016-04-08','2016-04-08 15:55:07','2016-04-17 11:20:03',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002762,'2016-04-16','2016-04-17 11:19:19','2016-04-17 11:19:19',2,'No','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002763,'2016-04-17','2016-04-17 11:19:19','2016-04-17 11:19:19',2,'No','0','0','0','0','');
INSERT INTO "salahtracker" VALUES(2002764,'2016-04-09','2016-04-17 11:20:35','2016-04-17 11:20:35',2,'Yes','No','Yes','Yes','No','');
INSERT INTO "salahtracker" VALUES(2002765,'2016-04-10','2016-04-17 11:20:57','2016-04-17 11:20:57',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002766,'2016-04-11','2016-04-17 11:22:05','2016-04-17 11:22:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002767,'2016-04-12','2016-04-17 11:22:05','2016-04-17 11:22:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002768,'2016-04-13','2016-04-17 11:22:05','2016-04-17 11:22:05',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002769,'2016-04-14','2016-04-17 11:22:56','2016-04-17 11:22:56',2,'Yes','Yes','Yes','Yes','Yes','');
INSERT INTO "salahtracker" VALUES(2002770,'2016-04-15','2016-04-17 11:22:56','2016-04-17 11:22:56',2,'Yes','Yes','Yes','Yes','Yes','');
DROP TABLE IF EXISTS "shoppinglist";
CREATE TABLE "shoppinglist" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "itemdesc" text DEFAULT NULL,
  "createddate" text NOT NULL,
  "updateddate" text DEFAULT NULL,
  "user" integer NOT NULL,
  "notes" blob,
  CONSTRAINT "FKSHOPPINGLIST_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
DROP TABLE IF EXISTS "status";
CREATE TABLE "status" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "status" VALUES(1,'Not Started',NULL);
INSERT INTO "status" VALUES(2,'In Progress',NULL);
INSERT INTO "status" VALUES(3,'Pending',NULL);
INSERT INTO "status" VALUES(4,'Completed',NULL);
INSERT INTO "status" VALUES(5,'Cancelled',NULL);
DROP TABLE IF EXISTS "submodule";
CREATE TABLE "submodule" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
  "pagename" text NOT NULL,
  "description" text DEFAULT NULL,
  "module" integer NOT NULL,
  "category" text DEFAULT NULL,
  "createddate" text NOT NULL,
  "updateddate" text NOT NULL,
  CONSTRAINT "FKSMODULE_MODULE" FOREIGN KEY ("module") REFERENCES "module" ("id")
);
INSERT INTO "submodule" VALUES(2,'Tasks','tasks',NULL,2,'tasktype','2012-10-07 09:42:52','2012-10-07 09:42:55');
INSERT INTO "submodule" VALUES(3,'Expenses','expenses',NULL,2,'ecategory','2012-10-07 09:43:09','2012-10-07 09:43:15');
INSERT INTO "submodule" VALUES(4,'Credentials','credentials',NULL,2,'ccategory','2012-10-07 09:43:41','2012-10-07 09:43:44');
INSERT INTO "submodule" VALUES(6,'Weight Recorder','weightrecorder',NULL,4,'member','2012-10-07 09:42:21','2012-10-07 09:42:21');
INSERT INTO "submodule" VALUES(7,'Credit Payment','creditpayment',NULL,4,'creditcard','2012-10-07 09:42:21','2012-10-07 09:42:21');
INSERT INTO "submodule" VALUES(8,'Funds Transfer','fundstransfer',NULL,4,'account','2013-08-21 17:42:55','2013-08-21 17:42:59');
INSERT INTO "submodule" VALUES(9,'URL Store','urlstore','',2,'urltype','2013-09-14 00:33:37','2016-01-04 15:45:10');
INSERT INTO "submodule" VALUES(11,'Salah Timings','salahtimings','',3,'','2013-10-05 09:31:14','2013-10-05 09:31:14');
INSERT INTO "submodule" VALUES(13,'Salah Tracker','salahtracker','',3,'','2013-10-05 09:40:40','2013-10-05 09:40:40');
INSERT INTO "submodule" VALUES(14,'Remainders','remainders','',4,'','2013-10-05 09:42:37','2013-10-05 09:42:37');
INSERT INTO "submodule" VALUES(15,'Biometrics','biometrics','',4,'','2013-10-05 09:43:02','2013-10-05 10:15:19');
INSERT INTO "submodule" VALUES(20,'Online Orders','onlineorders','',4,'','2013-10-05 11:26:40','2013-10-05 11:26:40');
INSERT INTO "submodule" VALUES(21,'Users','users','',6,'','2013-10-08 22:11:40','2013-10-08 22:11:40');
INSERT INTO "submodule" VALUES(22,'Roles','roles','',6,'','2013-10-08 22:25:06','2013-10-08 22:25:06');
INSERT INTO "submodule" VALUES(23,'Modules','modules','',6,'','2013-10-08 22:25:20','2013-10-08 22:25:20');
INSERT INTO "submodule" VALUES(24,'Categories','allcategories','',6,'','2013-10-08 22:25:54','2013-10-08 22:25:54');
INSERT INTO "submodule" VALUES(25,'DB Env Details','dbenvdetails','DB Env Details',8,'','2016-01-04 15:07:24','2016-01-04 15:07:24');
INSERT INTO "submodule" VALUES(26,'Misc','dtasks','Personal App Misc',2,'','2016-01-04 15:24:18','2016-01-04 15:24:18');
INSERT INTO "submodule" VALUES(27,'Requirements','reqmnts','Canopi Requirements',8,'release','2016-03-03','2016-03-03');
INSERT INTO "submodule" VALUES(28,'Circuit','circuitsbynode','',9,'','2016-05-25 13:51:12','2016-05-25 13:51:12');
INSERT INTO "submodule" VALUES(29,'Node','nodesbylocname','',9,'','2016-05-25 13:52:06','2016-05-25 13:52:06');
DROP TABLE IF EXISTS "subsubmodule";
CREATE TABLE "subsubmodule" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name"text NOT NULL,
  "description" text DEFAULT NULL,
  "submodule" integer NOT NULL,
  "createddate" text NOT NULL,
  "updateddate" text NOT NULL,
  CONSTRAINT "FK_SSMODULE_SUBMODULE" FOREIGN KEY ("submodule") REFERENCES "submodule" ("id")
);
INSERT INTO "subsubmodule" VALUES(1,'Add',NULL,5,'2012-10-07 09:44:27','2012-10-07 09:44:30');
INSERT INTO "subsubmodule" VALUES(2,'View',NULL,5,'2012-10-07 09:44:42','2012-10-07 09:44:46');
DROP TABLE IF EXISTS "task";
CREATE TABLE "task" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text NOT NULL,
  "priority" integer NOT NULL,
  "type" integer NOT NULL,
  "user" integer NOT NULL,
  "createddate" text NOT NULL,
  "duedate" text NOT NULL,
  "completeddate" text DEFAULT NULL,
  "status" integer NOT NULL,
  "notes" blob,
  CONSTRAINT "FKTASK_PRIORITY" FOREIGN KEY ("priority") REFERENCES "priority" ("id"),
  CONSTRAINT "FKTASK_STATUS" FOREIGN KEY ("status") REFERENCES "status" ("id"),
  CONSTRAINT "FKTASK_TYPE" FOREIGN KEY ("type") REFERENCES "tasktype" ("id"),
  CONSTRAINT "FKTASK_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "task" VALUES(1001001,'Create roles modules',3,2,1,'2013-08-01','2013-08-16',NULL,1,'');
INSERT INTO "task" VALUES(1001002,'test admin task',2,3,1,'2013-12-08','2013-12-10',NULL,1,'');
INSERT INTO "task" VALUES(2002001,'Find Gastroenterologist',3,2,2,'2013-05-06','2013-05-16','2013-06-26',5,'');
INSERT INTO "task" VALUES(2002002,'Check tag',2,2,2,'2013-05-06','2013-05-08','2013-05-11',4,'if not arrived call Honda carland and check

5/8 - Checked with Honda Carland, Tag is already done, it will come in few days.');
INSERT INTO "task" VALUES(2002003,'Enroll into Honda Carland',1,1,2,'2013-05-06','2013-05-10','2013-06-06',4,'both online and send card');
INSERT INTO "task" VALUES(2002004,'Call about ticket',1,2,2,'2013-05-06','2013-05-15','2013-06-26',4,'');
INSERT INTO "task" VALUES(2002006,'Call Madhu Reddy',1,2,2,'2013-05-06','2013-05-08','2013-05-14',4,'for refill
5/9 - called today and requested to send prescription to Walgreens.

5/14 - picked up medicine from walgreens');
INSERT INTO "task" VALUES(2002007,'Call walmart cc',1,1,2,'2013-05-06','2013-05-09','2013-05-06',4,'Check why i did not get discount of $20 upon opening card

5/6 - $20 will be debited and also late fee of $25 will be waived');
INSERT INTO "task" VALUES(2002008,'Check immigration email',1,3,2,'2013-05-13','2013-05-13','2013-05-14',4,'5/13 - respond by EOD today

5/14 - checked I129 and it has both the addresses');
INSERT INTO "task" VALUES(2002009,'Transfer money',2,1,2,'2013-05-17','2013-05-20','2013-05-24',4,'');
INSERT INTO "task" VALUES(2002010,'Renew Home Lease',1,1,2,'2013-05-28','2013-06-11','2013-07-01',4,'6/14 - Went to leasing office and request to consider reducing rent. Will get reply by next week.

6/30 - Signed docs are submitted to leasing office on sunday at around 2:30 PM');
INSERT INTO "task" VALUES(2002011,'Pay BOA CC bill',2,2,2,'2013-05-28','2013-06-05','2013-05-29',4,'Better balance rewards

5/29 - Paid');
INSERT INTO "task" VALUES(2002012,'Call YMCA',1,1,2,'2013-06-03','2013-06-03','2013-06-23',5,'');
INSERT INTO "task" VALUES(2002013,'Transfer money for Insurance',1,1,2,'2013-06-04','2013-06-17','2013-06-18',4,'SBI - check whether is it ok to send after 15th

6/14 - Transfered 2500');
INSERT INTO "task" VALUES(2002014,'Check error message',1,3,2,'2013-06-07','2013-06-10','2013-06-13',4,'6/7- Check error message email from Bill and should resolve this by monday');
INSERT INTO "task" VALUES(2002015,'Cramer GUI issues email',2,3,2,'2013-06-07','2013-06-10',NULL,5,'6/7- Cramer GUI email from Shankar
6/13 - Asked Bikky to take a look at this issue

6/18 - Bikky is able to replicate and found it is timing out.

Yes I was able to reproduce.
Has anything changed in Weblogic setting compare to other environments?
Query is timing out:

Jun 18, 2013 8:44:31 AM com.cramer.objectmodel.
server.persistence.dao.NodeDAO getCrossConnectDetails
WARNING: SQL ERROR: IO Error: Socket read timed out
Jun 18, 2013 8:44:31 AM com.cramer.core.
common.CramerException <init>
WARNING: Error getting cross connect info

7/9 - off my plate now
');
INSERT INTO "task" VALUES(2002016,'Check 6PM',1,2,2,'2013-06-13','2013-06-21',NULL,5,'Try to buy some gift before Anniversary');
INSERT INTO "task" VALUES(2002017,'Transfer money for loan',2,1,2,'2013-06-17','2013-06-17','2013-06-23',4,'');
INSERT INTO "task" VALUES(2002018,'Check Citi Bank account',1,1,2,'2013-06-17','2014-01-13','2014-03-10',4,'3/19 : Card got cancelled on 3/10 and received check from Citi Bank.

Call Citi Bank tonight and get info to cancel');
INSERT INTO "task" VALUES(2002019,'Call Walmart Credit Card Department',1,1,2,'2013-06-17','2013-06-22','2013-06-17',4,'6/17 - To check about $20 due sent

6/17 - $20 credit will be sent in 10 business days');
INSERT INTO "task" VALUES(2002020,'Kevin email regarding report',2,3,2,'2013-06-18','2013-06-18','2013-06-20',4,'6/18 - Check whether CIR is in Mbps

6/19 - Kevin replied that user do not need any report');
INSERT INTO "task" VALUES(2002021,'Daryl Emux report issue',1,3,2,'2013-06-18','2013-06-19','2013-08-28',4,'6/18 - Had a call today, i need to compare uni inventory report with emux report and should find out why there is a diff in UNI service name (2000 vs 8000)

UNI - 60/KRGN/750855/SB exists in Emux UNI Inv

6/24 - sent an email with analysis');
INSERT INTO "task" VALUES(2002022,'L3 CFM report from Bill',1,3,2,'2013-06-18','2013-06-21',NULL,5,'Need to create a script to delete L3 CFM');
INSERT INTO "task" VALUES(2002023,'Check Tax refunds',3,1,2,'2013-06-20','2013-06-24','2013-06-20',4,'It has been transferred both taxes');
INSERT INTO "task" VALUES(2002024,'UNI Service Activation Status',2,3,2,'2013-06-25','2013-06-27','2013-07-10',4,'6/25 - sent an email to Bikky

7/2 -  sent an email Pankaj & Dinesh saying that it worked using API

7/9 - Pankaj took this AI and will update');
INSERT INTO "task" VALUES(2002025,'Topology Mismatch Report',2,3,2,'2013-06-26','2013-07-01',NULL,5,'6/26 - Check email from Bill for more info
Bill told me it is not required, so changing to pending, may be it is required in future');
INSERT INTO "task" VALUES(2002026,'NMVLAN 4091 Migration',3,3,2,'2013-06-26','2013-07-31',NULL,5,'');
INSERT INTO "task" VALUES(2002027,'Return Cello tape at Walmart',3,1,2,'2013-07-01','2013-07-04','2013-07-03',4,'');
INSERT INTO "task" VALUES(2002028,'Deposit check in BOA',3,1,2,'2013-07-01','2013-07-04','2013-07-05',4,'7/3 - tried today but ATM was not accepting check. Will try tomorrow before 5 PM');
INSERT INTO "task" VALUES(2002029,'Book resistor for car  from Gwinett Nissan dealer',2,1,2,'2013-07-01','2013-07-06',NULL,5,'7/2 - Went to Nissan dealer and booked resistor, bit it is back ordered, dealer will let me know tomorrow i.e. on 7/3.');
INSERT INTO "task" VALUES(2002030,'Hair cut',3,2,2,'2013-07-01','2013-07-07','2013-07-07',4,'');
INSERT INTO "task" VALUES(2002031,'Buy ACT mouth wash',4,2,2,'2013-07-01','2013-07-07','2013-08-24',4,'');
INSERT INTO "task" VALUES(2002032,'Card migration failure',2,3,2,'2013-07-01','2013-07-02','2013-07-17',4,'7/12 - Asked Naren to open a defect on Monday');
INSERT INTO "task" VALUES(2002033,'Sample report for MTSO site types',2,3,2,'2013-07-01','2013-07-02','2013-07-05',4,'');
INSERT INTO "task" VALUES(2002034,'Send cleanup scripts to Chan',3,3,2,'2013-07-01','2013-07-04','2013-07-02',4,'');
INSERT INTO "task" VALUES(2002035,'Aalia Birth Certificate',3,1,2,'2013-07-03','2013-07-10','2013-07-15',4,'7/5 - Order birth certificate today from vitalcheck.com

Order No# 35508949 Pin: 831740');
INSERT INTO "task" VALUES(2002036,'Pay Old Navy CC',3,2,2,'2013-07-05','2013-07-09','2013-07-08',4,'7/8 - Paid today, amount will be deducted from bank account on 7/13');
INSERT INTO "task" VALUES(2002037,'Check for blower motor ordered',3,1,2,'2013-07-10','2013-07-15','2013-07-11',4,'7/10 - Ordered blower motor from partsgeek.com

Order No#
11-8905985');
INSERT INTO "task" VALUES(2002038,'Check comcast plan',2,1,2,'2013-07-16','2013-07-21','2013-09-17',4,'8/21 - I have to call on 9/11 to see whether there is any promotion available

9/11 - Got promotion for 49.93 and i was asked to call again on 9/18 to adjust the bill

9/17 - Called for bill adjustment. I was told that they will call me after 2 hours');
INSERT INTO "task" VALUES(2002039,'drop tmp tables',2,3,2,'2013-07-16','2013-07-20','2013-07-18',4,'from idis_rpt schema in prod');
INSERT INTO "task" VALUES(2002041,'Calculate Zakat & transfer money',1,1,2,'2013-07-18','2013-07-21','2013-08-11',4,'');
INSERT INTO "task" VALUES(2002042,'Pay $50 to Abdul Razzaq',2,5,2,'2013-07-25','2013-07-27','2013-07-25',4,'for Huffaz');
INSERT INTO "task" VALUES(2002043,'Send java material',2,2,2,'2013-07-27','2013-07-29','2013-07-30',4,'to Tony

7/30 - Shared JCF via DB (dropbox)');
INSERT INTO "task" VALUES(2002044,'Rpplan EVC context switch issue',1,3,2,'2013-07-30','2013-07-31','2013-08-14',4,'Check with Pankaj

8/14 - Pankaj will update by Monday (8/19)');
INSERT INTO "task" VALUES(2002045,'Oil Change for both cars',1,1,2,'2013-08-09','2013-08-10','2013-10-26',4,'9/14 - finished for Nissan Altima

10/26 - Complete oil change for Honda O');
INSERT INTO "task" VALUES(2002046,'Visiting Hafsa school',1,1,2,'2013-08-09','2013-08-17','2013-08-18',4,'to submit checks');
INSERT INTO "task" VALUES(2002047,'Call Radha krishna',3,2,2,'2013-08-09','2013-08-13',NULL,5,'');
INSERT INTO "task" VALUES(2002048,'Pay Old Navy CC',3,1,2,'2013-08-15','2013-08-24','2013-08-16',4,'');
INSERT INTO "task" VALUES(2002049,'Pay American Express CC',3,1,2,'2013-08-15','2013-08-24','2013-08-16',4,'');
INSERT INTO "task" VALUES(2002050,'Install Toad in kareems01',3,3,2,'2013-08-19','2013-08-20',NULL,5,'Can not be installed because Toad 9.6.1 in ASC is for 32 bit');
INSERT INTO "task" VALUES(2002051,'Add new car to state farm',2,1,2,'2013-08-19','2013-08-20','2013-08-21',4,'');
INSERT INTO "task" VALUES(2002052,'Call State informing aboutt NL',3,1,2,'2013-08-19','2013-08-26',NULL,5,'8/21 - Added Nissan Leaf to State Farm');
INSERT INTO "task" VALUES(2002053,'Follow up with Renee about Tag',2,1,2,'2013-08-19','2013-08-20',NULL,5,'8/21 - Called today and informed that i dont need HOV tag. I was asked call 5 days before expiry if i dont receive tag');
INSERT INTO "task" VALUES(2002054,'Check with Abdul Razzaq about selling Car',2,1,2,'2013-08-20','2013-08-23','2013-08-22',4,'');
INSERT INTO "task" VALUES(2002055,'Umaiza pics to be given in Pen drive to Abdul Razzaq',2,5,2,'2013-08-20','2013-08-23','2013-08-28',4,'');
INSERT INTO "task" VALUES(2002056,'Pay remaining amt of Old Navy',3,1,2,'2013-08-22','2013-08-30','2013-09-04',4,'9/4 - Paid $2.85 which will be deducted on 9/5');
INSERT INTO "task" VALUES(2002057,'Delete tmp tables from Dev6',2,3,2,'2013-08-27','2013-09-02',NULL,5,'');
INSERT INTO "task" VALUES(2002058,'Create a doc with duas',3,2,2,'2013-09-11','2013-09-30',NULL,1,'');
INSERT INTO "task" VALUES(2002059,'Check comcast bill',2,1,2,'2013-09-26','2013-10-01','2013-10-17',4,'9/26 - Talk to customer care if bill is not adjusted

10/17 - Callled CC today and i was told $19 will be credited to my account with 24-48 hours');
INSERT INTO "task" VALUES(2002060,'Create diet plan for myself',3,2,2,'2013-10-17','2013-10-26','2014-06-16',4,'');
INSERT INTO "task" VALUES(2002061,'Check for Nissan Leaf tag',2,1,2,'2013-10-21','2013-10-26','2013-10-29',4,'10/21 - if not found by 10/23 then call dealer

10/22 - Called Renee today, will call her again tomorrow as she is off to work today.

10/24 - sent text msg to Renee, she replied it will be ready by 11/1
');
INSERT INTO "task" VALUES(2002062,'Nissan Leaf auto pay enrollment',2,1,2,'2013-10-21','2013-10-26','2013-10-22',4,'');
INSERT INTO "task" VALUES(2002063,'Complete pending CMT EMUX report',1,3,2,'2013-10-21','2013-10-24','2013-10-21',4,'');
INSERT INTO "task" VALUES(2002064,'Book 24 hour collection box',3,2,2,'2013-10-22','2013-10-26','2013-12-11',4,'');
INSERT INTO "task" VALUES(2002065,'Check YMail for nissan leaf email',3,1,2,'2013-10-22','2013-10-30','2013-10-31',4,'');
INSERT INTO "task" VALUES(2002066,'Enroll into Electronic Vehicle to get amount',2,1,2,'2013-10-23','2013-11-09','2013-11-22',4,'11/22 - Need to check on 11/27');
INSERT INTO "task" VALUES(2002067,'Prepare home budget',2,6,2,'2013-10-23','2013-10-23',NULL,2,'VIH - P1');
INSERT INTO "task" VALUES(2002071,'Renting Home',2,6,2,'2013-10-23','2014-02-15',NULL,5,'VIH - P5');
INSERT INTO "task" VALUES(2002072,'Pay Old Navy CC',2,1,2,'2013-10-28','2013-10-31','2013-10-31',4,'');
INSERT INTO "task" VALUES(2002073,'Setup Auto Pay for Nissan Leaf',2,1,2,'2013-10-31','2013-11-15','2013-11-15',4,'');
INSERT INTO "task" VALUES(2002074,'Northfulton Bill Pay',2,1,2,'2013-11-06','2013-11-08','2013-11-06',4,'');
INSERT INTO "task" VALUES(2002075,'Call Nissan Leaf Enrollment',2,1,2,'2013-11-26','2013-12-02','2013-12-10',4,'');
INSERT INTO "task" VALUES(2002076,'Call Car Insurance Companies',1,2,2,'2013-05-06','2013-06-04','2013-06-28',4,'Check with State Farm first

6/28 - State farm insurance has been taken');
INSERT INTO "task" VALUES(2002077,'Pay Babies R Us Credit Card Amount',2,1,2,'2013-12-17','2013-12-19','2013-12-19',4,'');
INSERT INTO "task" VALUES(2002078,'Vehicle Registration Renewal',1,1,2,'2014-01-13','2014-01-14','2014-01-14',4,'');
INSERT INTO "task" VALUES(2002079,'Send Cancel letter to Citi Bank',2,2,2,'2014-01-13','2014-01-14','2014-02-05',4,'02/13 - Need to call and check');
INSERT INTO "task" VALUES(2002080,'Call North Fulton to check Bill',1,2,2,'2014-01-13','2014-02-03','2014-02-24',4,'1/13 - Called today and it seems they have submitted claims to CIGNA today itself and asked me to call back after 2/13

2/24 - Called today and paid the bill ($75)');
INSERT INTO "task" VALUES(2002081,'Fill WH',1,3,2,'2014-06-16','2014-06-16','2014-06-16',4,'');
INSERT INTO "task" VALUES(2002082,'Self Evaluation',2,3,2,'2014-06-16','2014-06-18',NULL,5,'');
INSERT INTO "task" VALUES(2002084,'Tax Refund',2,2,2,'2014-06-16','2014-06-18','2014-06-20',4,'6/17 :
Called Tax dept today and got to know that refund money will be deposited into account in 15-30 days');
INSERT INTO "task" VALUES(2002085,'Fill CMPM',2,3,2,'2014-06-17','2014-06-19',NULL,5,'Not required');
INSERT INTO "task" VALUES(2002086,'Call Ahmed friend',1,1,2,'2014-07-08','2014-07-11','2014-07-08',4,'Ask whether i can bring today');
INSERT INTO "task" VALUES(2002087,'Pay CC and transfer money',1,1,2,'2014-07-08','2014-07-09','2014-07-19',4,'');
INSERT INTO "task" VALUES(2002088,'Return Ross item',2,1,2,'2014-07-08','2014-07-11','2014-07-12',4,'');
INSERT INTO "task" VALUES(2002089,'Fill WH',2,3,2,'2014-07-29','2014-07-30','2014-08-07',4,'');
INSERT INTO "task" VALUES(2002090,'Take Dr Appt for Hafsa and Aalia',2,1,2,'2014-07-29','2014-08-08','2014-09-19',4,'Apt is on 9/16');
INSERT INTO "task" VALUES(2002092,'Take Dr Appt from GA Urology',1,2,2,'2014-07-29','2014-07-31','2014-08-29',4,'Appt is on 8/14');
INSERT INTO "task" VALUES(2002093,'Hafsa Passport Renewal',3,1,2,'2014-07-29','2014-08-06','2014-08-07',4,'');
INSERT INTO "task" VALUES(2002095,'Check house loan and Transfer money',1,1,2,'2014-07-29','2014-07-31',NULL,1,'');
INSERT INTO "task" VALUES(2002096,'Call Dr Asher Harolds office to check bill',2,2,2,'2014-08-29','2014-09-02','2014-09-12',4,'');
INSERT INTO "task" VALUES(2002098,'Pay Macys CC',1,1,2,'2014-08-29','2014-08-31','2014-09-18',4,'');
INSERT INTO "task" VALUES(2002099,'Buy Muntakhab Hadith',1,1,2,'2014-08-29','2014-09-17','2014-10-16',4,'');
INSERT INTO "task" VALUES(2002100,'100 dollars for fasting',2,2,2,'2014-09-02','2014-09-12','2014-12-26',4,'');
INSERT INTO "task" VALUES(2002102,'Money Transfer',1,1,2,'2016-04-01 18:26:05','2016-04-03','2016-04-02',4,'');
INSERT INTO "task" VALUES(2002103,'Tax Returns',1,1,2,'2016-04-01 18:26:05','2016-04-04',NULL,1,'');
INSERT INTO "task" VALUES(2002104,'Sending improvements to Zvika',2,3,2,'2016-04-01 18:26:05','2016-04-05','2016-04-11',4,'');
INSERT INTO "task" VALUES(2002105,'Sending meeting invite for Dave',3,3,2,'2016-04-01 18:26:28','2016-04-11',NULL,1,'');
DROP TABLE IF EXISTS "tasktype";
CREATE TABLE "tasktype" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "tasktype" VALUES(1,'Home','Home Desc for Tasks');
INSERT INTO "tasktype" VALUES(2,'Personal','');
INSERT INTO "tasktype" VALUES(3,'Work',NULL);
INSERT INTO "tasktype" VALUES(4,'Technical',NULL);
INSERT INTO "tasktype" VALUES(5,'Misc','Miscellaneous tasks');
INSERT INTO "tasktype" VALUES(6,'VIH','Very Important Home Tasks');
DROP TABLE IF EXISTS "taxreturns";
CREATE TABLE "taxreturns" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "taxyear" text NOT NULL UNIQUE,
  "user" integer NOT NULL,
  "createddate" text NOT NULL,
  "federaltax" text NOT NULL,
  "statetax" text NOT NULL,
  "notes" blob,
  CONSTRAINT "FKTASKRETURNS_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "taxreturns" VALUES(2002001,'2015',2,'2016-04-27 17:13:12','2972','853','');
INSERT INTO "taxreturns" VALUES(2002002,'2009',2,'2016-04-27 17:16:35','2046','-22','');
INSERT INTO "taxreturns" VALUES(2002003,'2010',2,'2016-04-27 17:17:15','1072','1886','');
INSERT INTO "taxreturns" VALUES(2002004,'2011',2,'2016-04-27 17:18:07','988','994','');
INSERT INTO "taxreturns" VALUES(2002005,'2012',2,'2016-04-27 17:18:36','1491','1998','');
INSERT INTO "taxreturns" VALUES(2002006,'2013',2,'2016-04-27 17:22:26','2574','4145','');
INSERT INTO "taxreturns" VALUES(2002007,'2014',2,'2016-04-27 17:22:56','2496','3713','');
DROP TABLE IF EXISTS "totalexpenses";
CREATE TABLE "totalexpenses" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "month" text NOT NULL,
  "year"text NOT NULL,
  "totalamount" real NOT NULL DEFAULT '0.00000',
  "user" bigint(20) NOT NULL,
  CONSTRAINT "FKTOTEXP_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "totalexpenses" VALUES(2002001,'November','2012',1297.15002,2);
INSERT INTO "totalexpenses" VALUES(2002002,'December','2012',1758.47998,2);
INSERT INTO "totalexpenses" VALUES(2002003,'May','2013',781.38,2);
INSERT INTO "totalexpenses" VALUES(2002004,'August','2013',10,2);
INSERT INTO "totalexpenses" VALUES(2002005,'October','2013',0,2);
INSERT INTO "totalexpenses" VALUES(2002006,'November','2013',2027.10999,2);
INSERT INTO "totalexpenses" VALUES(2002007,'December','2013',0,2);
INSERT INTO "totalexpenses" VALUES(2002008,'January','2014',0,2);
INSERT INTO "totalexpenses" VALUES(2002009,'February','2014',48.71,2);
INSERT INTO "totalexpenses" VALUES(2002010,'March','2014',1005.38788,2);
INSERT INTO "totalexpenses" VALUES(2002011,'April','2014',1021.31238,2);
INSERT INTO "totalexpenses" VALUES(2002012,'May','2014',1081.54285,2);
INSERT INTO "totalexpenses" VALUES(2002013,'June','2014',277.311,2);
INSERT INTO "totalexpenses" VALUES(2002014,'September','2014',448.31,2);
INSERT INTO "totalexpenses" VALUES(2002015,'October','2014',948.73529,2);
INSERT INTO "totalexpenses" VALUES(2002016,'November','2014',535.73932,2);
INSERT INTO "totalexpenses" VALUES(2002017,'December','2014',1276.48059,2);
INSERT INTO "totalexpenses" VALUES(2002018,'August','2014',507.8873,2);
INSERT INTO "totalexpenses" VALUES(2002019,'January','2015',881.32593,2);
INSERT INTO "totalexpenses" VALUES(2002020,'February','2015',990.78229,2);
INSERT INTO "totalexpenses" VALUES(2002021,'March','2015',595.92273,2);
INSERT INTO "totalexpenses" VALUES(2002022,'April','2015',874.82001,2);
INSERT INTO "totalexpenses" VALUES(2002023,'May','2015',259.92999,2);
INSERT INTO "totalexpenses" VALUES(2002024,'November','2015',3988.21,2);
INSERT INTO "totalexpenses" VALUES(2002027,'December','2015',672.18,2);
INSERT INTO "totalexpenses" VALUES(2002028,'January','2016',516.8579,2);
INSERT INTO "totalexpenses" VALUES(2002029,'February','2016',854.2727,2);
INSERT INTO "totalexpenses" VALUES(2002030,'March','2016',957.6315,2);
INSERT INTO "totalexpenses" VALUES(2002031,'April','2016',1112.8147,2);
INSERT INTO "totalexpenses" VALUES(2002032,'May','2016',1309.5382,2);
INSERT INTO "totalexpenses" VALUES(2002033,'June','2016',46.54,2);
DROP TABLE IF EXISTS "urlstore";
CREATE TABLE "urlstore" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" blob NOT NULL,
  "urltype" inetger NOT NULL,
  "url" blob NOT NULL,
  "user" integer NOT NULL,
  "createddate" text NOT NULL,
  "updateddate" text DEFAULT NULL,
  "notes" blob,
  CONSTRAINT "FKURLSTORE_URLTYPE" FOREIGN KEY ("urltype") REFERENCES "urltype" ("id"),
  CONSTRAINT "FKURLSTORE_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "urlstore" VALUES(2002001,'Create Passport Photo Online',7,'http://www.passportcorner.com/',2,'2014-01-24','2014-01-24','');
INSERT INTO "urlstore" VALUES(2002002,'Gram Flour Murukulu',1,'http://priyaeasyntastyrecipes.blogspot.com/2009/10/gramflourkadalamaavu-murukku.html',2,'2013-09-13','2013-09-13','');
INSERT INTO "urlstore" VALUES(2002003,'Making Punugulu',1,'http://myworldofrecipes.blogspot.com/2009/05/punugulu.html',2,'2013-09-17','2013-09-17','');
INSERT INTO "urlstore" VALUES(2002004,'Preparing Bread at home',1,'http://www.thekitchn.com/how-to-make-bread-dough-home-h-108807',2,'2013-10-05','2013-10-05','');
INSERT INTO "urlstore" VALUES(2002005,'Appu Series Cartoons',5,'http://www.youtube.com/watch?v=Pz1Y33VT4Rs',2,'2013-10-11','2013-10-11','Probably i would like to download and make a CD/DVD of it');
INSERT INTO "urlstore" VALUES(2002006,'JavaFx/MongoDB',3,'http://architects.dzone.com/articles/developing-sample-todo-desktop',2,'2014-02-06','2014-02-06','');
INSERT INTO "urlstore" VALUES(2002007,'JavaFx Layouts',3,'http://docs.oracle.com/javafx/2/layout/builtin_layouts.htm',2,'2014-02-07','2014-02-07','');
INSERT INTO "urlstore" VALUES(2002008,'JavaFx YouTube Vid',3,'http://www.youtube.com/watch?v=gKU7ZeCNbqU',2,'2014-02-11','2014-02-11','');
INSERT INTO "urlstore" VALUES(2002009,'FXML Link',3,'http://docs.oracle.com/javafx/2/api/javafx/fxml/doc-files/introduction_to_fxml.html#custom_components',2,'2014-02-12','2014-02-12','');
INSERT INTO "urlstore" VALUES(2002010,'JavaFx Getting Started',3,'http://docs.oracle.com/javafx/2/get_started/jfxpub-get_started.htm',2,'2014-02-12','2014-02-12','');
INSERT INTO "urlstore" VALUES(2002011,'Using FXML to create UI',3,'http://docs.oracle.com/javafx/2/get_started/fxml_tutorial.htm',2,'2014-02-12','2014-02-12','');
INSERT INTO "urlstore" VALUES(2002012,'Why use FXML',3,'http://docs.oracle.com/javafx/2/fxml_get_started/why_use_fxml.htm',2,'2014-02-12','2014-02-12','');
INSERT INTO "urlstore" VALUES(2002013,'JavaFx Tutorials',3,'http://edu.makery.ch/',2,'2014-02-20','2014-02-20','');
INSERT INTO "urlstore" VALUES(2002014,'Developing Stock Trader App',3,'https://platform.netbeans.org/tutorials/nbm-javafx.html',2,'2014-02-20','2014-02-20','');
INSERT INTO "urlstore" VALUES(2002015,'15 Nutella REcipes',1,'http://hiconsumption.com/2013/08/sweet-tooth-the-15-best-nutella-recipes-ever/',2,'2014-02-27','2014-02-27','');
INSERT INTO "urlstore" VALUES(2002016,'Nutella Cinnamon Rolls',1,'http://www.gimmesomeoven.com/nutella-cinnamon-rolls-recipe/',2,'2014-02-27','2014-02-27','');
INSERT INTO "urlstore" VALUES(2002017,'Fauzia''s Kitchen',1,'http://www.fauziaskitchenfun.com/',2,'2014-02-27','2014-02-27','');
INSERT INTO "urlstore" VALUES(2002018,'Desktop Organizer - I',7,'http://www.freewaregenius.com/ten-free-tools-to-better-organize-your-desktop-icons/',2,'2014-03-01','2014-03-01','');
INSERT INTO "urlstore" VALUES(2002019,'Desktop Organizer - II',7,'http://www.hongkiat.com/blog/desktop-customization-tools/',2,'2014-03-01','2014-03-01','');
INSERT INTO "urlstore" VALUES(2002020,'Kids games',9,'http://www.knowledgeadventure.com/games/',2,'2014-03-29','2014-03-29','');
INSERT INTO "urlstore" VALUES(2002021,'Kids math',10,'http://www.ixl.com/',2,'2014-03-29','2014-03-29','');
INSERT INTO "urlstore" VALUES(2002022,'Tafheem-ul-Quran',11,'http://tafheem.net/',2,'2014-04-04','2014-04-04','');
INSERT INTO "urlstore" VALUES(2002023,'Learn Arabic Online',12,'http://www.lqtoronto.com/videodl.html',2,'2014-04-04','2014-04-04','');
INSERT INTO "urlstore" VALUES(2002024,'Detox Water',8,'http://everydayroots.com/detox-drink-for-cleansing',2,'2014-05-13','2014-05-13','');
INSERT INTO "urlstore" VALUES(2002025,'FXML Menus',3,'http://java.dzone.com/articles/focus-javafx-2-fxml-netbeans',2,'2014-05-22','2014-05-22','');
INSERT INTO "urlstore" VALUES(2002026,'JavaFx Presentation',3,'https://www.youtube.com/watch?v=j7YWKPT6NV4#t=13',2,'2014-05-22','2014-05-22','');
INSERT INTO "urlstore" VALUES(2002027,'JavaFx Welcome page',3,'https://community.oracle.com/thread/2362147?tstart=0',2,'2014-05-22','2014-05-22','');
INSERT INTO "urlstore" VALUES(2002028,'Java Fx Menus',3,'http://www.javacodegeeks.com/2012/09/pure-java-javafx-20-menus.html',2,'2014-05-22','2014-05-22','');
INSERT INTO "urlstore" VALUES(2002029,'Samsung Galaxy S5',7,'http://www.trustedreviews.com/opinions/galaxy-s5-tips-tricks-and-secret-features',2,'2014-07-12','2014-07-12','');
INSERT INTO "urlstore" VALUES(2002030,'JavaFx Address App',3,'http://code.makery.ch/java/javafx-2-tutorial-intro/',2,'2014-07-14','2014-07-14','');
INSERT INTO "urlstore" VALUES(2002031,'Splitting FXML View and Controllers',3,'http://hkionline.net/blog/splitting-fxml-views-and-controllers',2,'2014-07-14','2014-07-14','');
INSERT INTO "urlstore" VALUES(2002032,'Workout Shoes - 1',7,'http://dailyburn.com/life/tech/best-fitness-sneakers-summer/',2,'2014-09-15','2014-09-15','');
INSERT INTO "urlstore" VALUES(2002033,'Workout Shoes - 2',7,'http://www.fitnessmagazine.com/workout/gear/reviews/shoetopia-the-best-sneakers-for-every-workout/',2,'2014-09-15','2014-09-15','');
INSERT INTO "urlstore" VALUES(2002034,'Nikon D7000',8,'http://oneslidephotography.com/nikon-d7000-tips-and-tricks/',2,'2014-10-01','2014-10-01','');
INSERT INTO "urlstore" VALUES(2002035,'Nikon D7000 Quick Tips',8,'http://farbspiel-photo.com/about/gear/nikon-d7000-quick-tips',2,'2014-10-03','2014-10-03','Nikon D 7000 Tips');
INSERT INTO "urlstore" VALUES(2002036,'Ken Rockwell Tips',8,'http://www.kenrockwell.com/nikon/d7000/users-guide/',2,'2014-10-03','2014-10-03','');
INSERT INTO "urlstore" VALUES(2002037,'Desktop Wallpapers',8,'https://www.google.com/search?q=wallpapers+for+desktop+background&espv=2&biw=1309&bih=714&tbm=isch&imgil=fwZ6oVFmly_C7M%253A%253BpDbizc49AvGLNM%253Bhttp%25253A%25252F%25252Fwww.hdwallpapersfullhd.net%25252Fpersonalize-your-computer-with-desktop-wallpaper%25252F&source=iu&pf=m&fir=fwZ6oVFmly_C7M%253A%252CpDbizc49AvGLNM%252C_&usg=__eJuSISPWfSp98mKGPgGD1wWZOFU%3D&ved=0CDEQyjc&ei=2rA-VLwm1KfIBP7hgJgO#facrc=_&imgdii=_&imgrc=c2DlgQVPOFeq-M%253A%3BKmcR9KzmSezfmM%3Bhttp%253A%252F%252Fcdn.wonderfulengine',2,'2014-10-15','2014-10-15','');
INSERT INTO "urlstore" VALUES(2002038,'Drive Space Finder',8,'https://www.raymond.cc/blog/find-out-what-files-and-folders-are-taking-up-hard-drive-spaces/',2,'2014-10-22','2014-10-22','');
INSERT INTO "urlstore" VALUES(2002039,'Wallpapers',8,'https://www.google.com/search?q=download+wallpapers&espv=2&biw=1273&bih=850&tbm=isch&imgil=H8IyPWsZYA0n6M%253A%253B8denBRG54XqnEM%253Bhttp%25253A%25252F%25252Fwww.toppicturespost.com%25252F2014%25252F10%25252F19%25252Fwallpaper-free-downloads%25252525E2%2525252580%252525258E%25252F&source=iu&pf=m&fir=H8IyPWsZYA0n6M%253A%252C8denBRG54XqnEM%252C_&usg=__BUoBIzYPtoY3ER2yC0CUdyxZkbY%3D&ved=0CGoQyjc&ei=zlxuVKXjKYOSyQSC5YLACw#facrc=_&imgdii=_&imgrc=nWc_rOEmivbIGM%253A%3BQAhC6yLyqliLSM%3Bhttp%253A%252F%',2,'2014-11-20','2014-11-20','');
INSERT INTO "urlstore" VALUES(2002040,'Abahayas Online',8,'http://en.modanisa.com/abayas.htm',2,'2014-12-11','2014-12-11','');
INSERT INTO "urlstore" VALUES(2002041,'Story of Bakhtiyar kaki',13,'https://www.youtube.com/watch?v=ywBylEZ4yTo',2,'2015-01-06','2015-01-06','');
INSERT INTO "urlstore" VALUES(2002042,'Scene Builder Tutorial - 1',3,'http://docs.oracle.com/javafx/scenebuilder/1/user_guide/library-panel.htm',2,'2015-01-22','2015-01-22','');
INSERT INTO "urlstore" VALUES(2002043,'JavaFx Menu YouTube Tutorial',3,'https://www.youtube.com/watch?v=onqVqMIiAG0',2,'2015-01-22','2015-01-22','');
INSERT INTO "urlstore" VALUES(2002044,'Node API',3,'https://platform.netbeans.org/tutorials/nbm-selection-1.html',2,'2015-04-30','2015-04-30','https://platform.netbeans.org/tutorials/nbm-selection-1.html
https://platform.netbeans.org/tutorials/nbm-selection-2.html');
INSERT INTO "urlstore" VALUES(2002045,'Urdu Learning',14,'https://www.youtube.com/results?search_query=learn+urdu+reading',2,'2015-06-02','2015-06-02','https://www.youtube.com/watch?v=wrOdYXzbPFQ

http://www.educationpyramid.com/urdu/beginner-level-course-in-urdu-language-for-non-native-urdu-speaker/');
INSERT INTO "urlstore" VALUES(2002046,'FeedReader JavaFx',3,'https://platform.netbeans.org/tutorials/nbm-feedreader.html',2,'2015-07-02','2015-07-02','');
INSERT INTO "urlstore" VALUES(2002047,'Hafsa fav cartoon',5,'https://www.youtube.com/watch?v=e613hsJh8UU',2,'2015-08-27','2015-08-27','');
INSERT INTO "urlstore" VALUES(2002048,'Building Java Desktop apps - 10/25',3,'https://www.udemy.com/build-a-desktop-application-using-java/',2,'2015-10-25','2015-10-25','');
INSERT INTO "urlstore" VALUES(2002049,'You Too Can Cook',1,'http://www.youtoocancook.net/',2,'2015-11-04','2015-11-04','');
INSERT INTO "urlstore" VALUES(2002050,'Joomla Reference',2,'http://www.reference.joomlademo.de/nav.html?_constants/index.html',2,'2015-12-16 08:45:37','2015-12-16 08:45:37','');
INSERT INTO "urlstore" VALUES(2002051,'How to draw scenery',15,'https://www.youtube.com/watch?v=ISbYWQbUkzo',2,'2015-12-26 09:47:02','2015-12-26 09:47:02','');
INSERT INTO "urlstore" VALUES(2002052,'Peg & Cat',5,'http://www.pbs.org/parents/peg/peg-cat-stick-puppets/',2,'2015-12-26 21:03:39','2015-12-26 21:03:39','');
INSERT INTO "urlstore" VALUES(2002053,'Dynamic tabs',4,'http://www.jankoatwarpspeed.com/dynamic-tabs-using-jquery-why-and-how-to-create-it/',2,'2015-12-30 10:46:42','2015-12-30 10:46:42','');
INSERT INTO "urlstore" VALUES(2002054,'Karam Chutlu',1,'https://www.youtube.com/watch?v=IhtP8e9zdQU',2,'2016-01-26 21:41:14','2016-01-26 21:41:14','');
INSERT INTO "urlstore" VALUES(2002055,'Islamic Bayaans',13,'http://www.minsid.com/',2,'2016-02-14','2016-02-14','');
INSERT INTO "urlstore" VALUES(2002056,'Ek Tukda Zindagi',1,'http://subzerobiker.blogspot.com/',2,'2016-03-04','2016-03-04','');
INSERT INTO "urlstore" VALUES(2002057,'Samosa Folding',1,'https://www.youtube.com/watch?v=jHIcEKy6ihU',2,'2016-03-09 19:11:17','2016-03-09 19:11:17','');
INSERT INTO "urlstore" VALUES(2002058,'Fluffy Heart shaped choclate cakes',1,'https://www.tastemade.com/videos/fluffy-heart-shaped-chocolate-cakes',2,'2016-03-17 17:23:45','2016-03-17 17:23:45','');
INSERT INTO "urlstore" VALUES(2002059,'Chicken Avacado pizza',1,'https://www.facebook.com/buzzfeedtasty/videos/vb.1614251518827491/1725949077657734/?type=2&theater',2,'2016-03-20 19:54:49','2016-03-20 19:55:19','https://www.facebook.com/
buzzfeedtasty/videos/
vb.1614251518827491
/1725949077657734/?type=2&theater');
INSERT INTO "urlstore" VALUES(2002060,'Tiramisu Cake',1,'https://www.youtube.com/watch?v=26bTgepaEv0',2,'2016-03-21 10:58:28','2016-03-21 10:58:28','');
INSERT INTO "urlstore" VALUES(2002061,'Tiramisu using lady fingers',1,'https://www.youtube.com/watch?v=bvVH4Mk2ku4',2,'2016-03-21 17:27:34','2016-03-21 17:27:34','');
INSERT INTO "urlstore" VALUES(2002062,'Raspberry Yogurt Cake',1,'https://www.youtube.com/watch?v=qUcOCne6hIU',2,'2016-03-22 14:24:00','2016-03-22 14:24:00','');
INSERT INTO "urlstore" VALUES(2002063,'Pound Cake',1,'http://www.marthastewart.com/337155/vanilla-pound-cake',2,'2016-03-23 12:02:39','2016-03-23 12:02:39','');
INSERT INTO "urlstore" VALUES(2002064,'YAJSW',3,'http://yajsw.sourceforge.net/',2,'2016-04-01 09:38:51','2016-04-01 09:38:51','Yet Another JSW');
INSERT INTO "urlstore" VALUES(2002065,'Urdu Leraning',14,'https://www.youtube.com/watch?v=d2l-VEx7ysQ&list=PLpIoKKr38VwCp0-FEEdBV2xd7s1Pdmg9C',2,'2016-05-17 23:33:43','2016-05-17 23:33:43','42 Videos');
INSERT INTO "urlstore" VALUES(2002066,'Horizantal Rules',4,'https://css-tricks.com/examples/hrs/',2,'2016-05-27 16:57:27','2016-05-27 16:57:27','');
DROP TABLE IF EXISTS "urltype";
CREATE TABLE "urltype" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "urltype" VALUES(1,'Cooking','Urls related to cooking');
INSERT INTO "urltype" VALUES(2,'Technical','');
INSERT INTO "urltype" VALUES(3,'Technical/Java','');
INSERT INTO "urltype" VALUES(4,'Technical/JavaScript','');
INSERT INTO "urltype" VALUES(5,'Kids/Cartoons','');
INSERT INTO "urltype" VALUES(6,'Technical/Database','');
INSERT INTO "urltype" VALUES(7,'Miscellaneous','');
INSERT INTO "urltype" VALUES(8,'Temp Urls','');
INSERT INTO "urltype" VALUES(9,'Kids/Games','');
INSERT INTO "urltype" VALUES(10,'Kids/Math','');
INSERT INTO "urltype" VALUES(11,'Islam/Quran','');
INSERT INTO "urltype" VALUES(12,'Islam/Arabic','');
INSERT INTO "urltype" VALUES(13,'Islam/Stories','');
INSERT INTO "urltype" VALUES(14,'Islam/Urdu','');
INSERT INTO "urltype" VALUES(15,'Kids/Drawing','');
DROP TABLE IF EXISTS "user";
CREATE TABLE "user" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "username" text NOT NULL,
  "password" text NOT NULL,
  "createddate" text NOT NULL,
  "updateddate" text NOT NULL,
  "tableid" integer NOT NULL
  );
INSERT INTO "user" VALUES(1,'admin','21232f297a57a5a743894a0e4a801fc3','2013-07-30','2013-07-30',1001001);
INSERT INTO "user" VALUES(2,'karims','54f9428421cc56c2a9dd0167dfee0cc3','2013-07-30','2013-08-01',2002001);
DROP TABLE IF EXISTS "user2role";
CREATE TABLE "user2role" (
  "id" integer NOT NULL PRIMARY KEY ,
  "userid" integer NOT NULL,
  "roleid" integer NOT NULL,
  CONSTRAINT "FKUSER2ROLE_ROLE" FOREIGN KEY ("roleid") REFERENCES "role" ("id"),
  CONSTRAINT "FKUSER2ROLE_USER" FOREIGN KEY ("userid") REFERENCES "user" ("id")
);
INSERT INTO "user2role" VALUES(1,1,1);
INSERT INTO "user2role" VALUES(2,2,1);
DROP TABLE IF EXISTS "userdetails";
CREATE TABLE "userdetails" (
  "userid"  integer NOT NULL PRIMARY KEY,
  "firstname" text NOT NULL,
  "lastname" text NOT NULL,
  "emailid" text DEFAULT NULL,
  "phone" text DEFAULT NULL,
  "address" text DEFAULT NULL,
  "city" text DEFAULT NULL,
  "state" text DEFAULT NULL,
  "zip" text DEFAULT NULL,
  CONSTRAINT "FKUSERDETAILS_USERID" FOREIGN KEY ("userid") REFERENCES "user" ("id")
);
INSERT INTO "userdetails" VALUES(1,'Admin','Admin',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "userdetails" VALUES(2,'Kareem','Shaik','mailtokarims@yahoo.com','6789435398','21021 Gardner Drive','Alpharetta','Georgia','30009');
DROP TABLE IF EXISTS "usersettings";
CREATE TABLE "usersettings" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "user" integer NOT NULL,
  "identifier" text NOT NULL,
  "value" text NOT NULL,
  "visible" text DEFAULT NULL,
  "description" blob DEFAULT NULL
 );
INSERT INTO "usersettings" VALUES(1,2,'homepage','123123',NULL,NULL);
INSERT INTO "usersettings" VALUES(2,2,'module','6','yes','Admin Apps');
INSERT INTO "usersettings" VALUES(3,2,'module','2','yes','Personal Apps');
INSERT INTO "usersettings" VALUES(4,2,'module','3','yes','Islamic Apps');
INSERT INTO "usersettings" VALUES(5,2,'module','4','yes','Misc Apps');
INSERT INTO "usersettings" VALUES(6,2,'module','8','yes','Work Apps');
INSERT INTO "usersettings" VALUES(7,2,'submodule','2','yes','Tasks');
INSERT INTO "usersettings" VALUES(8,2,'submodule','3','yes','Expenses');
INSERT INTO "usersettings" VALUES(9,2,'submodule','4','yes','Credentials');
INSERT INTO "usersettings" VALUES(10,2,'submodule','26','yes','Misc');
INSERT INTO "usersettings" VALUES(11,2,'submodule','6','yes','Weight Recorder');
INSERT INTO "usersettings" VALUES(12,2,'submodule','7','yes','Credit Payment');
INSERT INTO "usersettings" VALUES(13,2,'submodule','8','yes','Funds Transfer');
INSERT INTO "usersettings" VALUES(14,2,'submodule','9','yes','URL Store');
INSERT INTO "usersettings" VALUES(15,2,'submodule','11','yes','Salah Timings');
INSERT INTO "usersettings" VALUES(16,2,'submodule','13','yes','Salah Tracker');
INSERT INTO "usersettings" VALUES(17,2,'submodule','14','yes','Remainders');
INSERT INTO "usersettings" VALUES(18,2,'submodule','15','yes','Biometrics');
INSERT INTO "usersettings" VALUES(19,2,'submodule','20','yes','Online Orders');
INSERT INTO "usersettings" VALUES(20,2,'submodule','21','yes','Users');
INSERT INTO "usersettings" VALUES(21,2,'submodule','23','yes','Modules');
INSERT INTO "usersettings" VALUES(22,2,'submodule','24','yes','Categories');
INSERT INTO "usersettings" VALUES(23,2,'submodule','25','yes','ATT');
INSERT INTO "usersettings" VALUES(24,2,'monthlyexpensesyear','2016','','Monthly Expenses Report Year');
INSERT INTO "usersettings" VALUES(25,2,'categorizedexpensesmonth','05',NULL,'Expense Category Month');
INSERT INTO "usersettings" VALUES(26,2,'categorizedexpensesyear','2016',NULL,'Expense Category Year');
INSERT INTO "usersettings" VALUES(27,2,'submodulecategory','3',NULL,'Sub Module Category');
INSERT INTO "usersettings" VALUES(28,2,'weeklyexpensesmonth','05',NULL,'Expense Weekly Month');
INSERT INTO "usersettings" VALUES(29,2,'weeklyexpensesyear','2016',NULL,'Expense Weekly Year');
DROP TABLE IF EXISTS "weightrecorder";
CREATE TABLE "weightrecorder" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "createddate" text NOT NULL,
  "member" integer NOT NULL,
  "user" integer NOT NULL,
  "weight" real DEFAULT NULL,
  "notes"blob DEFAULT NULL,
  CONSTRAINT "FKWEIGHTRECORDER_MEMBER" FOREIGN KEY ("member") REFERENCES "member" ("id"),
  CONSTRAINT "FKWEIGHTRECORDER_USER" FOREIGN KEY ("user") REFERENCES "user" ("id")
);
INSERT INTO "weightrecorder" VALUES(2002001,'2013-07-05',1,2,131,'');
INSERT INTO "weightrecorder" VALUES(2002002,'2013-07-05',2,2,166,'');
INSERT INTO "weightrecorder" VALUES(2002003,'2013-07-05',3,2,38.4,'');
INSERT INTO "weightrecorder" VALUES(2002004,'2013-07-05',4,2,12,'');
INSERT INTO "weightrecorder" VALUES(2002005,'2013-09-17',1,2,127.2,'');
INSERT INTO "weightrecorder" VALUES(2002006,'2013-09-17',2,2,164,'');
INSERT INTO "weightrecorder" VALUES(2002007,'2013-09-17',3,2,39,'');
INSERT INTO "weightrecorder" VALUES(2002008,'2013-09-17',4,2,17.8,'');
INSERT INTO "weightrecorder" VALUES(2002009,'2013-10-24',2,2,159,'');
INSERT INTO "weightrecorder" VALUES(2002010,'2013-11-14',2,2,157.2,'');
INSERT INTO "weightrecorder" VALUES(2002011,'2014-02-23',1,2,126,'');
INSERT INTO "weightrecorder" VALUES(2002012,'2015-12-29 15:56:31',3,2,50,'');
INSERT INTO "weightrecorder" VALUES(2002013,'2015-12-29 18:19:25',1,2,135,'');
INSERT INTO "weightrecorder" VALUES(2002014,'2015-12-29 18:46:48',4,2,26,'');
DROP TABLE IF EXISTS "year";
CREATE TABLE "year" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT ,
  "name" text NOT NULL,
  "description" text DEFAULT NULL
);
INSERT INTO "year" VALUES(1,'2008','2008');
INSERT INTO "year" VALUES(2,'2009','2009');
INSERT INTO "year" VALUES(3,'2010','2010');
INSERT INTO "year" VALUES(4,'2011','2011');
INSERT INTO "year" VALUES(5,'2012','2012');
INSERT INTO "year" VALUES(6,'2013','2013');
INSERT INTO "year" VALUES(7,'2014','2014');
INSERT INTO "year" VALUES(8,'2015','2015');
INSERT INTO "year" VALUES(9,'2016','2016');
