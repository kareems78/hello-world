PHP binaries downloaded from windows.php.net:
"php-5.5.8-nts-Win32-VC11-x86.zip"

Extensions were moved from the ext/ directory to the root
directory to fix problem loading extensions on Windows XP,
see Issue 34 in PHP Desktop:
https://code.google.com/p/phpdesktop/issues/detail?id=34
